const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {coverTarget,workspaceFile}=require('../desktop/policy.cjs');
const root=path.join(__dirname,'../../KisiselAsistan/WorkspaceWeb');
test('shared interface is served only from its own folder',()=>{
  assert.equal(workspaceFile(root,'assistant://workspace/index.html'),path.join(root,'index.html'));
  assert.equal(workspaceFile(root,'assistant://workspace/scripts/core.js'),path.join(root,'scripts','core.js'));
  for(const url of ['assistant://workspace/../secret.txt','assistant://workspace/%2e%2e/secret.txt']){const file=workspaceFile(root,url);assert.ok(file===null||file.startsWith(path.resolve(root)+path.sep));}
  for(const url of ['assistant://workspace/..%2F..%2Fsecret.txt','assistant://workspace/%2E%2E%5Csecret.txt','assistant://other/index.html','https://workspace/index.html'])assert.equal(workspaceFile(root,url),null);
});
test('cover requests only reach Steam and Spotify image servers',()=>{
  assert.equal(coverTarget('https://covers.assistant.local/spotify?u='+encodeURIComponent('https://i.scdn.co/image/abc')),'https://i.scdn.co/image/abc');
  assert.equal(coverTarget('https://covers.assistant.local/spotify?u='+encodeURIComponent('https://evil.test/image/abc')),null);
  assert.equal(coverTarget('https://covers.assistant.local/steam?id=620&u='),'https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/620/header.jpg');
  assert.equal(coverTarget('https://covers.assistant.local/steam?id=620&u='+encodeURIComponent('https://evil.test/a.jpg')),'https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/620/header.jpg');
  assert.equal(coverTarget('https://other.test/steam?id=620'),null);
});
test('shared interface talks through either desktop bridge',()=>{
  const core=fs.readFileSync(path.join(root,'scripts','core.js'),'utf8');
  assert.match(core,/window\.chrome\?\.webview \?\? window\.assistantBridge/);
  assert.doesNotMatch(core,/window\.chrome\.webview\.postMessage/);
  const preload=fs.readFileSync(path.join(__dirname,'../desktop/preload.cjs'),'utf8');
  assert.match(preload,/exposeInMainWorld\('assistantBridge'/);
});
