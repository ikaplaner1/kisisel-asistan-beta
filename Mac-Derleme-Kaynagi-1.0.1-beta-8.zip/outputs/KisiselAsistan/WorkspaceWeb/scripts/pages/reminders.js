"use strict";
// Takvim: Ay / Hafta / Gün / Liste. Bileşen olarak çizilir (Preact + htm).
// Gün ve Hafta görünümünde saatsiz işler üstteki "gün boyu" şeridinde durur; şeritteki bir işi ızgarada
// bir saate sürüklemek aynı kayda saat ekler (hatırlatılır), başka günün şeridine bırakmak gününü değiştirir.
// Boş bir saate tıklamak o saate yeni iş açar (yarım saat hassasiyet, actions.js).

const hourHeight = 44; // hafta görünümünde bir saatin yüksekliği (px)
const firstHour = 0; // ızgara gece yarısından başlar; açılışta sabaha ya da ilk işe kaydırılır
const weekdayNames = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];

// Kategori rengi ve öncelik işareti: renk kategoriyi, "!" yüksek, "↓" düşük önceliği gösterir.
const categories = { Personal: "Kişisel", Work: "İş", School: "Okul", Health: "Sağlık", FreeTime: "Boş vakit" };
const priorityName = (p) => ({ 1: "Düşük", 3: "Yüksek" })[p] || "Normal";
const planClass = (r) => `cat-${r.plan?.category || "Personal"} prio-${r.plan?.priority || 2}`;
const planTitle = (r) => `${r.text} · ${categories[r.plan?.category] || "Kişisel"} · ${priorityName(r.plan?.priority)} öncelik`;
// Metin şablonları için (Günü planla penceresi).
const prioMark = (r) =>
  r.plan?.priority === 3 ? '<span class="prio-mark" aria-label="Yüksek öncelik">!</span>' : r.plan?.priority === 1 ? '<span class="prio-mark low" aria-label="Düşük öncelik">↓</span>' : "";

const CalendarEvent = ({ r }) =>
  html`<button type="button" data-action="reminder-menu" data-id=${r.id} title=${planTitle(r)} class=${`calendar-event ${planClass(r)}` + (r.plan?.certainty === "Flexible" ? " is-flexible" : "")}>
    <span class="event-time"><${PrioMark} r=${r} />${clock(r.due)}</span><span class="event-text">${r.text}</span>
  </button>`;
// Gün boyu şeridindeki saatsiz iş: tıklayınca düzenlenir, sürüklenince saate ya da başka güne taşınır.
const DayTask = ({ t, day }) => {
  const done = t.dailyActivity ? (t.completedDays || []).includes(day) : t.done;
  return html`<button type="button" class=${"day-task" + (t.important ? " is-important" : "") + (done ? " is-done" : "") + (t.dailyActivity ? " is-repeating" : "")} draggable="true" data-pill-task=${t.id} data-action="task-edit" data-id=${t.id}
    title=${(t.important ? "Önemli · " : "") + (t.dailyActivity ? "Tekrarlı iş · bir saate sürüklersen her tekrarına o saat eklenir" : "Düzenlemek için tıkla · bir saate sürükle: saat eklenir")}><span class="day-task-title">${t.title}</span></button>`;
};
// O günün saatsiz işleri: o güne konmuş (ya da son günü o gün olan) tek seferlikler ve o gün tekrar eden işler.
// Geçmiş günlerde tamamlanmış tek seferlikler şeridi doldurmasın diye gösterilmez.
const untimedOn = (key) =>
  state.data.tasks.filter((t) => (t.dailyActivity ? repeatsOn(t, key) : (t.myDay === key || (!t.myDay && t.due === key)) && (!t.done || key >= today())));

function MonthView({ reminders, selected }) {
  const first = new Date(selected.getFullYear(), selected.getMonth(), 1, 12);
  first.setDate(first.getDate() - ((first.getDay() + 6) % 7));
  const cells = Array.from({ length: 42 }, (_, i) => {
    const d = new Date(first);
    d.setDate(d.getDate() + i);
    const key = dayKey(d),
      items = reminders.filter((r) => dayKey(new Date(r.due)) === key).sort((a, b) => new Date(a.due) - new Date(b.due)),
      tasks = untimedOn(key).filter((t) => !t.dailyActivity && !t.done);
    return html`<div key=${key} class=${"day-cell" + (d.getMonth() !== selected.getMonth() ? " outside" : "") + (key === today() ? " today" : "")} data-date=${key} tabindex="0" role="button" aria-label=${d.toLocaleDateString("tr-TR")}>
      <span class="day-number">${d.getDate()}</span>${items.slice(0, 3).map((r) => html`<${CalendarEvent} key=${r.id} r=${r} />`)}
      ${items.length > 3 && html`<small>+${items.length - 3} saatli</small>`}${tasks.length > 0 && html`<small class="day-tasks-count">${tasks.length} saatsiz iş</small>`}
    </div>`;
  });
  return html`<div class="calendar-grid">${weekdayNames.map((x) => html`<div class="weekday" key=${x}>${x}</div>`)}${cells}</div>`;
}
// Çakışan işler üst üste değil yan yana. Saat yarım saatlik hücrelere bölünür: aynı yarım saate düşen birden çok iş
// (14:00 ve 14:15) hücrenin başında aynı hizada yan yana durur, sonraki yarım saattekiler (14:30, 14:45) altta.
// Yarım saat ya da daha kısa işler hücresine oturur (08:15 → 08:00–08:30 hücresi), böylece 08:30'daki işin üstüne
// taşmaz. Uzun işler gerçek saatinde ve boyunda kalır; birbirine değen hücreler ve uzun işler küme olur, kümede her
// biri boş ilk sütuna girer.
function sideBySide(list) {
  const half = hourHeight / 2;
  const slots = new Map();
  for (const r of list) {
    const due = new Date(r.due),
      minutes = r.plan?.durationMinutes || 30,
      exact = (Math.max(0, (due.getHours() - firstHour) * 60 + due.getMinutes()) * hourHeight) / 60,
      slot = Math.floor(exact / half + 1e-6),
      top = minutes <= 30 ? slot * half : exact,
      height = minutes <= 30 ? half - 2 : Math.max(20, (minutes * hourHeight) / 60 - 2);
    if (!slots.has(slot)) slots.set(slot, []);
    slots.get(slot).push({ r, top, height, exact });
  }
  const boxes = [...slots.entries()]
    .map(([slot, items]) => items.length > 1
      ? { items: items.sort((a, b) => a.exact - b.exact), top: slot * half, height: Math.max(...items.map((i) => i.height)), col: 0, cols: 1 }
      : { items, top: items[0].top, height: items[0].height, col: 0, cols: 1 })
    .sort((a, b) => a.top - b.top || b.height - a.height);
  let group = [], ends = [], groupEnd = -1;
  const close = () => group.forEach((b) => (b.cols = ends.length));
  for (const b of boxes) {
    if (b.top >= groupEnd) { close(); group = []; ends = []; }
    let col = ends.findIndex((end) => end <= b.top);
    if (col < 0) col = ends.push(0) - 1;
    ends[col] = b.top + b.height;
    b.col = col;
    group.push(b);
    groupEnd = Math.max(groupEnd, b.top + b.height);
  }
  close();
  return boxes.flatMap((b) => b.items.map((item, i) => ({
    r: item.r, top: b.top, height: item.height,
    left: ((b.col + i / b.items.length) * 100) / b.cols, width: 100 / (b.cols * b.items.length),
  })));
}
function WeekView({ reminders, selected, single = false }) {
  const start = new Date(selected);
  if (!single) start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  const days = Array.from({ length: single ? 1 : 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    return d;
  });
  const hours = Array.from({ length: 24 - firstHour }, (_, i) => firstHour + i);
  // Gün boyu şeridi işler arttıkça takvimi kapatmasın: her günde en fazla 3 (Gün görünümünde 6) iş görünür,
  // önce bitmemiş önemliler, sonra bitmemişler, en son bitenler; fazlası "+N daha". "Tümü" bütün haftayı açar,
  // açıkken şerit en fazla ekranın üçte biri kadar uzar ve kendi içinde kayar.
  const alldayLimit = single ? 6 : 3,
    alldayOpen = !!state.alldayOpen;
  const doneOn = (t, key) => (t.dailyActivity ? (t.completedDays || []).includes(key) : t.done);
  const alldayItems = (key) => untimedOn(key).map((t, i) => ({ t, i, rank: doneOn(t, key) ? 2 : t.important ? 0 : 1 })).sort((a, b) => a.rank - b.rank || a.i - b.i).map((x) => x.t);
  const overflowing = days.some((d) => untimedOn(dayKey(d)).length > alldayLimit);
  const now = new Date(),
    nowTop = ((now.getHours() - firstHour) * 60 + now.getMinutes()) * (hourHeight / 60);
  return html`<div class=${"week-view" + (single ? " day-view" : "")} style=${{ "--hour": hourHeight + "px", "--days": days.length, "--hour-count": 24 - firstHour }}>
    <div class="week-head"><div class="hour-gutter"></div>${days.map((d) => html`<div key=${dayKey(d)} class=${"week-head-day" + (dayKey(d) === today() ? " today" : "")}><small>${weekdayNames[(d.getDay() + 6) % 7]}</small><span>${d.getDate()}</span></div>`)}</div>
    <div class=${"week-allday" + (alldayOpen ? " is-open" : "")}><div class="hour-gutter allday-label">gün boyu
      ${overflowing && html`<${Button} action="allday-toggle" icon=${alldayOpen ? "up" : "down"} cls="text-button allday-toggle" title=${alldayOpen ? "Gün boyu şeridini daralt" : "Bütün saatsiz işleri göster"}>${alldayOpen ? "Daralt" : "Tümü"}<//>`}</div>${days.map((d, i) => {
      const key = dayKey(d),
        items = alldayItems(key),
        hidden = alldayOpen ? 0 : Math.max(0, items.length - alldayLimit);
      return html`<div key=${key} class="allday-cell" data-allday-date=${key}>${(hidden ? items.slice(0, alldayLimit - 1) : items).map((t) => html`<${DayTask} key=${t.id} t=${t} day=${key} />`)}
        ${hidden > 0 && html`<${Button} action="allday-toggle" cls="allday-more" title="Bu haftanın bütün saatsiz işlerini göster">+${hidden + 1} daha<//>`}
        ${i === 0 && days.every((x) => !untimedOn(dayKey(x)).length) && html`<span class="allday-empty">Saatsiz işler burada görünür; birini bir saate sürüklersen saat eklenir.</span>`}</div>`;
    })}</div>
    <div class="week-body"><div class="hours">${hours.map((h) => html`<span key=${h}>${String(h).padStart(2, "0")}:00</span>`)}</div>${days.map((d) => {
      const key = dayKey(d);
      return html`<div key=${key} class=${"week-day" + (key === today() ? " today" : "")} data-week-date=${key} title="Boş bir saate tıklayarak o saate iş ekle">
        ${sideBySide(reminders.filter((r) => dayKey(new Date(r.due)) === key)).map(({ r, top, height, left, width }) =>
          html`<div key=${r.id} class=${"week-event" + (height < 40 ? " is-short" : "") + (width < 100 ? " is-split" : "")} style=${{ top: top + "px", height: height + "px", left: `calc(${left}% + 2px)`, right: "auto", width: `calc(${width}% - 4px)` }}><${CalendarEvent} r=${r} /></div>`)}
        ${key === today() && nowTop >= 0 && html`<div class="now-line" style=${{ top: nowTop + "px" }}></div>`}
      </div>`;
    })}</div>
  </div>`;
}
function ListView({ reminders }) {
  const items = [...reminders].sort((a, b) => new Date(a.due) - new Date(b.due));
  return items.length
    ? html`<div class="rows">${items.map((r) => html`<div key=${r.id} class=${"item-row " + planClass(r)} data-row-reminder=${r.id}>
        <span class=${"cat-dot " + planClass(r)} title=${categories[r.plan?.category] || "Kişisel"}></span><span class="time"><${PrioMark} r=${r} />${clock(r.due)}</span>
        <div class="item-copy"><strong>${r.text}</strong><small>${r.settings?.level === "Adhd" && html`<${Chip} tone="accent">Yapana kadar<//>`}${relativeDay(r.due)} · ${r.plan?.durationMinutes || 30} dk · ${r.plan?.certainty === "Flexible" ? "Saati kayabilir" : "Kesin saat"} · ${categories[r.plan?.category] || "Kişisel"}</small></div>
        <${Button} action="reminder-menu" icon="more" cls="icon-button row-more" data-id=${r.id} aria-label="İşlemler" />
      </div>`)}</div>`
    : html`<${Empty} text="Bu görünümde bekleyen saatli iş yok." />`;
}
function CalendarPage() {
  const reminders = state.data.reminders.filter((r) => !r.done);
  const selected = parseDay(state.day);
  const views = {
    Ay: () => html`<${MonthView} reminders=${reminders} selected=${selected} />`,
    Hafta: () => html`<${WeekView} reminders=${reminders} selected=${selected} />`,
    Gün: () => html`<${WeekView} reminders=${reminders} selected=${selected} single />`,
    Liste: () => html`<${ListView} reminders=${reminders} />`,
  };
  // Hafta iki aya yayılıyorsa başlık iki ayı da yazar (seçili güne göre "Ekim" ya da "Kasım" demesin).
  const monthOf = (d) => d.toLocaleDateString("tr-TR", { month: "long", year: "numeric" });
  const weekStart = new Date(selected);
  weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7));
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);
  const weekTitle = weekStart.getMonth() === weekEnd.getMonth() ? monthOf(weekStart)
    : weekStart.getFullYear() === weekEnd.getFullYear() ? `${weekStart.toLocaleDateString("tr-TR", { month: "long" })} – ${monthOf(weekEnd)}`
    : `${monthOf(weekStart)} – ${monthOf(weekEnd)}`;
  const title =
    state.calendar === "Ay" || state.calendar === "Hafta"
      ? (state.calendar === "Hafta" ? weekTitle : monthOf(selected))
      : state.calendar === "Liste" ? "Bekleyen bütün saatli işler" : selected.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" });
  const label = selected.toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" });
  return html`
    <${Heading} title="Takvim" sub="Saatli işlerin ızgarada, saatsizler gün boyu şeridinde."><${Button} action="schedule-import" icon="folder" cls="ghost" title="Ders programı ya da iş saatlerini dosyadan ekle">İçe aktar<//><${Button} action="reminder-new" icon="plus" cls="primary" data-date=${state.day}>Ekle<//><//>
    <div class="toolbar">
      <div class="date-nav"><${Button} action="day-prev" icon="left" cls="arrow" aria-label="Önceki" /><span class="date">${label}</span><${Button} action="day-next" icon="right" cls="arrow" aria-label="Sonraki" /></div>
      ${state.day !== today() && html`<${Button} action="today" cls="ghost">Bugün<//>`}
      <span class="spacer"></span>
      <div class="segmented" role="group" aria-label="Takvim görünümü">${Object.keys(views).map((t) => html`<${Button} key=${t} action="calendar-mode" cls=${state.calendar === t ? "active" : ""} data-mode=${t} aria-pressed=${state.calendar === t}>${t}<//>`)}</div>
    </div>
    <section class=${"card calendar view-" + (state.calendar === "Ay" ? "month" : state.calendar === "Liste" ? "list" : "week")}>
      <div class="calendar-toolbar"><strong>${title}</strong>
        <div class="calendar-legend" aria-label="Renk açıklaması">${Object.entries(categories).map(([key, name]) => html`<span key=${key}><i class=${"cat-dot cat-" + key}></i>${name}</span>`)}<span><i class="cat-dot is-important-dot"></i>Önemli (gün boyu)</span><span><b class="prio-mark">!</b>Yüksek</span><span><b class="prio-mark low">↓</b>Düşük öncelik</span></div>
      </div>
      ${views[state.calendar]()}
    </section>`;
}
pageComponents.reminders = CalendarPage;
