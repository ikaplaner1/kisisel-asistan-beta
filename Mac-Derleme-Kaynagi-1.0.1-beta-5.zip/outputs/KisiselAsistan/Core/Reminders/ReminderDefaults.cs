namespace KisiselAsistan;

public sealed class ReminderDefaults
{
    private readonly JsonListStore<ReminderOptions> store;
    public ReminderOptions Options { get; private set; }
    public event Action? Changed;
    public static string PathName => DeploymentPaths.Data("reminder-defaults.json");
    public ReminderDefaults(string? path = null)
    {
        store = new(path ?? PathName);
        Options = store.Read().FirstOrDefault()?.Normalize() ?? new();
        Options.Validate();
    }
    public void Set(ReminderOptions options)
    {
        options.Validate();
        if (Options == options) return;
        store.Modify(_ => [options]); Options = options; Changed?.Invoke();
    }
}
