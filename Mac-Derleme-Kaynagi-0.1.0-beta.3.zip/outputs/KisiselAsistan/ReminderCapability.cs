using System.Text.RegularExpressions;

namespace KisiselAsistan;

public sealed class ReminderCapability(IReminderService reminders) : ICapability
{
    public string Name => "Hatırlatıcı";
    public bool CanHandle(string command) => Regex.IsMatch(command.Trim(), @"(?:hatırlat|hatırlatıcı(?:\s+(?:kur|ayarla|oluştur))?)[.!?]*$", RegexOptions.IgnoreCase);
    public CommandResult Execute(string command)
    {
        command = command.Trim().TrimEnd('.', '!', '?');
        var shortForm = Regex.Match(command, @"^(.+?)\s+(saniye|dakika|saat)(?:lik|lık)?\s+hatırlatıcı(?:\s+(?:kur|ayarla|oluştur))?$", RegexOptions.IgnoreCase);
        if (shortForm.Success) command = $"{shortForm.Groups[1].Value} {shortForm.Groups[2].Value} sonra Hatırlatma zamanı hatırlat";
        command = NormalizeDuration(command);
        var match = Regex.Match(command.Trim(), @"^(\d+)\s+(saniye|dakika|saat)\s+sonra\s+(.+?)\s+hatırlat$", RegexOptions.IgnoreCase);
        if (!match.Success) return new(false, "Örnek: 10 saniye hatırlatıcı veya 10 dakika sonra mola vermemi hatırlat.");
        if (!int.TryParse(match.Groups[1].Value, out var amount) || amount < 1 || amount > 100000)
            return new(false, "Süre 1 ile 100000 arasında olmalı.");
        var seconds = amount * (match.Groups[2].Value.ToLowerInvariant() switch { "saat" => 3600d, "dakika" => 60d, _ => 1d });
        var due = DateTimeOffset.Now.AddSeconds(seconds);
        reminders.Add(match.Groups[3].Value, due);
        return new(true, $"Kaydedildi: {due.LocalDateTime:g}");
    }
    public static string NormalizeDuration(string command)
    {
        var match = Regex.Match(command.Trim(), @"^(.+?)\s+(saniye|dakika|saat)\s+sonra\s+", RegexOptions.IgnoreCase);
        if (!match.Success || int.TryParse(match.Groups[1].Value, out _)) return command;
        var words = new Dictionary<string, int> { ["bir"] = 1, ["iki"] = 2, ["üç"] = 3, ["dört"] = 4, ["beş"] = 5, ["altı"] = 6, ["yedi"] = 7, ["sekiz"] = 8, ["dokuz"] = 9, ["on"] = 10, ["yirmi"] = 20, ["otuz"] = 30, ["kırk"] = 40, ["elli"] = 50, ["altmış"] = 60, ["yetmiş"] = 70, ["seksen"] = 80, ["doksan"] = 90 };
        var tokens = match.Groups[1].Value.ToLowerInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (tokens.Length is < 1 or > 2 || tokens.Any(t => !words.ContainsKey(t))) return command;
        if (tokens.Length == 2 && (words[tokens[0]] < 10 || words[tokens[1]] > 9)) return command;
        return tokens.Sum(t => words[t]).ToString() + command.Trim()[match.Groups[1].Length..];
    }
}
