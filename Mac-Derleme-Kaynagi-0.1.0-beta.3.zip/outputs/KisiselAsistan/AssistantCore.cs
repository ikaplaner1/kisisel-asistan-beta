namespace KisiselAsistan;

public interface IOperationOutcome { bool Success { get; } string Message { get; } }
public record CommandResult(bool Success, string Message) : IOperationOutcome;
public interface ICapability
{
    string Name { get; }
    bool CanHandle(string command);
    CommandResult Execute(string command);
}
public sealed class AssistantCore
{
    private readonly List<ICapability> capabilities = [];
    public void Register(ICapability capability) => capabilities.Add(capability);
    public CommandResult Execute(string command)
    {
        command = EnglishCommands.Normalize(command);
        return capabilities.FirstOrDefault(c => c.CanHandle(command))?.Execute(command)
            ?? new(false, "Komut desteklenmiyor. Örnek: Set a timer for ten seconds / 10 saniye hatırlatıcı");
    }
}
