import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const arch=process.argv.includes('--x64')?'x64':'arm64';
const zipOnly=process.argv.includes('--zip-only');
const hostOnly=process.argv.includes('--host-only');
if(process.platform!=='darwin'&&!hostOnly)throw new Error('Mac uygulama paketi macOS makinesinde üretilmelidir. Windows’ta yalnız servis çekirdeğini kontrol etmek için --host-only kullan.');
function run(executable,args,env={}){const result=spawnSync(executable,args,{cwd:root,stdio:'inherit',env:{...process.env,...env}});if(result.error)throw result.error;if(result.status!==0)throw new Error(`${executable} başarısız oldu (${result.status}).`);}
run('dotnet',['build','Host/Assistant.Host.csproj','-c','Release','--configfile','../KisiselAsistan/release.nuget.config']);
run('dotnet',['Host/bin/Release/net10.0/Assistant.Host.dll','--self-test']);
run(process.execPath,['--test','tests/policy.test.cjs','tests/workspace.test.cjs']);
const publish=path.join(root,`work/host-${arch}`);
run('dotnet',['publish','Host/Assistant.Host.csproj','-c','Release','-r',`osx-${arch}`,'--self-contained','true','--configfile','../KisiselAsistan/release.nuget.config','-o',publish,'-p:PublishSingleFile=false','-p:PublishTrimmed=false']);
const client=process.env.ASSISTANT_GITHUB_CLIENT_ID??'';
if(client&&!/^Iv[A-Za-z0-9]{8,62}$/.test(client))throw new Error('GitHub App Client ID geçersiz.');
fs.writeFileSync(path.join(publish,'beta-release.json'),JSON.stringify({repositoryUrl:'https://github.com/ikaplaner1/kisisel-asistan-beta',githubClientId:client}));
const forbidden=/account\.(bin|json)$|client_secret|credentials|reminders\.json|steam-watches|planning-preferences|ollama-settings/i;
for(const entry of fs.readdirSync(publish))if(forbidden.test(entry))throw new Error('Dağıtımda beklenmeyen kişisel dosya var.');
if(hostOnly){console.log(`Mac ${arch} servis çekirdeği hazır; bu bir Mac uygulama kurulumu değildir.`);process.exit(0);}
const builder=path.join(root,'node_modules/electron-builder/cli.js');
const config=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')).build;
// Ortak arayüz (Windows'taki WorkspaceWeb) pakete resources/workspace olarak girer.
const workspace=path.join(root,'../KisiselAsistan/WorkspaceWeb');if(!fs.existsSync(path.join(workspace,'index.html')))throw new Error('Ortak arayüz klasörü bulunamadı: '+workspace);
config.extraResources=[{from:workspace,to:'workspace'},{from:publish,to:'host',filter:['**/*','!**/*.pdb','!runtimes/linux-*/**','!runtimes/win-*/**',`!runtimes/macos-${arch==='arm64'?'x64':'arm64'}/**`]}];config.directories.output=path.join(root,'distribution',arch);
const configPath=path.join(root,'work',`builder-${arch}.json`);fs.writeFileSync(configPath,JSON.stringify(config));
const args=[builder,'--mac',...(zipOnly?['zip']:[]),`--${arch}`,'--publish','never','--config',configPath];
run(process.execPath,args,{CSC_IDENTITY_AUTO_DISCOVERY:'false'});
console.log(`Mac ${arch} paketi oluşturuldu. Gerçek Mac üzerinde kurulum ve izin testleri hâlâ gerekir.`);
