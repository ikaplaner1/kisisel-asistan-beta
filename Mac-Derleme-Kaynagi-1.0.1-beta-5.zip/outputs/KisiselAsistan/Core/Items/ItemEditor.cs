namespace KisiselAsistan;

// Tek görev formunun verisi. Görev ve hatırlatıcı aynı formdur: saat (TimeMinutes) verilirse o saatte hatırlatılır.
// Day: günü (tekrarlıysa başlangıcı); null ve tekrar yoksa "bir ara". RepeatDays: haftanın günleri (0 = tekrar yok, 127 = her gün).
// EditingDay: tekrarlı işin hangi gününden düzenlendiği; verilirse "bu ve sonraki günler" değişir, öncesi olduğu gibi kalır.
public record ItemForm(
    Guid? Id,
    string Title,
    DateOnly? Day = null,
    int? TimeMinutes = null,
    int RepeatDays = 0,
    int Priority = 2,
    PlanCategory Category = PlanCategory.Personal,
    int DurationMinutes = 30,
    bool Flexible = false,
    bool RemindDayBefore = false,
    ReminderOptions? Notify = null,
    List<RoutineTaskStep>? Steps = null,
    string List = "Görevler",
    DateOnly? Deadline = null,
    DateOnly? EditingDay = null,
    bool Done = false)
{
    internal void Validate()
    {
        if (string.IsNullOrWhiteSpace(Title) || Title.Trim().Length > 500) throw new ArgumentException("Görevin adını yaz (en fazla 500 karakter).");
        if (RepeatDays is < 0 or > 127) throw new ArgumentException("Tekrar günleri geçersiz.");
        if (TimeMinutes is < 0 or > 1439) throw new ArgumentException("Saat geçersiz.");
        if (DurationMinutes is < 5 or > 720) throw new ArgumentException("Süre 5 ile 720 dakika arasında olmalı.");
        if (Priority is < 1 or > 3) throw new ArgumentException("Öncelik geçersiz.");
        if (!Enum.IsDefined(Category)) throw new ArgumentException("Kategori geçersiz.");
        if (string.IsNullOrWhiteSpace(List) || List.Length > 100) throw new ArgumentException("Liste adı geçersiz.");
        Notify?.Validate();
    }
}

// Formu işe (Item) yazar ve işi forma okur. Saat eklemek/kaldırmak, tekrar açmak/kapatmak kaydın kimliğini değiştirmez.
public sealed class ItemEditor(ItemStore store, Func<Guid, (Guid Item, DateOnly? Day)?> locate, Func<DateTimeOffset>? clock = null)
{
    private DateTimeOffset Now => clock?.Invoke() ?? DateTimeOffset.Now;

    public ItemForm? Get(Guid id)
    {
        var items = store.Read();
        var item = items.FirstOrDefault(i => i.Id == id);
        DateOnly? day = null;
        if (item is null && locate(id) is { } found) { item = items.FirstOrDefault(i => i.Id == found.Item); day = found.Day; }
        if (item is null) return null;
        int? minutes = item.Repeat?.TimeMinutes ?? (item.At is { } at ? at.LocalDateTime.Hour * 60 + at.LocalDateTime.Minute : null);
        var shownDay = item.Repeat != null ? day ?? item.Repeat.Start : item.Day ?? (item.At is { } a ? DateOnly.FromDateTime(a.LocalDateTime) : null);
        var done = item.Repeat != null ? day is { } d && item.StateOn(d).Done : item.Done;
        return new(item.Id, item.Title, shownDay, minutes, item.Repeat?.DaysMask ?? 0, item.Priority, item.Category, item.DurationMinutes, item.Flexible,
            item.RemindDayBefore, item.Notify, [.. item.Steps ?? []], item.List, item.Deadline, day, done);
    }

    public Guid Save(ItemForm form)
    {
        form.Validate();
        var now = Now; var today = DateOnly.FromDateTime(now.LocalDateTime);
        var result = Guid.Empty;
        store.Modify(items => {
            Item? existing = null; DateOnly? editingDay = form.EditingDay;
            if (form.Id is Guid id) {
                existing = items.FirstOrDefault(i => i.Id == id);
                if (existing is null && locate(id) is { } found) { existing = items.FirstOrDefault(i => i.Id == found.Item); editingDay ??= found.Day; }
                if (existing is null) throw new InvalidOperationException("Bu kayıt artık yok.");
            }
            var details = (existing ?? new Item(Guid.NewGuid(), form.Title.Trim(), Created: now)) with {
                Title = form.Title.Trim(), List = form.List.Trim(), Steps = form.Steps?.Where(s => !string.IsNullOrWhiteSpace(s.Text)).Select(s => s with { Text = s.Text.Trim() }).ToList(),
                Priority = form.Priority, Category = form.Category, DurationMinutes = form.DurationMinutes, Flexible = form.Flexible,
                RemindDayBefore = form.RemindDayBefore, Notify = form.Notify?.Normalize(), Deadline = form.Deadline
            };
            // Tekrarlı işin ortasındaki bir günden düzenleme: o güne kadarki kısım (ve geçmiş tamamlamalar) yerinde kalır, yeni kısım ayrı kayıt olur.
            if (existing?.Repeat is { } oldRule && editingDay is { } from && from > oldRule.Start) {
                var series = existing.SeriesId ?? existing.Id;
                var ended = existing with { Repeat = oldRule with { Until = from.AddDays(-1) }, SeriesId = series };
                var fresh = Shape(details with { Id = Guid.NewGuid(), Occurrences = null, SeriesId = form.RepeatDays > 0 ? series : null, Created = now, Revision = 0 }, form, null, now, today, from);
                result = fresh.Id;
                return [.. items.Select(i => i.Id == existing.Id ? ended : i), fresh];
            }
            var saved = Shape(details, form, existing, now, today, null);
            result = saved.Id;
            return existing is null ? [.. items, saved] : items.Select(i => i.Id == existing.Id ? saved : i).ToList();
        });
        return result;
    }

    // Formdaki gün/saat/tekrar alanlarına göre işin zaman biçimini kurar.
    private static Item Shape(Item item, ItemForm form, Item? existing, DateTimeOffset now, DateOnly today, DateOnly? splitFrom)
    {
        if (form.RepeatDays > 0) {
            var start = splitFrom ?? form.Day ?? existing?.Repeat?.Start ?? today;
            var sameTime = existing?.Repeat?.TimeMinutes == form.TimeMinutes;
            // Saat değiştiyse gelecekteki günlerin bildirim ilerlemesi geçersizdir; tamamlanan günler korunur.
            var states = existing?.Repeat is null ? null : existing.Occurrences?.Where(o => o.Value.Done || (sameTime && Item.ParseKey(o.Key) < today)).ToDictionary(o => o.Key, o => o.Value);
            return item with { Day = null, At = null, Done = false, State = null, Repeat = new(form.RepeatDays, start, existing?.Repeat?.Until, form.TimeMinutes), Occurrences = states is { Count: > 0 } ? states : null };
        }
        var basis = item with { Repeat = null, Occurrences = null };
        if (form.TimeMinutes is not int minutes) {
            var keepDone = existing is { Repeat: null } && existing.Done && form.Done;
            return basis with { Day = form.Day, At = null, State = null, Done = keepDone || (existing is null && form.Done) };
        }
        var day = form.Day ?? today;
        var local = DateTime.SpecifyKind(day.ToDateTime(TimeOnly.MinValue).AddMinutes(minutes), DateTimeKind.Unspecified);
        if (TimeZoneInfo.Local.IsInvalidTime(local)) local = local.AddHours(1);
        var due = new DateTimeOffset(local, TimeZoneInfo.Local.GetUtcOffset(local));
        if (existing?.At == due && existing.Repeat is null) return basis with { Day = day };
        if (due <= now) throw new ArgumentException("Geçmiş bir saat seçtin; gelecekte bir saat seç.");
        return basis with { Day = day, At = due, Done = false, Revision = item.Revision + 1, State = new(AdvanceSentForDue: due.AddDays(-1) <= now ? due : null) };
    }
}
