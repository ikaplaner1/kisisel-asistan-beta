using System.Diagnostics;
namespace KisiselAsistan;

// Spotify adımı (Kind "spotify"): Target liste adresi, Label liste adı; Shuffle karışık başlatır, Repeat (off/context/track) verilirse tekrar ayarlanır.
public record RoutineStep(string Kind, string Target, string Browser = "default", string? Label = null, int Minutes = 1, bool Shuffle = false, string? Repeat = null);
// Schedule: verilirse kısayol seçili günlerde o saatte (önce bildirimle sorarak) kendiliğinden başlar (RoutineScheduler).
public record Routine(Guid Id, string Name, List<RoutineStep> Steps, RoutineSchedule? Schedule = null);
public sealed class RoutineService(string path, IReminderService? reminders = null)
{
    private readonly JsonListStore<Routine> store = new(path);
    private readonly SemaphoreSlim running = new(1, 1);
    public List<Routine> Items => store.Read();
    public static void Validate(Routine routine, bool requireExistingApps = true) {
        if (string.IsNullOrWhiteSpace(routine.Name)) throw new ArgumentException("Rutine bir isim ver.");
        if (routine.Steps.Count == 0 || routine.Steps.Count > 50) throw new ArgumentException("1–50 adım ekle.");
        if (routine.Schedule is { Valid: false }) throw new ArgumentException("Zamanlama için en az bir gün ve geçerli bir saat seç.");
        foreach (var step in routine.Steps) {
            if (step.Kind == "web") {
                if (!Uri.TryCreate(step.Target, UriKind.Absolute, out var uri) || uri.Scheme is not ("https" or "http")) throw new ArgumentException("Web adresi https:// veya http:// ile başlamalı.");
                if (step.Browser is not ("default" or "chrome")) throw new ArgumentException("Tarayıcı seçimi geçersiz.");
            } else if (step.Kind is "wait" or "reminder") {
                if (step.Minutes is < 1 or > 10080) throw new ArgumentException("Süre 1 dakika ile 7 gün arasında olmalı.");
                if (step.Kind == "reminder" && string.IsNullOrWhiteSpace(step.Target)) throw new ArgumentException("Hatırlatma metni yaz.");
            } else if (step.Kind == "command") {
                if (string.IsNullOrWhiteSpace(step.Target) || step.Target.Length > 300) throw new ArgumentException("Komut adımına 1–300 karakterlik bir cümle yaz.");
            } else if (step.Kind == "spotify") {
                if (!SpotifyPlaylist.Valid(step.Target)) throw new ArgumentException("Çalma listesi geçersiz. Listeden tekrar seç.");
                if (step.Repeat is not null && !SpotifyPlaying.ValidRepeat(step.Repeat)) throw new ArgumentException("Tekrar seçeneği geçersiz.");
            } else if (step.Kind == "installed-app") {
                if (!ValidAppId(step.Target)) throw new ArgumentException("Uygulama kaydı geçersiz. Listeden tekrar seç.");
            } else if (step.Kind == "app") {
                if (!Path.IsPathFullyQualified(step.Target) || (requireExistingApps && !File.Exists(step.Target)) || !string.Equals(Path.GetExtension(step.Target), ".exe", StringComparison.OrdinalIgnoreCase)) throw new ArgumentException("Var olan bir uygulama (.exe) seç.");
            } else throw new ArgumentException("Adım türü desteklenmiyor.");
        }
    }
    // Windows uygulama kimliği (shell:AppsFolder\kimlik): yalnızca harf, rakam ve güvenli işaretler.
    public static bool ValidAppId(string id) => id.Length is > 0 and <= 512 && System.Text.RegularExpressions.Regex.IsMatch(id, @"\A[\p{L}\p{N} ._!{}\-]+\z");
    public void Save(Routine routine) { Validate(routine); store.Modify(items => [.. items.Where(r => r.Id != routine.Id), routine with { Name = routine.Name.Trim(), Steps = [..routine.Steps] }]); }
    public void Remove(Guid id) => store.Modify(items => items.Where(r => r.Id != id).ToList());
    // command: "komut" adımını asistanın komut yolundan çalıştırır (CommandRunner); hata metni döner, başarıda null.
    // spotify: çalma listesi adımını Spotify işlemleriyle çalar (AppServices bağlar; bağlı değilse adım hata verir).
    public async Task<List<string>> RunAsync(Routine routine, CancellationToken cancellation, Action<int, int>? progress = null, Func<RoutineStep, Task>? launch = null, Func<string, CancellationToken, Task<string?>>? command = null, Func<RoutineStep, CancellationToken, Task>? spotify = null) {
        Validate(routine, requireExistingApps: false);
        if (!await running.WaitAsync(0, cancellation)) throw new InvalidOperationException("Bir rutin zaten çalışıyor.");
        var errors = new List<string>();
        try {
            for (var i = 0; i < routine.Steps.Count; i++) {
                cancellation.ThrowIfCancellationRequested(); progress?.Invoke(i + 1, routine.Steps.Count);
                try {
                    var step = routine.Steps[i];
                    if (step.Kind == "wait") await Task.Delay(TimeSpan.FromMinutes(step.Minutes), cancellation);
                    else if (step.Kind == "reminder") {
                        if (reminders is null) throw new InvalidOperationException("Hatırlatıcı hizmeti bağlı değil.");
                        reminders.Add(step.Target, DateTimeOffset.Now.AddMinutes(step.Minutes));
                    } else if (step.Kind == "command") {
                        if (command is null) throw new InvalidOperationException("Komut çalıştırıcı bağlı değil.");
                        if (await command(step.Target, cancellation) is { } problem) throw new InvalidOperationException(problem);
                    } else if (step.Kind == "spotify") {
                        if (spotify is null) throw new InvalidOperationException("Spotify bu cihazda bağlı değil.");
                        await spotify(step, cancellation);
                    } else if (launch is not null) await launch(step); else Launch(step);
                }
                catch (Exception ex) when (ex is not OperationCanceledException) { errors.Add($"{i + 1}. adım: {ex.Message}"); }
                if (i + 1 < routine.Steps.Count) await Task.Delay(350, cancellation);
            }
            return errors;
        } finally { running.Release(); }
    }
    private static void Launch(RoutineStep step) {
        if (step.Kind == "installed-app") {
            var explorer = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe");
            var startApp = new ProcessStartInfo(explorer) { UseShellExecute = false }; startApp.ArgumentList.Add(@"shell:AppsFolder\" + step.Target); Process.Start(startApp); return;
        }
        if (step.Kind == "app") { Process.Start(new ProcessStartInfo(step.Target) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(step.Target)! }); return; }
        if (step.Browser == "default") { Process.Start(new ProcessStartInfo(step.Target) { UseShellExecute = true }); return; }
        var candidates = new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) };
        var chrome = candidates.Select(p => Path.Combine(p, "Google", "Chrome", "Application", "chrome.exe")).FirstOrDefault(File.Exists)
            ?? throw new InvalidOperationException("Chrome bulunamadı. Varsayılan tarayıcıyı seçebilirsin.");
        var start = new ProcessStartInfo(chrome) { UseShellExecute = false }; start.ArgumentList.Add("--new-tab"); start.ArgumentList.Add(step.Target); Process.Start(start);
    }
}


