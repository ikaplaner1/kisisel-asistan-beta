using System.Text.Json;
using System.Text.RegularExpressions;

namespace KisiselAsistan;

public record SteamGame(int Id, string Name, bool ComingSoon, string ReleaseDate, bool EarlyAccess, string? CoverUrl = null);
public record SteamWatch(int Id, string Name, bool ComingSoon, string ReleaseDate, bool EarlyAccess,
    DateTimeOffset? CheckedAt, string? Error = null, string? CoverUrl = null, string[]? SeenUpdates = null, string? LatestUpdate = null);
public record SteamUpdate(string Id, string Title);
public record SteamSearchItem(int Id, string Name, bool Approximate = false, string? CoverUrl = null)
{
    public override string ToString() => Approximate ? Name + " · Yakın eşleşme" : Name;
}
public interface ISteamCatalog
{
    Task<List<SteamSearchItem>> SearchAsync(string query, CancellationToken token, Action<List<SteamSearchItem>>? preview = null);
    Task<SteamGame> GetAsync(int id, CancellationToken token);
    Task<List<SteamUpdate>> UpdatesAsync(int id, CancellationToken token);
}
public sealed class SteamClient : ISteamCatalog, IDisposable
{
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(15) };
    private readonly Dictionary<int, SteamSearchItem> candidates = new();
    public async Task<List<SteamSearchItem>> SearchAsync(string query, CancellationToken token, Action<List<SteamSearchItem>>? preview = null)
    {
        var idMatch = Regex.Match(query.Trim(), @"^(?:https://store\.steampowered\.com/app/)?(\d+)(?:/[^\s]*)?$", RegexOptions.IgnoreCase);
        if (idMatch.Success && int.TryParse(idMatch.Groups[1].Value, out var id) && id > 0)
        {
            var game = await GetAsync(id, token);
            return [new(game.Id, game.Name, CoverUrl: game.CoverUrl)];
        }
        if (query.Trim().Length > 150) throw new InvalidOperationException("Daha kısa bir oyun adı yaz.");
        var direct = await SearchStoreAsync(query, token);
        token.ThrowIfCancellationRequested();
        Remember(direct);
        var rankedDirect = Rank(query, direct, direct.Select(x => x.Id).ToHashSet());
        if (query.Trim().Length < 4 || direct.Any(x => GameNameMatcher.Score(query, x.Name) >= 0.95)) return rankedDirect;
        if (rankedDirect.Count > 0) preview?.Invoke(rankedDirect);
        using var budget = CancellationTokenSource.CreateLinkedTokenSource(token);
        budget.CancelAfter(TimeSpan.FromSeconds(25));
        foreach (var term in GameNameMatcher.FallbackQueries(query)) {
            try { Remember(await SearchStoreAsync(term, budget.Token)); }
            catch (OperationCanceledException) when (!token.IsCancellationRequested) { break; }
            catch (HttpRequestException) { break; }
            if (candidates.Values.Any(x => GameNameMatcher.Score(query, x.Name) >= 0.85)) break;
        }
        token.ThrowIfCancellationRequested();
        return Rank(query, candidates.Values.Concat(direct), direct.Select(x => x.Id).ToHashSet());
    }
    private void Remember(IEnumerable<SteamSearchItem> items)
    {
        foreach (var item in items) candidates[item.Id] = item;
        while (candidates.Count > 2000) candidates.Remove(candidates.Keys.First());
    }
    public static List<SteamSearchItem> Rank(string query, IEnumerable<SteamSearchItem> items, HashSet<int> directIds)
    {
        return items.DistinctBy(x => x.Id).Select(x => (Item: x, Score: GameNameMatcher.Score(query, x.Name)))
            .Where(x => x.Score >= 0.65 || directIds.Contains(x.Item.Id))
            .OrderByDescending(x => x.Score).ThenBy(x => x.Item.Name)
            .Take(25).Select(x => x.Item with { Approximate = x.Score >= 0.65 && x.Score < 0.95 }).ToList();
    }
    private async Task<List<SteamSearchItem>> SearchStoreAsync(string query, CancellationToken token)
    {
        var json = await http.GetStringAsync("https://store.steampowered.com/api/storesearch/?l=turkish&cc=tr&term=" + Uri.EscapeDataString(query.Trim()), token);
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement.GetProperty("items").EnumerateArray()
            .Where(x => x.TryGetProperty("id", out var value) && value.TryGetInt32(out _))
            .Select(x => new SteamSearchItem(x.GetProperty("id").GetInt32(), x.GetProperty("name").GetString()!, CoverUrl: x.TryGetProperty("tiny_image", out var image) ? image.GetString() : null)).Take(25).ToList();
    }
    public async Task<SteamGame> GetAsync(int id, CancellationToken token)
    {
        var json = await http.GetStringAsync($"https://store.steampowered.com/api/appdetails?appids={id}&l=turkish&cc=tr", token);
        return ParseGame(json, id);
    }
    public static SteamGame ParseGame(string json, int id)
    {
        using var doc = JsonDocument.Parse(json);
        var entry = doc.RootElement.GetProperty(id.ToString());
        if (!entry.GetProperty("success").GetBoolean()) throw new InvalidDataException("Oyun bilgisi alınamadı; mağazada erişilebilir olmayabilir.");
        var data = entry.GetProperty("data");
        if (data.GetProperty("type").GetString() != "game") throw new InvalidDataException("Bu kayıt oyun değil. Bir oyun seç.");
        var release = data.GetProperty("release_date");
        var early = data.TryGetProperty("genres", out var genres) && genres.EnumerateArray().Any(c => c.GetProperty("id").ToString() == "70");
        return new(id, data.GetProperty("name").GetString()!, release.GetProperty("coming_soon").GetBoolean(), release.GetProperty("date").GetString() ?? "Belirtilmedi", early, data.TryGetProperty("header_image", out var header) ? header.GetString() : null);
    }
    public void Dispose() => http.Dispose();
    public async Task<List<SteamUpdate>> UpdatesAsync(int id, CancellationToken token)
    {
        var json = await http.GetStringAsync($"https://api.steampowered.com/ISteamNews/GetNewsForApp/v2/?appid={id}&count=100&maxlength=0&feeds=steam_community_announcements", token);
        return ParseUpdates(json);
    }
    public static List<SteamUpdate> ParseUpdates(string json)
    {
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement.GetProperty("appnews").GetProperty("newsitems").EnumerateArray()
            .Where(n => !n.GetProperty("is_external_url").GetBoolean() && n.GetProperty("feedname").GetString() == "steam_community_announcements")
            .Where(n => Regex.IsMatch(n.GetProperty("title").GetString() ?? "", @"\b(update|patch|hotfix|güncelleme|yama|düzeltme)\b", RegexOptions.IgnoreCase)
                && !Regex.IsMatch(n.GetProperty("title").GetString() ?? "", @"\b(upcoming|preview|coming|roadmap|sale|yakında|indirim)\b", RegexOptions.IgnoreCase))
            .OrderByDescending(n => n.GetProperty("date").GetInt64()).Select(n => new SteamUpdate(n.GetProperty("gid").GetString()!, n.GetProperty("title").GetString()!)).ToList();
    }
}
public sealed class SteamWatchStore
{
    private readonly JsonListStore<SteamWatch> data;
    public List<SteamWatch> Items => data.Read();
    public SteamWatchStore(string path)
    {
        data = new(path);
        _ = Items;
    }
    public void Add(SteamGame game)
    {
        data.Modify(items => {
            if (items.Any(w => w.Id == game.Id)) throw new InvalidOperationException("Bu oyun zaten takip listesinde.");
            if (items.Count >= 50) throw new InvalidOperationException("İlk sürüm en fazla 50 oyunu takip ediyor.");
            return [.. items, new(game.Id, game.Name, game.ComingSoon, game.ReleaseDate, game.EarlyAccess, DateTimeOffset.Now, CoverUrl: game.CoverUrl)];
        });
    }
    public bool Update(SteamGame game)
    {
        var released = false;
        data.Modify(items => {
            var before = items.FirstOrDefault(w => w.Id == game.Id);
            if (before is null) return items;
            released = before.ComingSoon && !game.ComingSoon;
            return items.Select(w => w.Id == game.Id ? w with { Name = game.Name, ComingSoon = game.ComingSoon, ReleaseDate = game.ReleaseDate, EarlyAccess = game.EarlyAccess, CheckedAt = DateTimeOffset.Now, Error = null, CoverUrl = game.CoverUrl ?? w.CoverUrl } : w).ToList();
        });
        return released;
    }
    public void Failure(int id, string message) => data.Modify(items => items.Select(w => w.Id == id ? w with { Error = message } : w).ToList());
    public void Remove(int id) => data.Modify(items => items.Where(w => w.Id != id).ToList());
    public List<SteamUpdate> UpdateNews(int id, List<SteamUpdate> news)
    {
        List<SteamUpdate> fresh = [];
        data.Modify(items => items.Select(w => {
            if (w.Id != id) return w;
            if (w.SeenUpdates is not null) fresh = news.Where(n => !w.SeenUpdates.Contains(n.Id)).ToList();
            return w with { SeenUpdates = news.Select(n => n.Id).Concat(w.SeenUpdates ?? []).Distinct().Take(500).ToArray(), LatestUpdate = news.FirstOrDefault()?.Title ?? w.LatestUpdate };
        }).ToList());
        return fresh;
    }
}
