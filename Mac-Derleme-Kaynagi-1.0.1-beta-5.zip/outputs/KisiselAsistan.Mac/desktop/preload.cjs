const {contextBridge, ipcRenderer} = require('electron');
// Ortak arayüz (KisiselAsistan/WorkspaceWeb) Windows'ta window.chrome.webview ile konuşur.
// Burada aynı biçimde bir köprü verilir: postMessage({id, method, params}) → yanıt {id, ok, data, error}; olaylar {event, data}.
const listeners = new Set();
function deliver(data) { for (const listener of listeners) { try { listener({data}); } catch {} } }
ipcRenderer.on('workspace:message', (_, data) => deliver(data));

// Sesli komut: kayıt burada (16 kHz mono) alınır; konuşma bitince (1,2 sn sessizlik) ana sürece gider,
// orada yerel Whisper ile metne çevrilip ortak komut yolundan çalıştırılır. Mikrofona ikinci basış kaydı bitirir.
let recording = null;
async function listen() {
  if (recording) { recording.stop(); return; }
  await ipcRenderer.invoke('workspace:speech', {stage: 'start'});
  let stream, context;
  try {
    stream = await navigator.mediaDevices.getUserMedia({audio: {channelCount: 1, echoCancellation: true, noiseSuppression: true}});
    context = new AudioContext({sampleRate: 16000});
    const source = context.createMediaStreamSource(stream), node = context.createScriptProcessor(4096, 1, 1);
    const chunks = []; let total = 0, voice = false, quiet = 0;
    await new Promise(resolve => {
      recording = {stop: resolve};
      node.onaudioprocess = event => {
        const data = event.inputBuffer.getChannelData(0); chunks.push(new Float32Array(data)); total += data.length;
        let sum = 0; for (const x of data) sum += x * x;
        if (Math.sqrt(sum / data.length) > 0.02) { voice = true; quiet = 0; } else if (voice) quiet += data.length;
        if ((voice && quiet > 16000 * 1.2) || total > 16000 * 15 || (!voice && total > 16000 * 6)) resolve();
      };
      source.connect(node); node.connect(context.destination);
    });
    node.disconnect(); source.disconnect();
    const samples = new Float32Array(total); let offset = 0;
    for (const chunk of chunks) { samples.set(chunk, offset); offset += chunk.length; }
    return await ipcRenderer.invoke('workspace:speech', {stage: voice ? 'samples' : 'silent', samples: voice ? samples : null});
  } catch (error) {
    await ipcRenderer.invoke('workspace:speech', {stage: 'failed'}).catch(() => {});
    throw new Error(error?.name === 'NotAllowedError' ? 'Mikrofon izni yok. Sistem Ayarları → Gizlilik ve Güvenlik → Mikrofon bölümünden izin ver.' : clean(error));
  } finally {
    recording = null;
    stream?.getTracks().forEach(track => track.stop());
    context?.close().catch(() => {});
  }
}
// Electron hata metninin başına "Error invoking remote method ..." ekler; kullanıcıya yalnız asıl cümle gösterilir.
const clean = error => String(error?.message || error || 'İşlem tamamlanamadı.').replace(/^Error invoking remote method '[^']+': (Error: )?/, '');

contextBridge.exposeInMainWorld('assistantBridge', {
  postMessage(message) {
    const id = message?.id;
    const answer = promise => promise.then(data => deliver({id, ok: true, data}), error => deliver({id, ok: false, error: clean(error)}));
    if (message?.method === 'speech.listen') { answer(listen()); return; }
    if (message?.method === 'speech.cancel' && recording) recording.stop();
    answer(ipcRenderer.invoke('workspace:call', message?.method, message?.params ?? {}));
  },
  addEventListener(type, callback) { if (type === 'message' && typeof callback === 'function') listeners.add(callback); }
});

// Pencerenin çerçevesi yok; Windows'taki gibi marka alanından sürüklenir.
window.addEventListener('DOMContentLoaded', () => {
  const style = document.createElement('style');
  style.textContent = '#drag-area{-webkit-app-region:drag;cursor:default}';
  document.head.append(style);
  document.body.classList.add('platform-mac');
});
