"use strict";
// Pencereler, açılır menüler ve düzenleme formları.
//
// Hareket kuralları:
// - Ayarlar gibi pencereler her zaman ekranın ortasında aynı şekilde açılır.
// - Bir kaydı düzenleyen pencere o kaydın satırından büyüyerek açılır (origin).
// - Açılır menüler tıklanan noktadan açılır.
// - Kapanış açılıştan daha kısadır. Windows'ta animasyonlar kapalıysa hareket olmaz.

const reducedMotion = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
const easeOut = "cubic-bezier(.2,.8,.2,1)";

function openDialog(title, body, options = false) {
  const { wide = false, origin = null } = typeof options === "object" ? options : { wide: options };
  closeMenu();
  state.modal = title;
  $("#portal").innerHTML = `<div class="modal-layer"><section class="dialog ${wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header><h2>${esc(title)}</h2>${B("", "dialog-close", "close", "icon-button", 'aria-label="Kapat"')}</header><div class="dialog-content">${body}<div class="inline-error" role="alert"></div></div></section></div>`;
  const layer = $("#portal .modal-layer"),
    dialog = $(".dialog", layer);
  if (!reducedMotion()) {
    layer.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 160, easing: "ease-out" });
    const from = origin?.isConnected ? origin.getBoundingClientRect() : null,
      to = dialog.getBoundingClientRect();
    if (from && from.width && to.width) {
      // Satırdan büyüme: pencere, kaydın bulunduğu yerden ve boyutundan başlar.
      const dx = from.left + from.width / 2 - (to.left + to.width / 2),
        dy = from.top + from.height / 2 - (to.top + to.height / 2);
      dialog.animate(
        [
          { transform: `translate(${dx}px, ${dy}px) scale(${from.width / to.width}, ${from.height / to.height})`, opacity: 0.35 },
          { transform: "none", opacity: 1 },
        ],
        { duration: 240, easing: easeOut },
      );
    } else {
      dialog.animate(
        [
          { transform: "translateY(8px) scale(.96)", opacity: 0 },
          { transform: "none", opacity: 1 },
        ],
        { duration: 200, easing: easeOut },
      );
    }
  }
  scheduleSlots();
  setTimeout(() => {
    const content = $("#portal .modal-layer:not(.closing) .dialog-content");
    (content && ($("input:not([type=checkbox]):not([type=color]), textarea, select", content) || $("button.primary", content)))?.focus();
  }, 25);
}
function closeDialog() {
  // Yarım kalan Google işlemi pencereyle birlikte bırakılır (tarayıcı izni beklenirken gibi).
  if (state.modal === "Google Calendar") rpc("google.cancel").catch(() => {});
  state.modal = null;
  const layer = $("#portal .modal-layer");
  if (layer && !reducedMotion()) {
    // Yalnızca kapanan katman silinir; bu arada açılan yeni pencere etkilenmez.
    layer.classList.add("closing");
    layer.removeAttribute("role");
    $(".dialog", layer)?.removeAttribute("role");
    layer.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 130, easing: "ease-in" }).onfinish = () => layer.remove();
    $(".dialog", layer)?.animate([{ transform: "none" }, { transform: "scale(.98)" }], { duration: 130, easing: "ease-in" });
  } else layer?.remove();
  scheduleSlots();
}
function confirmDialog(title, text, action) {
  openDialog(
    title,
    `<p>${esc(text)}</p><div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}${B("Onayla", "confirm-action", "", "primary danger-fill")}</div>`,
  );
  $('#portal [data-action="confirm-action"]').onclick = () =>
    run(async () => {
      await action();
      closeDialog();
      await refresh();
    });
}
const field = (label, input, full = false) => `<label class="field ${full ? "full" : ""}">${label}${input}</label>`;

// ---------------------------------------------------------------- Açılır menüler
let menuAnchor = null;
// target: tıklanan öğe ya da {x, y} noktası (sağ tık).
function openMenu(target, items) {
  closeMenu();
  const menu = document.createElement("div");
  menu.className = "menu";
  menu.setAttribute("role", "menu");
  menu.innerHTML = items;
  document.body.append(menu);
  const point =
    target instanceof Element
      ? (() => {
          const r = target.getBoundingClientRect();
          return { x: r.right, y: r.bottom + 4, alignRight: true };
        })()
      : { x: target.x, y: target.y, alignRight: false };
  const w = menu.offsetWidth,
    h = menu.offsetHeight;
  let left = point.alignRight ? point.x - w : point.x,
    top = point.y,
    originY = "top";
  if (top + h > innerHeight - 8) {
    top = (target instanceof Element ? target.getBoundingClientRect().top - 4 : point.y) - h;
    originY = "bottom";
  }
  left = Math.min(Math.max(8, left), innerWidth - w - 8);
  top = Math.max(8, top);
  menu.style.left = left + "px";
  menu.style.top = top + "px";
  menu.style.transformOrigin = `${point.alignRight ? "right" : "left"} ${originY}`;
  if (!reducedMotion())
    menu.animate(
      [
        { transform: "scale(.94)", opacity: 0 },
        { transform: "none", opacity: 1 },
      ],
      { duration: 120, easing: easeOut },
    );
  menuAnchor = target instanceof Element ? target : null;
  menuAnchor?.classList.add("menu-open");
  setTimeout(() => $("button", menu)?.focus(), 10);
}
function closeMenu() {
  const menu = $(".menu");
  if (!menu) return;
  menuAnchor?.classList.remove("menu-open");
  menuAnchor = null;
  menu.remove();
}
const menuItem = (text, action, icon, cls = "", data = "") => B(`<span>${text}</span>`, action, icon, "menu-item " + cls, data);
const menuSeparator = '<div class="menu-separator" role="separator"></div>';

function taskMenu(id, target) {
  const t = state.data.tasks.find((x) => x.id === id);
  const steps = t.steps?.length
    ? menuSeparator +
      `<p class="menu-label">Adımlar</p>` +
      t.steps
        .map((s, i) => `<label class="menu-check"><input type="checkbox" data-step-task="${id}" data-index="${i}" ${s.done ? "checked" : ""}>${esc(s.text)}</label>`)
        .join("")
    : "";
  // Tamamlama satırdaki kutudan yapılır. Gün seçimi yalnızca tek seferlik işlerde anlamlı
  // (günlük aktiviteler zaten her gün görünür); bugün için "Bir ara" işlerinde "Bugüne al" yeterli.
  const onDay = t.myDay === state.day,
    dayName =
      state.day === today()
        ? onDay ? "Bugünden çıkar" : "Bugüne ekle"
        : state.day === tomorrow()
          ? onDay ? "Yarından çıkar" : "Yarına ekle"
          : `${parseDay(state.day).toLocaleDateString("tr-TR", { day: "numeric", month: "long", weekday: "long" })} ${onDay ? "gününden çıkar" : "gününe ekle"}`;
  // Geciken işte "Bugüne taşı" zaten var; gün seçeneği ikinci kez çıkmasın.
  const showDay = !t.dailyActivity && !t.done && !taskLate(t) && !(isSomeday(t) && state.day === today());
  openMenu(
    target,
    menuItem("Düzenle", "task-edit", "edit", "", `data-id="${id}"`) +
      (state.data.live?.ollama && !t.done ? menuItem("Adımlara böl (yapay zekâ)", "task-breakdown", "ai", "", `data-id="${id}"`) : "") +
      (showDay ? menuItem(dayName, "task-day", "calendar", "", `data-id="${id}"`) : "") +
      // Her gün yapılan alışkanlıklar tek seferlik hatırlatıcıya çevrilmez.
      (t.dailyActivity ? "" : menuItem("Saate bağla", "task-to-reminder", "clock", "", `data-id="${id}"`)) +
      (taskLate(t)
        ? menuItem("Bugüne taşı", "task-move", "calendar", "", `data-id="${id}" data-to="today"`) +
          menuItem("Yarına at", "task-move", "right", "", `data-id="${id}" data-to="tomorrow"`)
        : "") +
      // Bir ara listesindeki iş bugüne alınır; günü olan iş tarihsiz "bir ara"ya bırakılabilir.
      (isSomeday(t) && !t.done ? menuItem("Bugüne al", "task-move", "calendar", "", `data-id="${id}" data-to="today"`) : "") +
      (!t.dailyActivity && !t.done && !isSomeday(t) ? menuItem("Bir araya at", "task-someday", "clock", "", `data-id="${id}"`) : "") +
      // Pomodoro: bu işle odak turu başlatır (tur adı işin adı olur).
      (!t.done ? menuItem("Bununla odaklan", "focus-start", "play", "", `data-task="${esc(t.title)}"`) : "") +
      steps +
      menuSeparator +
      menuItem("Sil", "task-remove", "trash", "danger", `data-id="${id}"`),
  );
}
function reminderMenu(id, target) {
  const r = state.data.reminders.find((x) => x.id === id);
  openMenu(
    target,
    `<p class="menu-label">${relativeDay(r.due)} ${clock(r.due)} · ${esc(r.settings?.name || "Normal")}</p>` +
      menuItem(r.plan?.weekly ? "Bu ve sonraki tekrarları düzenle" : "Düzenle", "reminder-edit", "edit", "", `data-id="${id}"`) +
      (!r.done
        ? menuItem("Tamamladım", "reminder-complete", "check", "", `data-id="${id}"`) +
          menuSeparator +
          `<p class="menu-label">${r.plan?.weekly ? "Ertele · yalnız bu gün" : "Ertele"}</p>` +
          menuItem("5 dakika sonra", "reminder-snooze", "clock", "", `data-id="${id}"`) +
          menuItem("1 saat sonra", "reminder-move", "clock", "", `data-id="${id}" data-to="hour"`) +
          (new Date().getHours() < 19 ? menuItem("Bu akşam 20:00", "reminder-move", "clock", "", `data-id="${id}" data-to="evening"`) : "") +
          menuItem(`Yarın aynı saatte · ${clock(r.due)}`, "reminder-move", "calendar", "", `data-id="${id}" data-to="same-tomorrow"`) +
          menuItem(r.plan?.weekly ? "Başka güne taşı · yalnız bu hafta" : "Başka güne taşı…", "reminder-move-pick", "calendar", "", `data-id="${id}"`) +
          (r.plan?.weekly ? "" : menuItem("Saatten çıkar · göreve çevir", "reminder-to-task", "task", "", `data-id="${id}"`))
        : "") +
      menuSeparator +
      menuItem(r.plan?.weekly ? "Haftalık seriyi sil" : "Sil", "reminder-remove", "trash", "danger", `data-id="${id}"`),
  );
}
// Gecikenler başlığındaki toplu işlemler: biriken işler için tek kararlık seçenekler.
function lateMenu(target) {
  const { reminders } = lateItems(),
    weekly = reminders.filter((r) => r.plan?.weekly).length;
  openMenu(
    target,
    menuItem("Hepsini bugünün görevi yap", "late-move", "task", "", 'data-to="task"') +
      menuItem("Hepsini yarına taşı", "late-move", "calendar", "", 'data-to="tomorrow"') +
      (weekly ? `<p class="menu-label">${weekly} haftalık tekrar yerinde kalır</p>` : ""),
  );
}
function shortcutMenu(id, target) {
  openMenu(
    target,
    menuItem("Düzenle", "shortcut-edit", "edit", "", `data-id="${id}"`) +
      menuSeparator +
      menuItem("Sil", "shortcut-remove", "trash", "danger", `data-id="${id}"`),
  );
}
function reminderSettingsMenu(target) {
  openMenu(
    target,
    menuItem("Google Calendar", "google", "calendar") +
      menuItem("Kişisel tercihler", "preferences", "settings") +
      menuItem(`Varsayılan mod: ${esc(state.data.defaults.name)}`, "defaults", "clock") +
      (state.data.reminders.some((r) => r.done) ? menuSeparator + menuItem("Tamamlananları temizle", "reminder-clear", "trash") : ""),
  );
}
// Düzenleme penceresinin büyüyeceği satır.
const rowOf = (kind, id) => (id ? $(`[data-row-${kind}="${CSS.escape(id)}"]`) || $(`.calendar-event[data-id="${CSS.escape(id)}"]`) : null);

// ---------------------------------------------------------------- Formlar
function localDateTime(d) {
  const x = new Date(d);
  return dayKey(x) + "T" + String(x.getHours()).padStart(2, "0") + ":" + String(x.getMinutes()).padStart(2, "0");
}
function themeDialog() {
  let chosen = state.data.live.theme,
    colors = [...state.data.live.colors],
    details = false;
  openDialog(
    "Tema",
    `<p class="muted">${compact() ? "Küçük" : "Büyük"} görünüm için temayı seç; uygulamadan önce sağda gör.</p><div class="theme-layout"><div><div class="theme-list">${state.data.themes.map((t) => `<button class="theme-option ${t.name === chosen ? "active" : ""}" type="button" data-theme-name="${esc(t.name)}"><span class="swatch" style="background:linear-gradient(90deg, ${t.colors[0]} 0 50%, ${t.colors[5]} 50% 75%, ${t.colors[7]} 75%)"></span>${esc(t.name)}</button>`).join("")}</div>${B("Ayrıntılı renk ayarları", "theme-details", "settings", "ghost")}<div id="color-fields" class="color-fields" hidden>${["Arka plan", "Kartlar", "Seçili alan", "Ana yazılar", "Yardımcı yazılar", "Vurgu", "Kenarlıklar", "İkinci renk", "Başlıklar"].map((label, i) => `<label>${label}<input type="color" data-color="${i}" value="${colors[i]}"></label>`).join("")}</div>${B("Temanın renklerine dön", "theme-reset", "", "ghost")}</div><div class="theme-preview"><small>ÖNİZLEME</small><h3>Görevler</h3><div class="sample-card"><span class="sample-check"></span><div><p>Güne sakin bir başlangıç</p><small><span class="sample-time">09:00</span> · Her gün</small></div></div><button class="primary" type="button">${I("plus")}Görev ekle</button></div></div><div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}${B("Uygula", "theme-apply", "", "primary")}</div>`,
    { wide: true },
  );
  const preview = $(".theme-preview");
  function update() {
    themeVars(preview, colors);
    $$("[data-color]").forEach((el) => (el.value = colors[+el.dataset.color]));
    $$("[data-theme-name]").forEach((el) => el.classList.toggle("active", el.dataset.themeName === chosen));
  }
  update();
  $$("[data-theme-name]").forEach(
    (el) =>
      (el.onclick = () => {
        chosen = el.dataset.themeName;
        colors = [...state.data.themes.find((t) => t.name === chosen).colors];
        update();
      }),
  );
  $$("[data-color]").forEach(
    (el) =>
      (el.oninput = () => {
        colors[+el.dataset.color] = el.value;
        update();
      }),
  );
  $('[data-action="theme-details"]').onclick = () => {
    $("#color-fields").hidden = details;
    details = !details;
  };
  $('[data-action="theme-reset"]').onclick = () => {
    colors = [...state.data.themes.find((t) => t.name === chosen).colors];
    update();
  };
  $('[data-action="theme-apply"]').onclick = () =>
    run(async () => {
      await rpc("theme.apply", { name: chosen, colors });
      closeDialog();
      await refresh();
    });
}
async function speechSettings() {
  const s = await rpc("speech.settings");
  const hk = await rpc("hotkey.get").catch(() => null); // Windows: her yerden komut kısayolu (Mac'te yok)
  openDialog(
    "Ses ve komut ayarları",
    `<p class="muted">${esc(s.heard)}</p><form id="speech-form"><div class="fields">${field("Mikrofon", `<select name="microphone">${s.microphones.map((m, i) => `<option value="${i}" ${i === s.microphone ? "selected" : ""}>${esc(m)}</option>`).join("")}</select>`, true)}${field("Konuşma dili", `<select name="language"><option value="1" ${s.language === 1 ? "selected" : ""}>Türkçe</option><option value="0" ${s.language === 0 ? "selected" : ""}>English</option></select>`)}${field("Konuşma arası", `<select name="wait">${["Hızlı · 1,1 sn", "Dengeli · 1,8 sn", "Uzun · 2,8 sn"].map((x, i) => `<option value="${i}" ${s.wait === i ? "selected" : ""}>${x}</option>`).join("")}</select>`)}<label class="check-label full"><input name="speakReplies" type="checkbox" ${s.speak ? "checked" : ""}>Sesli cevap<small class="hint inline">Sesle verdiğin komutun sonucunu sesli söyler. Yazılı komutlar sessiz kalır.</small></label>${"natural" in s ? `<div class="field full"><span>Cevap sesi · Doğal Türkçe ses</span><div class="button-row"><select name="rate" aria-label="Konuşma hızı">${["Yavaş", "Normal", "Hızlı"].map((x, i) => `<option value="${i}" ${(s.rate ?? 1) === i ? "selected" : ""}>${x} konuşsun</option>`).join("")}</select>${B("Dinle", "voice-preview", "volume", "ghost")}${B("Tekrar dene", "voice-install", "refresh", "ghost")}</div><small id="voice-status" class="hint" role="status">${s.natural ? "Hazır; internetsiz çalışır." : s.downloading ? esc(s.voiceStatus || "İndiriliyor…") : esc(s.voiceStatus || "Henüz inmedi; inene kadar cevaplar sessiz kalır.")}</small></div>` : ""}${hk ? `<div class="field full"><span>Her yerden komut</span><select name="hotkey" aria-label="Her yerden komut kısayolu">${hk.presets.map((x) => `<option value="${x.id}" ${x.id === hk.preset ? "selected" : ""}>${esc(x.label)}</option>`).join("")}</select><small id="hotkey-status" class="hint">${hk.ok ? "Uygulama arkadayken de bu tuşlarla ekranın ortasında komut kutusu açılır." : "Bu kısayol başka bir programda kullanılıyor; başka birini seç."}</small></div>` : ""}<label class="check-label full"><input name="uiSounds" type="checkbox" ${soundsOn() ? "checked" : ""}>Arayüz sesleri<small class="hint inline">Görev tamamlayınca, gün bitince ve yeni kayıt ekleyince kısa bir ses; sesli komutta da dinleme başladı / anlaşıldı / anlaşılmadı sesleri.</small></label></div><div class="toolbar" style="margin-top:18px">${B("Komut örnekleri", "help", "help", "ghost")}${B("Ollama ayarları", "ollama", "ai", "ghost")}</div><div class="dialog-actions"><button class="primary">Kaydet</button></div></form>`,
  );
  // Açınca nasıl duyulduğunu hemen dinletir.
  $("#speech-form").elements.uiSounds.onchange = (e) => e.target.checked && playSound("done", true);
  if (hk)
    $("#speech-form").elements.hotkey.onchange = (e) =>
      rpc("hotkey.set", { preset: e.target.value })
        .then((ok) => ($("#hotkey-status").textContent = e.target.value === "off" ? "Kapalı." : ok ? "Hazır: uygulama arkadayken de çalışır." : "Bu kısayol başka bir programda kullanılıyor; başka birini seç."))
        .catch((err) => ($("#hotkey-status").textContent = err.message));
  // Doğal ses kendiliğinden iner; burada yalnız durumu, "Dinle"yi ve inemediyse "Tekrar dene"yi gösterir.
  if (!("natural" in s)) return; // Mac: kendi sesi (say) kullanılır.
  const retry = $('#portal [data-action="voice-install"]');
  const status = (text) => $("#voice-status") && ($("#voice-status").textContent = text);
  retry.hidden = s.natural || s.downloading;
  $('#portal [data-action="voice-preview"]').onclick = (e) => {
    e.stopPropagation();
    rpc("voice.preview", { rate: +$("#speech-form").elements.rate.value }).catch((err) => status(err.message));
  };
  retry.onclick = (e) => {
    e.stopPropagation();
    retry.hidden = true;
    status("İndirme başlıyor…");
    rpc("voice.install", {}, 3600000)
      .then((ok) => {
        if (!retry.isConnected) return ok && toast("Doğal ses indirildi.");
        if (ok) status("Doğal ses hazır. Dinle'ye basıp deneyebilirsin.");
        retry.hidden = ok;
      })
      .catch((err) => (retry.isConnected ? ((retry.hidden = false), status(err.message)) : toast(err.message)));
  };
}
function helpDialog() {
  openDialog(
    "Sesli ve yazılı komutlar",
    `<p class="muted">Bir örneğe basarak komut alanına aktarabilirsin. Komut alanına her yerden <kbd>Ctrl</kbd> + <kbd>K</kbd> ile geçebilirsin.</p><div class="help-grid">${["On dakika sonra su içmeyi hatırlat", "Yarın 15:00 toplantı, 15 dk önce hatırlat", "15 Ekim saat 19daki hatırlatıcıyı sil", "Su içme hatırlatıcısını 5 dakika ertele", "Steam ara Hades", "Spotify ara Tarkan", "Spotify sesi yüzde 30 yap", "Sabah rutinimi başlat"].map((x) => B(esc(x), "example", "", "", `data-example="${esc(x)}"`)).join("")}</div>`,
  );
}
const spotifyStepNote = (s) => ["Spotify", s.shuffle ? "karışık" : "baştan", { off: "tekrar kapalı", context: "liste tekrarı", track: "şarkı tekrarı" }[s.repeat]].filter(Boolean).join(" · ");
function shortcutEditor(id) {
  const old = state.data.routines.find((r) => r.id === id);
  let steps = structuredClone(old?.steps || []);
  // Zamanlama: seçili günlerde o saatte önce bildirimle sorar, cevap yoksa kendiliğinden başlar (Core/Routines/RoutineScheduler.cs).
  // Mac kabuğu henüz zamanlanmış başlatmayı yapmıyor; orada bu bölüm gösterilmez.
  const sched = { enabled: !!old?.schedule?.enabled, days: old?.schedule?.days || 62, minutes: old?.schedule?.minutes ?? 540 };
  const canSchedule = state.data.live?.platform !== "mac";
  openDialog(
    old ? "Kısayolu düzenle" : "Yeni kısayol",
    `<form id="shortcut-form">${field("Kısayol adı", `<input id="shortcut-name" name="name" required maxlength="200" value="${esc(old?.name || "")}">`)}${canSchedule ? '<div id="shortcut-schedule" class="form-block shortcut-schedule"></div>' : ""}<div id="shortcut-steps"></div><div class="toolbar" style="margin-top:14px">${B("Uygulama", "step-app", "plus")}${B("Web sayfası", "step-web", "plus")}${B("Bekleme", "step-wait", "plus")}${B("Hatırlatıcı", "step-reminder", "plus")}${B("Komut", "step-command", "plus")}${B("Spotify listesi", "step-spotify", "music")}</div><div id="step-editor"></div><div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Kaydet</button></div></form>`,
    { origin: rowOf("shortcut", id) },
  );
  const redraw = () => {
    $("#shortcut-steps").innerHTML = steps
      .map(
        (s, i) =>
          `<div class="step-row"><span class="badge">${i + 1}</span><div class="item-copy">${esc(s.label || s.target || "Bekle")}<small class="muted"> · ${esc(s.kind === "wait" || s.kind === "reminder" ? s.minutes + " dk" : s.kind === "web" ? "Web sayfası" : s.kind === "command" ? "Komut" : s.kind === "spotify" ? spotifyStepNote(s) : "Uygulama")}</small></div>${B("↑", "step-up", "", "icon-button", `data-index="${i}" aria-label="Adımı yukarı taşı"`)}${B("↓", "step-down", "", "icon-button", `data-index="${i}" aria-label="Adımı aşağı taşı"`)}${B("×", "step-remove", "", "icon-button", `data-index="${i}" aria-label="Adımı sil"`)}</div>`,
      )
      .join("");
  };
  const chip = (label, action, on, attr) => `<button type="button" class="choice small${on ? " on" : ""}" aria-pressed="${on}" data-action="${action}" ${attr}>${label}</button>`;
  const drawSchedule = () => {
    const box = $("#shortcut-schedule");
    if (!box) return;
    box.innerHTML =
      `<label class="toggle-row"><span>Belirli gün ve saatte başlat<small class="muted"> Saati gelince önce sorar; cevap vermezsen ${2} dakika sonra kendiliğinden başlar.</small></span><input type="checkbox" class="switch" id="schedule-on" ${sched.enabled ? "checked" : ""}></label>` +
      (sched.enabled
        ? `<div class="choices" role="group" aria-label="Hazır gün seçimleri">${[["Her gün", 127], ["Hafta içi", 62], ["Hafta sonu", 65]].map(([l, m]) => chip(l, "schedule-days", sched.days === m, `data-mask="${m}"`)).join("")}</div>` +
          `<div class="choices" role="group" aria-label="Günler">${WEEKDAYS.map(([l, b]) => chip(l, "schedule-day", (sched.days & (1 << b)) !== 0, `data-bit="${b}"`)).join("")}</div>` +
          `<label class="schedule-time">Saat <input type="time" id="schedule-time" required value="${minutesText(sched.minutes)}"></label>`
        : "");
    $("#schedule-on").onchange = (e) => {
      sched.enabled = e.target.checked;
      drawSchedule();
    };
    const time = $("#schedule-time");
    if (time) time.oninput = time.onchange = () => {
      const [h, m] = time.value.split(":").map(Number);
      if (Number.isFinite(h) && Number.isFinite(m)) sched.minutes = h * 60 + m;
    };
  };
  drawSchedule();
  redraw();
  $("#shortcut-form").onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    run(async () => {
      const schedule = canSchedule && sched.enabled ? { days: sched.days, minutes: sched.minutes, enabled: true } : canSchedule ? null : old?.schedule || null;
      await rpc("routine.save", { id: old?.id || null, name: $("#shortcut-name").value, steps, schedule });
      closeDialog();
      await refresh();
    });
  };
  $("#shortcut-form").addEventListener("click", (e) => {
    const b = e.target.closest("[data-action]");
    if (!b) return;
    const a = b.dataset.action,
      i = +b.dataset.index;
    if (a === "schedule-days") {
      sched.days = +b.dataset.mask;
      drawSchedule();
    }
    if (a === "schedule-day") {
      const mask = sched.days ^ (1 << +b.dataset.bit);
      if (mask) sched.days = mask; // en az bir gün kalır
      drawSchedule();
    }
    if (a === "step-remove") {
      steps.splice(i, 1);
      redraw();
    }
    if (a === "step-up" && i > 0) {
      [steps[i - 1], steps[i]] = [steps[i], steps[i - 1]];
      redraw();
    }
    if (a === "step-down" && i < steps.length - 1) {
      [steps[i + 1], steps[i]] = [steps[i], steps[i + 1]];
      redraw();
    }
    if (a === "step-app")
      appPicker($("#step-editor"), (step) => {
        steps.push(step);
        $("#step-editor").replaceChildren();
        redraw();
      });
    // "Komut" adımı: sesli/yazılı komutla aynı cümle (Spotify'da çal, oyun takibi, hatırlatıcı…); çalışınca komut yolundan geçer.
    if (a === "step-command") {
      const examples = ["Spotify'da lofi çal", "sesi yüzde 30 yap", "duraklat", "yarın 9'da raporu hatırlat"];
      $("#step-editor").innerHTML =
        `${field("Komut", '<input id="step-command" maxlength="300" placeholder="Sesli komutta söyleyeceğin cümle">', true)}<div class="choices" role="group" aria-label="Örnekler">${examples.map((x) => `<button type="button" class="choice small" data-example-step="${esc(x)}">${esc(x)}</button>`).join("")}</div>${B("Adımı ekle", "step-add", "", "primary")}`;
      $$("[data-example-step]").forEach((x) => (x.onclick = (e) => { e.stopPropagation(); $("#step-command").value = x.dataset.exampleStep; $("#step-command").focus(); }));
      $('[data-action="step-add"]').onclick = (e) => {
        e.stopPropagation();
        const target = $("#step-command").value.trim();
        if (!target) return toast("Komut cümlesini yaz.");
        steps.push({ kind: "command", target, browser: "default", minutes: 1 });
        $("#step-editor").replaceChildren();
        redraw();
      };
    }
    // "Spotify listesi" adımı: kartta sıralanan listelerden biri; baştan ya da karışık, istenirse tekrarla.
    if (a === "step-spotify") {
      const box = $("#step-editor");
      box.innerHTML = '<p class="muted">Çalma listeleri yükleniyor…</p>';
      run(async () => {
        let lists;
        try {
          lists = orderPlaylists((await rpc("operation", { name: "spotify.playlists", parameters: {} })) || []);
        } catch (e) {
          box.innerHTML = `<p class="muted">${esc(e.message)}</p>`;
          return;
        }
        if (!lists.length) {
          box.innerHTML = '<p class="muted">Spotify hesabında çalma listesi bulunamadı. Ayarlar → Spotify ile bağlı olduğundan emin ol.</p>';
          return;
        }
        box.innerHTML =
          `<div class="fields">${field("Çalma listesi", `<select id="step-playlist">${lists.map((p, i) => `<option value="${i}">${esc(p.name)}</option>`).join("")}</select>`, true)}` +
          `${field("Tekrar", `<select id="step-repeat">${[["", "Değiştirme"], ["off", "Kapalı"], ["context", "Listeyi tekrarla"], ["track", "Şarkıyı tekrarla"]].map(([v, l]) => `<option value="${v}">${l}</option>`).join("")}</select>`)}</div>` +
          `<label class="toggle-row"><span>Karışık çal<small class="muted"> Rastgele bir şarkıdan başlar.</small></span><input type="checkbox" class="switch" id="step-shuffle"></label>${B("Adımı ekle", "step-add", "", "primary")}`;
        $('[data-action="step-add"]').onclick = (e) => {
          e.stopPropagation();
          const p = lists[+$("#step-playlist").value];
          steps.push({ kind: "spotify", target: p.uri, label: p.name, browser: "default", minutes: 1, shuffle: $("#step-shuffle").checked, repeat: $("#step-repeat").value || null });
          box.replaceChildren();
          redraw();
        };
      });
    }
    if (["step-web", "step-wait", "step-reminder"].includes(a)) {
      const kind = a.slice(5);
      $("#step-editor").innerHTML =
        `<div class="fields">${kind !== "wait" ? field(kind === "web" ? "Web adresi" : "Hatırlatma metni", '<input id="step-target" placeholder="' + (kind === "web" ? "https://…" : "Mola zamanı") + '">', true) : ""}${kind === "web" ? field("Tarayıcı", '<select id="step-browser"><option value="default">Varsayılan</option><option value="chrome">Chrome</option></select>') : field("Dakika", '<input type="number" id="step-minutes" min="1" max="10080" value="5">')}</div>${B("Adımı ekle", "step-add", "", "primary")}`;
      $('[data-action="step-add"]').onclick = () => {
        let target = $("#step-target")?.value || "";
        if (kind === "web" && !/^https?:\/\//i.test(target)) target = "https://" + target;
        if (kind === "web") {
          try {
            const u = new URL(target);
            if (!["https:", "http:"].includes(u.protocol)) throw 0;
          } catch {
            toast("Geçerli bir web adresi yaz.");
            return;
          }
        }
        if (kind === "reminder" && !target.trim()) {
          toast("Hatırlatma metni yaz.");
          return;
        }
        steps.push({
          kind,
          target,
          browser: $("#step-browser")?.value || "default",
          minutes: +($("#step-minutes")?.value || 1),
        });
        $("#step-editor").replaceChildren();
        redraw();
      };
    }
  });
}

// ---------------------------------------------------------------- Ctrl+K komut penceresi
// Ortada açılır; yazarken Enter'a basınca ne olacağı üstte önizlenir.
// Saat içeren metin hatırlatıcı olur, bölüm adı o bölüme götürür, gerisi asistana gider.
// q: hızlı ekleme ayrıştırması (C#); henüz gelmediyse null.
function paletteOptions(text, q) {
  const t = text.trim(),
    low = t.toLocaleLowerCase("tr-TR");
  const go = (s) => ({ icon: s[2], kind: "Bölüme gidilecek", title: s[3], detail: "Bölüm", run: () => action("navigate", { dataset: { page: s[0] } }) });
  if (!t)
    return [
      { icon: "plus", kind: "Yeni hatırlatıcı", title: "Hatırlatıcı ekle", detail: "Pencere", run: () => reminderEditor() },
      { icon: "plus", kind: "Yeni görev", title: "Görev ekle", detail: "Pencere", run: () => taskEditor() },
      ...sections.map(go),
    ];
  const list = [];
  q = q || { kind: "none" };
  const save = async () => {
    await saveQuick(q);
    await refresh();
  };
  if (q.kind === "someday") list.push({ icon: "task", kind: "Bir ara listesine eklenecek", title: q.text, detail: quickLabel(q), run: save });
  if (q.kind === "reminder" && q.text)
    list.push({ icon: "clock", kind: "Hatırlatıcı oluşturulacak", title: q.text, detail: `${relativeDay(q.due)} ${clock(q.due)} · ${state.data.defaults.name || "Normal"}`, run: save });
  list.push(...sections.filter((s) => s[1].toLocaleLowerCase("tr-TR").startsWith(low) || s[3].toLocaleLowerCase("tr-TR").includes(low)).map(go));
  list.push({
    icon: "mic",
    kind: "Asistana gönderilecek",
    title: t,
    detail: "Sesli komutla aynı şekilde işlenir",
    run: async () => {
      await rpc("speech.command", { text: t });
      await refresh();
    },
  });
  if (q.kind === "task" && q.text) list.push({ icon: "task", kind: "Görev eklenecek", title: q.text, detail: quickLabel(q), run: save });
  const search = (page) => async () => {
    state.query[page] = t;
    await action("navigate", { dataset: { page } });
    $(`#${page}-search`)?.dispatchEvent(new Event("input", { bubbles: true }));
  };
  list.push(
    { icon: "music", kind: "Spotify'da aranacak", title: t, detail: "Müzik", run: search("spotify") },
    { icon: "game", kind: "Steam'de aranacak", title: t, detail: "Oyunlar", run: search("steam") },
    {
      icon: "ai",
      kind: "AI'lara sorulacak",
      title: t,
      detail: "AI sohbetleri",
      run: async () => {
        await action("navigate", { dataset: { page: "ai" } });
        toast(await rpc("ai.send", { text: t, targets: state.targets }));
      },
    },
  );
  return list;
}
function commandPalette() {
  closeMenu();
  state.modal = "Komut";
  $("#portal").innerHTML = `<div class="modal-layer palette-layer"><section class="dialog palette" role="dialog" aria-modal="true" aria-label="Komut"><label class="palette-input">${I("search")}<input id="palette-input" autocomplete="off" spellcheck="false" placeholder="Komut yaz, görev veya hatırlatıcı ekle…" aria-label="Komut"><kbd>Esc</kbd></label><div id="palette-preview" class="palette-preview"></div><div id="palette-options" class="palette-options" role="listbox" aria-label="Seçenekler"></div></section></div>`;
  const layer = $("#portal .modal-layer"),
    input = $("#palette-input");
  let options = [],
    selected = 0,
    parsed = null,
    pending = Promise.resolve();
  // Ayrıştırma C#'ta yapılır; yanıt gelince seçenekler yeniden çizilir. Enter yanıtı bekler.
  function parse() {
    const text = input.value.trim();
    parsed = null;
    pending = text
      ? parseQuick(text).then(
          (q) => {
            if (input.value.trim() === text) {
              parsed = q;
              draw();
            }
          },
          () => {},
        )
      : Promise.resolve();
  }
  function draw() {
    options = paletteOptions(input.value, parsed);
    selected = Math.min(selected, options.length - 1);
    const o = options[selected];
    $("#palette-preview").innerHTML = `<span class="palette-icon">${I(o.icon)}</span><div><small>${esc(o.kind)}</small><strong>${esc(o.title)}</strong><span>${esc(o.detail)}</span></div><kbd>Enter</kbd>`;
    $("#palette-options").innerHTML = options
      .map((x, i) => `<button type="button" role="option" class="palette-option ${i === selected ? "active" : ""}" aria-selected="${i === selected}" data-palette="${i}">${I(x.icon)}<span>${esc(x.kind)}</span><small>${esc(x.detail)}</small></button>`)
      .join("");
    $(".palette-option.active")?.scrollIntoView({ block: "nearest" });
  }
  function choose(i) {
    const o = options[i];
    if (!o) return;
    closeDialog();
    run(o.run);
  }
  input.addEventListener("input", () => {
    selected = 0;
    parse();
    draw();
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      selected = (selected + (e.key === "ArrowDown" ? 1 : options.length - 1)) % options.length;
      draw();
    }
    if (e.key === "Enter" && !e.isComposing) {
      e.preventDefault();
      pending.then(() => choose(selected));
    }
  });
  $("#palette-options").addEventListener("click", (e) => {
    const b = e.target.closest("[data-palette]");
    if (b) choose(+b.dataset.palette);
  });
  layer.addEventListener("mousedown", (e) => {
    if (e.target === layer) closeDialog();
  });
  draw();
  if (!reducedMotion()) {
    layer.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 140, easing: "ease-out" });
    $(".palette", layer).animate([{ transform: "translateY(-8px) scale(.98)", opacity: 0 }, { transform: "none", opacity: 1 }], { duration: 180, easing: easeOut });
  }
  scheduleSlots();
  setTimeout(() => input.focus(), 10);
}

// ---------------------------------------------------------------- Ayar pencereleri
// Eskiden ayrı Windows pencereleriydi; artık aynı belgede, ortada açılırlar.

// Uzun süren işlemlerde düğmeleri kilitler ve durum satırını günceller.
async function busy(statusSelector, text, work) {
  const buttons = $$("#portal .dialog-content button:not([data-action=dialog-close])");
  buttons.forEach((b) => (b.disabled = true));
  if (text) $(statusSelector).textContent = text;
  try {
    return await work();
  } catch (e) {
    if ($(statusSelector)) $(statusSelector).textContent = e.message;
  } finally {
    buttons.forEach((b) => b.isConnected && (b.disabled = b.dataset.locked === "1"));
  }
}

// Steam istek listesini içe aktar. Bu bilgisayarda Steam'e giriş yapılmışsa hesap kendiliğinden bulunur
// (Steam'in loginusers.vdf dosyasından; "steam.localAccount"), tek tıkla alınır. Bulunamazsa ya da başka hesap
// istenirse profil bağlantısı yazılır (bu bilgisayarda hatırlanır).
async function steamWishlistDialog() {
  let saved = "";
  try {
    saved = localStorage.getItem("steam-profile") || "";
  } catch {}
  const account = await rpc("steam.localAccount").catch(() => null);
  const manualHelp = `<p class="muted small">Bağlantıyı bulmak için: Steam'de sağ üstte adına tıkla → <strong>Profil</strong>. Profil sayfasında boş bir yere sağ tıkla → <strong>Sayfa URL'sini kopyala</strong> ve buraya yapıştır.</p>`;
  openDialog(
    "Steam istek listesini al",
    `<p class="muted">İstek listendeki oyunlar takibe alınır; çıkışları, büyük güncellemeleri ve indirimleri bildirilir.</p>
    <form id="steam-wishlist-form">
    ${account ? `<div class="steam-account" id="steam-account"><strong>${esc(account.name)}</strong><small class="muted">Bu bilgisayardaki Steam hesabın</small>${B("Başka hesap", "steam-other-account", "", "text-button")}</div>` : ""}
    <div id="steam-manual" ${account ? "hidden" : ""}><div class="fields">${field("Steam profil bağlantın", `<input name="profile" value="${esc(saved)}" placeholder="steamcommunity.com/id/adın" autocomplete="off">`, true)}</div>${manualHelp}</div>
    <p id="steam-wishlist-status" class="status-box" role="status">${account ? "" : "Bu bilgisayarda Steam hesabı bulunamadı; profil bağlantını yaz. "}En fazla 50 oyun takip edilir; zaten takipte olanlar atlanır.</p>
    <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">İçe aktar</button></div></form>`,
  );
  const form = $("#steam-wishlist-form");
  let useAccount = !!account;
  const other = $('#portal [data-action="steam-other-account"]');
  if (other)
    other.onclick = (e) => {
      e.stopPropagation();
      useAccount = false;
      $("#steam-account").hidden = true;
      $("#steam-manual").hidden = false;
      form.elements.profile.focus();
    };
  if (!account) form.elements.profile.focus();
  form.onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const profile = useAccount ? account.steamId : form.elements.profile.value.trim();
    if (!profile) return ($("#steam-wishlist-status").textContent = "Steam profil bağlantını yaz.");
    busy("#steam-wishlist-status", "İstek listesi okunuyor ve oyunlar takibe alınıyor… (oyun başına ~1 sn)", async () => {
      try {
        const result = await rpc("operation", { name: "steam.importWishlist", parameters: { profile } }, 10 * 60000);
        if (!useAccount)
          try {
            localStorage.setItem("steam-profile", profile);
          } catch {}
        if (result.added > 0) playSound("add");
        await refresh();
        if (form.isConnected) $("#steam-wishlist-status").textContent = result.message;
        else toast(result.message);
      } catch (err) {
        // Gizli liste: nereden açılacağını adım adım söyle.
        if (/gizli/.test(err.message))
          throw new Error("İstek listen gizli görünüyor. Steam'de: adına tıkla → Profil → Profili Düzenle → Gizlilik Ayarları → \"Oyun ayrıntıları\"nı Herkese açık yap, sonra tekrar dene.");
        throw err;
      }
    });
  };
}

// Hedef fiyat: oyun bu fiyata ya da altına inince bildirim gelir (telefon bağlıysa oraya da). Fiyat oyunun kendi
// para biriminde girilir ("12,99" ya da "12.99"); hızlı seçenekler şu anki normal fiyattan hesaplanır.
function steamTargetDialog(id) {
  const game = state.data.steam.find((g) => g.id === id);
  if (!game?.price || game.price.free) return toast("Bu oyunun fiyatı henüz bilinmiyor.");
  const cur = game.price.currency,
    normal = game.price.initial;
  const presets = [
    ["%25 indirim", Math.round(normal * 0.75)],
    ["%50 indirim", Math.round(normal * 0.5)],
    ["%75 indirim", Math.round(normal * 0.25)],
    ...(game.lowestPrice && game.lowestPrice < normal ? [["Görülen en düşük", game.lowestPrice]] : []),
  ];
  const asText = (cents) => (cents / 100).toFixed(2).replace(".", ",");
  openDialog(
    "Hedef fiyat",
    `<p class="muted"><strong>${esc(game.name)}</strong> bu fiyata ya da altına inince haber veririm. Şu an: ${esc(money(game.price.final, cur))}${game.price.discount ? ` (normalde ${esc(money(normal, cur))})` : ""}.</p>
    <form id="steam-target-form"><div class="fields">${field(`Hedef fiyat (${esc(cur)})`, `<input name="price" inputmode="decimal" autocomplete="off" value="${game.targetPrice ? asText(game.targetPrice) : ""}" placeholder="${asText(Math.round(normal * 0.5))}" required>`, true)}</div>
    <div class="button-row" style="margin-top:8px">${presets.map(([label, cents]) => B(`${esc(label)} · ${esc(money(cents, cur))}`, "target-preset", "", "ghost", `data-cents="${cents}"`)).join("")}</div>
    <p id="steam-target-status" class="hint" role="status"></p>
    <div class="dialog-actions">${game.targetPrice ? B("Hedefi kaldır", "target-clear", "trash", "ghost push-left") : ""}${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Kaydet</button></div></form>`,
  );
  const form = $("#steam-target-form");
  form.elements.price.focus();
  const save = (cents) =>
    run(async () => {
      await rpc("operation", { name: "steam.target", parameters: { id, price: cents } });
      closeDialog();
      await refresh();
      toast(cents == null ? "Hedef fiyat kaldırıldı." : cents >= game.price.final ? `Şu an zaten hedefin altında: ${money(game.price.final, cur)}.` : `Hedef kaydedildi: ${money(cents, cur)}. O fiyata inince haber veririm.`);
    });
  $$('#portal [data-action="target-preset"]').forEach((b) => (b.onclick = (e) => {
    e.stopPropagation();
    form.elements.price.value = asText(+b.dataset.cents);
  }));
  const clear = $('#portal [data-action="target-clear"]');
  if (clear) clear.onclick = (e) => {
    e.stopPropagation();
    save(null);
  };
  form.onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const value = Number(form.elements.price.value.trim().replace(/[^\d,.]/g, "").replace(",", "."));
    if (!(value > 0) || value > 100000) return ($("#steam-target-status").textContent = "Geçerli bir fiyat yaz (ör. 9,99).");
    save(Math.round(value * 100));
  };
}

function defaultsDialog() {
  let { level, count, intervalMinutes } = state.data.defaults;
  openDialog(
    "Hatırlatma sıklığı",
    `<p class="muted">Yeni hatırlatıcılar varsayılan olarak bu şekilde hatırlatılır.</p>
    <div class="segmented wide-segments" role="group" aria-label="Hatırlatma biçimi">${B("Normal", "level-pick", "", "", 'data-level="Normal"')}${B("Yapana kadar", "level-pick", "", "", 'data-level="Adhd"')}</div>
    <div class="fields" style="margin-top:16px">${field("Her turda kaç kez?", '<input id="opt-count" type="number" min="1" max="20">')}${field("Tekrarlar arası (dakika)", '<input id="opt-interval" type="number" min="1" max="1440">')}</div>
    <p id="opt-unlimited" class="muted" hidden>Sınırsız · onaylayana kadar tekrar eder.</p>
    <p id="opt-summary" class="summary-line"></p>
    <p class="muted small">Yapana kadar (DEHB için): onaylayana kadar sınırsız tekrar. Aralık her tekrarda yarıya iner, en sık 3 dakikada bir; bilgisayardan uzaktayken tekrarlar bekler; 4. bildirimden itibaren ortada görünür. “Yaptım” yanıtı ayrıca onaylanır.</p>
    <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}${B("Uygula", "defaults-apply", "", "primary")}</div>`,
  );
  const presets = { Normal: [1, 15], Adhd: [6, 10] };
  let describeTimer;
  const update = () => {
    $$("[data-level]").forEach((b) => b.classList.toggle("active", b.dataset.level === level));
    $("#opt-count").closest(".field").hidden = level === "Adhd";
    $("#opt-unlimited").hidden = level !== "Adhd";
    $("#opt-count").value = count;
    $("#opt-interval").value = intervalMinutes;
    $("#opt-interval").disabled = level !== "Adhd" && count <= 1;
    clearTimeout(describeTimer);
    describeTimer = setTimeout(
      () =>
        rpc("options.describe", { level, count, intervalMinutes })
          .then((d) => $("#opt-summary") && ($("#opt-summary").textContent = d.description))
          .catch(() => {}),
      120,
    );
  };
  $$("[data-level]").forEach(
    (b) =>
      (b.onclick = (e) => {
        e.stopPropagation();
        level = b.dataset.level;
        [count, intervalMinutes] = presets[level];
        update();
      }),
  );
  $("#opt-count").onchange = (e) => {
    count = Math.min(20, Math.max(1, +e.target.value || 1));
    update();
  };
  $("#opt-interval").onchange = (e) => {
    intervalMinutes = Math.min(1440, Math.max(1, +e.target.value || 1));
    update();
  };
  $('[data-action="defaults-apply"]').onclick = (e) => {
    e.stopPropagation();
    run(async () => {
      await rpc("defaults.save", { level, count, intervalMinutes });
      closeDialog();
      await refresh();
    });
  };
  update();
}

// Odak (pomodoro) ayarları: süreler, molada bekletilen hatırlatmalar, dikkat dağıtıcı uygulamalar (Core/Focus/FocusSession.cs).
async function focusSettingsDialog() {
  const s = await rpc("focus.settings");
  const mac = state.data.live?.platform === "mac";
  const num = (name, label, value, min, max) => `<div class="pref-row"><span>${label}</span><input type="number" name="${name}" value="${value}" min="${min}" max="${max}"></div>`;
  openDialog(
    "Odak (pomodoro)",
    `<form id="focus-form"><p class="muted">Çalışma turundan sonra mola gelir; mola bitince yeni tur kendiliğinden başlamaz, sana sorulur.</p>
    <div class="pref-list">${num("workMinutes", "Çalışma (dk)", s.workMinutes, 5, 180)}${num("breakMinutes", "Mola (dk)", s.breakMinutes, 1, 60)}${num("longBreakMinutes", "Uzun mola (dk)", s.longBreakMinutes, 1, 90)}${num("longEvery", "Kaç turda bir uzun mola", s.longEvery, 2, 10)}</div>
    <label class="toggle-row"><span>Hatırlatmaları molaya beklet<small class="muted"> Açıksa sıradan hatırlatmalar tur bitince toplu gelir (en fazla bir tur gecikir). "Yapana kadar" olanlar beklemez.</small></span><input type="checkbox" class="switch" name="holdReminders" ${s.holdReminders ? "checked" : ""}></label>
    ${mac ? "" : `<label class="toggle-row"><span>Dikkat dağıtıcı uygulamada sor<small class="muted"> Turda bu uygulamalar öne gelince "kapatayım mı?" diye sorar; zorla kapatmaz.</small></span><input type="checkbox" class="switch" name="watchApps" ${s.watchApps ? "checked" : ""}></label>
    ${field("Uygulamalar (süreç adları, virgülle)", `<input name="apps" maxlength="1200" value="${esc((s.distractingApps?.length ? s.distractingApps : FOCUS_DEFAULT_APPS).join(", "))}">`)}`}
    <div class="pref-row"><span>Ortam sesi<small class="muted"> Çalışma turunda arka planda çalar (bu bilgisayarda saklanır).</small></span><span class="ambient-pick"><select name="ambient" aria-label="Ortam sesi">${Object.entries(AMBIENT_KINDS).map(([k, v]) => `<option value="${k}" ${ambientPrefs().kind === k ? "selected" : ""}>${v}</option>`).join("")}</select><input type="range" name="ambientVolume" min="5" max="100" value="${ambientPrefs().volume}" aria-label="Ortam sesi seviyesi"></span></div>
    <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Kaydet</button></div></form>`,
  );
  const form = $("#focus-form");
  form.onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    run(async () => {
      const f = form.elements;
      const apps = f.apps ? f.apps.value.split(",").map((x) => x.trim().toLowerCase().replace(/\.exe$/, "")).filter(Boolean) : s.distractingApps;
      setAmbientPrefs({ kind: f.ambient.value, volume: +f.ambientVolume.value });
      await rpc("focus.save", { workMinutes: +f.workMinutes.value, breakMinutes: +f.breakMinutes.value, longBreakMinutes: +f.longBreakMinutes.value, longEvery: +f.longEvery.value, holdReminders: f.holdReminders.checked, watchApps: f.watchApps ? f.watchApps.checked : s.watchApps, distractingApps: apps });
      closeDialog();
      toast("Odak ayarları kaydedildi.");
    });
  };
}
// Komut geri bildirimi (Core/Feedback/CommandFeedback.cs): anlaşılmayan komutlar geliştiricinin formuna gider; kullanıcı ne gittiğini burada görür.
const FEEDBACK_STATUS = { sent: "Gönderildi", waiting: "Gönderilmeyi bekliyor", local: "Yalnız bu bilgisayarda" };
async function feedbackDialog() {
  const s = await rpc("feedback.get");
  const list = s.entries?.length
    ? `<ul class="feedback-list">${s.entries.map((e) => `<li><strong>${esc(e.text)}</strong><small class="muted">${esc(relativeDay(e.at))} ${clock(e.at)} · ${esc(e.phase)} · ${FEEDBACK_STATUS[e.status] || ""}</small></li>`).join("")}</ul>`
    : `<p class="muted small">Henüz kayıt yok.</p>`;
  openDialog(
    "Komut geri bildirimi",
    `<form id="feedback-form"><p class="muted">Asistanın anlamadığı ya da yanlış anlayabileceği komutlar, düzeltilebilmeleri için geliştiriciye gönderilir. Anlayıp yaptığı komutlar gönderilmez.</p>
    <label class="toggle-row"><span>Anlaşılmayan komutları gönder<small class="muted"> Yalnız cümle, sonuç ve uygulama sürümü gider; adın ya da hesapların gitmez. Bu kurulumun numarası: ${esc(s.installId || "")}</small></span><input type="checkbox" class="switch" name="share" ${s.share ? "checked" : ""}></label>
    ${s.available ? "" : `<p class="muted small">Gönderim bu sürümde henüz açık değil; kayıt yalnız bu bilgisayarda tutulur.</p>`}
    <h3 class="form-label">Son kaydedilenler</h3>${list}
    <div class="dialog-actions">${s.entries?.length ? B("Kaydı temizle", "feedback-clear", "trash", "ghost") : ""}${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Kaydet</button></div></form>`,
  );
  const form = $("#feedback-form");
  $("[data-action=feedback-clear]", form)?.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    run(async () => { await rpc("feedback.clear"); closeDialog(); toast("Komut kaydı temizlendi."); });
  });
  form.onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    run(async () => {
      await rpc("feedback.save", { share: form.elements.share.checked });
      closeDialog();
      toast(form.elements.share.checked ? "Anlaşılmayan komutlar geliştiriciye gönderilecek." : "Tamam, anlaşılmayan komutlar yalnız bu bilgisayarda kalacak.");
    });
  };
}
// Gönderim açıkken bir kez haber verilir (tanıtım turundan sonra, pencere boşken). Testte açılmaz.
let feedbackNoticeTried = false;
function feedbackNoticeAutoStart() {
  if (feedbackNoticeTried || !state.data || state.data.live?.testing || state.modal || document.hidden || $("#tour")) return;
  if (typeof tourSeen === "function" && !tourSeen() && !compact()) return;
  feedbackNoticeTried = true;
  rpc("feedback.get").then((s) => {
    if (!s.available || !s.share || s.noticeShown || state.modal) return;
    openDialog(
      "Küçük bir bilgi",
      `<p>Asistanın anlamadığı sesli ve yazılı komutlar, düzeltilebilmeleri için geliştiriciye gönderilir. Anlayıp yaptığı komutlar, adın ve hesapların gönderilmez.</p>
      <p class="muted small">İstediğin zaman Ayarlar → Komut geri bildirimi'nden kapatabilir, neyin gittiğini görebilirsin.</p>
      <div class="dialog-actions">${B("Gönderme", "feedback-off", "", "ghost")}${B("Tamam", "dialog-close", "", "primary")}</div>`,
    );
    rpc("feedback.notice").catch(() => {});
    $("#portal [data-action=feedback-off]")?.addEventListener("click", (e) => {
      e.stopPropagation();
      run(async () => { await rpc("feedback.save", { share: false }); closeDialog(); toast("Tamam, anlaşılmayan komutlar yalnız bu bilgisayarda kalacak."); });
    });
  }).catch(() => {});
}
const FOCUS_DEFAULT_APPS = ["steam", "steamwebhelper", "discord", "epicgameslauncher", "riotclientux", "riotclientservices", "battle.net", "leagueclient", "valorant"];
// Bildirimleri hafifletme: sabah özeti ve aynı anda gelenleri toplama (Core/Notifications/NotificationPlan.cs).
async function notificationsDialog() {
  const s = await rpc("notifications.get");
  const mac = state.data.live?.platform === "mac";
  openDialog(
    "Bildirimler",
    `<form id="notifications-form">
    ${mac ? "" : `<h3 class="form-label" style="margin-top:0">Rahatsız etme</h3>
    <p class="muted small">Sessizken hatırlatmalar ve diğer bildirimler bekler, sessizlik bitince birlikte gelir. "Yapana kadar" hatırlatmalar (ilaç gibi) yine hemen gelir.</p>
    <label class="toggle-row"><span>Sessiz saatler<small class="muted"> Her gün bu saatler arasında; gece yarısını geçebilir (23:00–08:00 gibi).</small></span><input type="checkbox" class="switch" name="quietEnabled" ${s.quietEnabled ? "checked" : ""}></label>
    <div class="quiet-times"><label class="schedule-time">Başlangıç <input type="time" name="quietStart" value="${minutesText(s.quietStart ?? 1380)}"></label><label class="schedule-time">Bitiş <input type="time" name="quietEnd" value="${minutesText(s.quietEnd ?? 480)}"></label></div>
    <label class="toggle-row"><span>Tam ekran oyun ya da videoda sessiz kal<small class="muted"> Oyun, tam ekran video ya da sunum öndeyken bildirim pencereleri açılmaz.</small></span><input type="checkbox" class="switch" name="quietFullscreen" ${s.quietFullscreen !== false ? "checked" : ""}></label>
    <h3 class="form-label">Özet ve toplama</h3>`}
    <p class="muted">Her hatırlatma için ayrı bildirim yerine günü tek bakışta gör.</p>
    <label class="toggle-row"><span>Sabah özeti<small class="muted"> Her sabah tek bildirim: günün planları, görevleri ve gecikenler (hatırlatmasız dersler dahil).</small></span><input type="checkbox" class="switch" name="digestEnabled" ${s.digestEnabled ? "checked" : ""}></label>
    <label class="schedule-time" style="margin:8px 0 14px">Saat <input type="time" name="digestTime" required value="${minutesText(s.digestMinutes)}"></label>
    ${mac ? "" : `<label class="toggle-row"><span>Özeti sesli de oku<small class="muted"> Özet saatinde doğal sesle okunur (Ses ayarlarında sesli cevap açıksa). Oyun ya da video sırasında araya girebileceği için varsayılan kapalı. İstediğinde "günaydın" ya da "bugün ne var" demen yeter.</small></span><input type="checkbox" class="switch" name="speakDigest" ${s.speakDigest ? "checked" : ""}></label>`}
    ${mac ? "" : `<label class="toggle-row"><span>Akşam kapanışı<small class="muted"> Bu saatte tek bir nazik bildirim: bugün bitenleri gör, kalanları tek tıkla yarına ya da bir araya at.</small></span><input type="checkbox" class="switch" name="shutdownEnabled" ${s.shutdownEnabled !== false ? "checked" : ""}></label>
    <label class="schedule-time" style="margin:8px 0 14px">Saat <input type="time" name="shutdownTime" value="${minutesText(s.shutdownMinutes ?? 1260)}"></label>`}
    ${mac ? "" : `<label class="toggle-row"><span>Aynı anda gelenleri topla<small class="muted"> Birkaç saniye içinde düşen hatırlatmalar tek bildirimde listelenir. "Yapana kadar" olanlar ayrı kalır.</small></span><input type="checkbox" class="switch" name="groupReminders" ${s.groupReminders ? "checked" : ""}></label>`}
    <div class="digest-preview" id="digest-preview" hidden></div>
    <div class="phone-section" id="phone-section"></div>
    <div class="dialog-actions">${B("Bugünün özetini göster", "digest-preview", "", "ghost")}${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Kaydet</button></div></form>`,
  );
  const form = $("#notifications-form");
  // Telefon (ntfy): bağla → konu adını ntfy uygulamasında abone ol. Konu adı şifre gibidir; yalnız istenince gösterilir.
  const phoneNote = (text, ok = true) => { const n = $("#phone-note"); if (n) { n.textContent = text; n.classList.toggle("inline-error", !ok); } };
  const topicBox = (t) => `<div class="phone-topic"><code>${esc(t.topic)}</code>${B("Kopyala", "phone-copy", "", "ghost", `data-topic="${esc(t.topic)}"`)}</div><p class="muted small">Sunucu: ${esc(t.server)}. Telefonunda ücretsiz <strong>ntfy</strong> uygulamasını kur, + ile bu konuya abone ol (sunucu ntfy.sh ise varsayılan). Konu adını kimseyle paylaşma: bilen herkes bildirimlerini okuyabilir ve sana ekleme yapabilir.</p>`;
  let phoneState = null;
  const drawPhone = (st, topic = null) => {
    phoneState = st;
    const box = $("#phone-section");
    if (!box) return;
    box.innerHTML = `<h3 class="form-label">Telefon (ntfy)</h3>` + (!st.linked
      ? `<p class="muted small">Hatırlatmalar ve sabah özeti telefonuna da düşsün; telefondan "yarın 9'da dişçi" yazınca buraya eklensin. Hesap gerekmez. Mesajlar ntfy sunucusundan geçer.</p><div class="toolbar">${B("Telefonu bağla", "phone-link", "plus", "ghost")}</div>`
      : `<label class="toggle-row"><span>Telefona gönder<small class="muted"> Hatırlatmanın ilk bildirimi ve sabah özeti. Telefondan yazdıkların yalnız görev/hatırlatıcı olarak eklenir.</small></span><input type="checkbox" class="switch" name="phoneEnabled" ${st.enabled ? "checked" : ""}></label>
        <label class="toggle-row"><span>Ayrıntıları göster<small class="muted"> Kapalıysa telefona yalnız "bir hatırlatman var" gider; metin sunucudan geçmez.</small></span><input type="checkbox" class="switch" name="phoneDetails" ${st.showDetails ? "checked" : ""}></label>
        ${topic ? topicBox(topic) : ""}
        <div class="toolbar">${topic ? "" : B("Konu adını göster", "phone-topic", "", "ghost")}${B("Deneme gönder", "phone-test", "", "ghost")}${B("Bağlantıyı kaldır", "phone-unlink", "trash", "ghost")}</div>`) + `<p id="phone-note" class="muted small"></p>`;
  };
  rpc("phone.status").then((st) => drawPhone(st), () => $("#phone-section")?.remove());
  $("#phone-section").addEventListener("click", (e) => {
    const b = e.target.closest("[data-action]");
    if (!b) return;
    e.stopPropagation();
    const a = b.dataset.action;
    run(async () => {
      if (a === "phone-link") { const t = await rpc("phone.link"); drawPhone(await rpc("phone.status"), t); phoneNote("Bağlandı. Şimdi telefonda bu konuya abone ol, sonra \"Deneme gönder\"."); }
      if (a === "phone-topic") drawPhone(await rpc("phone.status"), await rpc("phone.topic"));
      if (a === "phone-copy") { await navigator.clipboard.writeText(b.dataset.topic); phoneNote("Konu adı kopyalandı."); }
      if (a === "phone-test") phoneNote(await rpc("phone.test", {}, 30000));
      if (a === "phone-unlink") {
        if (b.dataset.sure !== "1") { b.dataset.sure = "1"; b.lastChild.textContent = "Emin misin? Tekrar bas"; return; }
        drawPhone(await rpc("phone.unlink")); phoneNote("Telefon bağlantısı kaldırıldı. Telefondaki aboneliği de silebilirsin.");
      }
    }).catch((err) => phoneNote(err.message, false));
  });
  form.onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    run(async () => {
      const minutes = textMinutes(form.elements.digestTime.value);
      if (minutes == null) throw new Error("Özet saatini seç.");
      await rpc("notifications.save", { digestEnabled: form.elements.digestEnabled.checked, digestMinutes: minutes, groupReminders: form.elements.groupReminders ? form.elements.groupReminders.checked : s.groupReminders, speakDigest: form.elements.speakDigest ? form.elements.speakDigest.checked : s.speakDigest, shutdownEnabled: form.elements.shutdownEnabled ? form.elements.shutdownEnabled.checked : s.shutdownEnabled !== false, shutdownMinutes: (form.elements.shutdownTime && textMinutes(form.elements.shutdownTime.value)) ?? s.shutdownMinutes ?? 1260,
        quietEnabled: form.elements.quietEnabled ? form.elements.quietEnabled.checked : !!s.quietEnabled, quietFullscreen: form.elements.quietFullscreen ? form.elements.quietFullscreen.checked : s.quietFullscreen !== false,
        quietStart: (form.elements.quietStart && textMinutes(form.elements.quietStart.value)) ?? s.quietStart ?? 1380, quietEnd: (form.elements.quietEnd && textMinutes(form.elements.quietEnd.value)) ?? s.quietEnd ?? 480 });
      if (phoneState?.linked && form.elements.phoneEnabled)
        await rpc("phone.save", { enabled: form.elements.phoneEnabled.checked, showDetails: form.elements.phoneDetails.checked, server: phoneState.server });
      closeDialog();
      toast("Bildirim ayarları kaydedildi.");
    });
  };
  form.querySelector('[data-action="digest-preview"]').onclick = (e) => {
    e.stopPropagation();
    run(async () => {
      const d = await rpc("notifications.preview");
      const box = $("#digest-preview");
      box.hidden = false;
      box.innerHTML = `<strong>${esc(d.title)}</strong>${d.message.split("\n").map((l) => `<div>${esc(l)}</div>`).join("")}`;
    });
  };
}
async function preferencesDialog() {
  const p = await rpc("preferences.get");
  const num = (name, value, min, max) => `<input type="number" name="${name}" value="${value}" min="${min}" max="${max}">`;
  const range = (label, a, b, max = 24) =>
    `<div class="pref-row"><span>${label}</span><div class="pref-range">${num(a, p[a], 0, max)}<span>–</span>${num(b, p[b], 0, max)}</div></div>`;
  openDialog(
    "Kişisel plan tercihleri",
    `<form id="preferences-form"><p class="muted">Kendi ritmini belirle. Saatler 24 saat düzenindedir; tercihler yalnızca saat önerilerini etkiler, kesin planlarını taşımaz ve bildirimleri susturmaz.</p>
    <div class="pref-list">${range("Hafta içi boş saatlerin", "weekdayStart", "weekdayEnd")}${range("Hafta sonu boş saatlerin", "weekendStart", "weekendEnd")}${range("Uyku (başlangıç – bitiş)", "sleepStart", "sleepEnd", 23)}${range("Tercih ettiğin çalışma saatleri", "preferredStart", "preferredEnd")}
    <div class="pref-row"><span>Görevler arası mola (dk)</span>${num("breakMinutes", p.breakMinutes, 0, 120)}</div>
    <div class="pref-row"><span>Günlük plan yükü üst sınırı (dk)</span>${num("dailyLimitMinutes", p.dailyLimitMinutes, 5, 1440)}</div>
    <div class="pref-row"><span>Varsayılan görev süresi (dk)</span>${num("defaultDuration", p.defaultDuration, 5, 720)}</div></div>
    <div class="check-row" style="margin-top:12px"><label class="check-label"><input type="checkbox" name="useWeekdays" ${p.useWeekdays ? "checked" : ""}>Hafta içi öner</label><label class="check-label"><input type="checkbox" name="useWeekends" ${p.useWeekends ? "checked" : ""}>Hafta sonu öner</label></div>
    <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Kaydet</button></div></form>`,
  );
  $("#preferences-form").onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const f = e.target,
      values = {};
    for (const input of $$("input[type=number]", f)) values[input.name] = +input.value;
    values.useWeekdays = f.elements.useWeekdays.checked;
    values.useWeekends = f.elements.useWeekends.checked;
    run(async () => {
      await rpc("preferences.save", values);
      closeDialog();
      toast("Plan tercihlerin kaydedildi.");
    });
  };
}

// Günü planla: bugünün (ve geciken) saatsiz tek seferlik görevlerini boş saatlere yerleştirir.
// Öneri C# tarafında (PlanSuggestions.PlanDay) hesaplanır; kaydedince her iş esnek bir plana dönüşür.
async function dayPlanner() {
  const key = today();
  const items = state.data.tasks
    .filter((t) => !t.dailyActivity && !t.done && (t.myDay === key || t.due === key || taskLate(t, key)))
    .sort((a, b) => Number(b.important) - Number(a.important));
  if (!items.length) {
    toast("Planlanacak saatsiz iş yok.");
    return;
  }
  const durations = [15, 30, 45, 60, 90, 120];
  openDialog(
    "Günü planla",
    `<p class="muted">Saatsiz işlerini bugünün boş saatlerine yerleştiririm. Kesin planların, aradaki molalar ve plan tercihlerin dikkate alınır; önemli işler önce yer alır. Kaydedince işler takvime esnek plan olarak geçer.</p>
    <div class="plan-rows">${items
      .map(
        (t) =>
          `<div class="plan-row" data-plan-task="${esc(t.id)}"><label class="check-label"><input type="checkbox" data-plan-pick checked><span>${t.important ? prioMark({ plan: { priority: 3 } }) : ""}${esc(t.title)}</span></label><select data-plan-duration aria-label="Süre">${durations.map((m) => `<option value="${m}" ${m === 30 ? "selected" : ""}>${m} dk</option>`).join("")}</select><span class="plan-slot" data-plan-slot>…</span></div>`,
      )
      .join("")}</div>
    <p id="day-load" class="summary-line" role="status"></p>
    <div class="dialog-actions">${B("Plan tercihleri", "preferences", "settings", "ghost push-left")}${B("Vazgeç", "dialog-close", "", "ghost")}<button type="button" id="day-plan-save" class="primary">Takvime yerleştir</button></div>`,
    { wide: true },
  );
  const rows = $$(".plan-row");
  const load = await rpc("day.load", { day: key });
  const span = (m) => (m >= 60 ? `${Math.floor(m / 60)} sa${m % 60 ? " " + (m % 60) + " dk" : ""}` : m + " dk");
  // İş yükü: seçilenlerin toplamı bugünkü boş zamanla karşılaştırılır; sığmayanlar tek tıkla yarına gider.
  function showLoad(picked) {
    const line = $("#day-load");
    if (!line) return;
    const need = picked.reduce((sum, r) => sum + +$("[data-plan-duration]", r).value, 0),
      missing = picked.filter((r) => !r.dataset.start),
      over = need > load.free;
    line.classList.toggle("is-warning", over || missing.length > 0);
    line.innerHTML =
      `Seçtiklerin <strong>${span(need)}</strong> · bugün planlamaya uygun boş zamanın <strong>${span(load.free)}</strong>.` +
      (over ? " Hepsi bugüne sığmıyor; süreleri kısaltabilir ya da bazılarını yarına atabilirsin." : "") +
      (missing.length ? " " + B(`Sığmayan ${missing.length} işi yarına at`, "day-plan-later", "", "ghost") : "");
    const later = $('#portal [data-action="day-plan-later"]');
    if (later)
      later.onclick = (e) => {
        e.stopPropagation();
        run(async () => {
          for (const r of missing) await moveTask(items.find((t) => t.id === r.dataset.planTask), tomorrow());
          toast(`${missing.length} iş yarına taşındı.`);
          closeDialog();
          await refresh();
        });
      };
  }
  async function suggest() {
    const picked = rows.filter((r) => $("[data-plan-pick]", r).checked);
    rows.forEach((r) => {
      delete r.dataset.start;
      $("[data-plan-slot]", r).textContent = picked.includes(r) ? "…" : "—";
    });
    if (!picked.length) {
      showLoad([]);
      return;
    }
    const slots = await rpc("day.plan", {
      day: key,
      plans: picked.map((r) => ({
        durationMinutes: +$("[data-plan-duration]", r).value,
        priority: items.find((t) => t.id === r.dataset.planTask).important ? 3 : 2,
        category: "Personal",
      })),
    });
    picked.forEach((r, i) => {
      const s = slots[i],
        cell = $("[data-plan-slot]", r);
      if (s) r.dataset.start = s.start;
      cell.textContent = s ? `${clock(s.start)} – ${clock(s.end)}` : "Bugüne sığmadı";
      cell.classList.toggle("is-missing", !s);
    });
    showLoad(picked);
  }
  rows.forEach((r) => $$("input, select", r).forEach((el) => (el.onchange = () => run(suggest))));
  $("#day-plan-save").onclick = () =>
    run(async () => {
      const placed = rows.filter((r) => r.dataset.start && $("[data-plan-pick]", r).checked);
      if (!placed.length) throw new Error("Yerleştirilecek iş yok; süreleri kısaltmayı ya da plan tercihlerini değiştirmeyi dene.");
      const d = state.data.defaults;
      for (const r of placed) {
        const t = items.find((x) => x.id === r.dataset.planTask);
        // Aynı kayda saat eklenir (kimlik, adımlar ve liste korunur).
        const start = new Date(r.dataset.start),
          form = await rpc("item.get", { id: t.id });
        await rpc("item.save", {
          form: { ...form, day: dayKey(start), timeMinutes: start.getHours() * 60 + start.getMinutes(), flexible: true, durationMinutes: +$("[data-plan-duration]", r).value, notify: form.notify || { level: d.level, count: d.count, intervalMinutes: d.intervalMinutes } },
        });
      }
      playSound("add");
      toast(`${placed.length} iş takvime yerleşti.`);
      closeDialog();
      await refresh();
    });
  await suggest();
}

async function googleDialog() {
  const g = await rpc("google.status");
  openDialog(
    "Google Calendar",
    `<h3 class="dialog-lead">Planların telefonunda da yanında</h3>
    <ol class="steps-list"><li>Google Cloud’da Calendar API’yi etkinleştir.</li><li>Google Auth Platform’da <strong>Desktop app</strong> türünde istemci oluştur ve JSON dosyasını indir. Test kullanıcısı olarak Gmail adresini ekle.</li><li>Dosyayı seç ve Google ile bağlan.</li></ol>
    <p class="muted small">Google’da ayrı bir Kişisel Asistan takvimi kullanılır. Bu takvimdeki saatli, tek seferlik planlar iki yönlü eşitlenir. Otomatik kontrol 5 dakikada bir yapılır. Özel bildirimler asistan açıkken çalışır.</p>
    <div class="button-row"><label class="file-button ${g.available ? "" : "is-disabled"}">${I("folder")}Bağlantı dosyasını seç (.json)<input id="google-file" type="file" accept=".json,application/json" ${g.available ? "" : "disabled"} hidden></label>${B("Google kurulumunu aç", "google-setup", "external", "ghost")}</div>
    <div class="button-row">${B("Google ile bağlan", "google-connect", "", "primary")}${B("Şimdi eşitle", "google-sync", "refresh")}${B("Bağlantıyı kes", "google-disconnect", "", "ghost danger")}</div>
    <p id="google-status" class="status-box" role="status">${esc(g.status)}</p>
    <p class="muted small">Telefonunda Google Calendar’ın Kişisel Asistan takvimini görünür yap.</p>`,
  );
  if (!g.available) $$('#portal [data-action^="google-"]').forEach((b) => ((b.disabled = true), (b.dataset.locked = "1")));
  $("#google-file").onchange = (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    if (file.size > 65536) {
      $("#google-status").textContent = "Bu dosya bir Google bağlantı dosyası olamayacak kadar büyük.";
      return;
    }
    busy("#google-status", "Dosya okunuyor…", async () => ($("#google-status").textContent = await rpc("google.import", { json: await file.text() })));
  };
  const actions = {
    "google-connect": ["Tarayıcıda Google hesabını seçip izin ver…", "google.connect"],
    "google-sync": ["Eşitleniyor…", "google.sync"],
    "google-disconnect": ["Bağlantı kesiliyor…", "google.disconnect"],
  };
  for (const [name, [text, method]] of Object.entries(actions))
    $(`#portal [data-action="${name}"]`).onclick = (e) => {
      e.stopPropagation();
      busy("#google-status", text, async () => {
        const status = await rpc(method, {}, 600000);
        if ($("#google-status")) $("#google-status").textContent = status;
      });
    };
  $('#portal [data-action="google-setup"]').onclick = (e) => {
    e.stopPropagation();
    run(() => rpc("google.setup"));
  };
}

async function ollamaDialog() {
  const o = await rpc("ollama.get");
  openDialog(
    "Komut zekâsı · Ollama",
    `<p class="muted">Anlaşılamayan sesli ve yazılı komutları bilgisayarındaki modele sor. Komutların bilgisayarında işlenir; Ollama ve model isteğe bağlıdır.</p>
    <label class="check-label"><input id="ollama-enabled" type="checkbox" ${o.enabled ? "checked" : ""}>Esnek komutlar için Ollama kullan</label>
    <div class="button-row" style="margin-top:12px"><select id="ollama-model" aria-label="Yerel model">${o.model ? `<option>${esc(o.model)}</option>` : '<option value="">Model yok</option>'}</select>${B("Yerel modelleri kontrol et", "ollama-discover", "refresh")}</div>
    <h3 class="dialog-lead" style="margin-top:18px">Kurulum</h3>
    <div class="button-row"><select id="ollama-package" aria-label="Kurulacak model">${o.packages.map((p, i) => `<option value="${i}">${esc(p)}</option>`).join("")}</select>${B("Ollama ve modeli kur", "ollama-install", "plus")}${B("İndirmeyi durdur", "ollama-stop", "stop", "ghost")}</div>
    <p class="muted small">İlk kurulum internet kullanır: modele ek olarak birkaç GB Ollama dosyası indirilir. Mevcut Ollama varsa kullanılır. İndirilenler uygulama güncellemelerinde korunur. Pencereyi kapatsan da indirme sürer.</p>
    <p id="ollama-status" class="status-box" role="status">${o.installing ? "Kurulum sürüyor…" : "Ollama ve yerel modeller kontrol ediliyor…"}</p>
    <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}${B("Kaydet", "ollama-save", "", "primary")}</div>`,
  );
  const stop = $('#portal [data-action="ollama-stop"]'),
    install = $('#portal [data-action="ollama-install"]');
  const installing = (on) => {
    stop.hidden = !on;
    install.dataset.locked = on ? "1" : "";
    install.disabled = on;
  };
  installing(o.installing);
  async function discover() {
    const select = $("#ollama-model");
    const chosen = select.value || o.model;
    const models = await rpc("ollama.models");
    if (!$("#ollama-model")) return models;
    select.innerHTML = models.length ? models.map((m) => `<option ${m === chosen ? "selected" : ""}>${esc(m)}</option>`).join("") : '<option value="">Model yok</option>';
    $("#ollama-status").textContent = models.length ? "Yerel bağlantı hazır. Modeli seçip etkinleştirebilirsin." : "Ollama açık, fakat yerel model yok. Model kurduktan sonra tekrar kontrol et.";
    return models;
  }
  $('#portal [data-action="ollama-discover"]').onclick = (e) => {
    e.stopPropagation();
    busy("#ollama-status", "Ollama ve yerel modeller kontrol ediliyor…", discover);
  };
  stop.onclick = (e) => {
    e.stopPropagation();
    rpc("ollama.stop").catch(() => {});
  };
  install.onclick = (e) => {
    e.stopPropagation();
    installing(true);
    $("#ollama-status").textContent = "Kurulum başlıyor…";
    rpc("ollama.install", { index: +$("#ollama-package").value }, 6 * 3600000)
      .then(async (model) => {
        if (!stop.isConnected) return toast("Ollama kurulumu tamamlandı.");
        const models = await discover();
        if (!models.includes(model)) return ($("#ollama-status").textContent = "İndirme bitti ancak model doğrulanamadı. Yerel modelleri kontrol et'e bas.");
        $("#ollama-model").value = model;
        $("#ollama-enabled").checked = true;
        $("#ollama-status").textContent = "Kurulum hazır. Etkinleştirmek için Kaydet'e bas.";
      })
      .catch((err) => (stop.isConnected ? ($("#ollama-status").textContent = err.message) : toast(err.message)))
      .finally(() => stop.isConnected && installing(false));
  };
  $('#portal [data-action="ollama-save"]').onclick = (e) => {
    e.stopPropagation();
    run(async () => {
      await rpc("ollama.save", { enabled: $("#ollama-enabled").checked, model: $("#ollama-model").value });
      closeDialog();
      toast("Ollama ayarı kaydedildi.");
    });
  };
  if (!o.installing) busy("#ollama-status", "", discover);
}

async function spotifyDialog() {
  const a = await rpc("spotify.account");
  openDialog(
    "Spotify bağlantısı",
    `<p class="status-line ${a.connected ? "is-on" : ""}">${a.connected ? "Bağlı" : "Bağlı değil"}</p>
    <h3 class="dialog-lead">Hesap bağlantısı</h3>
    <p class="muted small">Spotify, uygulamaları kendi listesine kayıtlı kişilere açıyor. Bu yüzden uygulamayı sana verenden bir “Client ID” (uygulamanın kimlik kodu, şifre değil) iste ve aşağıya yapıştır; o da senin Spotify e-postanı listesine ekler.</p>
    ${field("Client ID", `<input id="spotify-client" value="${esc(a.clientId)}" placeholder="Spotify Developer Client ID" autocomplete="off" spellcheck="false">`)}
    <div class="button-row" style="margin-top:10px">${B(a.connected ? "Yeniden bağlan" : "Spotify hesabını bağla", "spotify-connect", "", "primary")}${a.connected ? B("Bağlantıyı kaldır", "spotify-disconnect", "", "ghost danger") : ""}</div>
    <h3 class="dialog-lead" style="margin-top:18px">Masaüstü uygulaması</h3>
    <div class="button-row">${B("Spotify uygulamasını seç", "spotify-choose", "folder")}${B("Spotify durumunu kontrol et", "spotify-inspect", "search", "ghost")}</div>
    <details class="help-details"><summary>Kurulum yardımı</summary><p>Kendi Spotify hesabını bağla; yayıncının hesabıyla giriş yapman gerekmez. Yayıncı sana bir Client ID verdiyse buraya yapıştır. Client ID uygulamayı tanımlar; hesap şifresi değildir. Test modunda yayıncının senin hesabını uygulamanın kullanıcı listesine eklemesi gerekir.</p><p>Kendi geliştirici uygulamanı kullanmak istersen:</p><ol class="steps-list"><li>developer.spotify.com/dashboard üzerinden uygulama oluştur.</li><li>Redirect URI: <code>${esc(a.redirectUri)}</code></li><li>Web API seçeneğini kaydet, Client ID değerini buraya yapıştır. Client Secret gerekmez.</li></ol><p>Sonra “Spotify hesabını bağla”ya bas ve tarayıcıda izin ver. Şarkılar bilgisayarındaki Spotify uygulamasında çalar; doğrudan oynatma için Spotify Premium gerekir.</p></details>
    <p id="spotify-feedback" class="status-box" role="status">${a.connected ? "Hesabın bağlı. Şarkı arayıp sonuca tıklayınca çalar." : "Kodu yapıştırıp “Spotify hesabını bağla”ya bas."}</p>`,
  );
  const handlers = {
    "spotify-connect": ["Tarayıcıda kendi Spotify hesabını seçip izin ver…", () => rpc("spotify.connect", { clientId: $("#spotify-client").value.trim() }, 600000)],
    "spotify-disconnect": ["Bağlantı kaldırılıyor…", () => rpc("spotify.disconnect")],
    "spotify-choose": ["", () => rpc("spotify.chooseApp")],
    "spotify-inspect": ["Kontrol ediliyor…", () => rpc("spotify.inspect")],
  };
  for (const [name, [text, call]] of Object.entries(handlers)) {
    const b = $(`#portal [data-action="${name}"]`);
    if (b)
      b.onclick = (e) => {
        e.stopPropagation();
        busy("#spotify-feedback", text, async () => {
          const message = await call();
          if (message && $("#spotify-feedback")) $("#spotify-feedback").textContent = message;
        });
      };
  }
}

// Kısayol düzenleyicisinin içinde açılan uygulama seçici. Sonuç çift tıkla (veya Enter) eklenir.
let installedApps = null;
const fold = (s) => s.normalize("NFD").replace(/\p{M}/gu, "").toLocaleLowerCase("tr-TR");
function appPicker(container, add) {
  container.innerHTML = `<div class="app-picker"><label class="search">${I("search")}<input id="app-search" placeholder="Uygulama ara…" autocomplete="off" aria-label="Uygulama ara"></label><div id="app-list" class="app-list rows" role="listbox" aria-label="Uygulamalar"><div class="empty">Windows uygulamaları okunuyor…</div></div><div class="button-row"><small id="app-count" class="muted"></small><span class="spacer"></span>${B("Dosyadan seç…", "step-file", "folder", "ghost")}</div></div>`;
  const draw = () => {
    if (!installedApps || !$("#app-list")) return;
    const q = fold($("#app-search").value.trim());
    const found = installedApps.map((a, i) => [a, i]).filter(([a]) => !q || fold(a.name).includes(q));
    $("#app-list").innerHTML =
      found
        .slice(0, 80)
        .map(
          ([a, i]) =>
            `<div class="item-row is-pickable app-pick" tabindex="0" role="option" data-app="${i}" title="Eklemek için çift tıkla">${a.icon ? `<img class="app-icon" src="${a.icon}" alt="">` : `<span class="app-icon">${I("shortcut")}</span>`}<div class="item-copy"><strong>${esc(a.name)}</strong><small>Windows uygulaması</small></div><small class="pick-hint">Çift tıkla · ekle</small></div>`,
        )
        .join("") || `<div class="empty">${installedApps.length ? "Aramana uygun uygulama yok." : "Uygulama bulunamadı. Dosyadan seçebilirsin."}</div>`;
    $("#app-count").textContent = `${found.length} uygulama · listede olmayanlar için “Dosyadan seç”`;
  };
  const pick = (row) => {
    const a = installedApps[+row.dataset.app];
    add({ kind: "installed-app", target: a.id, label: a.name, browser: "default", minutes: 1 });
  };
  $("#app-search").oninput = draw;
  $("#app-list").ondblclick = (e) => {
    const row = e.target.closest("[data-app]");
    if (row) pick(row);
  };
  $("#app-list").onkeydown = (e) => {
    const row = e.key === "Enter" && e.target.closest("[data-app]");
    if (row) {
      e.preventDefault();
      pick(row);
    }
  };
  $('[data-action="step-file"]', container).onclick = (e) => {
    e.stopPropagation();
    run(async () => {
      const step = await rpc("routine.pickFile");
      if (step) add(step);
    });
  };
  setTimeout(() => $("#app-search")?.focus(), 20);
  if (installedApps) draw();
  else
    rpc("apps.list")
      .then((apps) => {
        installedApps = apps;
        draw();
      })
      .catch(() => {
        if ($("#app-list")) $("#app-list").innerHTML = '<div class="empty">Liste okunamadı. Dosyadan seçebilirsin.</div>';
      });
}

// ---------------------------------------------------------------- Toplu ekleme (sesli beyin boşaltma)
// Aklındakileri art arda söyler ya da yazarsın; metin işlere bölünür (C# BrainDump + WhenParser, "quick.split"),
// her satır hızlı eklemedeki gibi hatırlatıcı / bugünün görevi / bir ara olur. Yalnız işaretliler eklenir.
async function dumpDialog(text = "", { listen = false } = {}) {
  const open = $("#dump-form");
  if (open) {
    // Pencere açıkken dinleme bitti: duyulanlar metnin sonuna eklenir.
    const area = open.elements.text;
    area.value = [area.value.trim(), text.trim()].filter(Boolean).join(". ");
    area.dispatchEvent(new Event("input"));
    return;
  }
  openDialog(
    "Toplu ekle",
    `<p class="muted">Aklındakileri art arda söyle ya da yaz: "yarın 9'da dişçi, sonra market alışverişi, bir de bi ara dolabı düzenle". Ayrı işlere bölerim; kontrol edip eklersin.</p>
    <form id="dump-form"><textarea name="text" rows="4" aria-label="Eklenecekler" placeholder="Virgülle, noktayla ya da 'sonra', 'bir de' diyerek ayır…">${esc(text)}</textarea>
    <div class="button-row" style="margin-top:8px">${state.data.live?.platform === "mac" ? "" : B("Söyle", "dump-listen", "mic", "ghost")}<small id="dump-status" class="hint" role="status"></small></div>
    <div id="dump-list" class="dump-list" role="list"></div>
    <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary" id="dump-save" disabled>Ekle</button></div></form>`,
    { wide: true },
  );
  const form = $("#dump-form"),
    area = form.elements.text;
  let parsed = [],
    timer = 0;
  async function preview() {
    const value = area.value.trim();
    parsed = value ? await rpc("quick.split", { text: value }) : [];
    if (!$("#dump-list")) return;
    $("#dump-list").innerHTML = parsed
      .map((q, i) => `<label class="dump-row" role="listitem"><input type="checkbox" data-dump="${i}" checked><span>${esc(q.text)}</span><small class="muted">${esc(quickLabel(q))}</small></label>`)
      .join("");
    count();
  }
  function count() {
    const n = $$("[data-dump]:checked").length,
      save = $("#dump-save");
    if (!save) return;
    save.disabled = n === 0;
    save.textContent = n ? `${n} işi ekle` : "Ekle";
  }
  area.oninput = () => {
    clearTimeout(timer);
    timer = setTimeout(() => run(preview), 250);
  };
  $("#dump-list").onchange = count;
  const listenButton = $('#portal [data-action="dump-listen"]');
  // Mac: sesli toplu ekleme yok (dinleme komut olarak çalışır); yazarak eklenir.
  const startListening = () => {
    $("#dump-status").textContent = "Dinliyorum… bitirince 3-4 saniye sus ya da mikrofona bas.";
    listenButton.disabled = true;
    rpc("speech.listen", { dump: true }, 10 * 60000)
      .catch((err) => toast(err.message))
      .finally(() => {
        if (!listenButton.isConnected) return;
        listenButton.disabled = false;
        $("#dump-status").textContent = "";
      });
  };
  if (listenButton) listenButton.onclick = (e) => {
    e.stopPropagation();
    startListening();
  };
  form.onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    run(async () => {
      const picked = $$("[data-dump]:checked").map((c) => parsed[+c.dataset.dump]);
      for (const q of picked) await saveQuick(q, true);
      playSound("add");
      toast(`${picked.length} iş eklendi.`);
      closeDialog();
      await refresh();
    });
  };
  if (text) await preview();
  else area.focus();
  if (listen && listenButton) startListening();
}

// ---------------------------------------------------------------- Akşam kapanışı (Sunsama gibi)
// Bitenler kutlanır; kalan her iş tek tıkla yarına ya da "Bir ara"ya gider. Günlük aktiviteler ve hatırlatmasız
// planlar listelenmez (kendiliğinden tekrar ederler / bildirim vermezler). "Günü kapat" gün bitti sesini çalar.
function shutdownDialog() {
  const key = today(),
    now = new Date();
  const doneTasks = state.data.tasks.filter((t) => (t.dailyActivity ? (t.completedDays || []).includes(key) : t.done && (t.myDay === key || t.due === key)));
  const doneReminders = state.data.reminders.filter((r) => r.done && dayKey(new Date(r.due)) === key);
  const leftTasks = () => state.data.tasks.filter((t) => !t.dailyActivity && !t.done && (t.myDay === key || t.due === key || taskLate(t, key)));
  const leftReminders = () => state.data.reminders.filter((r) => !r.done && !isSilent(r) && !r.plan?.weekly && new Date(r.due) < now);
  const done = [...doneReminders.map((r) => r.text), ...doneTasks.map((t) => t.title)];
  openDialog(
    "Günü kapat",
    `<div class="shutdown-done">${done.length
      ? `<p><strong>Bugün ${done.length} iş bitirdin.</strong> Güzel iş.</p><ul>${done.slice(0, 6).map((x) => `<li>${esc(x)}</li>`).join("")}${done.length > 6 ? `<li class="muted">… ve ${done.length - 6} tane daha</li>` : ""}</ul>`
      : `<p>Bugün işaretlenmiş iş yok; olsun, yarın yeni bir gün.</p>`}</div>
    <div id="shutdown-left"></div>
    <div class="dialog-actions">${B("Kalanların hepsini yarına at", "shutdown-all", "", "ghost push-left")}<button type="button" class="primary" id="shutdown-close">Günü kapat</button></div>`,
    { wide: true },
  );
  const draw = () => {
    const box = $("#shutdown-left");
    if (!box) return;
    const tasks = leftTasks(),
      reminders = leftReminders();
    $('#portal [data-action="shutdown-all"]').hidden = !tasks.length && !reminders.length;
    box.innerHTML = tasks.length + reminders.length
      ? `<h3 class="form-label">Kalanlar · ${tasks.length + reminders.length}</h3><div class="shutdown-rows">${[
          ...reminders.map((r) => `<div class="shutdown-row"><span>${esc(r.text)}<small class="muted"> · ${esc(clock(r.due))}</small></span>${B("Yarına", "shutdown-move", "", "ghost", `data-kind="reminder" data-id="${esc(r.id)}"`)}</div>`),
          ...tasks.map((t) => `<div class="shutdown-row"><span>${esc(t.title)}</span>${B("Yarına", "shutdown-move", "", "ghost", `data-kind="task" data-id="${esc(t.id)}"`)}${B("Bir ara", "shutdown-someday", "", "ghost", `data-id="${esc(t.id)}"`)}</div>`),
        ].join("")}</div>`
      : `<p class="summary-line">Kalan iş yok. Yarına temiz başlıyorsun.</p>`;
  };
  draw();
  const moveOne = async (kind, id) => {
    if (kind === "reminder") {
      const r = state.data.reminders.find((x) => x.id === id);
      if (r) await moveReminder(r, moveTarget("same-tomorrow", r));
    } else {
      const t = state.data.tasks.find((x) => x.id === id);
      if (t) await moveTask(t, tomorrow());
    }
  };
  $("#portal").addEventListener("click", function handler(e) {
    if (!$("#shutdown-left")) return $("#portal").removeEventListener("click", handler);
    const b = e.target.closest("[data-action^=shutdown-]");
    if (!b) return;
    e.stopPropagation();
    run(async () => {
      if (b.dataset.action === "shutdown-move") await moveOne(b.dataset.kind, b.dataset.id);
      if (b.dataset.action === "shutdown-someday") await rpc("task.save", { task: { ...state.data.tasks.find((x) => x.id === b.dataset.id), myDay: null, due: null } });
      if (b.dataset.action === "shutdown-all") {
        for (const r of leftReminders()) await moveOne("reminder", r.id);
        for (const t of leftTasks()) await moveOne("task", t.id);
      }
      await refresh();
      draw();
    });
  });
  $("#shutdown-close").onclick = () => {
    playSound("allDone");
    closeDialog();
    toast(new Date().getHours() >= 18 ? "Gün kapandı. İyi akşamlar." : "Gün kapandı.");
  };
}

// ---------------------------------------------------------------- Adımlara böl (yerel Ollama, Goblin Tools gibi)
// Büyük bir işi 3–6 küçük adıma böler; öneriler önizlenir, seçilenler görevin adımlarına eklenir (mevcut adımlar kalır).
async function breakdownDialog(id) {
  const t = state.data.tasks.find((x) => x.id === id);
  if (!t) return;
  openDialog(
    "Adımlara böl",
    `<p class="muted"><strong>${esc(t.title)}</strong> için küçük, somut adımlar öneriyorum (bilgisayarındaki yapay zekâ ile, internetsiz).</p>
    <div id="breakdown-list" class="dump-list"><p class="muted">Düşünüyorum… (ilk seferde model yüklenirken biraz sürebilir)</p></div>
    <div class="dialog-actions">${B("Yeniden öner", "breakdown-again", "refresh", "ghost push-left")}${B("Vazgeç", "dialog-close", "", "ghost")}<button type="button" class="primary" id="breakdown-save" disabled>Adımları ekle</button></div>`,
  );
  let steps = [];
  const draw = () => {
    if (!$("#breakdown-list")) return;
    $("#breakdown-list").innerHTML = steps.map((s, i) => `<label class="dump-row"><input type="checkbox" data-step="${i}" checked><input class="breakdown-text" data-text="${i}" value="${esc(s)}" maxlength="120" aria-label="Adım ${i + 1}"><small class="muted">${i + 1}</small></label>`).join("");
    $("#breakdown-save").disabled = !steps.length;
  };
  const ask = async () => {
    $("#breakdown-save").disabled = true;
    try {
      steps = await rpc("task.breakdown", { title: t.title }, 180000);
      draw();
    } catch (e) {
      if ($("#breakdown-list")) $("#breakdown-list").innerHTML = `<p class="inline-error">${esc(e.message)}</p>`;
    }
  };
  $('#portal [data-action="breakdown-again"]').onclick = (e) => {
    e.stopPropagation();
    if ($("#breakdown-list")) $("#breakdown-list").innerHTML = '<p class="muted">Düşünüyorum…</p>';
    ask();
  };
  $("#breakdown-save").onclick = () =>
    run(async () => {
      const picked = $$("[data-step]:checked").map((c) => $(`[data-text="${c.dataset.step}"]`).value.trim()).filter(Boolean);
      if (!picked.length) return;
      const fresh = state.data.tasks.find((x) => x.id === id) || t;
      await rpc("task.save", { task: { ...fresh, steps: [...(fresh.steps || []), ...picked.map((text) => ({ text, done: false }))] } });
      playSound("add");
      toast(`${picked.length} adım eklendi.`);
      closeDialog();
      await refresh();
    });
  await ask();
}
