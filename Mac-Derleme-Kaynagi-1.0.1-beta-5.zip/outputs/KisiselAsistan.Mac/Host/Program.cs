using KisiselAsistan;

// Mac kabuğunun .NET tarafı. Electron masaüstü kabuğu bu süreci başlatır ve stdin/stdout üzerinden satır satır JSON ile konuşur;
// ağdan erişilen bir sunucu açılmaz. Arayüz Windows'taki WorkspaceWeb'in aynısıdır; arayüzün çağırdığı işlemler
// paylaşılan WorkspaceApi'ye (Core) gider. Platforma özgü olanlar MacHost'ta ya da Electron ana sürecindedir.
// --data <klasör>: veriyi ayrı klasörde tut (deneme ve testler gerçek veriye dokunmasın). --testing: hesaplar ve dış işlemler kapalı.
if (args.Contains("--self-test")) { await HostSelfTest.RunAsync(); return; }
var data = Array.IndexOf(args, "--data");
if (data >= 0 && data + 1 < args.Length) DeploymentPaths.UseDataFolder(args[data + 1]);
Console.OutputEncoding = System.Text.Encoding.UTF8; Console.InputEncoding = System.Text.Encoding.UTF8;
using var host = new MacHost(Console.Out, testing: args.Contains("--testing"));
await host.RunAsync(Console.In);
