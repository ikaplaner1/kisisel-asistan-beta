namespace KisiselAsistan;

// Keep the persisted numeric values of the former Low and Uber modes.
// Silent: takvimde ve Bugün'de görünür ama hiç bildirim vermez (ders programı, iş saatleri gibi); geciken sayılmaz.
public enum ReminderIntensity { Normal = 1, Adhd = 3, Silent = 5 }
// ADHD ("yapana kadar"): ilk tekrar IntervalMinutes sonra (varsayılan 10), her tekrarda yarıya iner, en sık AdhdFloorMinutes (3).
// 27 Ekim 2026'ya kadarki ADHD ön ayarı 3 dk'dan başlıyordu; kayıtlı 3, okunurken yeni başlangıca (10) çevrilir.
public record ReminderOptions(ReminderIntensity Level = ReminderIntensity.Normal, int Count = 1, int IntervalMinutes = 15)
{
    public const int AdhdStartMinutes = 10, AdhdFloorMinutes = 3;
    public ReminderOptions Normalize() => Level == ReminderIntensity.Adhd
        ? this with { IntervalMinutes = IntervalMinutes == AdhdFloorMinutes ? AdhdStartMinutes : IntervalMinutes }
        : this with { Level = Level == ReminderIntensity.Silent ? Level : ReminderIntensity.Normal };
    public static ReminderOptions Preset(ReminderIntensity level) => level == ReminderIntensity.Adhd ? new(level, 6, AdhdStartMinutes) : level == ReminderIntensity.Silent ? new(level, 1, 15) : new(ReminderIntensity.Normal, 1, 15);
    public string Name => Level switch { ReminderIntensity.Adhd => "Yapana kadar", ReminderIntensity.Silent => "Hatırlatma yok", _ => "Normal" };
    public bool Silent => Level == ReminderIntensity.Silent;
    public bool Sound => Level == ReminderIntensity.Adhd;
    public int VisibleSeconds => Level == ReminderIntensity.Adhd ? 45 : 14;
    public string Description => Level switch {
        ReminderIntensity.Adhd => $"Sınırsız · başlangıç {IntervalMinutes} dk · giderek sıklaşır (en sık {AdhdFloorMinutes} dk)",
        ReminderIntensity.Silent => "Bildirim gelmez; takvimde ve Bugün ekranında görünür.",
        _ => $"{Count} kez" + (Count > 1 ? $" · {IntervalMinutes} dakika arayla" : "") + (Sound ? " · sesli" : " · sessiz") + $" · ekranda {VisibleSeconds} sn"
    };
    public void Validate() { if (!Enum.IsDefined(Level) || Count is < 1 or > 20 || IntervalMinutes is < 1 or > 1440) throw new ArgumentException("Tekrar sayısı 1–20, aralık 1–1440 dakika olmalı."); }
}
