using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace KisiselAsistan;

internal record CalendarLink(Guid LocalId, string EventId, string LocalHash, string Etag);
internal record CalendarSyncState(string CalendarId = "", List<CalendarLink>? Links = null, string AccountKey = "");
internal record CalendarSyncResult(int Uploaded, int Downloaded, int Deleted, int Conflicts, int Unsupported)
{
    internal string Message => $"Eşitlendi · gönderilen {Uploaded}, alınan {Downloaded}, silinen {Deleted}"
        + (Conflicts > 0 ? $" · {Conflicts} çakışmada asistandaki değişiklik korundu" : "")
        + (Unsupported > 0 ? $" · {Unsupported} tüm gün/tekrarlayan kayıt aktarılmadı" : "");
}

internal sealed class GoogleCalendarSync(ReminderService reminders, IGoogleCalendarApi api, string statePath, Func<string>? accountKey = null)
{
    private readonly JsonListStore<CalendarSyncState> stateStore = new(statePath);
    private readonly SemaphoreSlim gate = new(1, 1);
    internal CalendarSyncState State => stateStore.Read().FirstOrDefault() ?? new();
    private void Save(CalendarSyncState state) => stateStore.Modify(_ => [state]);
    private static string Segment(string value) => Uri.EscapeDataString(value);
    internal async Task EnsureCalendarAsync(CancellationToken token)
    {
        await gate.WaitAsync(token);
        try {
            var existing = State;
            if (existing.CalendarId.Length > 0 && existing.AccountKey == (accountKey?.Invoke() ?? "")) {
                try { await api.RequestAsync(HttpMethod.Get, "calendars/" + Segment(existing.CalendarId), null, null, token); return; }
                catch (CalendarApiException ex) when (ex.Status == HttpStatusCode.NotFound) { }
            }
            var created = await api.RequestAsync(HttpMethod.Post, "calendars", new JsonObject { ["summary"] = "Kişisel Asistan", ["timeZone"] = "Europe/Istanbul", ["description"] = "Kişisel Asistan ile eşitlenen planlar" }, null, token);
            Save(new(created["id"]?.GetValue<string>() ?? throw new InvalidDataException("Google takvim kimliği gelmedi."), [], accountKey?.Invoke() ?? ""));
        } finally { gate.Release(); }
    }
    internal static string Fingerprint(Reminder? reminder) => reminder == null ? "deleted" : Convert.ToHexString(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(new { reminder.Text, reminder.Due, reminder.Done, Options = reminder.Settings, Plan = reminder.Plan ?? new() })));
    internal string LocalFingerprint => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join("|", reminders.Items.OrderBy(r => r.Id).Select(r => r.Id + ":" + Fingerprint(r))))));
    internal static JsonObject Payload(Reminder reminder, JsonObject? remote = null)
    {
        var plan = reminder.Plan ?? new();
        var properties = remote?["extendedProperties"]?["private"]?.DeepClone().AsObject() ?? new JsonObject();
        properties["assistantId"] = reminder.Id.ToString("N");
        properties["assistantDone"] = reminder.Done ? "true" : "false";
        properties["assistantPlan"] = JsonSerializer.Serialize(plan);
        // Notification intensity remains private to this device, never in the
        // event description or shared event properties.
        var overrides = new JsonArray();
        if (!reminder.Done) { overrides.Add(new JsonObject { ["method"] = "popup", ["minutes"] = 0 }); if (plan.RemindDayBefore) overrides.Add(new JsonObject { ["method"] = "popup", ["minutes"] = 1440 }); }
        return new JsonObject {
            ["summary"] = reminder.Text,
            ["start"] = new JsonObject { ["dateTime"] = reminder.Due.ToString("o") },
            ["end"] = new JsonObject { ["dateTime"] = reminder.Due.AddMinutes(plan.DurationMinutes).ToString("o") },
            ["status"] = plan.Certainty == PlanCertainty.Flexible ? "tentative" : "confirmed",
            ["extendedProperties"] = new JsonObject { ["private"] = properties },
            ["reminders"] = new JsonObject { ["useDefault"] = false, ["overrides"] = overrides }
        };
    }
    private static Reminder? Decode(JsonObject remote, Guid id, Reminder? local)
    {
        if (remote["recurrence"] != null || remote["recurringEventId"] != null || remote["start"]?["dateTime"] == null) return null;
        if (!DateTimeOffset.TryParse(remote["start"]?["dateTime"]?.GetValue<string>(), out var due) || !DateTimeOffset.TryParse(remote["end"]?["dateTime"]?.GetValue<string>(), out var end)) return null;
        var duration = (int)(end - due).TotalMinutes;
        if (duration is < 5 or > 720) return null;
        var plan = local?.Plan ?? new PlanDetails();
        try { if (remote["extendedProperties"]?["private"]?["assistantPlan"]?.GetValue<string>() is string json) plan = JsonSerializer.Deserialize<PlanDetails>(json) ?? plan; }
        catch (JsonException) { }
        plan = plan with { DurationMinutes = duration, Certainty = remote["status"]?.GetValue<string>() == "tentative" ? PlanCertainty.Flexible : PlanCertainty.Fixed };
        var custom = remote["reminders"]?["overrides"]?.AsArray();
        if (custom != null) plan = plan with { RemindDayBefore = custom.Any(r => r?["minutes"]?.GetValue<int>() == 1440) };
        try { plan.Validate(); } catch (ArgumentException) { return null; }
        var done = remote["extendedProperties"]?["private"]?["assistantDone"]?.GetValue<string>() == "true";
        var text = remote["summary"]?.GetValue<string>();
        if (string.IsNullOrWhiteSpace(text)) text = "İsimsiz plan";
        var current = local ?? new Reminder(id, text, due);
        var result = current with { Text = text, Due = due, Done = done, Plan = plan };
        return result;
    }
    private bool Import(Guid id, Reminder? incoming, string expectedHash)
        => reminders.ApplyExternal(id, incoming, current => Fingerprint(current) == expectedHash);
    private static Guid ImportedId(string calendar, string eventId) => new(SHA256.HashData(Encoding.UTF8.GetBytes(calendar + ":" + eventId)).AsSpan(0, 16));
    internal async Task<CalendarSyncResult> SyncAsync(CancellationToken token)
    {
        await gate.WaitAsync(token);
        try {
            var saved = State;
            if (saved.CalendarId.Length == 0) throw new InvalidOperationException("Önce Google hesabını bağla.");
            if (saved.AccountKey != (accountKey?.Invoke() ?? "")) throw new InvalidOperationException("Google hesabı değişti. Google ile bağlan düğmesinden yeni hesabın takvimini oluştur.");
            var links = (saved.Links ?? []).ToDictionary(x => x.LocalId);
            var path = "calendars/" + Segment(saved.CalendarId) + "/events";
            var events = new Dictionary<string, JsonObject>(); string? page = null;
            // Fetch every page before making any local deletion decision.
            do {
                var response = await api.RequestAsync(HttpMethod.Get, path + "?showDeleted=true&maxResults=2500" + (page == null ? "" : "&pageToken=" + Segment(page)), null, null, token);
                foreach (var item in response["items"]?.AsArray() ?? []) if (item is JsonObject obj && obj["id"]?.GetValue<string>() is string eventId) events[eventId] = obj;
                page = response["nextPageToken"]?.GetValue<string>();
            } while (page != null);
            var uploaded = 0; var downloaded = 0; var deleted = 0; var conflicts = 0; var unsupported = 0;
            void Persist() => Save(new(saved.CalendarId, links.Values.ToList(), saved.AccountKey));
            foreach (var link in links.Values.ToArray()) {
                token.ThrowIfCancellationRequested();
                var local = reminders.Items.FirstOrDefault(r => r.Id == link.LocalId);
                events.TryGetValue(link.EventId, out var remote);
                var missing = remote == null || remote["status"]?.GetValue<string>() == "cancelled";
                var localHash = Fingerprint(local);
                if (local == null) {
                    if (!missing) await api.RequestAsync(HttpMethod.Delete, path + "/" + Segment(link.EventId), null, remote?["etag"]?.GetValue<string>(), token);
                    links.Remove(link.LocalId); deleted++; Persist(); continue;
                }
                if (missing) {
                    // Deletion on the phone wins only if the local plan has not
                    // also been edited. Do not discard a concurrent local edit.
                    if (localHash == link.LocalHash) { if (!Import(local.Id, null, localHash)) continue; links.Remove(local.Id); deleted++; Persist(); }
                    else { conflicts++; throw new InvalidOperationException("Bir plan Google’da silinmiş, asistanda değiştirilmiş. Asistandaki plan korundu; Google bağlantısını kontrol et."); }
                    continue;
                }
                var etag = remote!["etag"]?.GetValue<string>() ?? "";
                if (localHash != link.LocalHash) {
                    if (etag != link.Etag) conflicts++;
                    var written = await api.RequestAsync(HttpMethod.Patch, path + "/" + Segment(link.EventId), Payload(local, remote), etag, token);
                    links[local.Id] = link with { LocalHash = localHash, Etag = written["etag"]?.GetValue<string>() ?? "" }; uploaded++; Persist();
                } else if (etag != link.Etag) {
                    var decoded = Decode(remote, local.Id, local);
                    if (decoded == null) { unsupported++; continue; }
                    if (Fingerprint(decoded) != localHash) {
                        decoded = decoded with { SentCount = 0, Pressure = 0, NextNotice = null, Revision = local.Revision + 1, AdvanceSentForDue = decoded.Due.AddDays(-1) <= DateTimeOffset.Now ? decoded.Due : null };
                        if (!Import(local.Id, decoded, localHash)) continue;
                        downloaded++;
                    }
                    links[local.Id] = link with { LocalHash = Fingerprint(decoded), Etag = etag }; Persist();
                }
            }
            var known = links.Values.Select(l => l.EventId).ToHashSet();
            foreach (var (eventId, remote) in events) {
                if (known.Contains(eventId) || remote["status"]?.GetValue<string>() == "cancelled") continue;
                var id = ImportedId(saved.CalendarId, eventId);
                // Recover an insert that reached Google just before a crash.
                if (Guid.TryParse(remote["extendedProperties"]?["private"]?["assistantId"]?.GetValue<string>(), out var original) && !links.ContainsKey(original)) id = original;
                var local = reminders.Items.FirstOrDefault(r => r.Id == id);
                var incoming = Decode(remote, id, local);
                if (incoming == null) { unsupported++; continue; }
                if (local == null) {
                    if (incoming.Due <= DateTimeOffset.Now) incoming = incoming with { Done = true };
                    incoming = incoming with { AdvanceSentForDue = incoming.Due.AddDays(-1) <= DateTimeOffset.Now ? incoming.Due : null };
                    if (!Import(id, incoming, "deleted")) continue;
                    local = incoming; downloaded++;
                }
                // If recovered copies differ, force a conditional update next
                // pass rather than silently treating the difference as synced.
                var baseline = Fingerprint(incoming);
                links[id] = new(id, eventId, baseline, remote["etag"]?.GetValue<string>() ?? ""); Persist();
            }
            foreach (var local in reminders.Items) {
                if (links.ContainsKey(local.Id) || local.Done) continue;
                var payload = Payload(local); payload["id"] = "ka" + local.Id.ToString("N");
                JsonObject written;
                try { written = await api.RequestAsync(HttpMethod.Post, path, payload, null, token); }
                catch (CalendarApiException ex) when (ex.Status == HttpStatusCode.Conflict) { continue; }
                links[local.Id] = new(local.Id, written["id"]!.GetValue<string>(), Fingerprint(local), written["etag"]?.GetValue<string>() ?? ""); uploaded++; Persist();
            }
            return new(uploaded, downloaded, deleted, conflicts, unsupported);
        } finally { gate.Release(); }
    }
}
