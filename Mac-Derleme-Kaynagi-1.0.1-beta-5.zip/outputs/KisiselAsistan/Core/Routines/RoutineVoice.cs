namespace KisiselAsistan;
internal static class RoutineVoice
{
    internal static Routine[] Find(IEnumerable<Routine> items, string target)
    {
        var key = ReminderVoiceRemoval.Fold(target);
        if (key.Length == 0) return [];
        var all = items.ToArray();
        var exact = all.Where(r => ReminderVoiceRemoval.Fold(r.Name) == key).ToArray();
        return exact.Length > 0 ? exact : all.Where(r => (" " + ReminderVoiceRemoval.Fold(r.Name) + " ").Contains(" " + key + " ", StringComparison.Ordinal)).ToArray();
    }
}
