using System.Text.Json;

namespace KisiselAsistan;

// Mac host'unun kendi denetimi: ayrı veri klasöründe ortak arayüz isteklerini, komut yolunu ve hesap korumasını dener.
internal static class HostSelfTest
{
    internal static async Task RunAsync()
    {
        var folder = Path.Combine(Path.GetTempPath(), "assistant-mac-test-" + Guid.NewGuid().ToString("N"));
        DeploymentPaths.UseDataFolder(folder);
        try {
            var output = new StringWriter();
            using var host = new MacHost(output, testing: true);
            async Task<JsonElement> Call(string method, object parameters) {
                var line = JsonSerializer.Serialize(new { id = "1", method = "workspace", @params = new { method, @params = parameters } }, WorkspaceApi.Json);
                var before = output.ToString().Length;
                await host.HandleAsync(line);
                var reply = output.ToString()[before..].Split('\n', StringSplitOptions.RemoveEmptyEntries).Select(l => JsonDocument.Parse(l).RootElement).Last(r => r.TryGetProperty("id", out _));
                if (!reply.GetProperty("success").GetBoolean()) throw new Exception(method + ": " + reply.GetProperty("error").GetString());
                return reply.GetProperty("result").Clone();
            }
            var snapshot = await Call("snapshot", new { });
            if (!snapshot.TryGetProperty("live", out _)) throw new Exception("Arayüz anlık görüntüsü eksik.");
            await Call("item.save", new { form = new { title = "Mac testi", day = DateTime.Today.ToString("yyyy-MM-dd") } });
            if (!host.Tasks.Items.Any(t => t.Title == "Mac testi")) throw new Exception("Ortak form görevi kaydetmedi.");
            await Call("speech.command", new { text = "yarın 9'da raporu hatırlat" });
            if (!host.Reminders.Items.Any(r => r.Text.Contains("rapor", StringComparison.OrdinalIgnoreCase))) throw new Exception("Ortak komut yolu hatırlatıcı eklemedi.");
            if (ChatSendScript.Build("gemini", "test").Length < 100) throw new Exception("Ortak sohbet gönderimi eksik.");
            var oldKey = Environment.GetEnvironmentVariable("ASSISTANT_ACCOUNT_KEY");
            try {
                Environment.SetEnvironmentVariable("ASSISTANT_ACCOUNT_KEY", Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(32)));
                var plain = System.Text.Encoding.UTF8.GetBytes("fixture-account");
                var encrypted = WindowsSecret.PortableTransform(plain, true);
                if (!WindowsSecret.PortableTransform(encrypted, false).SequenceEqual(plain)) throw new Exception("Mac hesap koruması çözülemedi.");
                encrypted[^1] ^= 1;
                try { WindowsSecret.PortableTransform(encrypted, false); throw new Exception("Değiştirilmiş hesap dosyası kabul edildi."); } catch (System.Security.Cryptography.CryptographicException) { }
            } finally { Environment.SetEnvironmentVariable("ASSISTANT_ACCOUNT_KEY", oldKey); }
            Console.WriteLine("Mac host: ortak arayüz, form, komut yolu ve hesap koruması kontrolleri geçti.");
        } finally { try { Directory.Delete(folder, true); } catch (IOException) { } }
    }
}
