namespace KisiselAsistan;
public interface ISpotifySession { Task<string> AccessAsync(CancellationToken token); }
public record SpotifyTrack(string Uri, string Name, string Artist, string? CoverUrl = null)
{
    public override string ToString() => Name + " · " + Artist;
}
public record SpotifyPlaying(SpotifyTrack Track, int Position, int Duration, bool Playing, string Device);
