const path = require('node:path');
const {execFileSync} = require('node:child_process');
// electron-builder 26 normalizes helper names to NFD. Electron must look up
// exactly that spelling; keep the user-facing display name unchanged.
module.exports = async context => {
  if(process.platform !== 'darwin')return;
  const name=context.packager.appInfo.productFilename;
  const info=path.join(context.appOutDir,name+'.app','Contents','Info.plist');
  execFileSync('/usr/libexec/PlistBuddy',['-c','Set :CFBundleName '+name,info],{stdio:'inherit'});
};
