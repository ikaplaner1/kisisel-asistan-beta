"use strict";
// Kullanıcı işlemleri, olay dinleyicileri ve başlangıç.

async function action(a, b) {
  const id = b?.dataset.id;
  // Stok sekmesinin işlemleri pages/stock.js içinde.
  if (a.startsWith("stock-")) return stockAction(a, b);
  if (a === "navigate") {
    state.page = sectionOf(b.dataset.page);
    if (state.page === "today") state.day = today();
    await rpc("section", { page: state.page });
    render();
    if (state.page === "today") await updatePlaying(true);
    return;
  }
  if (a === "navigate-reminders") {
    state.page = "reminders";
    render();
    return;
  }
  if (a === "nav-scroll") {
    const nav = $("#navigation");
    nav.scrollBy({ left: (b.dataset.direction === "left" ? -1 : 1) * nav.clientWidth, behavior: "smooth" });
    return;
  }
  if (a === "dialog-close") {
    closeDialog();
    return;
  }
  if (a === "theme") {
    themeDialog();
    return;
  }
  if (a === "day-prev" || a === "day-next") {
    const d = parseDay(state.day);
    const delta = a === "day-prev" ? -1 : 1;
    if (state.page === "reminders" && state.calendar === "Ay") {
      d.setDate(1);
      d.setMonth(d.getMonth() + delta);
    } else d.setDate(d.getDate() + delta * (state.page === "reminders" && state.calendar === "Hafta" ? 7 : 1));
    state.day = dayKey(d);
    render();
    return;
  }
  if (a === "today") {
    state.day = today();
    render();
    return;
  }
  if (a === "calendar-mode") {
    state.calendar = b.dataset.mode;
    render();
    return;
  }
  // Widget'lar: düzenleme kipi, kaldır, geri koy (sıra ve gizlenenler widgetPrefs'te).
  // Takvim: gün boyu şeridini aç / daralt.
  if (a === "allday-toggle") {
    state.alldayOpen = !state.alldayOpen;
    render();
    return;
  }
  if (a === "tour") {
    startTour();
    return;
  }
  if (a === "widgets-edit") {
    state.widgetEdit = !state.widgetEdit;
    render();
    return;
  }
  if (a === "widget-remove" || a === "widget-add") {
    const prefs = widgetPrefs(),
      w = b.dataset.widget;
    prefs.hidden = a === "widget-remove" ? [...prefs.hidden.filter((x) => x !== w), w] : prefs.hidden.filter((x) => x !== w);
    if (a === "widget-add") prefs.order = [...prefs.order.filter((x) => x !== w), w];
    saveWidgetPrefs(prefs);
    return;
  }
  if (a === "task-breakdown") {
    breakdownDialog(id);
    return;
  }
  if (a === "shutdown-open") {
    shutdownDialog();
    return;
  }
  if (a === "dump-open") {
    await dumpDialog();
    return;
  }
  if (a === "task-new" || a === "task-edit") {
    taskEditor(id);
    return;
  }
  if (a === "task-menu") {
    taskMenu(id, b);
    return;
  }
  if (a === "task-to-reminder") {
    // Saate bağla: aynı kayda saat eklenir (kimlik ve sıra değişmez).
    await itemEditor({ id, withTime: true, origin: rowOf("task", id) });
    return;
  }
  if (a === "reminder-to-task") {
    const key = await reminderToTask(state.data.reminders.find((x) => x.id === id));
    toast(`Göreve çevrildi · ${relativeDay(key + "T12:00:00")}`);
    await refresh();
    return;
  }
  if (a === "reminder-move") {
    const r = state.data.reminders.find((x) => x.id === id),
      due = moveTarget(b.dataset.to, r);
    await moveReminder(r, due);
    toast(`Ertelendi · ${relativeDay(due)} ${clock(due)}`);
    await refresh();
    return;
  }
  if (a === "reminder-move-pick") {
    moveReminderDialog(state.data.reminders.find((x) => x.id === id));
    return;
  }
  if (a === "task-move") {
    const key = b.dataset.to === "tomorrow" ? tomorrow() : today();
    await moveTask(state.data.tasks.find((x) => x.id === id), key);
    toast(key === today() ? "Bugüne taşındı." : "Yarına taşındı.");
    await refresh();
    return;
  }
  if (a === "someday-undo") {
    const back = somedayPending().pop();
    if (!back) return;
    state.somedayDone = state.somedayDone.filter((id) => id !== back);
    // Tamamlanmış işte task.complete tamamlanmayı geri alır.
    await rpc("task.complete", { id: back, day: state.day });
    playSound("undo");
    toast("Geri alındı: " + (state.data.tasks.find((x) => x.id === back)?.title || ""));
    await refresh();
    return;
  }
  if (a === "task-someday") {
    await rpc("task.save", { task: { ...state.data.tasks.find((x) => x.id === id), myDay: null, due: null } });
    toast("Bir ara listesine alındı.");
    await refresh();
    return;
  }
  if (a === "late-menu") {
    lateMenu(b);
    return;
  }
  // Ana ekran: boş vakit önerisinde sıradaki iş, listeyi yerinde aç/kapat (bitenler ve Bir ara da görünür), ⋯ menüsü.
  if (a === "now-other") {
    state.suggestAt = (state.suggestAt || 0) + 1;
    render();
    return;
  }
  // Boş vakit kartı süresiz bir iş önerince "5 · 15 · 30 dk" sorar; seçilen süre işe yazılır (formdaki "Ne kadar sürer?" ile aynı alan).
  if (a === "task-estimate") {
    const form = await rpc("item.get", { id });
    await rpc("item.save", { form: { ...form, durationMinutes: +b.dataset.minutes, durationSet: true } });
    await refresh();
    return;
  }
  if (a === "free-expand" || a === "free-done") {
    state.freeExpanded = a === "free-done" || !state.freeExpanded;
    if (a === "free-done") state.completed = true;
    render();
    return;
  }
  if (a === "day-menu") {
    const evening = new Date().getHours() >= 17;
    openMenu(
      b,
      menuItem("Görev ekle", "task-new", "plus") +
        menuItem("Saatli ekle", "reminder-new", "clock", "", `data-date="${today()}"`) +
        menuItem("Toplu ekle", "dump-open", "mic") +
        menuSeparator +
        menuItem("Günü planla", "day-plan", "calendar") +
        (evening ? menuItem("Günü kapat", "shutdown-open", "sun") : "") +
        menuItem(state.freeExpanded ? "Daha az göster" : "Bitenler ve Bir ara listesi", "free-expand", "right") +
        menuItem("Takvimde aç", "navigate", "calendar", "", 'data-page="reminders"'),
    );
    return;
  }
  if (a === "late-move") {
    const { reminders, tasks } = lateItems();
    const later = b.dataset.to === "tomorrow";
    // "task": hepsi bugünün saatsiz görevi olur. "tomorrow": hepsi yarına, hatırlatıcılar kendi saatinde.
    // Haftalık seriler tek tek kaydırılamaz; onlar yerinde kalır.
    for (const r of reminders.filter((r) => !r.plan?.weekly)) await (later ? moveReminder(r, moveTarget("same-tomorrow", r)) : reminderToTask(r));
    for (const t of tasks) await moveTask(t, later ? tomorrow() : today());
    toast(later ? "Gecikenler yarına taşındı." : "Gecikenler bugünün görevleri oldu.");
    await refresh();
    return;
  }
  if (a === "day-plan") {
    await dayPlanner();
    return;
  }
  if (a === "task-remove") {
    confirmDialog("Görevi sil", "Bu görevi silmek istiyor musun?", () => rpc("task.remove", { id }));
    return;
  }
  if (a === "task-star" || a === "task-day" || a === "task-complete") {
    if (a === "task-complete") playSound(taskDone(state.data.tasks.find((t) => t.id === id)) ? "undo" : "done");
    await rpc({ "task-star": "task.important", "task-day": "task.day", "task-complete": "task.complete" }[a], { id, day: state.day });
    if (state.modal) closeDialog();
    await refresh();
    return;
  }
  if (a === "schedule-import") scheduleImportDialog();
  // Odak (pomodoro): sonuç canlı duruma hemen yazılır, Bugün yeniden çizilir.
  if (a === "focus-start" || a === "focus-stop" || a === "focus-skip") {
    const focus = await rpc(a.replace("-", "."), a === "focus-start" && b?.dataset.task ? { task: b.dataset.task } : {});
    if (state.data.live) state.data.live = { ...state.data.live, focus };
    if (a === "focus-start") toast(focus.task ? `Odak: ${focus.task}` : "Odak başladı. Bitince haber vereceğim.");
    render();
    return;
  }
  if (a === "reminder-new" || a === "reminder-edit") {
    reminderEditor(id, b.dataset.date);
    return;
  }
  if (a === "reminder-menu") {
    reminderMenu(id, b);
    return;
  }
  if (a === "reminder-settings") {
    reminderSettingsMenu(b);
    return;
  }
  if (a === "reminder-remove") {
    confirmDialog("Planı sil", "Bu planı ve varsa haftalık serisini silmek istiyor musun?", () => rpc("reminder.remove", { id }));
    return;
  }
  if (a === "reminder-clear") {
    confirmDialog("Tamamlananları temizle", "Tamamlanan hatırlatıcı kayıtları silinecek.", () => rpc("reminder.clear"));
    return;
  }
  if (a === "reminder-complete" || a === "reminder-snooze") {
    if (a === "reminder-complete") playSound("done");
    await rpc(a === "reminder-complete" ? "reminder.complete" : "reminder.snooze", { id });
    if (state.modal) closeDialog();
    await refresh();
    return;
  }
  if (a === "defaults") {
    defaultsDialog();
    return;
  }
  const settings = { preferences: preferencesDialog, notifications: notificationsDialog, "focus-settings": focusSettingsDialog, "feedback-settings": feedbackDialog, google: googleDialog, ollama: ollamaDialog, "spotify-settings": spotifyDialog }[a];
  if (settings) {
    await settings();
    return;
  }
  if (a === "shortcut-new") {
    shortcutEditor();
    return;
  }
  if (a === "shortcut-menu") {
    shortcutMenu(id, b);
    return;
  }
  if (a === "shortcut-edit") {
    shortcutEditor(id);
    return;
  }
  if (a === "shortcut-remove") {
    confirmDialog("Kısayolu sil", "Bu kısayolu silmek istiyor musun?", () => rpc("routine.remove", { id }));
    return;
  }
  if (a === "shortcut-run") {
    await rpc("routine.run", { id });
    toast("Kısayol başlatıldı.");
    return;
  }
  if (a === "shortcut-stop") {
    await rpc("routine.stop");
    return;
  }
  if (a === "steam-track") {
    await rpc("operation", { name: "steam.track", parameters: { id: +id } });
    await refresh();
    return;
  }
  if (a === "steam-remove") {
    confirmDialog("Takibi bırak", "Bu oyunun takibini bırakmak istiyor musun?", () =>
      rpc("operation", { name: "steam.unwatch", parameters: { id: +id } }),
    );
    return;
  }
  if (a === "steam-target") {
    steamTargetDialog(+id);
    return;
  }
  if (a === "steam-wishlist") {
    steamWishlistDialog();
    return;
  }
  if (a === "steam-check") {
    toast("Takipler kontrol ediliyor…");
    const result = await rpc("operation", { name: "steam.check", parameters: {} });
    toast(result.message || "Kontrol tamamlandı.");
    await refresh();
    return;
  }
  // Karışık / tekrar: ekranda hemen değişir, Spotify'a sonra gider; hata olursa eski hâline döner.
  if ((a === "spotify-shuffle" || a === "spotify-repeat") && state.playing) {
    const key = a === "spotify-shuffle" ? "shuffle" : "repeat",
      old = state.playing[key],
      next = key === "shuffle" ? !old : REPEAT_NEXT[old || "off"];
    const show = () => (state.page === "today" ? render() : htmPreact.render(html`<${BarPlayer} />`, $("#bar-player")));
    state.playing[key] = next;
    modeSet[key] = { value: next, at: Date.now() };
    show();
    try {
      await rpc("operation", { name: "spotify." + key, parameters: key === "shuffle" ? { state: next } : { mode: next } });
    } catch (e) {
      state.playing && (state.playing[key] = old);
      delete modeSet[key];
      show();
      throw e;
    }
    return;
  }
  // Hoparlör düğmesi: ses açıksa kapatır (eski sesi bu bilgisayarda hatırlar), kapalıysa o sese döner.
  if (a === "spotify-mute") {
    const current = state.playing?.volume ?? 50;
    let back = 50;
    try {
      if (current > 0) localStorage.setItem("spotify-unmute", String(current));
      else back = +localStorage.getItem("spotify-unmute") || 50;
    } catch {}
    await setSpotifyVolume(current > 0 ? 0 : back);
    return;
  }
  if (["spotify-previous", "spotify-next", "spotify-toggle", "spotify-open"].includes(a)) {
    await rpc("operation", {
      name: a === "spotify-open" ? "spotify.open" : "spotify.control",
      parameters: a === "spotify-open" ? {} : { action: a.slice(8) },
    });
    // Medya tuşuyla gönderilen komutu Spotify birkaç yüz ms sonra bildirir: hemen sorulursa eski şarkı görünür
    // ve sonraki yoklamaya (10 sn) kadar kalırdı. Oynat/duraklat ekranda hemen döner, sonra iki kez sorulur.
    if (a === "spotify-toggle" && state.playing) {
      Object.assign(state.playing, { position: playingPosition(), at: Date.now(), playing: !state.playing.playing });
      if (state.page === "today") render();
      else htmPreact.render(html`<${BarPlayer} />`, $("#bar-player"));
    }
    setTimeout(() => updatePlaying(true), 600);
    setTimeout(() => updatePlaying(true), 1800);
    return;
  }
  if (a === "ai-view") {
    state.aiSingle = !state.aiSingle;
    render();
    return;
  }
  if (a === "ai-prev" || a === "ai-next") {
    state.aiProvider = (state.aiProvider + (a === "ai-prev" ? 2 : 1)) % 3;
    render();
    return;
  }
  if (["ai-refresh", "ai-new", "ai-one-reload", "ai-external"].includes(a)) {
    await rpc("ai.action", { action: a, index: b.dataset.index == null ? -1 : +b.dataset.index });
    toast(a === "ai-new" ? "Yeni sohbetler açıldı." : "İşlem tamamlandı.");
    return;
  }
  if (a === "speech-settings") {
    await speechSettings();
    return;
  }
  if (a === "help") {
    helpDialog();
    return;
  }
  if (a === "example") {
    $("#command").value = b.dataset.example;
    if (state.modal) closeDialog();
    $("#command").focus();
    $("#command").dispatchEvent(new Event("input", { bubbles: true }));
    return;
  }
  if (a === "microphone" || a === "microphone-answer") {
    await rpc("speech.listen", a === "microphone-answer" ? { answer: true } : {});
    await refresh();
    return;
  }
  if (a === "cancel-command") {
    await rpc("speech.cancel");
    return;
  }
  if (a === "view") {
    await rpc("window.view");
    return;
  }
  if (a.startsWith("window-")) {
    await rpc("window.action", { action: a.slice(7) });
    return;
  }
  // Yenile ve geliştirici yayınlama (anahtar girildiği için yerel pencere kalır).
  if (a === "refresh" || a === "publish") {
    await rpc("dialog." + a);
    await refresh();
    return;
  }
}

// Spotify sesini ayarlar (çubuk ve hoparlör düğmesi); son ayarlanan değer birkaç saniye korunur (updatePlaying).
let volumeSet = null;
// Karışık/tekrar da Spotify'a gecikmeli yansır; düğmeye basıldıktan sonra 4 sn ekrandaki değer korunur.
const modeSet = {};
// Sürüklerken ses anında değişir: aynı anda tek istek gider, arada gelen değerlerden yalnız sonuncusu bekler
// (açık bağlantıda istek ~60 ms; her "input" olayına istek göndermek Spotify'ı sıraya sokup geride bırakırdı).
let volumeSending = false,
  volumeWaiting = null,
  volumeSent = null,
  volumeSentAt = 0;
async function sendSpotifyVolume(value) {
  volumeWaiting = value;
  if (volumeSending) return;
  volumeSending = true;
  try {
    while (volumeWaiting != null) {
      const next = volumeWaiting;
      volumeWaiting = null;
      // Az önce gönderilen değer tekrar gönderilmez (bırakınca gelen "change" sürüklemenin son değeriyle aynıdır).
      if ((next === volumeSent && Date.now() - volumeSentAt < 1500) || !state.playing?.deviceId) continue;
      await rpc("operation", { name: "spotify.volume", parameters: { percent: next, deviceId: state.playing.deviceId } });
      volumeSent = next;
      volumeSentAt = Date.now();
      volumeSet = { value: next, at: Date.now() };
    }
  } finally {
    volumeSending = false;
  }
}
async function setSpotifyVolume(value) {
  if (!state.playing?.deviceId) return;
  value = Math.max(0, Math.min(100, Math.round(value)));
  volumeSet = { value, at: Date.now() };
  state.playing.volume = value;
  await sendSpotifyVolume(value);
  if (state.page === "today") render();
  else htmPreact.render(html`<${BarPlayer} />`, $("#bar-player"));
}
// Şarkıda konuma gider; Spotify yeni konumu birkaç saniye gecikmeli bildirebilir, o arada eski konum çubuğu geri çekmesin.
let seekSet = null;
async function seekSpotify(position) {
  const playing = state.playing;
  if (!playing?.deviceId || !playing.duration) return;
  position = Math.max(0, Math.min(playing.duration - 500, Math.round(position)));
  Object.assign(playing, { position, at: Date.now() });
  seekSet = { position, at: Date.now() };
  try {
    await rpc("operation", { name: "spotify.seek", parameters: { positionMs: position, deviceId: playing.deviceId } });
  } finally {
    seekSet = { position, at: Date.now() };
    Object.assign(playing, { position, at: Date.now() });
  }
}
// Konum çubukları ve süre yazıları saniyede bir yerinde ilerletilir (sayfa yeniden çizilmez); şarkı bitince Spotify'a sorulur.
let seekEnded = false;
function tickSeek() {
  const playing = state.playing;
  if (!playing?.duration || document.hidden) return;
  const at = playingPosition(playing);
  for (const range of document.querySelectorAll(".spotify-seek")) {
    if (range.dataset.dragging) continue;
    range.value = at;
    range.style.setProperty("--fill", ((at / playing.duration) * 100).toFixed(2) + "%");
    const label = range.previousElementSibling?.firstChild;
    if (label?.nodeType === Node.TEXT_NODE) label.data = trackTime(at);
  }
  if (playing.playing && at >= playing.duration && !seekEnded) {
    seekEnded = true;
    setTimeout(() => updatePlaying(true).finally(() => (seekEnded = false)), 800);
  }
}
setInterval(tickSeek, 1000);
let updatingPlaying = false;
async function updatePlaying(quiet = false) {
  if (updatingPlaying) return;
  updatingPlaying = true;
  try {
    state.playing = await rpc("operation", { name: "spotify.current", parameters: {} });
    if (state.playing) state.playing.at = Date.now();
    // Spotify yeni sesi birkaç saniye gecikmeli bildirir; o arada gelen eski değer çubuğu geri çekmesin.
    if (state.playing && volumeSet && Date.now() - volumeSet.at < 6000) state.playing.volume = volumeSet.value;
    if (state.playing) for (const [k, v] of Object.entries(modeSet)) if (Date.now() - v.at < 4000) state.playing[k] = v.value;
    if (state.playing && seekSet && Date.now() - seekSet.at < 3000) Object.assign(state.playing, { position: seekSet.position, at: seekSet.at });
    // Bugün bileşen olarak çizildiği için yalnızca değişen kısım (Müzik kartı) güncellenir.
    // Bugün'de Müzik widget'ı da güncellenir; diğer sayfalarda yalnız alt çubuktaki oynatıcı. Ses ya da konum çubuğu tutulurken çizilmez.
    if (document.activeElement?.matches?.(".spotify-volume, .spotify-seek") || $(".spotify-seek[data-dragging]")) return;
    if (state.page !== "today") htmPreact.render(html`<${BarPlayer} />`, $("#bar-player"));
    else if (!state.modal && !$(".menu")) render();
  } catch (e) {
    if (!quiet) toast(e.message);
  } finally {
    updatingPlaying = false;
  }
}
setInterval(() => {
  if (!document.hidden && !state.modal && !compact() && (state.page === "today" || state.playing?.track)) updatePlaying(true);
}, 10000);
// Üst çubuktaki saat her bölümde görünür; yalnız yazısı değişir, sayfa yeniden çizilmez.
function tickTitleClock() {
  const el = $("#title-clock"),
    now = new Date();
  if (!el) return;
  el.textContent = clock(now);
  el.title = now.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}
tickTitleClock();
setInterval(tickTitleClock, 5000);
// Bugün ekranındaki şimdi çizgisi, geri sayım ve gecikmeler dakikada bir güncellenir.
// Kullanıcı yazarken, menü veya pencere açıkken ekran yeniden çizilmez.
setInterval(() => {
  if (state.page !== "today" || !state.data || document.hidden || state.modal || $(".menu")) return;
  if (document.activeElement?.closest?.("#page input, #page textarea, #page select")) return;
  render();
}, 60000);

// Bir görevi tamamlarken tik dolar ve satır yumuşakça kapanır; kayıt hemen yapılır.
async function completeWithMotion(row, save) {
  const started = performance.now();
  const finishing = row && !row.classList.contains("is-done") && !reducedMotion();
  if (finishing) {
    row.style.height = row.offsetHeight + "px"; // yüksekliğin yumuşakça sıfıra inebilmesi için
    row.classList.add("completing");
  }
  await save();
  if (finishing) await wait(Math.max(0, 320 - (performance.now() - started)));
  await refresh();
  // Bileşen sayfasında aynı satır yeniden kullanılabilir; hareketin bıraktığı yükseklik temizlenir.
  if (row) {
    row.style.height = "";
    row.classList.remove("completing");
  }
}
// ---------------------------------------------------------------- Erteleme ve taşıma
const tomorrow = () => dayKey(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() + 1));
// Gecikmiş (saati geçmiş hatırlatıcı, günü geçmiş görev) kayıtlar; Bugün ekranındaki "Gecikenler" ile aynı.
function lateItems() {
  const now = new Date();
  return {
    reminders: state.data.reminders.filter((r) => !r.done && new Date(r.due) < now),
    tasks: state.data.tasks.filter((t) => taskLate(t)),
  };
}
// "hour": bir saat sonra (5 dakikaya yuvarlı), "evening": bu akşam 20:00, "tomorrow": yarın 09:00,
// "same-tomorrow": yarın, kaydın kendi saatinde.
function moveTarget(to, r) {
  const now = new Date(),
    at = (offset, h, m = 0) => new Date(now.getFullYear(), now.getMonth(), now.getDate() + offset, h, m);
  if (to === "hour") return new Date(Math.ceil((now.getTime() + 3600000) / 300000) * 300000);
  if (to === "evening") return at(0, 20);
  if (to === "same-tomorrow") {
    const d = new Date(r.due);
    return at(1, d.getHours(), d.getMinutes());
  }
  return at(1, 9);
}
// Yalnız bu kayıt (tekrarlıysa yalnız bu gün) taşınır; seri yerinde kalır.
const moveReminder = (r, due) => rpc("reminder.move", { id: r.id, due: due.toISOString() });
// "Başka güne taşı": gün ve saat seçilir, başlangıçta kaydın kendi günü ve saati.
function moveReminderDialog(r) {
  const d = new Date(r.due);
  openDialog(
    r.plan?.weekly ? "Yalnız bu haftayı taşı" : "Başka güne taşı",
    `<form id="move-form"><p class="muted small">${esc(r.text)} · ${relativeDay(r.due)} ${clock(r.due)}${r.plan?.weekly ? "<br>Diğer haftalar olduğu gibi kalır." : ""}</p>
      <div class="form-grid">${field("Gün", `<input type="date" name="day" required value="${dayKey(d)}" min="${today()}" />`)}${field("Saat", `<input type="time" name="time" required value="${clock(r.due)}" />`)}</div>
      <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Taşı</button></div></form>`,
  );
  $("#move-form").onsubmit = (e) => {
    e.preventDefault();
    const f = e.target.elements,
      due = new Date(`${f.day.value}T${f.time.value}:00`);
    run(async () => {
      await moveReminder(r, due);
      closeDialog();
      toast(`Taşındı · ${relativeDay(due)} ${clock(due)}`);
      await refresh();
    });
  };
}
const moveTask = (t, key) => rpc("task.save", { task: { ...t, due: key, myDay: key } });
// Saatten çıkar: aynı kayıt saatsiz göreve döner (kimlik değişmez). Geçmiş günse bugüne alınır.
async function reminderToTask(r) {
  const key = dayKey(new Date(r.due)) < today() ? today() : dayKey(new Date(r.due));
  const form = await rpc("item.get", { id: r.id });
  await rpc("item.save", { form: { ...form, timeMinutes: null, repeatDays: 0, day: key, editingDay: null } });
  return key;
}

// ---------------------------------------------------------------- Çalma listesi sırası
// Spotify kitaplıktaki liste sırasını değiştirmeye izin vermiyor; sıra bu bilgisayarda tutulur
// (localStorage spotify-playlist-order). Sıraya hiç girmemiş (yeni) listeler Spotify'daki gibi üstte durur.
function orderPlaylists(lists) {
  let saved = [];
  try {
    saved = JSON.parse(localStorage.getItem("spotify-playlist-order") || "[]");
  } catch {}
  const at = new Map((Array.isArray(saved) ? saved : []).map((uri, i) => [uri, i]));
  return [...lists.filter((p) => !at.has(p.uri)), ...lists.filter((p) => at.has(p.uri)).sort((a, b) => at.get(a.uri) - at.get(b.uri))];
}

// ---------------------------------------------------------------- Sürükle-bırak sıralama
// data-sortable listedeki görev satırı (ya da data-sort-key taşıyan satır) tutulup sürüklenir; satır imleci izler,
// diğerleri yumuşakça yer açar. Bırakınca yeni sıra task.order ile kaydedilir. Kutu, düğme ve menülere basmak sürüklemeyi başlatmaz.
let drag = null,
  dragJustEnded = false;
const sortRows = (list) => $$(":scope > [data-row-task], :scope > [data-sort-key]", list),
  sortKey = (row) => row.dataset.rowTask || row.dataset.sortKey;
document.addEventListener("pointerdown", (e) => {
  if (e.button !== 0) return;
  const row = e.target.closest("[data-sortable] > [data-row-task], [data-sortable] > [data-sort-key]");
  if (!row || e.target.closest("input, button, a, select, textarea")) return;
  drag = { row, list: row.parentElement, pointerId: e.pointerId, startY: e.clientY, grab: e.clientY - row.getBoundingClientRect().top, before: sortRows(row.parentElement).map(sortKey), active: false };
});
document.addEventListener("pointermove", (e) => {
  if (!drag || e.pointerId !== drag.pointerId) return;
  if (!drag.active) {
    if (Math.abs(e.clientY - drag.startY) < 6) return;
    drag.active = true;
    closeMenu();
    drag.row.classList.add("dragging");
    document.body.classList.add("is-sorting");
  }
  e.preventDefault();
  // Widget'lardaki gibi kenara yaklaşınca liste (kendi kaydırması varsa) ya da sayfa kayar (autoScrollTick).
  autoScroll.y = e.clientY;
  if (!autoScroll.frame) { autoScroll.last = 0; autoScroll.since = 0; autoScroll.frame = requestAnimationFrame(autoScrollTick); }
  dragMove(e.clientY);
});
// Satırı imlecin altına taşır; kenarda kayarken fare kıpırdamasa da her karede yeniden çağrılır.
function dragMove(y) {
  const others = sortRows(drag.list).filter((r) => r !== drag.row);
  const next = others.find((r) => {
    const b = r.getBoundingClientRect();
    return y < b.top + b.height / 2;
  });
  if ((next || null) !== drag.row.nextElementSibling || (!next && others.at(-1)?.nextElementSibling !== drag.row)) {
    const tops = new Map(others.map((r) => [r, r.getBoundingClientRect().top]));
    if (next) drag.list.insertBefore(drag.row, next);
    else others.at(-1)?.after(drag.row);
    if (!reducedMotion())
      for (const r of others) {
        const delta = tops.get(r) - r.getBoundingClientRect().top;
        if (delta) r.animate([{ transform: `translateY(${delta}px)` }, { transform: "none" }], { duration: 140, easing: easeOut });
      }
  }
  drag.row.style.transform = "none";
  drag.row.style.transform = `translateY(${y - drag.grab - drag.row.getBoundingClientRect().top}px)`;
}
function endDrag(e) {
  if (!drag || e.pointerId !== drag.pointerId) return;
  const { row, list, active, before } = drag;
  drag = null;
  if (!active) return;
  row.classList.remove("dragging");
  row.style.transform = "";
  document.body.classList.remove("is-sorting");
  dragJustEnded = true;
  setTimeout(() => (dragJustEnded = false), 0);
  if (!row.isConnected) return;
  const ids = sortRows(list).map(sortKey);
  if (ids.join() === before.join()) return;
  // Satırlar bileşen tarafından çizilir: önce eski sıraya dönülür, yeni sırayı kayıt sonrası çizim getirir.
  const rows = new Map(sortRows(list).map((r) => [sortKey(r), r]));
  const anchor = sortRows(list).at(-1).nextSibling;
  for (const id of before) list.insertBefore(rows.get(id), anchor);
  run(async () => {
    await rpc("task.order", { ids });
    await refresh();
  });
}
document.addEventListener("pointerup", endDrag);
document.addEventListener("pointercancel", endDrag);
// Bırakma anındaki tıklama satırda bir işlem başlatmasın.
document.addEventListener(
  "click",
  (e) => {
    if (!dragJustEnded) return;
    dragJustEnded = false;
    e.stopPropagation();
    e.preventDefault();
  },
  true,
);

// Bugün ekranındaki son iş de bittiyse küçük bir kutlama sesi.
// Üstteki ilerleme çubuğuyla aynı işler sayılır: "Bir ara" ve "Gecikenler" dahil değil.
// counted: tıklanan satır bu işlerden biri miydi (satır tamamlanınca yerinden kalktığı için tıklamadan önce bakılır).
const countedToday = (check) => !!check.closest(".today-main") && !check.closest(".today-someday, .today-late");
function celebrateIfDayDone(counted = true) {
  if (!counted || state.page !== "today") return;
  const checks = $$(".today-main [data-task-check], .today-main [data-reminder-check]").filter((c) => !c.closest(".today-someday, .today-late"));
  if (checks.length && checks.every((c) => c.checked)) playSound("allDone");
}

// ---------------------------------------------------------------- Olaylar
document.addEventListener("click", (e) => {
  const inMenu = e.target.closest(".menu");
  if (!inMenu) closeMenu();
  const b = e.target.closest("[data-action]");
  if (b && !b.disabled) {
    if (inMenu) closeMenu();
    run(() => action(b.dataset.action, b));
    return;
  }
  if (inMenu) return;
  const day = e.target.closest("[data-date]");
  if (day) {
    state.day = day.dataset.date;
    state.calendar = "Gün";
    render();
    return;
  }
  // Gün ve Hafta görünümünde boş bir saate tıklamak o saat için plan açar (yarım saat hassasiyetle).
  const column = e.target.closest(".week-day");
  if (column && !e.target.closest(".week-event")) reminderEditor(null, column.dataset.weekDate, slotAt(column, e.clientY).time);
});
function slotAt(column, y) {
  const half = Math.max(0, Math.floor(((y - column.getBoundingClientRect().top) / hourHeight) * 2));
  const minutes = Math.min((24 - firstHour) * 60 - 30, half * 30);
  const hour = firstHour + Math.floor(minutes / 60);
  return { top: (minutes * hourHeight) / 60, time: `${String(hour).padStart(2, "0")}:${minutes % 60 ? "30" : "00"}` };
}
// Fare boş bir saatin üzerindeyken oraya eklenecek planın yeri ve saati gösterilir.
document.addEventListener("mousemove", (e) => {
  const column = e.target.closest?.(".week-day");
  const hint = column && !e.target.closest(".week-event") ? column.querySelector(".slot-hint") || column.appendChild(Object.assign(document.createElement("div"), { className: "slot-hint" })) : null;
  $$(".slot-hint").forEach((h) => h !== hint && h.remove());
  if (!hint) return;
  const slot = slotAt(column, e.clientY);
  hint.style.top = slot.top + "px";
  hint.style.height = hourHeight / 2 + "px";
  hint.textContent = "+ " + slot.time;
});

// ---------------------------------------------------------------- Takvim: gün boyu şeridinden sürükle-bırak
// Şeritteki saatsiz iş ızgaraya bırakılınca aynı kayda o saat eklenir (yarım saat hassasiyet);
// başka bir günün şeridine bırakılınca yalnızca günü değişir. Geçmiş saate bırakmak reddedilir.
// Widget sıralama (yalnız "Düzenle" kipinde): tutulan widget başka birinin üstüne bırakılınca onun önüne geçer.
// Çizim Preact'ta olduğu için DOM elle taşınmaz; yalnız hedef vurgulanır, yeni sıra kaydedilip yeniden çizilir.
let widgetDrag = null;
// Kenarda otomatik kayma (sürükle-bırak kütüphanelerindeki gibi): hız fare olayı sayısına değil zamana bağlıdır,
// böylece fare kıpırdasa da durursa da aynı hızda kayar. Kenardan 80 px içeride başlar; kenara yaklaştıkça
// 40'tan 280 px/sn'ye çıkar (SortableJS: 30 px bölge, kare başına 10 px ≈ 600 px/sn; bilerek daha yavaş).
// İlk 0,6 sn yumuşak başlar (react-beautiful-dnd'deki gibi), yanlışlıkla kenardan geçerken sayfa fırlamasın.
const autoScroll = { y: 0, frame: 0, last: 0, since: 0, carry: 0 };
function autoScrollTick(now) {
  const page = $("#page"),
    sorting = drag?.active && drag.row.isConnected;
  if ((!widgetDrag && !sorting) || !page) return (autoScroll.frame = 0);
  // Satır sıralarken kendi kaydırması olan liste (çalma listeleri) önce kayar; sonuna gelince sayfa devam eder.
  // Küçük kutuda kenar bölgesi kutunun dörtte biri kadardır, yoksa 280 px'lik listede ortası hiç kalmazdı.
  const zone = (el) => {
    const box = el.getBoundingClientRect(),
      edge = Math.min(80, box.height / 4),
      d = autoScroll.y < box.top + edge ? box.top + edge - autoScroll.y : autoScroll.y > box.bottom - edge ? -(autoScroll.y - box.bottom + edge) : 0,
      room = d > 0 ? el.scrollTop > 0 : d < 0 ? el.scrollTop + el.clientHeight < el.scrollHeight - 1 : false;
    return room ? { el, d, edge } : null;
  };
  const list = sorting && drag.list.scrollHeight > drag.list.clientHeight + 1 ? zone(drag.list) : null,
    hit = list || zone(page),
    scroller = hit?.el,
    edge = hit?.edge || 80,
    depth = hit?.d || 0;
  const dt = Math.min(50, now - (autoScroll.last || now));
  autoScroll.last = now;
  if (!depth) autoScroll.since = autoScroll.carry = 0;
  else {
    autoScroll.since ||= now;
    const closeness = Math.min(1, Math.abs(depth) / edge),
      warm = Math.min(1, 0.25 + (now - autoScroll.since) / 800),
      speed = (40 + 240 * closeness * closeness) * warm;
    // Yavaş hızda kare başına 1 pikselden az düşer; birikip tam piksel olunca kaydırılır.
    autoScroll.carry += Math.sign(depth) * (speed * dt) / 1000;
    const whole = Math.trunc(autoScroll.carry);
    if (whole) {
      scroller.scrollTop -= whole;
      autoScroll.carry -= whole;
      if (sorting) dragMove(autoScroll.y);
    }
  }
  autoScroll.frame = requestAnimationFrame(autoScrollTick);
}
document.addEventListener("dragstart", (e) => {
  const w = e.target.closest?.(".widgets.is-editing .widget");
  if (!w) return;
  widgetDrag = w.dataset.widget;
  e.dataTransfer.setData("text/plain", widgetDrag);
  e.dataTransfer.effectAllowed = "move";
});
document.addEventListener("dragover", (e) => {
  if (!widgetDrag) return;
  // Widget tutulurken imleç sayfanın üst ya da alt kenarına yaklaşınca sayfa o yöne kayar (autoScrollTick).
  autoScroll.y = e.clientY;
  if (!autoScroll.frame) { autoScroll.last = 0; autoScroll.since = 0; autoScroll.frame = requestAnimationFrame(autoScrollTick); }
  e.preventDefault();
  const target = e.target.closest?.(".widgets .widget"),
    after = target && dropAfter(target, e.clientY);
  clearWidgetDrop(target, after);
  if (!target || target.dataset.widget === widgetDrag) return;
  target.classList.toggle("drop-before", !after);
  target.classList.toggle("drop-after", after);
});
// İmleç hedefin alt yarısındaysa arkasına, üst yarısındaysa önüne bırakılır. Önceden hep önüne bırakılıyordu:
// en üstteki widget hemen altındakinin üstüne bırakılınca yerinde kalıyor, en sona hiç taşınamıyordu.
const dropAfter = (target, y) => {
  const r = target.getBoundingClientRect();
  return y > r.top + r.height / 2;
};
const clearWidgetDrop = (keep = null, after = false) =>
  $$(".widget.drop-before, .widget.drop-after").forEach((x) => {
    if (x !== keep || after) x.classList.remove("drop-before");
    if (x !== keep || !after) x.classList.remove("drop-after");
  });
// Sırayı hesaplar: moved widget'ı target'ın önüne ya da arkasına koyar (actions dışında testte de kullanılır).
function moveWidget(order, moved, target, after) {
  const next = order.filter((x) => x !== moved);
  next.splice(next.indexOf(target) + (after ? 1 : 0), 0, moved);
  return next;
}
document.addEventListener("drop", (e) => {
  if (!widgetDrag) return;
  const target = e.target.closest?.(".widgets .widget"),
    moved = widgetDrag;
  widgetDrag = null;
  clearWidgetDrop();
  if (!target || target.dataset.widget === moved) return;
  e.preventDefault();
  const prefs = widgetPrefs();
  saveWidgetPrefs({ ...prefs, order: moveWidget(prefs.order, moved, target.dataset.widget, dropAfter(target, e.clientY)) });
});
document.addEventListener("dragend", () => {
  widgetDrag = null;
  clearWidgetDrop();
});

let pillDrag = null;
const clearDropHints = () => {
  $$(".slot-hint").forEach((h) => h.remove());
  $$(".drop-target").forEach((x) => x.classList.remove("drop-target"));
};
document.addEventListener("dragstart", (e) => {
  const pill = e.target.closest?.("[data-pill-task]");
  if (!pill) return;
  pillDrag = pill.dataset.pillTask;
  e.dataTransfer.setData("text/plain", pillDrag);
  e.dataTransfer.effectAllowed = "move";
  closeMenu();
});
document.addEventListener("dragend", () => {
  pillDrag = null;
  clearDropHints();
});
document.addEventListener("dragover", (e) => {
  if (!pillDrag) return;
  const column = e.target.closest?.(".week-day"),
    strip = e.target.closest?.(".allday-cell");
  if (!column && !strip) return;
  e.preventDefault();
  clearDropHints();
  if (strip) return strip.classList.add("drop-target");
  const slot = slotAt(column, e.clientY),
    hint = column.appendChild(Object.assign(document.createElement("div"), { className: "slot-hint" }));
  hint.style.top = slot.top + "px";
  hint.style.height = hourHeight / 2 + "px";
  hint.textContent = "Saat ekle · " + slot.time;
});
document.addEventListener("drop", (e) => {
  if (!pillDrag) return;
  const id = pillDrag,
    column = e.target.closest?.(".week-day"),
    strip = e.target.closest?.(".allday-cell");
  pillDrag = null;
  clearDropHints();
  if (!column && !strip) return;
  e.preventDefault();
  const slot = column ? slotAt(column, e.clientY) : null;
  run(async () => {
    const form = await rpc("item.get", { id }),
      d = state.data.defaults;
    if (column) {
      const [h, m] = slot.time.split(":").map(Number);
      // Tekrarlı işte başlangıç günü değişmez; her tekrarına bu saat eklenir.
      await rpc("item.save", { form: { ...form, day: form.repeatDays ? form.day : column.dataset.weekDate, timeMinutes: h * 60 + m, notify: form.notify || { level: d.level, count: d.count, intervalMinutes: d.intervalMinutes } } });
      toast(`Saat eklendi · ${relativeDay(column.dataset.weekDate + "T12:00:00")} ${slot.time}`);
    } else {
      if (strip.dataset.alldayDate === form.day) return;
      if (form.repeatDays) throw new Error("Tekrarlı işin günleri formdan değişir (Tekrar).");
      await rpc("item.save", { form: { ...form, day: strip.dataset.alldayDate } });
      toast(`Günü değişti · ${relativeDay(strip.dataset.alldayDate + "T12:00:00")}`);
    }
    playSound("add");
    await refresh();
  });
});
// Steam sonuçları çift tıklamayla işlenir (takip listesine kalıcı ekleme olduğu için);
// Spotify sonuçları tek tıkla çalar. İkisi de seçiliyken Enter ile çalışır.
document.addEventListener("dblclick", (e) => {
  const row = e.target.closest("[data-dbl-action]");
  if (row) run(() => action(row.dataset.dblAction, row));
});
document.addEventListener("keydown", (e) => {
  const row = e.key === "Enter" && e.target.closest?.("[data-dbl-action], .is-pickable[data-action]");
  if (row) run(() => action(row.dataset.dblAction || row.dataset.action, row));
});
// Sağ tık: satırın kendi menüsü tıklanan noktada açılır.
document.addEventListener("contextmenu", (e) => {
  if (e.target.closest("input, textarea")) return;
  e.preventDefault();
  const point = { x: e.clientX, y: e.clientY };
  // Takvimin "gün boyu" şeridindeki işler de görev menüsünü açar (Sil dahil).
  const task = e.target.closest("[data-row-task]") || e.target.closest("[data-pill-task]"),
    reminder = e.target.closest("[data-row-reminder]"),
    event = e.target.closest(".calendar-event[data-id]"),
    shortcut = e.target.closest("[data-row-shortcut]"),
    stock = e.target.closest("[data-row-stock]");
  if (task) taskMenu(task.dataset.rowTask || task.dataset.pillTask, point);
  else if (reminder) reminderMenu(reminder.dataset.rowReminder, point);
  else if (event) reminderMenu(event.dataset.id, point);
  else if (shortcut) shortcutMenu(shortcut.dataset.rowShortcut, point);
  else if (stock) stockMenu(stock.dataset.rowStock, point);
});
document.addEventListener("change", (e) =>
  run(async () => {
    const t = e.target;
    if (t.id === "task-filter") {
      state.filter = t.value;
      render();
    }
    if (t.id === "task-lane") {
      state.lane = t.value;
      render();
    }
    if (t.dataset.taskCheck) {
      const task = state.data.tasks.find((x) => x.id === t.dataset.taskCheck);
      // "Bir ara" işi tamamlanınca listeden kaybolur; altındaki "Geri al" düğmesi onu geri getirir.
      if (t.checked && task && isSomeday(task)) state.somedayDone = [...state.somedayDone.filter((id) => id !== task.id), task.id];
      const counted = countedToday(t);
      playSound(t.checked ? "done" : "undo");
      await completeWithMotion(t.closest(".task-row"), () => rpc("task.complete", { id: t.dataset.taskCheck, day: state.day }));
      if (t.checked) celebrateIfDayDone(counted);
    }
    if (t.dataset.reminderCheck) {
      const counted = countedToday(t);
      playSound("done");
      await completeWithMotion(t.closest(".task-row"), () => rpc("reminder.complete", { id: t.dataset.reminderCheck }));
      celebrateIfDayDone(counted);
    }
    if (t.dataset.stepTask) {
      if (t.checked) playSound("step");
      await rpc("task.step", { id: t.dataset.stepTask, index: +t.dataset.index, done: t.checked });
      await refresh();
    }
    if (t.dataset.aiTarget != null) state.targets[+t.dataset.aiTarget] = t.checked;
    if (t.classList.contains("spotify-volume")) {
      t.blur();
      await setSpotifyVolume(+t.value);
    }
    if (t.classList.contains("spotify-seek")) {
      delete t.dataset.dragging;
      t.blur();
      await seekSpotify(+t.value);
    }
  }),
);
document.addEventListener("input", (e) => {
  // Ses çubuğu sürüklenirken dolgu, yüzde ve Spotify'ın sesi anında değişir (sendSpotifyVolume); bırakınca son değer kesinleşir.
  // Yüzde, Preact'in çizdiği yazı düğümünde yerinde değişir: textContent ile değiştirmek düğümü
  // Preact'in elinden alır ve sonraki çizimde "68%68%" gibi çift yazı olur.
  if (e.target.classList?.contains("spotify-volume")) {
    e.target.style.setProperty("--fill", e.target.value + "%");
    const label = e.target.nextElementSibling?.firstChild;
    if (label?.nodeType === Node.TEXT_NODE) label.data = e.target.value + "%";
    if (state.playing?.deviceId) {
      state.playing.volume = +e.target.value;
      volumeSet = { value: +e.target.value, at: Date.now() };
      sendSpotifyVolume(+e.target.value).catch((err) => toast(err.message));
    }
  }
  // Konum çubuğu sürüklenirken yalnız süre yazısı değişir; şarkı bırakınca (change) o konuma gider.
  if (e.target.classList?.contains("spotify-seek")) {
    e.target.dataset.dragging = "1";
    const max = +e.target.max || 1;
    e.target.style.setProperty("--fill", ((+e.target.value / max) * 100).toFixed(2) + "%");
    const label = e.target.previousElementSibling?.firstChild;
    if (label?.nodeType === Node.TEXT_NODE) label.data = trackTime(+e.target.value);
  }
  // Ana ekrandaki asistan kutusu (komut şeridi): yazarken altında Enter'a basınca ne olacağı. Saat ya da "bir ara" varsa
  // hızlı ekleme ayrıştırması (C#, quick.parse) söyler; gerisi komut yolundan geçer (komut değilse bugüne görev olur).
  if (e.target.id === "command") {
    const value = e.target.value.trim();
    state.askText = value;
    if (!value) state.askHint = "";
    else
      parseQuick(value).then((q) => {
        // Yanıt gelene kadar metin değiştiyse eski önizleme gösterilmez.
        if (state.askText !== value) return;
        state.askHint = q.kind === "reminder" || q.kind === "someday" ? quickLabel(q) : "";
        if (state.page === "today") render();
      }, () => {});
    if (state.page === "today") render();
  }
  if (e.target.id === "ai-question") {
    state.aiQuestion = e.target.value;
    scheduleSlots();
  }
  const type = e.target.id === "steam-search" ? "steam" : null;
  if (!type) return;
  const value = e.target.value;
  state.query[type] = value;
  clearTimeout(searchTimer);
  // Kutu boşalınca eski sonuçlar da gider.
  if (!value.trim()) {
    state[type === "steam" ? "steamResults" : "spotifyResults"] = [];
    render();
    return;
  }
  searchTimer = setTimeout(
    () =>
      run(async () => {
        const results = await rpc("operation", { name: type + ".search", parameters: { query: value } });
        if (state.query[type] !== value) return;
        state[type === "steam" ? "steamResults" : "spotifyResults"] = results;
        const start = e.target.selectionStart;
        render();
        const input = $("#" + type + "-search");
        if (input) {
          input.focus();
          input.setSelectionRange(start, start);
        }
      }),
    450,
  );
});
document.addEventListener("submit", (e) => {
  if (e.target.id === "shortcut-form") return;
  // Stok: yapıştırılan bağlantı ekleme penceresini açar (birden çoksa toplu ekleme).
  if (e.target.matches("[data-stock-paste]")) {
    e.preventDefault();
    const text = $("#stock-url").value.trim();
    if (text) stockPaste(text);
    return;
  }
  e.preventDefault();
  run(async () => {
    const f = e.target,
      d = new FormData(f);
    if (f.id === "command-form") {
      const text = d.get("command").trim();
      if (!text) return;
      $("#command").value = "";
      state.askText = state.askHint = "";
      await rpc("speech.command", { text });
      await refresh();
    }
    if (f.id === "someday-task") {
      if (!d.get("title").trim()) return;
      await saveSomeday(d.get("title").trim());
      playSound("add");
      f.reset();
      await refresh();
      $("#someday-task input")?.focus();
    }
    if (f.id === "quick-task") {
      if (!d.get("title").trim()) return;
      await rpc("task.save", {
        task: { title: d.get("title"), list: "Görevler", steps: [], dailyActivity: true, myDay: state.day, startsOn: state.day },
      });
      playSound("add");
      await refresh();
      $("#quick-task input")?.focus();
    }
    if (f.id === "speech-form") {
      await rpc("speech.configure", { microphone: +d.get("microphone"), language: +d.get("language"), wait: +d.get("wait"), speak: d.get("speakReplies") === "on", ...(d.has("rate") ? { rate: +d.get("rate") } : {}) });
      setSoundsOn(d.has("uiSounds"));
      closeDialog();
    }
  });
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    if ($(".menu")) closeMenu();
    else if (state.modal) closeDialog();
    // Pencere ve menü yokken Esc ana ekrana döner (açık listeyi önce kapatır); yazı alanındayken dokunmaz.
    // Yalnız gerçek tuş basışı (hedef bir öğe); belgeye gönderilen olay (kod içi) bölüm değiştirmez.
    else if (e.target instanceof Element && !e.target.closest("input, textarea, select, [contenteditable]")) {
      if (state.page === "today" && state.freeExpanded) state.freeExpanded = false;
      else if (state.page !== "today") return void action("navigate", { dataset: { page: "today" } });
      render();
    }
    return;
  }
  // Ctrl+K: her yerden ortadaki komut penceresini aç.
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
    e.preventDefault();
    if (state.modal === "Komut") closeDialog();
    else commandPalette();
    return;
  }
  if (e.target.id === "ai-question") {
    if (e.key === "Tab") {
      e.preventDefault();
      const t = e.target;
      t.setRangeText("\n", t.selectionStart, t.selectionEnd, "end");
      state.aiQuestion = t.value;
    }
    if (e.key === "Enter" && !e.isComposing) {
      e.preventDefault();
      const text = e.target.value.trim();
      if (!text) return;
      if (!state.targets.some(Boolean)) {
        toast("En az bir AI seç.");
        return;
      }
      e.target.value = "";
      state.aiQuestion = "";
      run(async () => {
        const result = await rpc("ai.send", { text, targets: state.targets });
        toast(result);
      });
    }
  }
  const trap = $(".menu") ? ".menu" : state.modal ? ".modal-layer:not(.closing) .dialog" : null;
  if (trap && e.key === "Tab" && e.target.id !== "ai-question") {
    const focus = $$(`${trap} button:not(:disabled),${trap} input:not(:disabled),${trap} select,${trap} textarea`).filter(
        (x) => x.offsetParent !== null,
      ),
      first = focus[0],
      last = focus.at(-1);
    if (e.shiftKey && e.target === first) {
      e.preventDefault();
      last?.focus();
    } else if (!e.shiftKey && e.target === last) {
      e.preventDefault();
      first?.focus();
    }
  }
});
// Küçük görünümde sekme şeridi fare tekerleğiyle yana kayar: her tık bir sekme. Hedef sekme sınırına hesaplanır;
// sabit piksel kaydırma "sekmeye yapış" (scroll-snap) yüzünden bırakınca eski yere geri çekiliyordu.
// Hızlı art arda tıklar birikir (kayma bitmeden ikinci tık bir sonrakine gider).
let navWheel = { target: null, timer: 0 };
$("#navigation").addEventListener(
  "wheel",
  (e) => {
    if (!compact() || Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
    e.preventDefault();
    const nav = $("#navigation"),
      first = $("button", nav);
    if (!first) return;
    const step = first.getBoundingClientRect().width + 2,
      max = nav.scrollWidth - nav.clientWidth,
      from = navWheel.target ?? nav.scrollLeft;
    navWheel.target = Math.max(0, Math.min(max, (Math.round(from / step) + Math.sign(e.deltaY)) * step));
    nav.scrollTo({ left: navWheel.target, behavior: "smooth" });
    clearTimeout(navWheel.timer);
    navWheel.timer = setTimeout(() => (navWheel.target = null), 450);
  },
  { passive: false },
);
$("#drag-area").addEventListener("mousedown", (e) => {
  if (e.button === 0 && e.detail === 1) rpc("window.drag").catch(() => {});
});
$("#drag-area").addEventListener("dblclick", () => rpc("window.action", { action: "maximize" }));
$("#page").addEventListener("scroll", () => {
  closeMenu();
  scheduleSlots();
});
new ResizeObserver(scheduleSlots).observe($("#page"));
window.addEventListener("resize", () => {
  closeMenu();
  scheduleSlots();
});
window.workspace = { ready: false, refresh, state, receive };
run(async () => {
  await refresh();
  window.workspace.ready = true;
});

// Geçiş uyarısı (Tiimo gibi): sıradaki saatli işe 5 dakika kala nazik bir ses ve kısa bir not. Yalnız büyük pencere
// ekrandayken (live.shown: simge durumunda, gizli ya da küçük görünümde değil); her iş için bir kez.
const transitionWarned = new Set();
function checkTransition() {
  const live = state.data?.live;
  if (!live?.shown || document.hidden) return;
  const now = Date.now();
  for (const r of state.data.reminders) {
    const due = new Date(r.due).getTime(),
      key = r.id + "|" + r.due;
    if (r.done || isSilent(r) || due <= now || due - now > 5 * 60000 || transitionWarned.has(key)) continue;
    transitionWarned.add(key);
    playSound("transition");
    toast(`${Math.max(1, Math.round((due - now) / 60000))} dk sonra: ${r.text} · toparlanma zamanı`);
    break;
  }
}
setInterval(checkTransition, 15000);
