using System.Globalization;

namespace KisiselAsistan;

// Kurallı ayrıştırıcının çıktısı: kullanıcının ne istediği, henüz hangi kayda dokunacağı çözülmeden.
// Kind işlem adıdır ("steam.search", "reminder.snooze" …). Text ad/sorgu, Number sayı (sıra, dakika, saniye, ses),
// Target kayıt hedefi ("su icme", "ikinci", "secili", "" = belirtilmedi), Due/Day zaman.
// CommandResolver bunu o anki listelere bakarak tek bir işlem önerisine (OperationProposal) çevirir.
public sealed record Intent(string Kind, string Text = "", int Number = 0, string? Target = null, DateTimeOffset? Due = null, DateOnly? Day = null)
{
    // Testlerde karşılaştırma için kısa yazım: "reminder.snooze 5 [su icme]", "reminder.add 600 Mola".
    public override string ToString() => Kind + (Number != 0 ? " " + Number : "") + (Text.Length > 0 ? " " + Text : "") + (Target is null ? "" : " [" + Target + "]")
        + (Due is { } due ? " @" + due.LocalDateTime.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) : "")
        + (Day is { } day ? " @" + day.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : "");
}
