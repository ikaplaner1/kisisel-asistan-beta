namespace KisiselAsistan;

// Odak (pomodoro): çalışma → mola → (soru) → çalışma … Her 4 turda bir uzun mola.
// Mola bitince yeni tur kendiliğinden başlamaz; kullanıcıya sorulur (DEHB için baskısız).
// Odak sürerken öne gelen dikkat dağıtıcı uygulama için kabuk "kapatayım mı?" diye sorar (Distracting); zorla kapatılmaz.
public enum FocusPhase { Idle, Work, Break, LongBreak }
public sealed record FocusSettings(int WorkMinutes = 25, int BreakMinutes = 5, int LongBreakMinutes = 15, int LongEvery = 4,
    bool HoldReminders = false, bool WatchApps = true, List<string>? DistractingApps = null)
{
    public static readonly string[] DefaultApps = ["steam", "steamwebhelper", "discord", "epicgameslauncher", "riotclientux", "riotclientservices", "battle.net", "leagueclient", "valorant"];
    public IReadOnlyList<string> Apps => DistractingApps is { Count: > 0 } list ? list : DefaultApps;
    public void Validate()
    {
        if (WorkMinutes is < 5 or > 180 || BreakMinutes is < 1 or > 60 || LongBreakMinutes is < 1 or > 90 || LongEvery is < 2 or > 10) throw new ArgumentException("Süreler: çalışma 5–180, mola 1–60, uzun mola 1–90 dk; uzun mola 2–10 turda bir.");
        if (DistractingApps is { } apps && (apps.Count > 40 || apps.Any(a => string.IsNullOrWhiteSpace(a) || a.Length > 60))) throw new ArgumentException("Uygulama listesi geçersiz.");
    }
}
public sealed record FocusState(FocusPhase Phase, DateTimeOffset? EndsAt, int Round, string? Task, int TodayCount, int TodayMinutes);
// Tick sonucu: biten aşama ve sıradaki (kabuk bildirim/ses için).
public sealed record FocusTransition(FocusPhase Ended, FocusPhase Next, string Title, string Message);

public sealed class FocusSession(string folder, Func<DateTimeOffset>? clock = null)
{
    public sealed record DayStat(DateOnly Day, int Count, int Minutes);
    private readonly JsonListStore<FocusSettings> settings = new(Path.Combine(folder, "focus-settings.json"));
    private readonly JsonListStore<DayStat> stats = new(Path.Combine(folder, "focus-stats.json"));
    private readonly object gate = new();
    private FocusPhase phase = FocusPhase.Idle;
    private DateTimeOffset? endsAt, startedAt;
    private int round;
    private DateTimeOffset? breakEndedAt;
    private string? task;
    private readonly Dictionary<string, DateTimeOffset> allowedUntil = new(StringComparer.OrdinalIgnoreCase);
    private DateTimeOffset Now => clock?.Invoke() ?? DateTimeOffset.Now;
    private DayStat? today;   // arayüz durumu sık sorar; günün sayacı bellekte tutulur
    private DayStat Today() { var day = DateOnly.FromDateTime(Now.LocalDateTime); if (today?.Day != day) today = stats.Read().FirstOrDefault(s => s.Day == day) ?? new(day, 0, 0); return today; }
    public event Action? Changed;

    private FocusSettings? cachedSettings;
    public FocusSettings Settings { get { try { return cachedSettings ??= settings.Read().FirstOrDefault() ?? new(); } catch (Exception ex) when (ex is IOException or System.Text.Json.JsonException or InvalidDataException) { return new(); } } }
    public void Save(FocusSettings value) { value.Validate(); settings.Modify(_ => [value]); cachedSettings = value; Changed?.Invoke(); }
    public bool Working { get { lock (gate) return phase == FocusPhase.Work; } }

    public FocusState State()
    {
        lock (gate) {
            var stat = Today();
            return new(phase, endsAt, round, task, stat.Count, stat.Minutes);
        }
    }
    public FocusState Start(string? taskTitle = null)
    {
        lock (gate) {
            var s = Settings;
            // Mola bittikten sonra "yeni tur" seriyi sürdürür; "Bitir" ya da 1 saatten uzun ara seriyi sıfırlar (uzun mola sayımı için).
            if (phase == FocusPhase.Idle && (breakEndedAt is not { } ended || Now - ended > TimeSpan.FromHours(1))) round = 0;
            phase = FocusPhase.Work; round++; task = string.IsNullOrWhiteSpace(taskTitle) ? task : taskTitle.Trim()[..Math.Min(200, taskTitle.Trim().Length)];
            startedAt = Now; endsAt = Now.AddMinutes(s.WorkMinutes); allowedUntil.Clear();
        }
        Changed?.Invoke(); return State();
    }
    // Bitir: süren çalışma turu yarıdan fazlaysa sayılır (bölünen çabayı yok saymamak için).
    public FocusState Stop()
    {
        lock (gate) {
            if (phase == FocusPhase.Work && startedAt is { } start && endsAt is { } end && (Now - start) >= (end - start) / 2) Record((int)Math.Round((Now - start).TotalMinutes));
            phase = FocusPhase.Idle; endsAt = null; startedAt = null; round = 0; task = null; breakEndedAt = null; allowedUntil.Clear();
        }
        Changed?.Invoke(); return State();
    }
    // Odak geçmişi (Forest gibi): son günlerin tur ve dakikaları, en eskiden bugüne; kaydı olmayan gün 0.
    public IReadOnlyList<DayStat> History(int days = 28)
    {
        days = Math.Clamp(days, 1, 60);
        var today = DateOnly.FromDateTime(Now.LocalDateTime);
        var saved = stats.Read().ToDictionary(s => s.Day);
        return Enumerable.Range(0, days).Select(i => today.AddDays(i - days + 1)).Select(d => saved.GetValueOrDefault(d) ?? new DayStat(d, 0, 0)).ToList();
    }
    public FocusState SkipBreak() { lock (gate) if (phase is not (FocusPhase.Break or FocusPhase.LongBreak)) return State(); return Start(); }

    // Saniyede bir çağrılır; aşama bittiyse geçişi döner.
    public FocusTransition? Tick()
    {
        FocusTransition? result = null;
        lock (gate) {
            if (endsAt is not { } end || Now < end) return null;
            var s = Settings;
            if (phase == FocusPhase.Work) {
                Record(s.WorkMinutes);
                var longBreak = round % s.LongEvery == 0;
                phase = longBreak ? FocusPhase.LongBreak : FocusPhase.Break;
                var minutes = longBreak ? s.LongBreakMinutes : s.BreakMinutes;
                endsAt = Now.AddMinutes(minutes); startedAt = Now;
                result = new(FocusPhase.Work, phase, $"{round}. tur bitti", (longBreak ? $"Uzun mola: {minutes} dakika. " : $"{minutes} dakika mola. ") + "Kalk, su iç, gözlerini dinlendir.");
            } else {
                var ended = phase;
                phase = FocusPhase.Idle; endsAt = null; startedAt = null; breakEndedAt = Now;
                result = new(ended, FocusPhase.Idle, "Mola bitti", "Yeni bir tura hazır mısın? Başlamak sende.");
            }
        }
        Changed?.Invoke(); return result;
    }

    // Öne gelen uygulama dikkat dağıtıcı mı? Çalışma turunda, listede, "izin ver" süresi dolmuşsa evet.
    public bool Distracting(string processName)
    {
        lock (gate) {
            if (phase != FocusPhase.Work || !Settings.WatchApps) return false;
            var name = Path.GetFileNameWithoutExtension(processName).ToLowerInvariant();
            if (!Settings.Apps.Any(a => string.Equals(a.Trim(), name, StringComparison.OrdinalIgnoreCase))) return false;
            if (allowedUntil.TryGetValue(name, out var until) && Now < until) return false;
            allowedUntil[name] = Now.AddMinutes(2);   // aynı uygulama için 2 dk içinde tekrar sorma
            return true;
        }
    }
    public void Allow(string processName, int minutes) { lock (gate) allowedUntil[Path.GetFileNameWithoutExtension(processName).ToLowerInvariant()] = Now.AddMinutes(minutes); }

    private void Record(int minutes)
    {
        var day = DateOnly.FromDateTime(Now.LocalDateTime);
        stats.Modify(list => {
            var old = list.FirstOrDefault(s => s.Day == day);
            today = new DayStat(day, (old?.Count ?? 0) + 1, (old?.Minutes ?? 0) + Math.Max(0, minutes));
            return [.. list.Where(s => s.Day != day && s.Day > day.AddDays(-60)), today];
        });
    }
}
