"use strict";
// Pencereler, açılır menüler ve düzenleme formları.
//
// Hareket kuralları:
// - Ayarlar gibi pencereler her zaman ekranın ortasında aynı şekilde açılır.
// - Bir kaydı düzenleyen pencere o kaydın satırından büyüyerek açılır (origin).
// - Açılır menüler tıklanan noktadan açılır.
// - Kapanış açılıştan daha kısadır. Windows'ta animasyonlar kapalıysa hareket olmaz.

const reducedMotion = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
const easeOut = "cubic-bezier(.2,.8,.2,1)";

function openDialog(title, body, options = false) {
  const { wide = false, origin = null } = typeof options === "object" ? options : { wide: options };
  closeMenu();
  state.modal = title;
  $("#portal").innerHTML = `<div class="modal-layer"><section class="dialog ${wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header><h2>${esc(title)}</h2>${B("", "dialog-close", "close", "icon-button", 'aria-label="Kapat"')}</header><div class="dialog-content">${body}<div class="inline-error" role="alert"></div></div></section></div>`;
  const layer = $("#portal .modal-layer"),
    dialog = $(".dialog", layer);
  if (!reducedMotion()) {
    layer.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 160, easing: "ease-out" });
    const from = origin?.isConnected ? origin.getBoundingClientRect() : null,
      to = dialog.getBoundingClientRect();
    if (from && from.width && to.width) {
      // Satırdan büyüme: pencere, kaydın bulunduğu yerden ve boyutundan başlar.
      const dx = from.left + from.width / 2 - (to.left + to.width / 2),
        dy = from.top + from.height / 2 - (to.top + to.height / 2);
      dialog.animate(
        [
          { transform: `translate(${dx}px, ${dy}px) scale(${from.width / to.width}, ${from.height / to.height})`, opacity: 0.35 },
          { transform: "none", opacity: 1 },
        ],
        { duration: 240, easing: easeOut },
      );
    } else {
      dialog.animate(
        [
          { transform: "translateY(8px) scale(.96)", opacity: 0 },
          { transform: "none", opacity: 1 },
        ],
        { duration: 200, easing: easeOut },
      );
    }
  }
  scheduleSlots();
  setTimeout(() => {
    const content = $("#portal .modal-layer:not(.closing) .dialog-content");
    (content && ($("input:not([type=checkbox]):not([type=color]), textarea, select", content) || $("button.primary", content)))?.focus();
  }, 25);
}
function closeDialog() {
  // Yarım kalan Google işlemi pencereyle birlikte bırakılır (tarayıcı izni beklenirken gibi).
  if (state.modal === "Google Calendar") rpc("google.cancel").catch(() => {});
  state.modal = null;
  const layer = $("#portal .modal-layer");
  if (layer && !reducedMotion()) {
    // Yalnızca kapanan katman silinir; bu arada açılan yeni pencere etkilenmez.
    layer.classList.add("closing");
    layer.removeAttribute("role");
    $(".dialog", layer)?.removeAttribute("role");
    layer.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 130, easing: "ease-in" }).onfinish = () => layer.remove();
    $(".dialog", layer)?.animate([{ transform: "none" }, { transform: "scale(.98)" }], { duration: 130, easing: "ease-in" });
  } else layer?.remove();
  scheduleSlots();
}
function confirmDialog(title, text, action) {
  openDialog(
    title,
    `<p>${esc(text)}</p><div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}${B("Onayla", "confirm-action", "", "primary danger-fill")}</div>`,
  );
  $('#portal [data-action="confirm-action"]').onclick = () =>
    run(async () => {
      await action();
      closeDialog();
      await refresh();
    });
}
const field = (label, input, full = false) => `<label class="field ${full ? "full" : ""}">${label}${input}</label>`;

// ---------------------------------------------------------------- Açılır menüler
let menuAnchor = null;
// target: tıklanan öğe ya da {x, y} noktası (sağ tık).
function openMenu(target, items) {
  closeMenu();
  const menu = document.createElement("div");
  menu.className = "menu";
  menu.setAttribute("role", "menu");
  menu.innerHTML = items;
  document.body.append(menu);
  const point =
    target instanceof Element
      ? (() => {
          const r = target.getBoundingClientRect();
          return { x: r.right, y: r.bottom + 4, alignRight: true };
        })()
      : { x: target.x, y: target.y, alignRight: false };
  const w = menu.offsetWidth,
    h = menu.offsetHeight;
  let left = point.alignRight ? point.x - w : point.x,
    top = point.y,
    originY = "top";
  if (top + h > innerHeight - 8) {
    top = (target instanceof Element ? target.getBoundingClientRect().top - 4 : point.y) - h;
    originY = "bottom";
  }
  left = Math.min(Math.max(8, left), innerWidth - w - 8);
  top = Math.max(8, top);
  menu.style.left = left + "px";
  menu.style.top = top + "px";
  menu.style.transformOrigin = `${point.alignRight ? "right" : "left"} ${originY}`;
  if (!reducedMotion())
    menu.animate(
      [
        { transform: "scale(.94)", opacity: 0 },
        { transform: "none", opacity: 1 },
      ],
      { duration: 120, easing: easeOut },
    );
  menuAnchor = target instanceof Element ? target : null;
  menuAnchor?.classList.add("menu-open");
  setTimeout(() => $("button", menu)?.focus(), 10);
}
function closeMenu() {
  const menu = $(".menu");
  if (!menu) return;
  menuAnchor?.classList.remove("menu-open");
  menuAnchor = null;
  menu.remove();
}
const menuItem = (text, action, icon, cls = "", data = "") => B(`<span>${text}</span>`, action, icon, "menu-item " + cls, data);
const menuSeparator = '<div class="menu-separator" role="separator"></div>';

function taskMenu(id, target) {
  const t = state.data.tasks.find((x) => x.id === id);
  const steps = t.steps?.length
    ? menuSeparator +
      `<p class="menu-label">Adımlar</p>` +
      t.steps
        .map((s, i) => `<label class="menu-check"><input type="checkbox" data-step-task="${id}" data-index="${i}" ${s.done ? "checked" : ""}>${esc(s.text)}</label>`)
        .join("")
    : "";
  // Tamamlama satırdaki kutudan yapılır. Gün seçimi yalnızca tek seferlik işlerde anlamlı
  // (günlük aktiviteler zaten her gün görünür); bugün için "Bir ara" işlerinde "Bugüne al" yeterli.
  const onDay = t.myDay === state.day,
    dayName =
      state.day === today()
        ? onDay ? "Bugünden çıkar" : "Bugüne ekle"
        : state.day === tomorrow()
          ? onDay ? "Yarından çıkar" : "Yarına ekle"
          : `${parseDay(state.day).toLocaleDateString("tr-TR", { day: "numeric", month: "long", weekday: "long" })} ${onDay ? "gününden çıkar" : "gününe ekle"}`;
  const showDay = !t.dailyActivity && !t.done && !(isSomeday(t) && state.day === today());
  openMenu(
    target,
    menuItem("Düzenle", "task-edit", "edit", "", `data-id="${id}"`) +
      (showDay ? menuItem(dayName, "task-day", "calendar", "", `data-id="${id}"`) : "") +
      // Her gün yapılan alışkanlıklar tek seferlik hatırlatıcıya çevrilmez.
      (t.dailyActivity ? "" : menuItem("Saate bağla", "task-to-reminder", "clock", "", `data-id="${id}"`)) +
      (!t.dailyActivity && !t.done && t.due && t.due < today()
        ? menuItem("Bugüne taşı", "task-move", "calendar", "", `data-id="${id}" data-to="today"`) +
          menuItem("Yarına at", "task-move", "right", "", `data-id="${id}" data-to="tomorrow"`)
        : "") +
      // Bir ara listesindeki iş bugüne alınır; günü olan iş tarihsiz "bir ara"ya bırakılabilir.
      (isSomeday(t) && !t.done ? menuItem("Bugüne al", "task-move", "calendar", "", `data-id="${id}" data-to="today"`) : "") +
      (!t.dailyActivity && !t.done && !isSomeday(t) ? menuItem("Bir araya at", "task-someday", "clock", "", `data-id="${id}"`) : "") +
      steps +
      menuSeparator +
      menuItem("Sil", "task-remove", "trash", "danger", `data-id="${id}"`),
  );
}
function reminderMenu(id, target) {
  const r = state.data.reminders.find((x) => x.id === id);
  openMenu(
    target,
    `<p class="menu-label">${relativeDay(r.due)} ${clock(r.due)} · ${esc(r.settings?.name || "Normal")}</p>` +
      menuItem(r.plan?.weekly ? "Bu ve sonraki tekrarları düzenle" : "Düzenle", "reminder-edit", "edit", "", `data-id="${id}"`) +
      (!r.done
        ? menuItem("Tamamladım", "reminder-complete", "check", "", `data-id="${id}"`) +
          menuItem("5 dakika ertele", "reminder-snooze", "clock", "", `data-id="${id}"`) +
          (r.plan?.weekly
            ? ""
            : menuSeparator +
              `<p class="menu-label">Ertele</p>` +
              menuItem("1 saat sonra", "reminder-move", "clock", "", `data-id="${id}" data-to="hour"`) +
              (new Date().getHours() < 19 ? menuItem("Bu akşam 20:00", "reminder-move", "clock", "", `data-id="${id}" data-to="evening"`) : "") +
              menuItem("Yarın 09:00", "reminder-move", "calendar", "", `data-id="${id}" data-to="tomorrow"`) +
              menuItem("Saatten çıkar · göreve çevir", "reminder-to-task", "task", "", `data-id="${id}"`))
        : "") +
      menuSeparator +
      menuItem(r.plan?.weekly ? "Haftalık seriyi sil" : "Sil", "reminder-remove", "trash", "danger", `data-id="${id}"`),
  );
}
// Gecikenler başlığındaki toplu işlemler: biriken işler için tek kararlık seçenekler.
function lateMenu(target) {
  const { reminders } = lateItems(),
    weekly = reminders.filter((r) => r.plan?.weekly).length;
  openMenu(
    target,
    menuItem("Hepsini bugünün görevi yap", "late-move", "task", "", 'data-to="task"') +
      menuItem("Hepsini yarına taşı", "late-move", "calendar", "", 'data-to="tomorrow"') +
      (weekly ? `<p class="menu-label">${weekly} haftalık tekrar yerinde kalır</p>` : ""),
  );
}
function shortcutMenu(id, target) {
  openMenu(
    target,
    menuItem("Düzenle", "shortcut-edit", "edit", "", `data-id="${id}"`) +
      menuSeparator +
      menuItem("Sil", "shortcut-remove", "trash", "danger", `data-id="${id}"`),
  );
}
function reminderSettingsMenu(target) {
  openMenu(
    target,
    menuItem("Google Calendar", "google", "calendar") +
      menuItem("Kişisel tercihler", "preferences", "settings") +
      menuItem(`Varsayılan mod: ${esc(state.data.defaults.name)}`, "defaults", "clock") +
      (state.data.reminders.some((r) => r.done) ? menuSeparator + menuItem("Tamamlananları temizle", "reminder-clear", "trash") : ""),
  );
}
// Düzenleme penceresinin büyüyeceği satır.
const rowOf = (kind, id) => (id ? $(`[data-row-${kind}="${CSS.escape(id)}"]`) || $(`.calendar-event[data-id="${CSS.escape(id)}"]`) : null);

// ---------------------------------------------------------------- Formlar
function localDateTime(d) {
  const x = new Date(d);
  return dayKey(x) + "T" + String(x.getHours()).padStart(2, "0") + ":" + String(x.getMinutes()).padStart(2, "0");
}
function themeDialog() {
  let chosen = state.data.live.theme,
    colors = [...state.data.live.colors],
    details = false;
  openDialog(
    "Tema",
    `<p class="muted">${compact() ? "Küçük" : "Büyük"} görünüm için temayı seç; uygulamadan önce sağda gör.</p><div class="theme-layout"><div><div class="theme-list">${state.data.themes.map((t) => `<button class="theme-option ${t.name === chosen ? "active" : ""}" type="button" data-theme-name="${esc(t.name)}"><span class="swatch" style="background:linear-gradient(90deg, ${t.colors[0]} 0 50%, ${t.colors[5]} 50% 75%, ${t.colors[7]} 75%)"></span>${esc(t.name)}</button>`).join("")}</div>${B("Ayrıntılı renk ayarları", "theme-details", "settings", "ghost")}<div id="color-fields" class="color-fields" hidden>${["Arka plan", "Kartlar", "Seçili alan", "Ana yazılar", "Yardımcı yazılar", "Vurgu", "Kenarlıklar", "İkinci renk", "Başlıklar"].map((label, i) => `<label>${label}<input type="color" data-color="${i}" value="${colors[i]}"></label>`).join("")}</div>${B("Temanın renklerine dön", "theme-reset", "", "ghost")}</div><div class="theme-preview"><small>ÖNİZLEME</small><h3>Görevler</h3><div class="sample-card"><span class="sample-check"></span><div><p>Güne sakin bir başlangıç</p><small><span class="sample-time">09:00</span> · Her gün</small></div></div><button class="primary" type="button">${I("plus")}Görev ekle</button></div></div><div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}${B("Uygula", "theme-apply", "", "primary")}</div>`,
    { wide: true },
  );
  const preview = $(".theme-preview");
  function update() {
    themeVars(preview, colors);
    $$("[data-color]").forEach((el) => (el.value = colors[+el.dataset.color]));
    $$("[data-theme-name]").forEach((el) => el.classList.toggle("active", el.dataset.themeName === chosen));
  }
  update();
  $$("[data-theme-name]").forEach(
    (el) =>
      (el.onclick = () => {
        chosen = el.dataset.themeName;
        colors = [...state.data.themes.find((t) => t.name === chosen).colors];
        update();
      }),
  );
  $$("[data-color]").forEach(
    (el) =>
      (el.oninput = () => {
        colors[+el.dataset.color] = el.value;
        update();
      }),
  );
  $('[data-action="theme-details"]').onclick = () => {
    $("#color-fields").hidden = details;
    details = !details;
  };
  $('[data-action="theme-reset"]').onclick = () => {
    colors = [...state.data.themes.find((t) => t.name === chosen).colors];
    update();
  };
  $('[data-action="theme-apply"]').onclick = () =>
    run(async () => {
      await rpc("theme.apply", { name: chosen, colors });
      closeDialog();
      await refresh();
    });
}
async function speechSettings() {
  const s = await rpc("speech.settings");
  openDialog(
    "Ses ve komut ayarları",
    `<p class="muted">${esc(s.heard)}</p><form id="speech-form"><div class="fields">${field("Mikrofon", `<select name="microphone">${s.microphones.map((m, i) => `<option value="${i}" ${i === s.microphone ? "selected" : ""}>${esc(m)}</option>`).join("")}</select>`, true)}${field("Konuşma dili", `<select name="language"><option value="1" ${s.language === 1 ? "selected" : ""}>Türkçe</option><option value="0" ${s.language === 0 ? "selected" : ""}>English</option></select>`)}${field("Konuşma arası", `<select name="wait">${["Hızlı · 1,1 sn", "Dengeli · 1,8 sn", "Uzun · 2,8 sn"].map((x, i) => `<option value="${i}" ${s.wait === i ? "selected" : ""}>${x}</option>`).join("")}</select>`)}<label class="check-label full"><input name="uiSounds" type="checkbox" ${soundsOn() ? "checked" : ""}>Arayüz sesleri<small class="hint inline">Görev tamamlayınca, gün bitince ve yeni kayıt ekleyince kısa bir ses çalar.</small></label></div><div class="toolbar" style="margin-top:18px">${B("Komut örnekleri", "help", "help", "ghost")}${B("Ollama ayarları", "ollama", "ai", "ghost")}</div><div class="dialog-actions"><button class="primary">Kaydet</button></div></form>`,
  );
  // Açınca nasıl duyulduğunu hemen dinletir.
  $("#speech-form").elements.uiSounds.onchange = (e) => e.target.checked && playSound("done", true);
}
function helpDialog() {
  openDialog(
    "Sesli ve yazılı komutlar",
    `<p class="muted">Bir örneğe basarak komut alanına aktarabilirsin. Komut alanına her yerden <kbd>Ctrl</kbd> + <kbd>K</kbd> ile geçebilirsin.</p><div class="help-grid">${["On dakika sonra su içmeyi hatırlat", "15 Ekim saat 19daki hatırlatıcıyı sil", "Su içme hatırlatıcısını 5 dakika ertele", "Steam ara Hades", "Spotify ara Tarkan", "Spotify sesi yüzde 30 yap", "Sabah rutinimi başlat"].map((x) => B(esc(x), "example", "", "", `data-example="${esc(x)}"`)).join("")}</div>`,
  );
}
function shortcutEditor(id) {
  const old = state.data.routines.find((r) => r.id === id);
  let steps = structuredClone(old?.steps || []);
  openDialog(
    old ? "Kısayolu düzenle" : "Yeni kısayol",
    `<form id="shortcut-form">${field("Kısayol adı", `<input id="shortcut-name" name="name" required maxlength="200" value="${esc(old?.name || "")}">`)}<div id="shortcut-steps"></div><div class="toolbar" style="margin-top:14px">${B("Uygulama", "step-app", "plus")}${B("Web sayfası", "step-web", "plus")}${B("Bekleme", "step-wait", "plus")}${B("Hatırlatıcı", "step-reminder", "plus")}</div><div id="step-editor"></div><div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Kaydet</button></div></form>`,
    { origin: rowOf("shortcut", id) },
  );
  const redraw = () => {
    $("#shortcut-steps").innerHTML = steps
      .map(
        (s, i) =>
          `<div class="step-row"><span class="badge">${i + 1}</span><div class="item-copy">${esc(s.label || s.target || "Bekle")}<small class="muted"> · ${esc(s.kind === "wait" || s.kind === "reminder" ? s.minutes + " dk" : s.kind === "web" ? "Web sayfası" : "Uygulama")}</small></div>${B("↑", "step-up", "", "icon-button", `data-index="${i}" aria-label="Adımı yukarı taşı"`)}${B("↓", "step-down", "", "icon-button", `data-index="${i}" aria-label="Adımı aşağı taşı"`)}${B("×", "step-remove", "", "icon-button", `data-index="${i}" aria-label="Adımı sil"`)}</div>`,
      )
      .join("");
  };
  redraw();
  $("#shortcut-form").onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    run(async () => {
      await rpc("routine.save", { id: old?.id || null, name: $("#shortcut-name").value, steps });
      closeDialog();
      await refresh();
    });
  };
  $("#shortcut-form").addEventListener("click", (e) => {
    const b = e.target.closest("[data-action]");
    if (!b) return;
    const a = b.dataset.action,
      i = +b.dataset.index;
    if (a === "step-remove") {
      steps.splice(i, 1);
      redraw();
    }
    if (a === "step-up" && i > 0) {
      [steps[i - 1], steps[i]] = [steps[i], steps[i - 1]];
      redraw();
    }
    if (a === "step-down" && i < steps.length - 1) {
      [steps[i + 1], steps[i]] = [steps[i], steps[i + 1]];
      redraw();
    }
    if (a === "step-app")
      appPicker($("#step-editor"), (step) => {
        steps.push(step);
        $("#step-editor").replaceChildren();
        redraw();
      });
    if (["step-web", "step-wait", "step-reminder"].includes(a)) {
      const kind = a.slice(5);
      $("#step-editor").innerHTML =
        `<div class="fields">${kind !== "wait" ? field(kind === "web" ? "Web adresi" : "Hatırlatma metni", '<input id="step-target" placeholder="' + (kind === "web" ? "https://…" : "Mola zamanı") + '">', true) : ""}${kind === "web" ? field("Tarayıcı", '<select id="step-browser"><option value="default">Varsayılan</option><option value="chrome">Chrome</option></select>') : field("Dakika", '<input type="number" id="step-minutes" min="1" max="10080" value="5">')}</div>${B("Adımı ekle", "step-add", "", "primary")}`;
      $('[data-action="step-add"]').onclick = () => {
        let target = $("#step-target")?.value || "";
        if (kind === "web" && !/^https?:\/\//i.test(target)) target = "https://" + target;
        if (kind === "web") {
          try {
            const u = new URL(target);
            if (!["https:", "http:"].includes(u.protocol)) throw 0;
          } catch {
            toast("Geçerli bir web adresi yaz.");
            return;
          }
        }
        if (kind === "reminder" && !target.trim()) {
          toast("Hatırlatma metni yaz.");
          return;
        }
        steps.push({
          kind,
          target,
          browser: $("#step-browser")?.value || "default",
          minutes: +($("#step-minutes")?.value || 1),
        });
        $("#step-editor").replaceChildren();
        redraw();
      };
    }
  });
}

// ---------------------------------------------------------------- Ctrl+K komut penceresi
// Ortada açılır; yazarken Enter'a basınca ne olacağı üstte önizlenir.
// Saat içeren metin hatırlatıcı olur, bölüm adı o bölüme götürür, gerisi asistana gider.
// q: hızlı ekleme ayrıştırması (C#); henüz gelmediyse null.
function paletteOptions(text, q) {
  const t = text.trim(),
    low = t.toLocaleLowerCase("tr-TR");
  const go = (s) => ({ icon: s[2], kind: "Bölüme gidilecek", title: s[3], detail: "Bölüm", run: () => action("navigate", { dataset: { page: s[0] } }) });
  if (!t)
    return [
      { icon: "plus", kind: "Yeni hatırlatıcı", title: "Hatırlatıcı ekle", detail: "Pencere", run: () => reminderEditor() },
      { icon: "plus", kind: "Yeni görev", title: "Görev ekle", detail: "Pencere", run: () => taskEditor() },
      ...sections.map(go),
    ];
  const list = [];
  q = q || { kind: "none" };
  const save = async () => {
    await saveQuick(q);
    await refresh();
  };
  if (q.kind === "someday") list.push({ icon: "task", kind: "Bir ara listesine eklenecek", title: q.text, detail: quickLabel(q), run: save });
  if (q.kind === "reminder" && q.text)
    list.push({ icon: "clock", kind: "Hatırlatıcı oluşturulacak", title: q.text, detail: `${relativeDay(q.due)} ${clock(q.due)} · ${state.data.defaults.name || "Normal"}`, run: save });
  list.push(...sections.filter((s) => s[1].toLocaleLowerCase("tr-TR").startsWith(low) || s[3].toLocaleLowerCase("tr-TR").includes(low)).map(go));
  list.push({
    icon: "mic",
    kind: "Asistana gönderilecek",
    title: t,
    detail: "Sesli komutla aynı şekilde işlenir",
    run: async () => {
      await rpc("speech.command", { text: t });
      await refresh();
    },
  });
  if (q.kind === "task" && q.text) list.push({ icon: "task", kind: "Görev eklenecek", title: q.text, detail: quickLabel(q), run: save });
  const search = (page) => async () => {
    state.query[page] = t;
    await action("navigate", { dataset: { page } });
    $(`#${page}-search`)?.dispatchEvent(new Event("input", { bubbles: true }));
  };
  list.push(
    { icon: "music", kind: "Spotify'da aranacak", title: t, detail: "Müzik", run: search("spotify") },
    { icon: "game", kind: "Steam'de aranacak", title: t, detail: "Oyunlar", run: search("steam") },
    {
      icon: "ai",
      kind: "AI'lara sorulacak",
      title: t,
      detail: "AI sohbetleri",
      run: async () => {
        await action("navigate", { dataset: { page: "ai" } });
        toast(await rpc("ai.send", { text: t, targets: state.targets }));
      },
    },
  );
  return list;
}
function commandPalette() {
  closeMenu();
  state.modal = "Komut";
  $("#portal").innerHTML = `<div class="modal-layer palette-layer"><section class="dialog palette" role="dialog" aria-modal="true" aria-label="Komut"><label class="palette-input">${I("search")}<input id="palette-input" autocomplete="off" spellcheck="false" placeholder="Komut yaz, görev veya hatırlatıcı ekle…" aria-label="Komut"><kbd>Esc</kbd></label><div id="palette-preview" class="palette-preview"></div><div id="palette-options" class="palette-options" role="listbox" aria-label="Seçenekler"></div></section></div>`;
  const layer = $("#portal .modal-layer"),
    input = $("#palette-input");
  let options = [],
    selected = 0,
    parsed = null,
    pending = Promise.resolve();
  // Ayrıştırma C#'ta yapılır; yanıt gelince seçenekler yeniden çizilir. Enter yanıtı bekler.
  function parse() {
    const text = input.value.trim();
    parsed = null;
    pending = text
      ? parseQuick(text).then(
          (q) => {
            if (input.value.trim() === text) {
              parsed = q;
              draw();
            }
          },
          () => {},
        )
      : Promise.resolve();
  }
  function draw() {
    options = paletteOptions(input.value, parsed);
    selected = Math.min(selected, options.length - 1);
    const o = options[selected];
    $("#palette-preview").innerHTML = `<span class="palette-icon">${I(o.icon)}</span><div><small>${esc(o.kind)}</small><strong>${esc(o.title)}</strong><span>${esc(o.detail)}</span></div><kbd>Enter</kbd>`;
    $("#palette-options").innerHTML = options
      .map((x, i) => `<button type="button" role="option" class="palette-option ${i === selected ? "active" : ""}" aria-selected="${i === selected}" data-palette="${i}">${I(x.icon)}<span>${esc(x.kind)}</span><small>${esc(x.detail)}</small></button>`)
      .join("");
    $(".palette-option.active")?.scrollIntoView({ block: "nearest" });
  }
  function choose(i) {
    const o = options[i];
    if (!o) return;
    closeDialog();
    run(o.run);
  }
  input.addEventListener("input", () => {
    selected = 0;
    parse();
    draw();
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      selected = (selected + (e.key === "ArrowDown" ? 1 : options.length - 1)) % options.length;
      draw();
    }
    if (e.key === "Enter" && !e.isComposing) {
      e.preventDefault();
      pending.then(() => choose(selected));
    }
  });
  $("#palette-options").addEventListener("click", (e) => {
    const b = e.target.closest("[data-palette]");
    if (b) choose(+b.dataset.palette);
  });
  layer.addEventListener("mousedown", (e) => {
    if (e.target === layer) closeDialog();
  });
  draw();
  if (!reducedMotion()) {
    layer.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 140, easing: "ease-out" });
    $(".palette", layer).animate([{ transform: "translateY(-8px) scale(.98)", opacity: 0 }, { transform: "none", opacity: 1 }], { duration: 180, easing: easeOut });
  }
  scheduleSlots();
  setTimeout(() => input.focus(), 10);
}

// ---------------------------------------------------------------- Ayar pencereleri
// Eskiden ayrı Windows pencereleriydi; artık aynı belgede, ortada açılırlar.

// Uzun süren işlemlerde düğmeleri kilitler ve durum satırını günceller.
async function busy(statusSelector, text, work) {
  const buttons = $$("#portal .dialog-content button:not([data-action=dialog-close])");
  buttons.forEach((b) => (b.disabled = true));
  if (text) $(statusSelector).textContent = text;
  try {
    return await work();
  } catch (e) {
    if ($(statusSelector)) $(statusSelector).textContent = e.message;
  } finally {
    buttons.forEach((b) => b.isConnected && (b.disabled = b.dataset.locked === "1"));
  }
}

function defaultsDialog() {
  let { level, count, intervalMinutes } = state.data.defaults;
  openDialog(
    "Hatırlatma sıklığı",
    `<p class="muted">Yeni hatırlatıcılar varsayılan olarak bu şekilde hatırlatılır.</p>
    <div class="segmented wide-segments" role="group" aria-label="Hatırlatma biçimi">${B("Normal", "level-pick", "", "", 'data-level="Normal"')}${B("ADHD", "level-pick", "", "", 'data-level="Adhd"')}</div>
    <div class="fields" style="margin-top:16px">${field("Her turda kaç kez?", '<input id="opt-count" type="number" min="1" max="20">')}${field("Tekrarlar arası (dakika)", '<input id="opt-interval" type="number" min="1" max="1440">')}</div>
    <p id="opt-unlimited" class="muted" hidden>Sınırsız · onaylayana kadar tekrar eder.</p>
    <p id="opt-summary" class="summary-line"></p>
    <p class="muted small">ADHD: Onaylayana kadar sınırsız tekrar. Aralık 1 dakikaya kadar kısalır; 4. bildirimden itibaren ortada görünür. “Yaptım” yanıtı ayrıca onaylanır.</p>
    <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}${B("Uygula", "defaults-apply", "", "primary")}</div>`,
  );
  const presets = { Normal: [1, 15], Adhd: [6, 3] };
  let describeTimer;
  const update = () => {
    $$("[data-level]").forEach((b) => b.classList.toggle("active", b.dataset.level === level));
    $("#opt-count").closest(".field").hidden = level === "Adhd";
    $("#opt-unlimited").hidden = level !== "Adhd";
    $("#opt-count").value = count;
    $("#opt-interval").value = intervalMinutes;
    $("#opt-interval").disabled = level !== "Adhd" && count <= 1;
    clearTimeout(describeTimer);
    describeTimer = setTimeout(
      () =>
        rpc("options.describe", { level, count, intervalMinutes })
          .then((d) => $("#opt-summary") && ($("#opt-summary").textContent = d.description))
          .catch(() => {}),
      120,
    );
  };
  $$("[data-level]").forEach(
    (b) =>
      (b.onclick = (e) => {
        e.stopPropagation();
        level = b.dataset.level;
        [count, intervalMinutes] = presets[level];
        update();
      }),
  );
  $("#opt-count").onchange = (e) => {
    count = Math.min(20, Math.max(1, +e.target.value || 1));
    update();
  };
  $("#opt-interval").onchange = (e) => {
    intervalMinutes = Math.min(1440, Math.max(1, +e.target.value || 1));
    update();
  };
  $('[data-action="defaults-apply"]').onclick = (e) => {
    e.stopPropagation();
    run(async () => {
      await rpc("defaults.save", { level, count, intervalMinutes });
      closeDialog();
      await refresh();
    });
  };
  update();
}

async function preferencesDialog() {
  const p = await rpc("preferences.get");
  const num = (name, value, min, max) => `<input type="number" name="${name}" value="${value}" min="${min}" max="${max}">`;
  const range = (label, a, b, max = 24) =>
    `<div class="pref-row"><span>${label}</span><div class="pref-range">${num(a, p[a], 0, max)}<span>–</span>${num(b, p[b], 0, max)}</div></div>`;
  openDialog(
    "Kişisel plan tercihleri",
    `<form id="preferences-form"><p class="muted">Kendi ritmini belirle. Saatler 24 saat düzenindedir; tercihler yalnızca saat önerilerini etkiler, kesin planlarını taşımaz ve bildirimleri susturmaz.</p>
    <div class="pref-list">${range("Hafta içi boş saatlerin", "weekdayStart", "weekdayEnd")}${range("Hafta sonu boş saatlerin", "weekendStart", "weekendEnd")}${range("Uyku (başlangıç – bitiş)", "sleepStart", "sleepEnd", 23)}${range("Tercih ettiğin çalışma saatleri", "preferredStart", "preferredEnd")}
    <div class="pref-row"><span>Görevler arası mola (dk)</span>${num("breakMinutes", p.breakMinutes, 0, 120)}</div>
    <div class="pref-row"><span>Günlük plan yükü üst sınırı (dk)</span>${num("dailyLimitMinutes", p.dailyLimitMinutes, 5, 1440)}</div>
    <div class="pref-row"><span>Varsayılan görev süresi (dk)</span>${num("defaultDuration", p.defaultDuration, 5, 720)}</div></div>
    <div class="check-row" style="margin-top:12px"><label class="check-label"><input type="checkbox" name="useWeekdays" ${p.useWeekdays ? "checked" : ""}>Hafta içi öner</label><label class="check-label"><input type="checkbox" name="useWeekends" ${p.useWeekends ? "checked" : ""}>Hafta sonu öner</label></div>
    <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Kaydet</button></div></form>`,
  );
  $("#preferences-form").onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const f = e.target,
      values = {};
    for (const input of $$("input[type=number]", f)) values[input.name] = +input.value;
    values.useWeekdays = f.elements.useWeekdays.checked;
    values.useWeekends = f.elements.useWeekends.checked;
    run(async () => {
      await rpc("preferences.save", values);
      closeDialog();
      toast("Plan tercihlerin kaydedildi.");
    });
  };
}

// Günü planla: bugünün (ve geciken) saatsiz tek seferlik görevlerini boş saatlere yerleştirir.
// Öneri C# tarafında (PlanSuggestions.PlanDay) hesaplanır; kaydedince her iş esnek bir plana dönüşür.
async function dayPlanner() {
  const key = today();
  const items = state.data.tasks
    .filter((t) => !t.dailyActivity && !t.done && (t.myDay === key || t.due === key || (t.due && t.due < key)))
    .sort((a, b) => Number(b.important) - Number(a.important));
  if (!items.length) {
    toast("Planlanacak saatsiz iş yok.");
    return;
  }
  const durations = [15, 30, 45, 60, 90, 120];
  openDialog(
    "Günü planla",
    `<p class="muted">Saatsiz işlerini bugünün boş saatlerine yerleştiririm. Kesin planların, aradaki molalar ve plan tercihlerin dikkate alınır; önemli işler önce yer alır. Kaydedince işler takvime esnek plan olarak geçer.</p>
    <div class="plan-rows">${items
      .map(
        (t) =>
          `<div class="plan-row" data-plan-task="${esc(t.id)}"><label class="check-label"><input type="checkbox" data-plan-pick checked><span>${t.important ? prioMark({ plan: { priority: 3 } }) : ""}${esc(t.title)}</span></label><select data-plan-duration aria-label="Süre">${durations.map((m) => `<option value="${m}" ${m === 30 ? "selected" : ""}>${m} dk</option>`).join("")}</select><span class="plan-slot" data-plan-slot>…</span></div>`,
      )
      .join("")}</div>
    <div class="dialog-actions">${B("Plan tercihleri", "preferences", "settings", "ghost push-left")}${B("Vazgeç", "dialog-close", "", "ghost")}<button type="button" id="day-plan-save" class="primary">Takvime yerleştir</button></div>`,
    { wide: true },
  );
  const rows = $$(".plan-row");
  async function suggest() {
    const picked = rows.filter((r) => $("[data-plan-pick]", r).checked);
    rows.forEach((r) => {
      delete r.dataset.start;
      $("[data-plan-slot]", r).textContent = picked.includes(r) ? "…" : "—";
    });
    if (!picked.length) return;
    const slots = await rpc("day.plan", {
      day: key,
      plans: picked.map((r) => ({
        durationMinutes: +$("[data-plan-duration]", r).value,
        priority: items.find((t) => t.id === r.dataset.planTask).important ? 3 : 2,
        category: "Personal",
      })),
    });
    picked.forEach((r, i) => {
      const s = slots[i],
        cell = $("[data-plan-slot]", r);
      if (s) r.dataset.start = s.start;
      cell.textContent = s ? `${clock(s.start)} – ${clock(s.end)}` : "Bugüne sığmadı";
      cell.classList.toggle("is-missing", !s);
    });
  }
  rows.forEach((r) => $$("input, select", r).forEach((el) => (el.onchange = () => run(suggest))));
  $("#day-plan-save").onclick = () =>
    run(async () => {
      const placed = rows.filter((r) => r.dataset.start && $("[data-plan-pick]", r).checked);
      if (!placed.length) throw new Error("Yerleştirilecek iş yok; süreleri kısaltmayı ya da plan tercihlerini değiştirmeyi dene.");
      const d = state.data.defaults;
      for (const r of placed) {
        const t = items.find((x) => x.id === r.dataset.planTask);
        // Aynı kayda saat eklenir (kimlik, adımlar ve liste korunur).
        const start = new Date(r.dataset.start),
          form = await rpc("item.get", { id: t.id });
        await rpc("item.save", {
          form: { ...form, day: dayKey(start), timeMinutes: start.getHours() * 60 + start.getMinutes(), flexible: true, durationMinutes: +$("[data-plan-duration]", r).value, notify: form.notify || { level: d.level, count: d.count, intervalMinutes: d.intervalMinutes } },
        });
      }
      playSound("add");
      toast(`${placed.length} iş takvime yerleşti.`);
      closeDialog();
      await refresh();
    });
  await suggest();
}

async function googleDialog() {
  const g = await rpc("google.status");
  openDialog(
    "Google Calendar",
    `<h3 class="dialog-lead">Planların telefonunda da yanında</h3>
    <ol class="steps-list"><li>Google Cloud’da Calendar API’yi etkinleştir.</li><li>Google Auth Platform’da <strong>Desktop app</strong> türünde istemci oluştur ve JSON dosyasını indir. Test kullanıcısı olarak Gmail adresini ekle.</li><li>Dosyayı seç ve Google ile bağlan.</li></ol>
    <p class="muted small">Google’da ayrı bir Kişisel Asistan takvimi kullanılır. Bu takvimdeki saatli, tek seferlik planlar iki yönlü eşitlenir. Otomatik kontrol 5 dakikada bir yapılır. Özel bildirimler asistan açıkken çalışır.</p>
    <div class="button-row"><label class="file-button ${g.available ? "" : "is-disabled"}">${I("folder")}Bağlantı dosyasını seç (.json)<input id="google-file" type="file" accept=".json,application/json" ${g.available ? "" : "disabled"} hidden></label>${B("Google kurulumunu aç", "google-setup", "external", "ghost")}</div>
    <div class="button-row">${B("Google ile bağlan", "google-connect", "", "primary")}${B("Şimdi eşitle", "google-sync", "refresh")}${B("Bağlantıyı kes", "google-disconnect", "", "ghost danger")}</div>
    <p id="google-status" class="status-box" role="status">${esc(g.status)}</p>
    <p class="muted small">Telefonunda Google Calendar’ın Kişisel Asistan takvimini görünür yap.</p>`,
  );
  if (!g.available) $$('#portal [data-action^="google-"]').forEach((b) => ((b.disabled = true), (b.dataset.locked = "1")));
  $("#google-file").onchange = (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    if (file.size > 65536) {
      $("#google-status").textContent = "Bu dosya bir Google bağlantı dosyası olamayacak kadar büyük.";
      return;
    }
    busy("#google-status", "Dosya okunuyor…", async () => ($("#google-status").textContent = await rpc("google.import", { json: await file.text() })));
  };
  const actions = {
    "google-connect": ["Tarayıcıda Google hesabını seçip izin ver…", "google.connect"],
    "google-sync": ["Eşitleniyor…", "google.sync"],
    "google-disconnect": ["Bağlantı kesiliyor…", "google.disconnect"],
  };
  for (const [name, [text, method]] of Object.entries(actions))
    $(`#portal [data-action="${name}"]`).onclick = (e) => {
      e.stopPropagation();
      busy("#google-status", text, async () => {
        const status = await rpc(method, {}, 600000);
        if ($("#google-status")) $("#google-status").textContent = status;
      });
    };
  $('#portal [data-action="google-setup"]').onclick = (e) => {
    e.stopPropagation();
    run(() => rpc("google.setup"));
  };
}

async function ollamaDialog() {
  const o = await rpc("ollama.get");
  openDialog(
    "Komut zekâsı · Ollama",
    `<p class="muted">Anlaşılamayan sesli ve yazılı komutları bilgisayarındaki modele sor. Komutların bilgisayarında işlenir; Ollama ve model isteğe bağlıdır.</p>
    <label class="check-label"><input id="ollama-enabled" type="checkbox" ${o.enabled ? "checked" : ""}>Esnek komutlar için Ollama kullan</label>
    <div class="button-row" style="margin-top:12px"><select id="ollama-model" aria-label="Yerel model">${o.model ? `<option>${esc(o.model)}</option>` : '<option value="">Model yok</option>'}</select>${B("Yerel modelleri kontrol et", "ollama-discover", "refresh")}</div>
    <h3 class="dialog-lead" style="margin-top:18px">Kurulum</h3>
    <div class="button-row"><select id="ollama-package" aria-label="Kurulacak model">${o.packages.map((p, i) => `<option value="${i}">${esc(p)}</option>`).join("")}</select>${B("Ollama ve modeli kur", "ollama-install", "plus")}${B("İndirmeyi durdur", "ollama-stop", "stop", "ghost")}</div>
    <p class="muted small">İlk kurulum internet kullanır: modele ek olarak birkaç GB Ollama dosyası indirilir. Mevcut Ollama varsa kullanılır. İndirilenler uygulama güncellemelerinde korunur. Pencereyi kapatsan da indirme sürer.</p>
    <p id="ollama-status" class="status-box" role="status">${o.installing ? "Kurulum sürüyor…" : "Ollama ve yerel modeller kontrol ediliyor…"}</p>
    <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}${B("Kaydet", "ollama-save", "", "primary")}</div>`,
  );
  const stop = $('#portal [data-action="ollama-stop"]'),
    install = $('#portal [data-action="ollama-install"]');
  const installing = (on) => {
    stop.hidden = !on;
    install.dataset.locked = on ? "1" : "";
    install.disabled = on;
  };
  installing(o.installing);
  async function discover() {
    const select = $("#ollama-model");
    const chosen = select.value || o.model;
    const models = await rpc("ollama.models");
    if (!$("#ollama-model")) return models;
    select.innerHTML = models.length ? models.map((m) => `<option ${m === chosen ? "selected" : ""}>${esc(m)}</option>`).join("") : '<option value="">Model yok</option>';
    $("#ollama-status").textContent = models.length ? "Yerel bağlantı hazır. Modeli seçip etkinleştirebilirsin." : "Ollama açık, fakat yerel model yok. Model kurduktan sonra tekrar kontrol et.";
    return models;
  }
  $('#portal [data-action="ollama-discover"]').onclick = (e) => {
    e.stopPropagation();
    busy("#ollama-status", "Ollama ve yerel modeller kontrol ediliyor…", discover);
  };
  stop.onclick = (e) => {
    e.stopPropagation();
    rpc("ollama.stop").catch(() => {});
  };
  install.onclick = (e) => {
    e.stopPropagation();
    installing(true);
    $("#ollama-status").textContent = "Kurulum başlıyor…";
    rpc("ollama.install", { index: +$("#ollama-package").value }, 6 * 3600000)
      .then(async (model) => {
        if (!stop.isConnected) return toast("Ollama kurulumu tamamlandı.");
        const models = await discover();
        if (!models.includes(model)) return ($("#ollama-status").textContent = "İndirme bitti ancak model doğrulanamadı. Yerel modelleri kontrol et'e bas.");
        $("#ollama-model").value = model;
        $("#ollama-enabled").checked = true;
        $("#ollama-status").textContent = "Kurulum hazır. Etkinleştirmek için Kaydet'e bas.";
      })
      .catch((err) => (stop.isConnected ? ($("#ollama-status").textContent = err.message) : toast(err.message)))
      .finally(() => stop.isConnected && installing(false));
  };
  $('#portal [data-action="ollama-save"]').onclick = (e) => {
    e.stopPropagation();
    run(async () => {
      await rpc("ollama.save", { enabled: $("#ollama-enabled").checked, model: $("#ollama-model").value });
      closeDialog();
      toast("Ollama ayarı kaydedildi.");
    });
  };
  if (!o.installing) busy("#ollama-status", "", discover);
}

async function spotifyDialog() {
  const a = await rpc("spotify.account");
  openDialog(
    "Spotify bağlantısı",
    `<p class="status-line ${a.connected ? "is-on" : ""}">${a.connected ? "Bağlı" : "Bağlı değil"}</p>
    <h3 class="dialog-lead">Hesap bağlantısı</h3>
    ${field("Client ID", `<input id="spotify-client" value="${esc(a.clientId)}" placeholder="Spotify Developer Client ID" autocomplete="off" spellcheck="false">`)}
    <div class="button-row" style="margin-top:10px">${B(a.connected ? "Yeniden bağlan" : "Spotify hesabını bağla", "spotify-connect", "", "primary")}${a.connected ? B("Bağlantıyı kaldır", "spotify-disconnect", "", "ghost danger") : ""}</div>
    <h3 class="dialog-lead" style="margin-top:18px">Masaüstü uygulaması</h3>
    <div class="button-row">${B("Spotify uygulamasını seç", "spotify-choose", "folder")}${B("Spotify durumunu kontrol et", "spotify-inspect", "search", "ghost")}</div>
    <details class="help-details"><summary>Kurulum yardımı</summary><p>Kendi Spotify hesabını bağla; yayıncının hesabıyla giriş yapman gerekmez. Yayıncı sana bir Client ID verdiyse buraya yapıştır. Client ID uygulamayı tanımlar; hesap şifresi değildir. Test modunda yayıncının senin hesabını uygulamanın kullanıcı listesine eklemesi gerekir.</p><p>Kendi geliştirici uygulamanı kullanmak istersen:</p><ol class="steps-list"><li>developer.spotify.com/dashboard üzerinden uygulama oluştur.</li><li>Redirect URI: <code>${esc(a.redirectUri)}</code></li><li>Web API seçeneğini kaydet, Client ID değerini buraya yapıştır. Client Secret gerekmez.</li></ol><p>Sonra “Spotify hesabını bağla”ya bas ve tarayıcıda izin ver. Şarkılar bilgisayarındaki Spotify uygulamasında çalar; doğrudan oynatma için Spotify Premium gerekir.</p></details>
    <p id="spotify-feedback" class="status-box" role="status">${a.connected ? "Hesabın bağlı. Şarkı arayıp sonuca çift tıklayabilirsin." : "Client ID yapıştırıp hesabını bağla."}</p>`,
  );
  const handlers = {
    "spotify-connect": ["Tarayıcıda kendi Spotify hesabını seçip izin ver…", () => rpc("spotify.connect", { clientId: $("#spotify-client").value.trim() }, 600000)],
    "spotify-disconnect": ["Bağlantı kaldırılıyor…", () => rpc("spotify.disconnect")],
    "spotify-choose": ["", () => rpc("spotify.chooseApp")],
    "spotify-inspect": ["Kontrol ediliyor…", () => rpc("spotify.inspect")],
  };
  for (const [name, [text, call]] of Object.entries(handlers)) {
    const b = $(`#portal [data-action="${name}"]`);
    if (b)
      b.onclick = (e) => {
        e.stopPropagation();
        busy("#spotify-feedback", text, async () => {
          const message = await call();
          if (message && $("#spotify-feedback")) $("#spotify-feedback").textContent = message;
        });
      };
  }
}

// Kısayol düzenleyicisinin içinde açılan uygulama seçici. Sonuç çift tıkla (veya Enter) eklenir.
let installedApps = null;
const fold = (s) => s.normalize("NFD").replace(/\p{M}/gu, "").toLocaleLowerCase("tr-TR");
function appPicker(container, add) {
  container.innerHTML = `<div class="app-picker"><label class="search">${I("search")}<input id="app-search" placeholder="Uygulama ara…" autocomplete="off" aria-label="Uygulama ara"></label><div id="app-list" class="app-list rows" role="listbox" aria-label="Uygulamalar"><div class="empty">Windows uygulamaları okunuyor…</div></div><div class="button-row"><small id="app-count" class="muted"></small><span class="spacer"></span>${B("Dosyadan seç…", "step-file", "folder", "ghost")}</div></div>`;
  const draw = () => {
    if (!installedApps || !$("#app-list")) return;
    const q = fold($("#app-search").value.trim());
    const found = installedApps.map((a, i) => [a, i]).filter(([a]) => !q || fold(a.name).includes(q));
    $("#app-list").innerHTML =
      found
        .slice(0, 80)
        .map(
          ([a, i]) =>
            `<div class="item-row is-pickable app-pick" tabindex="0" role="option" data-app="${i}" title="Eklemek için çift tıkla">${a.icon ? `<img class="app-icon" src="${a.icon}" alt="">` : `<span class="app-icon">${I("shortcut")}</span>`}<div class="item-copy"><strong>${esc(a.name)}</strong><small>Windows uygulaması</small></div><small class="pick-hint">Çift tıkla · ekle</small></div>`,
        )
        .join("") || `<div class="empty">${installedApps.length ? "Aramana uygun uygulama yok." : "Uygulama bulunamadı. Dosyadan seçebilirsin."}</div>`;
    $("#app-count").textContent = `${found.length} uygulama · listede olmayanlar için “Dosyadan seç”`;
  };
  const pick = (row) => {
    const a = installedApps[+row.dataset.app];
    add({ kind: "installed-app", target: a.id, label: a.name, browser: "default", minutes: 1 });
  };
  $("#app-search").oninput = draw;
  $("#app-list").ondblclick = (e) => {
    const row = e.target.closest("[data-app]");
    if (row) pick(row);
  };
  $("#app-list").onkeydown = (e) => {
    const row = e.key === "Enter" && e.target.closest("[data-app]");
    if (row) {
      e.preventDefault();
      pick(row);
    }
  };
  $('[data-action="step-file"]', container).onclick = (e) => {
    e.stopPropagation();
    run(async () => {
      const step = await rpc("routine.pickFile");
      if (step) add(step);
    });
  };
  setTimeout(() => $("#app-search")?.focus(), 20);
  if (installedApps) draw();
  else
    rpc("apps.list")
      .then((apps) => {
        installedApps = apps;
        draw();
      })
      .catch(() => {
        if ($("#app-list")) $("#app-list").innerHTML = '<div class="empty">Liste okunamadı. Dosyadan seçebilirsin.</div>';
      });
}
