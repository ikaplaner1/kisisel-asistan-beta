using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Nodes;

namespace KisiselAsistan;

internal interface IGoogleCalendarApi
{
    Task<JsonObject> RequestAsync(HttpMethod method, string path, JsonObject? body, string? etag, CancellationToken token);
}
internal sealed class GoogleCalendarApi(IGoogleCalendarSession session) : IGoogleCalendarApi, IDisposable
{
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(25) };
    public async Task<JsonObject> RequestAsync(HttpMethod method, string path, JsonObject? body, string? etag, CancellationToken token)
    {
        using var request = new HttpRequestMessage(method, "https://www.googleapis.com/calendar/v3/" + path);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", await session.AccessAsync(token));
        if (etag != null) request.Headers.TryAddWithoutValidation("If-Match", etag);
        if (body != null) request.Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json");
        using var response = await http.SendAsync(request, token);
        if (!response.IsSuccessStatusCode) {
            var details = await response.Content.ReadAsStringAsync(token);
            var message = ErrorMessage(response.StatusCode, details);
            throw new CalendarApiException(response.StatusCode, message);
        }
        var text = await response.Content.ReadAsStringAsync(token);
        return text.Length == 0 ? new JsonObject() : JsonNode.Parse(text)?.AsObject() ?? new JsonObject();
    }
    internal static string ErrorMessage(HttpStatusCode status, string payload)
    {
        var reasons = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        try {
            var error = JsonNode.Parse(payload)?["error"];
            if (error?["errors"] is JsonArray errors)
                foreach (var item in errors) if (item?["reason"]?.GetValue<string>() is { } reason) reasons.Add(reason);
            if (error?["details"] is JsonArray details)
                foreach (var item in details) if (item?["reason"]?.GetValue<string>() is { } reason) reasons.Add(reason);
            // Google sometimes omits ErrorInfo for an insufficient OAuth scope.
            if (error?["message"]?.GetValue<string>() is { } text && text.Contains("insufficient authentication scopes", StringComparison.OrdinalIgnoreCase)) reasons.Add("ACCESS_TOKEN_SCOPE_INSUFFICIENT");
        } catch (Exception ex) when (ex is System.Text.Json.JsonException or InvalidOperationException) { }
        if (status == HttpStatusCode.Forbidden) {
            if (reasons.Overlaps(["accessNotConfigured", "SERVICE_DISABLED"]))
                return "Google Calendar API, bağlantı dosyasının ait olduğu projede etkin değil. Google Cloud’da o projeyi seçip Google Calendar API → Enable yap. Başka projeden dosya seçtiysen doğru Desktop app JSON dosyasını yükle.";
            if (reasons.Overlaps(["insufficientPermissions", "ACCESS_TOKEN_SCOPE_INSUFFICIENT"]))
                return "Google takvim izni eksik. Google ile bağlan’a yeniden bas; izin ekranında uygulamanın oluşturduğu takvimlere erişim iznini işaretleyip devam et.";
            if (reasons.Overlaps(["rateLimitExceeded", "userRateLimitExceeded", "quotaExceeded", "RATE_LIMIT_EXCEEDED", "QUOTA_EXCEEDED"]))
                return "Google Calendar kullanım sınırına ulaşıldı. Bir süre sonra Şimdi eşitle’ye bas; planların korunuyor.";
            if (reasons.Contains("forbiddenForNonOrganizer")) return "Bu etkinliği değiştirmek için düzenleyici izni gerekiyor.";
            var safeReasons = reasons.Where(r => r.Length <= 80 && r.All(c => char.IsAsciiLetterOrDigit(c) || c == '_')).Take(3).ToArray();
            return "Google takvim erişimini reddetti (403" + (safeReasons.Length == 0 ? "" : ": " + string.Join(", ", safeReasons)) + "). Google ile bağlan’a yeniden basıp takvim iznini ver. Devam ederse bu hata kodunu paylaş.";
        }
        return status switch {
                HttpStatusCode.Unauthorized => "Google bağlantı izni sona erdi. Yeniden bağlan.",
                HttpStatusCode.PreconditionFailed => "Plan eşitleme sırasında değişti. Tekrar eşitle; iki kopya korunuyor.",
                HttpStatusCode.NotFound => "Google takvimi bulunamadı. Bağlantıyı yeniden kur.",
                HttpStatusCode.TooManyRequests => "Google kullanım sınırına ulaşıldı. Eşitleme daha sonra tekrar denenecek.",
                _ => $"Google Calendar işlemi tamamlanamadı ({(int)status})."
            };
    }
    public void Dispose() => http.Dispose();
}
internal sealed class CalendarApiException(HttpStatusCode status, string message) : Exception(message)
{
    internal HttpStatusCode Status => status;
}
