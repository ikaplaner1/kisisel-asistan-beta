namespace KisiselAsistan;

public record Reminder(Guid Id, string Text, DateTimeOffset Due, bool Done = false, ReminderOptions? Options = null, int SentCount = 0, DateTimeOffset? NextNotice = null, int Revision = 0, int Pressure = 0, PlanDetails? Plan = null, DateTimeOffset? AdvanceSentForDue = null)
{ public ReminderOptions Settings => Options?.Normalize() ?? new(); public bool CanNotify(DateTimeOffset now) => !Done && (Settings.Level == ReminderIntensity.Adhd || SentCount < Settings.Count) && (NextNotice ?? Due) <= now; }
