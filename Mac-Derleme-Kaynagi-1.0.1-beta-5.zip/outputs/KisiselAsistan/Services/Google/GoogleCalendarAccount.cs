using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace KisiselAsistan;


public sealed class GoogleCalendarAccount : IGoogleCalendarSession, IDisposable
{
    public const string Scope = "openid https://www.googleapis.com/auth/calendar.app.created";
    private readonly HttpClient http;
    private readonly Action<string> openBrowser;
    internal event Action<string>? Progress;
    private readonly SemaphoreSlim gate = new(1, 1);
    private readonly string path;
    private AccountData? data;
    public bool Configured => !string.IsNullOrEmpty(data?.ClientId);
    internal string AccountKey => data?.Subject ?? "";
    internal void ImportCredentials(string json)
    {
        using var document = JsonDocument.Parse(json);
        if (!document.RootElement.TryGetProperty("installed", out var installed)) throw new ArgumentException("Masaüstü uygulaması (Desktop app) için indirilen JSON dosyasını seç.");
        var id = installed.GetProperty("client_id").GetString() ?? "";
        var secret = installed.GetProperty("client_secret").GetString() ?? "";
        if (!id.EndsWith(".apps.googleusercontent.com") || secret.Length == 0) throw new ArgumentException("Google bağlantı dosyası geçersiz.");
        if (data?.ClientId == id && data.ClientSecret == secret) return;
        var next = new AccountData(id, secret, "", "", DateTimeOffset.MinValue); Save(next); data = next;
    }
    public bool Connected => !string.IsNullOrEmpty(data?.RefreshToken);
    public GoogleCalendarAccount(string? storagePath = null, HttpMessageHandler? transport = null, Action<string>? browserLauncher = null)
    {
        http = transport == null ? new HttpClient() : new HttpClient(transport);
        http.Timeout = TimeSpan.FromSeconds(20);
        openBrowser = browserLauncher ?? (url => { using var process = Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); });
        path = storagePath ?? DeploymentPaths.Data("google-calendar-account.bin");
        if (File.Exists(path)) {
            try { data = JsonSerializer.Deserialize<AccountData>(WindowsSecret.Decode(File.ReadAllBytes(path))); }
            catch { data = null; }
        }
    }
    public async Task ConnectAsync(CancellationToken token)
    {
        var clientId = data?.ClientId ?? throw new InvalidOperationException("Önce Google bağlantı JSON dosyasını seç.");
        var clientSecret = data.ClientSecret;
        await gate.WaitAsync(token);
        try {
            var verifier = Base64Url(RandomNumberGenerator.GetBytes(64));
            var state = Base64Url(RandomNumberGenerator.GetBytes(32));
            var challenge = Base64Url(SHA256.HashData(Encoding.ASCII.GetBytes(verifier)));
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token); timeout.CancelAfter(TimeSpan.FromMinutes(3));
            using var listener = new TcpListener(IPAddress.Loopback, 0);
            listener.Start();
            var redirectUri = $"http://127.0.0.1:{((IPEndPoint)listener.LocalEndpoint).Port}/callback";
            var url = "https://accounts.google.com/o/oauth2/v2/auth?" + Query(new Dictionary<string, string> {
                ["client_id"] = clientId.Trim(), ["response_type"] = "code", ["redirect_uri"] = redirectUri,
                ["scope"] = Scope, ["state"] = state,
                ["access_type"] = "offline", ["prompt"] = "consent", ["code_challenge_method"] = "S256", ["code_challenge"] = challenge });
            Progress?.Invoke("Tarayıcıda Google izni bekleniyor. Hesabını seçip izin ekranını tamamla.");
            openBrowser(url);
            string? code = null;
            while (code is null) {
                using var socket = await listener.AcceptTcpClientAsync(timeout.Token);
                using var stream = socket.GetStream();
                var buffer = new byte[8192]; var length = 0;
                using var readTimeout = CancellationTokenSource.CreateLinkedTokenSource(timeout.Token); readTimeout.CancelAfter(TimeSpan.FromSeconds(5));
                try { while (length < buffer.Length) {
                    var count = await stream.ReadAsync(buffer.AsMemory(length), readTimeout.Token);
                    if (count == 0) break;
                    length += count;
                    if (Encoding.ASCII.GetString(buffer, 0, length).Contains("\r\n\r\n")) break;
                } } catch (OperationCanceledException) when (!timeout.IsCancellationRequested) { continue; }
                if (length == 0) continue;
                var first = Encoding.ASCII.GetString(buffer, 0, length).Split("\r\n")[0].Split(' ');
                var valid = first.Length == 3 && first[0] == "GET" && Uri.TryCreate("http://127.0.0.1" + first[1], UriKind.Absolute, out var ignored);
                var callback = valid ? new Uri("http://127.0.0.1" + first[1]) : null;
                var args = callback is null ? new Dictionary<string, string>() : ParseQuery(callback.Query);
                var matched = callback?.AbsolutePath == "/callback" && args.GetValueOrDefault("state") == state;
                var html = matched ? args.ContainsKey("error") ? "Google izni verilmedi. Asistana donup yeniden baglanabilirsin." : "Google izni asistana iletildi. Baglantinin sonucunu asistan penceresinden kontrol et." : "Gecersiz istek.";
                var body = Encoding.UTF8.GetBytes(html);
                await stream.WriteAsync(Encoding.ASCII.GetBytes($"HTTP/1.1 {(matched ? "200 OK" : "400 Bad Request")}\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: {body.Length}\r\nConnection: close\r\n\r\n"), timeout.Token);
                await stream.WriteAsync(body, timeout.Token);
                if (!matched) continue;
                if (args.ContainsKey("error")) throw new InvalidOperationException("Google Calendar bağlantı izni verilmedi.");
                code = args.GetValueOrDefault("code") ?? throw new InvalidOperationException("Google Calendar bağlantı kodu gelmedi.");
            }
            Progress?.Invoke("Google izni geldi. Hesap bağlantısı tamamlanıyor…");
            var result = await TokenAsync(new() { ["client_id"] = clientId.Trim(), ["client_secret"] = clientSecret, ["grant_type"] = "authorization_code", ["code"] = code, ["redirect_uri"] = redirectUri, ["code_verifier"] = verifier }, timeout.Token);
            if (result.Subject == null) throw new InvalidOperationException("Google hesap kimliği gelmedi. Yeniden izin ver.");
            var connected = new AccountData(clientId.Trim(), clientSecret, result.AccessToken, result.RefreshToken ?? throw new InvalidOperationException("Google Calendar yenileme anahtarı gelmedi."), DateTimeOffset.UtcNow.AddSeconds(result.ExpiresIn), result.Subject);
            Save(connected); data = connected;
        } catch (OperationCanceledException) when (!token.IsCancellationRequested) { throw new InvalidOperationException("Google Calendar bağlantısı zaman aşımına uğradı. Yeniden Bağlan'a bas."); }
        finally { gate.Release(); }
    }
    public async Task<string> AccessAsync(CancellationToken token)
    {
        await gate.WaitAsync(token);
        try {
            var current = data;
            if (current is null || !Connected) throw new InvalidOperationException("Hatırlatıcılar bölümündeki Google Calendar düğmesinden hesabını bağla.");
            if (current.ExpiresAt > DateTimeOffset.UtcNow.AddMinutes(1)) return current.AccessToken;
            TokenResult result;
            try { result = await TokenAsync(new() { ["client_id"] = current.ClientId, ["client_secret"] = current.ClientSecret, ["grant_type"] = "refresh_token", ["refresh_token"] = current.RefreshToken }, token); }
            catch (GrantRevokedException) {
                // Google izni geri aldı: bağlantı kapalı sayılır ki uygulama 5 dakikada bir boşuna denemesin.
                // İstemci bilgileri (JSON) korunur; yeniden bağlanmak tek tıklık iştir.
                var cleared = current with { AccessToken = "", RefreshToken = "", ExpiresAt = DateTimeOffset.MinValue };
                Save(cleared); data = cleared;
                throw new InvalidOperationException("Google bağlantısının süresi doldu. Google ile bağlan’a basıp izni yenile. Bu her hafta oluyorsa Google Cloud’daki uygulaman test modundadır; Audience bölümünden Publish app ile yayına al.");
            }
            var refreshed = current with { AccessToken = result.AccessToken, RefreshToken = result.RefreshToken ?? current.RefreshToken, ExpiresAt = DateTimeOffset.UtcNow.AddSeconds(result.ExpiresIn) };
            Save(refreshed); data = refreshed; return refreshed.AccessToken;
        } finally { gate.Release(); }
    }
    public async Task DisconnectAsync(CancellationToken token)
    {
        await gate.WaitAsync(token);
        try { if (data != null) { var cleared = data with { AccessToken = "", RefreshToken = "", ExpiresAt = DateTimeOffset.MinValue }; Save(cleared); data = cleared; } }
        finally { gate.Release(); }
    }
    private async Task<TokenResult> TokenAsync(Dictionary<string, string> fields, CancellationToken token)
    {
        using var response = await http.PostAsync("https://oauth2.googleapis.com/token", new FormUrlEncodedContent(fields), token);
        if (!response.IsSuccessStatusCode) {
            var code = "";
            try { using var error = JsonDocument.Parse(await response.Content.ReadAsStringAsync(token)); code = error.RootElement.GetProperty("error").GetString() ?? ""; } catch (JsonException) { }
            if (code == "invalid_grant" && fields.GetValueOrDefault("grant_type") == "refresh_token") throw new GrantRevokedException();
            throw new InvalidOperationException(code switch {
                "invalid_client" => "Google istemci bilgileri kabul edilmedi. Doğru projeden Desktop app JSON dosyasını yeniden indirip seç.",
                "invalid_grant" => "Google giriş kodu veya oturum izni geçersizleşti. Google ile bağlan’a tekrar basıp yeni izin ekranını tamamla.",
                "access_denied" => "Google erişim izni verilmedi. Test kullanıcıları listesine giriş yaptığın hesabı ekle.",
                _ => $"Google oturumu tamamlanamadı ({(int)response.StatusCode}). JSON dosyasını ve Google izinlerini kontrol et."
            });
        }
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync(token)); var root = json.RootElement;
        RequireCalendarScope(root);
        string? subject = null;
        // This token comes directly from Google's TLS token endpoint after the
        // PKCE exchange. It is used only to partition local calendar mappings.
        if (root.TryGetProperty("id_token", out var identity)) {
            var encoded = identity.GetString()!.Split('.')[1].Replace('-', '+').Replace('_', '/');
            using var claims = JsonDocument.Parse(Convert.FromBase64String(encoded.PadRight((encoded.Length + 3) / 4 * 4, '=')));
            subject = claims.RootElement.GetProperty("sub").GetString();
        }
        return new(root.GetProperty("access_token").GetString()!, root.TryGetProperty("refresh_token", out var refresh) ? refresh.GetString() : null, root.GetProperty("expires_in").GetInt32(), subject);
    }
    internal static void RequireCalendarScope(JsonElement tokenResponse)
    {
        // OAuth may omit scope when the granted scope is identical to the request.
        if (tokenResponse.TryGetProperty("scope", out var grantedScope) &&
            !(grantedScope.GetString() ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries).Contains("https://www.googleapis.com/auth/calendar.app.created", StringComparer.Ordinal))
            throw new InvalidOperationException("Google takvim izni verilmedi. Google ile bağlan’a tekrar bas; izin ekranında uygulamanın oluşturduğu takvimlere erişim seçeneğini işaretleyip devam et.");
    }
    private void Save(AccountData value)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temporary = path + ".tmp";
        File.WriteAllBytes(temporary, WindowsSecret.Encode(JsonSerializer.SerializeToUtf8Bytes(value)));
        File.Move(temporary, path, true);
    }
    internal static string Base64Url(byte[] bytes) => Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    internal static string Query(Dictionary<string, string> values) => string.Join("&", values.Select(x => Uri.EscapeDataString(x.Key) + "=" + Uri.EscapeDataString(x.Value)));
    internal static Dictionary<string, string> ParseQuery(string text) => text.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries).Select(x => x.Split('=', 2)).GroupBy(x => Uri.UnescapeDataString(x[0])).ToDictionary(x => x.Key, x => Uri.UnescapeDataString(x.Last().ElementAtOrDefault(1) ?? ""));
    public void Dispose() { http.Dispose(); }
    private record AccountData(string ClientId, string ClientSecret, string AccessToken, string RefreshToken, DateTimeOffset ExpiresAt, string Subject = "");
    private record TokenResult(string AccessToken, string? RefreshToken, int ExpiresIn, string? Subject);
    // Yenileme anahtarı Google tarafından geri alındı (test modundaki uygulamalarda 7 günde bir olur).
    private sealed class GrantRevokedException() : InvalidOperationException("Google yenileme anahtarı geçersiz.");
}
