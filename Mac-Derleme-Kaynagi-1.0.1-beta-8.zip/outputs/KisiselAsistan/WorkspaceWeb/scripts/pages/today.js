"use strict";
// Bugün: gecikenler, saatli işler (şimdi çizgisiyle), gün içindeki işler, tamamlananlar ve "Bir ara".
// Büyük görünümde sağda Sıradaki, Müzik (arama dahil), Oyunlar ve Kısayollar kartları durur.
// Bileşen olarak çizilir (Preact + htm); olaylar data-action / data-task-check ile actions.js'te yakalanır.

// ---------------------------------------------------------------- Görev yardımcıları
function taskDone(t) {
  return t.dailyActivity ? (t.completedDays || []).includes(state.day) : t.done;
}
// Tekrarlı görev o gün var mı: başlangıçtan sonra ve haftanın seçili günlerinden biri (repeatDays bit 0 = pazar).
const repeatsOn = (t, key) =>
  key >= (t.startsOn || "0001-01-01") && ((t.repeatDays ?? 127) & (1 << new Date(key + "T12:00:00").getDay())) !== 0;
// "Bir ara": günü ve bitiş tarihi olmayan, acil olmayan tek seferlik görev. Zamanı gelince bugüne alınır.
const isSomeday = (t) => !t.dailyActivity && !t.myDay && !t.due;
const saveSomeday = (title) =>
  rpc("task.save", { task: { title, list: "Görevler", steps: [], dailyActivity: false, myDay: null, due: null, startsOn: today() } });
// Yanlışlıkla tamamlanan "bir ara" işini geri getirir: bu oturumda tamamlananlardan en sonuncusu.
// Hâlâ tamamlanmış ve tarihsiz olanlar sayılır; silinen ya da tarih alan düşer.
// Tamamlanma henüz veriye yansımadıysa (tıklama ile yenileme arasında çizim) kayıt listede kalır, yalnız gösterilmez;
// yoksa "Geri al" hiç görünmeyebilirdi.
function somedayPending() {
  state.somedayDone = state.somedayDone.filter((id) => state.data.tasks.some((t) => t.id === id && isSomeday(t)));
  return state.somedayDone.filter((id) => state.data.tasks.some((t) => t.id === id && t.done));
}
const reminderLabel = (r) => (r.settings?.level === "Adhd" ? "Yapana kadar ısrar" : "");
// Hatırlatmasız plan (ders, iş saati): bildirim vermez, geciken sayılmaz, çubukta sayılmaz; gün boyu zaman akışında kalır.
const isSilent = (r) => r.settings?.level === "Silent";


// ---------------------------------------------------------------- Esnek seri (günlük aktiviteler)
// Planlı günlerden geriye sayılır; 7 gün içinde bir kez kaçırmak seriyi bozmaz (DEHB için baskısız).
// Bugün henüz yapılmadıysa seri dünden sayılır, gün bitmeden "bozuldu" denmez.
const dayGap = (a, b) => Math.round((new Date(a + "T12:00:00") - new Date(b + "T12:00:00")) / 86400000);
function streakOf(t, key = today()) {
  if (!t.dailyActivity) return 0;
  const done = new Set(t.completedDays || []),
    misses = [];
  let count = 0,
    day = done.has(key) ? key : addDays(key, -1);
  for (let i = 0; i < 400 && day >= (t.startsOn || "0001-01-01"); i++, day = addDays(day, -1)) {
    if (!repeatsOn(t, day)) continue;
    if (done.has(day)) count++;
    else if (misses.some((m) => dayGap(m, day) < 7)) break;
    else misses.push(day);
  }
  return count;
}
// Son 4 haftanın ısı haritası (pazartesiden başlayan 4 satır): yapıldı · kaçtı · planlı değil · gelecek.
function StreakMap({ task }) {
  const key = today(),
    done = new Set(task.completedDays || []);
  const monday = addDays(key, -((new Date(key + "T12:00:00").getDay() + 6) % 7) - 21);
  const days = Array.from({ length: 28 }, (_, i) => addDays(monday, i));
  const cls = (d) => (d > key ? "future" : !repeatsOn(task, d) || d < (task.startsOn || "") ? "off" : done.has(d) ? "done" : d === key ? "today" : "missed");
  const streak = streakOf(task);
  return html`<div class="streak-map"><div class="streak-head"><strong>${streak > 0 ? `${streak} günlük seri` : "Seri yok"}</strong><small class="muted">Son 4 hafta · 7 günde bir kaçırmak seriyi bozmaz</small></div>
    <div class="streak-grid">${days.map((d) => html`<span key=${d} class=${"streak-cell " + cls(d)} title=${new Date(d + "T12:00:00").toLocaleDateString("tr-TR", { day: "numeric", month: "long", weekday: "short" })}></span>`)}</div></div>`;
}
// ---------------------------------------------------------------- Hızlı ekleme
// Metni C# tarafındaki tek tarih/saat ayrıştırıcısı çözer: saat varsa hatırlatıcı, yoksa göreve.
// "yarın 9'da diş hekimi", "17:30 annemi ara", "cuma akşam 7 toplantı", "bi ara dolabı düzenle".
// Dönen: { kind: "reminder" | "task" | "someday", text, due, day }
const parseQuick = (input) => rpc("quick.parse", { text: String(input || "") });
const quickLabel = (q) =>
  q.kind === "someday"
    ? "Bir ara · tarihsiz görev"
    : q.kind === "reminder" ? `Hatırlatıcı · ${relativeDay(q.due)} ${clock(q.due)}` : q.day === today() ? "Bugüne görev" : `Görev · ${relativeDay(q.day + "T12:00:00")}`;
async function saveQuick(q, quiet = false) {
  if (!q.text) throw new Error("Ne ekleneceğini yaz.");
  if (q.kind === "reminder") {
    const d = state.data.defaults;
    await rpc("reminder.save", {
      id: null,
      text: q.text,
      due: q.due,
      options: { level: d.level, count: d.count, intervalMinutes: d.intervalMinutes },
      plan: { certainty: "Fixed", durationMinutes: 30, priority: 2, category: "Personal" },
    });
  } else if (q.kind === "someday") await saveSomeday(q.text);
  else await rpc("task.save", { task: { title: q.text, list: "Görevler", steps: [], dailyActivity: false, myDay: q.day, startsOn: q.day } });
  if (!quiet) toast(quickLabel(q) + " eklendi.");
}

// "45 dk", "1 sa 30 dk"
const durationText = (m) => (m >= 60 ? `${Math.floor(m / 60)} sa${m % 60 ? " " + (m % 60) + " dk" : ""}` : m + " dk");
// "48 dk", "2 sa 10 dk", "yarın 09:00"
function countdown(due) {
  const minutes = Math.max(0, Math.round((new Date(due) - new Date()) / 60000));
  if (minutes < 60) return `${minutes} dk`;
  if (minutes < 24 * 60) return `${Math.floor(minutes / 60)} sa${minutes % 60 ? ` ${minutes % 60} dk` : ""}`;
  return `${relativeDay(due)} ${clock(due)}`;
}
function lateness(due) {
  const minutes = Math.round((new Date() - new Date(due)) / 60000);
  if (minutes < 60) return `${Math.max(1, minutes)} dk gecikti`;
  if (minutes < 24 * 60) return `${Math.floor(minutes / 60)} saat gecikti`;
  return `${relativeDay(due)} kaldı`;
}

// ---------------------------------------------------------------- Satırlar
// Geciken görevin notu (taslaktaki gibi, ajanlar 3 Kasım 2026): "dünden kaldı", "3 gündür bekliyor".
function leftOver(t) {
  const days = dayGap(today(), [t.due, t.myDay].filter(Boolean).sort()[0] || today());
  return days <= 1 ? "dünden kaldı" : `${days} gündür bekliyor`;
}
const PrioMark = ({ r }) =>
  r.plan?.priority === 3
    ? html`<span class="prio-mark" aria-label="Yüksek öncelik">!</span>`
    : r.plan?.priority === 1 ? html`<span class="prio-mark low" aria-label="Düşük öncelik">↓</span>` : null;

function TaskRow({ t, late = false, cls = "" }) {
  const done = taskDone(t);
  const repeat = t.dailyActivity ? ((t.repeatDays ?? 127) === 127 ? "Her gün" : "Seçili günler") : "";
  const streak = streakOf(t);
  const meta = [repeat, t.list !== "Görevler" ? t.list : "", t.steps?.length ? `${t.steps.filter((s) => s.done).length}/${t.steps.length} adım` : ""].filter(Boolean).join(" · ");
  return html`<div class=${"task-row today-row" + (done ? " is-done" : "") + (late ? " is-overdue" : "") + (cls ? " " + cls : "")} data-row-task=${t.id}>
    <input type="checkbox" data-task-check=${t.id} checked=${done} aria-label=${t.title + " tamamlandı"} />
    <span class=${"cat-dot cat-" + (t.category || "Personal")} title=${categories[t.category] || "Kişisel"}></span>
    <div class="task-copy">
      <strong>${t.title}</strong>
      ${(meta || late || streak > 1) && html`<small>${late && html`<span class="late-note">${leftOver(t)}</span>`}${streak > 1 && html`<span class="streak-badge" title="Esnek seri: 7 günde bir kaçırmak bozmaz">${streak} gün seri</span>`}${meta}</small>`}
    </div>
    ${t.minutes && html`<span class="row-minutes" title="Tahmini süre">${durationText(t.minutes)}</span>`}
    <${Button} action="task-star" icon="star" cls=${"icon-button star" + (t.important ? " is-important" : "")} data-id=${t.id} aria-label="Önem işaretini değiştir" />
    <${Button} action="task-menu" icon="more" cls="icon-button row-more" data-id=${t.id} aria-label="Görev işlemleri" />
  </div>`;
}
// Zaman akışında her plan kategorisinin renginde, simgeli bir kabarcıkla durur (Tiimo / Structured gibi);
// kabarcık planın süresiyle uzar (30 dk = tek satır, en fazla ~3 satır).
const CATEGORY_ICON = { Personal: "user", Work: "briefcase", School: "book", Health: "heart", FreeTime: "coffee" };
const Bubble = ({ r }) => {
  const minutes = r.plan?.durationMinutes || 30;
  return html`<span class="bubble" aria-hidden="true" style=${{ "--len": Math.min(3, Math.max(1, minutes / 45)).toFixed(2) }}><${Icon} n=${CATEGORY_ICON[r.plan?.category] || "user"} /></span>`;
};
function ReminderRow({ r, late = false, next = false, flow = false }) {
  const meta = [r.plan?.weekly ? "Tekrarlı" : "", r.plan?.certainty === "Flexible" ? "Saati kayabilir" : "", flow && r.plan?.durationMinutes ? durationText(r.plan.durationMinutes) : "", next ? countdown(r.due) + " sonra" : ""].filter(Boolean).join(" · ");
  const silent = isSilent(r),
    past = silent && new Date(r.due) < new Date();
  return html`<div class=${`task-row today-row ${planClass(r)}` + (r.done ? " is-done" : "") + (late ? " is-overdue" : "") + (next ? " is-next" : "") + (silent ? " is-silent" : "") + (past ? " is-past" : "") + (flow ? " is-flow" : "")} data-row-reminder=${r.id} title=${planTitle(r)}>
    ${flow && html`<${Bubble} r=${r} />`}
    ${silent
      ? html`<span class="event-mark" title="Hatırlatmasız plan"><${Icon} n="calendar" /></span>`
      : html`<input type="checkbox" data-reminder-check=${r.id} checked=${r.done} disabled=${r.done} aria-label=${r.text + " tamamlandı"} />`}
    <span class="time"><${PrioMark} r=${r} />${clock(r.due)}</span>
    <div class="task-copy">
      <strong>${r.text}</strong>
      ${(meta || late || reminderLabel(r)) && html`<small>${late && html`<${Chip} tone="danger">${lateness(r.due)}<//>`}${reminderLabel(r) && html`<${Chip} tone="accent">${reminderLabel(r)}<//>`}${meta}</small>`}
    </div>
    <${Button} action="reminder-menu" icon="more" cls="icon-button row-more" data-id=${r.id} aria-label="Hatırlatıcı işlemleri" />
  </div>`;
}
const Head = ({ icon, title, count, children }) =>
  html`<h2 class="today-head"><${Icon} n=${icon} /><span>${title}</span>${count ? html`<span class="badge">${count}</span>` : null}${children}</h2>`;
// Küçük görünümde yalnız simgesi görünür; adı ipucu (title) olarak kalır.
const HeadButton = ({ action, icon, children, ...rest }) => html`<${Button} action=${action} icon=${icon} cls="text-button head-add" title=${typeof children === "string" ? children : undefined} ...${rest}>${children}<//>`;

// ---------------------------------------------------------------- Ana ekran
// Kullanıcı (2 Kasım 2026): "ana ekran hissi yok", "her şey ekranda görünsün, sayfa uzamasın", "saatsiz işler göz önünde olsun:
// boş bir anında bakınca 'şu işim vardı, hazır halledeyim' diyebilmeli". Taslak work/taslak/ana-ekran-taslak.html,
// dört ajanlı değerlendirme docs/degerlendirme/2026-11-02-arayuz/RAPOR.md.
// - Ortada asistan kutusu: komut şeridinin kendisi (core.js placeCommandBar buraya taşır), altında örnek çipler / önizleme.
// - Tek Şimdi kartı: odak sürüyorsa odak, sıradaki iş yakınsa o, uzun boşluk varsa bir saatsiz iş önerisi; altında saatlilerin
//   tek satır şeridi (saatli işin bildirimi ve kartı zaten var, listede ikinci kez yer kaplamaz).
// - Ana liste "Boş bir anında": bugünün saatsiz işleri, kullanıcının sürükleme sırasıyla. Sayfa kaydırılmaz; sığmayanlar
//   "ve N iş daha" olur, en az 3 iş hep görünür (gerekirse örnek çipler çekilir). Gecikenler üstte, kırmızı.
// Sığdırma: önce hepsi çizilir, useLayoutEffect satır boylarını ölçer (boyamadan önce), homeFit kaç satır sığacağını söyler,
// liste slice ile kesilir. DOM elle gizlenmez. Pencere boyu ya da veri değişince bileşen yeni anahtarla baştan ölçer.

// Saf: satır boyları ve boş alan → kaç satır görünür, "Bir ara" önerisi sığar mı. Sığmayan varsa "ve N iş daha" satırı (moreH) için yer ayrılır.
function homeFit(heights, available, { min = 3, moreH = 30, hintH = 0 } = {}) {
  const count = (room) => {
    let used = 0, n = 0;
    for (const h of heights) {
      if (used + h > room + 0.5) break;
      used += h;
      n++;
    }
    return { n, used };
  };
  let { n, used } = count(available);
  if (n < heights.length) ({ n, used } = count(available - moreH));
  const shown = Math.max(n, Math.min(min, heights.length));
  return { shown, fits: n, hint: shown === heights.length && hintH > 0 && used + hintH <= available + 0.5 };
}
// Pencere boyunu izler; değişince ana ekran bileşenlerinin anahtarı değişir ve baştan ölçülür.
function useHomeSize(ref) {
  const [size, setSize] = htmPreact.useState("");
  htmPreact.useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      const next = Math.round(el.clientWidth) + "x" + Math.round(el.clientHeight);
      setSize((old) => (old === next ? old : next));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return size;
}

// Asistan kutusunun altı: boşken örnek çipler (dokununca kutuya yazılır), yazarken Enter'a basınca ne olacağı.
const ASK_EXAMPLES = ["yarın 9'da diş hekimi", "market alışverişi", "lo-fi çal", "bir ara kitap al"];
function AskHints({ tight }) {
  if (tight && !state.askText) return null;
  return html`<div class="ask-preview" aria-live="polite">${state.askText
    ? html`<span><b>Enter</b> · ${state.askHint || "asistana gönderilir"}</span>`
    : ASK_EXAMPLES.map((x) => html`<button type="button" key=${x} class="ask-chip" data-action="example" data-example=${x}>${x}</button>`)}</div>`;
}

// Saatlilerin şeridi: tek satır; sığmayanlar "+N" olur (ölçüm boyamadan önce).
function TimeStrip({ items }) {
  const ref = htmPreact.useRef(null);
  const [hidden, setHidden] = htmPreact.useState(0);
  htmPreact.useLayoutEffect(() => {
    const chips = [...(ref.current?.children || [])];
    const top = chips[0]?.offsetTop ?? 0;
    const n = chips.filter((c) => c.offsetTop > top + 2).length;
    if (n !== hidden) setHidden(n);
  });
  if (!items.length) return null;
  return html`<div class="time-strip"><span class="strip-label">Sonra</span>
    <div class="strip-chips" ref=${ref}>${items.map((r) => html`<button type="button" key=${r.id} class=${"time-chip" + (isSilent(r) ? " is-silent" : "")} data-action="reminder-menu" data-id=${r.id} title=${r.text}><b>${clock(r.due)}</b><span>${r.text}</span></button>`)}</div>
    ${hidden > 0 && html`<span class="strip-more">+${hidden}</span>`}</div>`;
}

// Tek Şimdi kartı. Odak düğmeleri (focus-start/stop/skip) eski Odak widget'ıyla aynı işlemlerdir.
function NowCard({ next, free, gap, open, strip }) {
  const f = focusOf(),
    running = f.phase !== "Idle";
  // Kartın sağındaki büyük sayı her durumda canlıdır (odak süresi, sıradaki saat, boşluk ya da şimdiki saat).
  useSecondTick(true);
  let body;
  if (running) {
    const clash = next && dayKey(new Date(next.due)) === today() && new Date(next.due) < new Date(f.endsAt);
    body = html`<div class="now-copy"><small class="now-label">${FOCUS_LABEL[f.phase]} · ${f.round}. tur</small><strong class="now-title">${f.task || (f.phase === "Work" ? "Odaktasın" : "Mola")}</strong>
        <span class="now-meta">kaldı${f.todayCount ? ` · bugün ${f.todayCount} tur` : ""}</span></div>
      <div class="now-side"><div class="focus-time now-count" role="timer">${focusLeft(f)}</div>
        <div class="now-actions">${f.phase !== "Work" && html`<${Button} action="focus-skip" icon="play" cls="ghost">Molayı geç<//>`}<${Button} action="focus-stop" icon="stop" cls="ghost">Bitir<//></div></div>
      ${clash && html`<div class="now-next"><${Icon} n="clock" /><span>Sırada <b>${clock(next.due)} ${next.text}</b> · ${countdown(next.due)}</span>${clash && html`<span class="now-warn">odak bitmeden başlıyor</span>`}</div>`}`;
  } else if (free && open.length) {
    const pick = open[(state.suggestAt || 0) % open.length];
    // Büyük sayı şimdiki saat değil (üst çubukta var), sıradaki saatli iştir; bugün yoksa sayı da yok (ajanlar, 3 Kasım 2026).
    const later = next && dayKey(new Date(next.due)) === today();
    // Süresi bilinmeyen öneride süre sorulur; cevap işe yazılır, sonraki önerilerde kısa ve sığan iş öne çıkar.
    body = html`<div class="now-copy"><small class="now-label">${gap ? `${durationText(gap)} boşluğun var` : "Boş vaktin var"}</small><strong class="now-title">${pick.title}?</strong>
        <span class="now-meta"><span class=${"now-dot cat-" + (pick.category || "Personal")}></span>${pick.minutes ? `~${durationText(pick.minutes)} · ` : ""}${later ? `Sırada ${next.text} · ${countdown(next.due)} sonra` : "Bugün başka saatli iş yok"}</span>
        ${!pick.minutes && html`<span class="now-estimate">Ne kadar sürer?${[5, 15, 30].map((m) => html`<button type="button" class="estimate-chip" data-action="task-estimate" data-id=${pick.id} data-minutes=${m}>${m} dk</button>`)}</span>`}</div>
      <div class="now-side">${later && html`<div class="now-count">${clock(next.due)}<small>sırada</small></div>`}
        <div class="now-actions">${open.length > 1 && html`<${Button} action="now-other" cls="ghost">Başka<//>`}<${Button} action="focus-start" icon="play" cls="primary" data-task=${pick.title}>Başla<//></div></div>`;
  } else if (next) {
    const minutes = next.plan?.durationMinutes;
    body = html`<div class="now-copy"><small class="now-label">Sırada · ${countdown(next.due)} sonra</small><strong class="now-title">${next.text}</strong>
        <span class="now-meta"><span class=${"now-dot " + planClass(next)}></span>${relativeDay(next.due)} ${clock(next.due)}${minutes ? " – " + clock(new Date(new Date(next.due).getTime() + minutes * 60000)) : ""}${reminderLabel(next) ? " · " + reminderLabel(next) : ""}</span></div>
      <div class="now-side"><div class="now-count">${clock(next.due)}</div>
        <div class="now-actions"><${Button} action="reminder-menu" cls="ghost" data-id=${next.id}>Ertele…<//><${Button} action="focus-start" icon="play" cls="primary">Odaklan<//></div></div>`;
  } else {
    body = html`<div class="now-copy"><small class="now-label">Şimdi</small><strong class="now-title">Sakin bir gün</strong><span class="now-meta">Sırada saatli iş yok.</span></div>
      <div class="now-side"><div class="now-actions"><${Button} action="focus-start" icon="play" cls="primary">Odaklan<//></div></div>`;
  }
  return html`<section class=${"now-card focus-card" + (running ? " is-" + f.phase.toLowerCase() : free ? " is-free" : "")}>${body}<${TimeStrip} items=${strip} /></section>`;
}

// "Boş bir anında": sığdığı kadar satır; açılınca (state.freeExpanded) hepsi, bitenler ve Bir ara listesi kendi içinde kayar.
function FreeList({ open, finished, doneReminders, someday, suggestId, onTight }) {
  const box = htmPreact.useRef(null);
  const [fit, setFit] = htmPreact.useState(null);
  const expanded = !!state.freeExpanded;
  const hintTask = someday[0];
  htmPreact.useLayoutEffect(() => {
    if (fit || expanded || !box.current) return;
    const rows = [...box.current.querySelectorAll(":scope > .task-row, :scope > .today-empty")];
    const hint = box.current.querySelector(":scope > .someday-hint");
    const result = homeFit(rows.map((r) => r.offsetHeight), box.current.clientHeight, { hintH: hint?.offsetHeight || 0 });
    // Sığan satır en az 3 değilse önce örnek çipler çekilir (onTight); yine sığmazsa liste kendi içinde kayar, satır kırpılmaz.
    if (result.fits < result.shown) onTight?.();
    setFit(result);
  });
  // Kartta önerilen iş listede ikinci kez yer kaplamaz; liste açılınca (ya da öneri bitince) yerine döner.
  const rows = expanded ? open : open.filter((t) => t.id !== suggestId);
  const shown = expanded || !fit ? rows : rows.slice(0, fit.shown);
  const hidden = rows.length - shown.length;
  const undo = somedayPending();
  const lastUndone = undo.length ? state.data.tasks.find((t) => t.id === undo[undo.length - 1]) : null;
  return html`<div class=${"free-rows today-rows" + (expanded ? " is-expanded" : "") + (fit && fit.fits < fit.shown ? " is-tight" : "")} ref=${box} data-sortable>
      ${shown.map((t) => html`<${TaskRow} key=${t.id} t=${t} cls=${t.id === suggestId ? "is-suggested" : ""} />`)}
      ${!open.length && html`<div class="today-empty">Bugün için bekleyen iş yok. Aklına geleni yukarıdaki kutuya yaz.</div>`}
      ${!expanded && hintTask && (!fit || fit.hint) && html`<div class="someday-hint"><span>Bir ara listesinden:</span><strong>${hintTask.title}</strong><${Button} action="task-move" cls="text-button" data-id=${hintTask.id} data-to="today">Bugüne al<//></div>`}
      ${expanded && finished.length + doneReminders.length > 0 && html`<details class="completed today-done" open=${state.completed} onToggle=${(e) => (state.completed = e.target.open)}>
        <summary>Tamamlananlar <span class="badge">${finished.length + doneReminders.length}</span></summary>
        <div class="today-rows">${doneReminders.map((r) => html`<${ReminderRow} key=${r.id} r=${r} />`)}${finished.map((t) => html`<${TaskRow} key=${t.id} t=${t} />`)}</div>
      </details>`}
      ${expanded && html`<details class="today-section today-someday someday" open=${state.somedayOpen !== false} onToggle=${(e) => (state.somedayOpen = e.target.open)}>
        <summary class="today-head"><${Icon} n="right" /><span>Bir ara</span>${someday.length ? html`<span class="badge">${someday.length}</span>` : null}<small class="head-note">tarihi yok, acil değil</small></summary>
        <div class="today-rows" data-sortable>${someday.map((t) => html`<${TaskRow} key=${t.id} t=${t} />`)}</div>
        ${lastUndone && html`<div class="someday-undo"><${Button} action="someday-undo" icon="undo" cls="ghost">Geri al: <span class="someday-undo-title">${lastUndone.title}</span>${undo.length > 1 && html` <span class="muted">(+${undo.length - 1})</span>`}<//></div>`}
        <form id="someday-task" class="task-entry"><${Icon} n="plus" /><input name="title" maxlength="500" autocomplete="off" placeholder="Bir ara yapılacak…" aria-label="Bir ara yapılacak görev" /><button class="ghost">Ekle</button></form>
      </details>`}
    </div>
    ${(hidden > 0 || expanded) && html`<${Button} action="free-expand" icon=${expanded ? "up" : "right"} cls="text-button free-more">${expanded ? "Daha az göster" : `ve ${hidden} iş daha`}<//>`}`;
}

function TodayPage() {
  state.day = today();
  const key = state.day,
    now = new Date();
  const ref = htmPreact.useRef(null);
  const size = useHomeSize(ref);
  const [tight, setTight] = htmPreact.useState("");
  const reminders = state.data.reminders;
  const lateReminders = reminders.filter((r) => !r.done && !isSilent(r) && new Date(r.due) < now).sort((a, b) => new Date(a.due) - new Date(b.due));
  const lateTasks = state.data.tasks.filter((t) => taskLate(t, key));
  const late = [...lateReminders.map((r) => ({ r })), ...lateTasks.map((t) => ({ t }))];
  // Saatliler: bugünün henüz gelmemiş planları (hatırlatmasız dersler dahil) şeritte; ilki kartta.
  const timed = reminders.filter((r) => dayKey(new Date(r.due)) === key && !r.done && new Date(r.due) >= now).sort((a, b) => new Date(a.due) - new Date(b.due));
  const next = reminders.filter((r) => !r.done && !isSilent(r) && new Date(r.due) > now).sort((a, b) => new Date(a.due) - new Date(b.due))[0];
  const dayTasks = state.data.tasks.filter((t) => !lateTasks.includes(t) && (t.dailyActivity ? repeatsOn(t, key) : t.myDay === key || t.due === key));
  const open = dayTasks.filter((t) => !taskDone(t)),
    finished = dayTasks.filter(taskDone);
  // Ana ekranda az önce tamamlanan iş yerinde (üstü çizili) kalır, yanlışlıkla işaretlendiyse geri alınır;
  // başka bölüme geçince listeden düşer (core.js render state.freeKeep'i sıfırlar), "N iş bitti" içinde görünür.
  const keep = (state.freeKeep ||= new Set());
  for (const t of finished) if ((state.freeOpen || []).includes(t.id)) keep.add(t.id);
  const listed = dayTasks.filter((t) => !taskDone(t) || keep.has(t.id));
  state.freeOpen = open.map((t) => t.id);
  const doneReminders = reminders.filter((r) => dayKey(new Date(r.due)) === key && !isSilent(r) && r.done);
  const someday = state.data.tasks.filter((t) => isSomeday(t) && !t.done);
  // Boş vakit: sıradaki saatli iş 45 dakikadan uzaksa (ya da bugün yoksa) kart bir saatsiz iş önerir.
  const gapMinutes = next && dayKey(new Date(next.due)) === key ? Math.round((new Date(next.due) - now) / 60000) : 0;
  const free = open.length > 0 && (!gapMinutes || gapMinutes > 45);
  // Öneri sırası: boşluğa sığan süreli işler kısadan uzuna, sonra süresizler, en son sığmayanlar; eşitlerde liste sırası.
  // Liste kendisi bu sırayla dizilmez (kullanıcının sırası kalır), yalnız kartın önerisi.
  const fitRank = (t) => (!t.minutes ? 10000 : gapMinutes && t.minutes > gapMinutes ? 20000 + t.minutes : t.minutes);
  const suggestions = [...open].sort((a, b) => fitRank(a) - fitRank(b));
  const suggestId = free && focusOf().phase === "Idle" ? suggestions[(state.suggestAt || 0) % suggestions.length]?.id : null;
  // Sıradaki modunda kartın kendisi sıradaki iştir, şeritte tekrar etmez. Odakta sıradaki iş şeridin ilk çipidir.
  const strip = timed.filter((r) => free || focusOf().phase !== "Idle" || r !== next);
  const doneCount = finished.length + doneReminders.length;
  const hour = now.getHours();
  const greeting = hour < 5 ? "İyi geceler" : hour < 12 ? "Günaydın" : hour < 18 ? "İyi günler" : "İyi akşamlar";
  const expanded = !!state.freeExpanded;
  const dataKey = [size, tight, expanded, listed.map((t) => t.id).join(","), late.length, strip.length, someday.length ? 1 : 0, state.askText ? 1 : 0, focusOf().phase, suggestId].join("|");

  const main = html`<div class=${"today-main home-main" + (expanded ? " is-expanded" : "")} ref=${ref}>
    <div class="home-greet"><small>${now.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" })}</small><h1>${greeting}</h1></div>
    <div id="ask-slot" class="ask-slot"></div>
    ${!expanded && html`<${AskHints} tight=${tight === size} />`}
    ${!expanded && html`<${NowCard} next=${next} free=${free} gap=${gapMinutes} open=${suggestions} strip=${strip} />`}
    <section class="today-free">
      <h2 class="today-head free-head"><span>Boş bir anında</span>${doneCount > 0 && html`<button type="button" class="done-pill" data-action="free-done" title="Bitenleri göster">${doneCount} iş bitti ✓</button>`}
        ${late.length > 0 && html`<${Button} action="late-menu" icon="calendar" cls="text-button late-move" aria-label="Gecikenleri toplu taşı" title="Gecikenleri bugüne ya da yarına taşı">Gecikenleri taşı<//>`}
        <${Button} action="day-menu" icon="more" cls="icon-button" aria-label="Bugün için işlemler" title="Bugün için işlemler" /></h2>
      ${late.length > 0 && html`<div class="today-late">
        <div class="today-rows">${late.slice(0, expanded ? late.length : 2).map((x) => (x.r ? html`<${ReminderRow} key=${x.r.id} r=${x.r} late />` : html`<${TaskRow} key=${x.t.id} t=${x.t} late />`))}</div>
        ${!expanded && late.length > 2 && html`<${Button} action="free-expand" cls="text-button free-more">+${late.length - 2} geciken daha<//>`}
      </div>`}
      <${FreeList} key=${dataKey} open=${listed} finished=${finished.filter((t) => !keep.has(t.id))} doneReminders=${doneReminders} someday=${someday} suggestId=${suggestId} onTight=${() => setTight(size)} />
    </section>
    ${compact() && html`<${NowStrip} />`}
  </div>`;
  return compact() ? html`<div class="home is-compact">${main}</div>` : html`<div class="today-layout home">${main}<aside class="today-side" aria-label="Özet"><${TodaySide} /></aside></div>`;
}

// ---------------------------------------------------------------- Widget'lar (sağ sütun)
// Müzik, Oyunlar, Stok, Kısayollar ayrı widget'lardır. Sıradaki ve odak sayacı ana ekranın Şimdi kartına geçti
// (2 Kasım 2026); Odak widget'ı yalnız haftalık odak geçmişi için kalır, varsayılan kapalıdır (eski kayıtta da bir kez kapatılır).
// "Düzenle" ile kaldırılır (−), "Widget ekle" ile geri konur, sürükleyerek sıralanır. Tercih bu bilgisayarda
// (localStorage "today-widgets") saklanır; okunamazsa hepsi varsayılan sırayla görünür.
const WIDGETS = {
  music: { title: "Müzik", icon: "music", color: "var(--w-music)" },
  games: { title: "Oyunlar", icon: "game", color: "var(--w-games)", page: "steam" },
  stock: { title: "Stok", icon: "box", color: "var(--w-stock)", page: "stock" },
  shortcuts: { title: "Kısayollar", icon: "shortcut", color: "var(--w-shortcuts)", page: "shortcuts" },
  focus: { title: "Odak geçmişi", icon: "check", color: "var(--accent)" },
};
function widgetPrefs() {
  let saved = null;
  try {
    saved = JSON.parse(localStorage.getItem("today-widgets") || "null");
  } catch {}
  const known = Object.keys(WIDGETS);
  const order = Array.isArray(saved?.order) ? saved.order.filter((id) => known.includes(id)) : [];
  const hidden = Array.isArray(saved?.hidden) ? saved.hidden.filter((id) => known.includes(id)) : [];
  if (saved?.v !== 2 && !hidden.includes("focus")) hidden.push("focus");
  return { order: [...order, ...known.filter((id) => !order.includes(id))], hidden };
}
function saveWidgetPrefs(prefs) {
  try {
    localStorage.setItem("today-widgets", JSON.stringify({ ...prefs, v: 2 }));
  } catch {}
  render();
}
const widgetVisible = (id) => !compact() && state.page === "today" && !widgetPrefs().hidden.includes(id);

const SideHead = ({ title, page, children }) =>
  html`<header class="side-head"><h2>${title}</h2>${children}${page && html`<${Button} action="navigate" icon="right" cls="text-button" data-page=${page}>Aç<//>`}</header>`;
// Widget çerçevesi: başlıkta renkli simge, ad, isteğe bağlı "Aç" ve ek düğmeler; düzenlerken kaldırma düğmesi.
// draggable mantıksal değer olmalı: Preact DOM özelliğine atar ve "false" yazısı tarayıcıda "doğru" sayılır
// (widget'lar düzenleme dışında da sürükleniyor, ses çubuğu tutulunca widget geliyordu).
// bare: başlık yalnız düzenlerken görünür (Müzik).
function Widget({ id, cls = "", elId, actions, bare, children }) {
  const w = WIDGETS[id];
  return html`<section id=${elId} class=${"card side-card widget " + cls} data-widget=${id} style=${{ "--w": w.color }} draggable=${!!state.widgetEdit}>
    ${state.widgetEdit && html`<button type="button" class="widget-remove" data-action="widget-remove" data-widget=${id} aria-label=${w.title + " widget'ını kaldır"} title="Kaldır"><${Icon} n="minus" /></button>`}
    ${(!bare || state.widgetEdit) && html`<header class="side-head"><span class="widget-icon"><${Icon} n=${w.icon} /></span><h2>${w.title}</h2>${actions}${w.page && html`<${Button} action="navigate" icon="right" cls="text-button" data-page=${w.page}>Aç<//>`}</header>`}
    ${children}
  </section>`;
}
const Art = ({ track }) =>
  track?.coverUrl ? html`<img class="art" src=${spotifyCover(track.coverUrl)} alt="" />` : html`<span class="art"><${Icon} n="music" /></span>`;
// Spotify sesi: hoparlör düğmesi (basınca sessize alır, tekrar basınca önceki sese döner), çubuk ve yüzde.
// Müzik widget'ı, alt çubuk ve küçük görünüm aynısını kullanır; olaylar actions.js'te (.spotify-volume, spotify-mute).
function Volume({ cls = "" }) {
  const playing = state.playing;
  if (!playing?.deviceId) return null;
  const value = playing.volume ?? 50,
    muted = value === 0;
  return html`<div class=${"volume " + cls}><button type="button" class="icon-button volume-mute" data-action="spotify-mute" aria-label=${muted ? "Sesi aç" : "Sesi kapat"} title=${muted ? "Sesi aç" : "Sesi kapat"}><${Icon} n=${muted ? "volume-off" : "volume"} /></button><input class="spotify-volume" type="range" min="0" max="100" value=${value} style=${{ "--fill": value + "%" }} aria-label="Spotify ses seviyesi" /><small>${(playing.volume ?? "—") + "%"}</small></div>`;
}
// Şarkının konumu: Spotify 10 sn'de bir sorulur, aradaki saniyeler yerelde ilerletilir (playingPosition, actions.js tickSeek).
// Sürüklerken süre anında değişir; bırakınca Spotify'a gider (spotify.seek). Saniye yazıları Preact'in yazı düğümünde yerinde değişir.
const trackTime = (ms) => {
  const s = Math.max(0, Math.floor((ms || 0) / 1000));
  return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
};
function playingPosition(p = state.playing) {
  if (!p?.duration) return 0;
  return Math.min(p.duration, (p.position || 0) + (p.playing && p.at ? Date.now() - p.at : 0));
}
function Seek({ cls = "" }) {
  const playing = state.playing;
  if (!playing?.duration || !playing.deviceId) return null;
  const at = playingPosition();
  return html`<div class=${"seek " + cls}><small>${trackTime(at)}</small><input class="spotify-seek" type="range" min="0" max=${playing.duration} step="any" value=${at} style=${{ "--fill": ((at / playing.duration) * 100).toFixed(2) + "%" }} aria-label="Şarkının konumu" /><small>${trackTime(playing.duration)}</small></div>`;
}
// Karışık ve tekrar düğmeleri (Spotify'daki gibi önceki/sonrakinin iki yanında). Açıkken vurgu renginde ve altında nokta;
// tekrar düğmesi kapalı → listeyi tekrarla → şarkıyı tekrarla → kapalı diye döner.
const REPEAT_NEXT = { off: "context", context: "track", track: "off" },
  REPEAT_LABEL = { off: "Tekrar kapalı", context: "Liste tekrarlanıyor", track: "Şarkı tekrarlanıyor" };
function ShuffleButton() {
  const on = !!state.playing?.shuffle;
  return html`<${Button} action="spotify-shuffle" icon="shuffle" cls=${"icon-button mode-button" + (on ? " is-on" : "")} aria-pressed=${on} aria-label=${on ? "Karışık çalmayı kapat" : "Karışık çal"} title=${on ? "Karışık çalma açık" : "Karışık çalma kapalı"} />`;
}
function RepeatButton() {
  const mode = state.playing?.repeat || "off";
  return html`<${Button} action="spotify-repeat" icon=${mode === "track" ? "repeat-one" : "repeat"} cls=${"icon-button mode-button" + (mode !== "off" ? " is-on" : "")} aria-pressed=${mode !== "off"} data-mode=${mode} aria-label=${REPEAT_LABEL[mode] + " · değiştir"} title=${REPEAT_LABEL[mode]} />`;
}
// Küçük görünümde çalan şarkı ince bir şerit: önceki, oynat/duraklat, sonraki ve altında ses.
function NowStrip() {
  const playing = state.playing,
    track = playing?.track;
  if (!track) return html`<div id="today-player" hidden></div>`;
  return html`<div id="today-player" class="now-strip"><div class="now-row"><${Art} track=${track} /><div class="item-copy"><strong>${track.name}</strong><small>${track.artist}</small></div>
    <${Button} action="spotify-previous" icon="previous" cls="icon-button" aria-label="Önceki şarkı" />
    <${Button} action="spotify-toggle" icon=${playing.playing ? "pause" : "play"} cls="icon-button" aria-label=${playing.playing ? "Duraklat" : "Oynat"} />
    <${Button} action="spotify-next" icon="next" cls="icon-button" aria-label="Sonraki şarkı" /></div>
    <${Seek} cls="mini" />
    <${Volume} cls="mini" /></div>`;
}
// Alt çubuktaki oynatıcı (Spotify'ın alt çubuğu gibi): Müzik widget'ı ekranda değilse çalan şarkı ve sesi burada görünür.
function BarPlayer() {
  const playing = state.playing,
    track = playing?.track;
  if (!track || compact() || widgetVisible("music")) return null;
  // Alt çubuk tek satır: sanatçı adın yanında, altında ince konum çubuğu.
  return html`<div class="bar-player"><${Art} track=${track} /><div class="item-copy" title=${track.name + " · " + track.artist}><strong>${track.name}<small> · ${track.artist}</small></strong><${Seek} cls="bar" /></div>
    <${ShuffleButton} />
    <${Button} action="spotify-previous" icon="previous" cls="icon-button" aria-label="Önceki şarkı" />
    <${Button} action="spotify-toggle" icon=${playing.playing ? "pause" : "play"} cls="icon-button" aria-label=${playing.playing ? "Duraklat" : "Oynat"} />
    <${Button} action="spotify-next" icon="next" cls="icon-button" aria-label="Sonraki şarkı" />
    <${RepeatButton} />
    <${Volume} cls="bar" /></div>`;
}
// Müzik: yalnız çalan şarkı, önceki / oynat / sonraki ve ses (3 Kasım 2026 sadeleştirildi; arama ve çalma listeleri kalktı).
// Başlıksız ince kart; bir şey çalmıyorsa hiç görünmez (TodaySide), yalnız "Düzenle"deyken yer tutucu olarak durur.
function MusicCard() {
  const playing = state.playing,
    track = playing?.track;
  return html`<${Widget} id="music" elId="today-player" cls="music-card" bare=${!!track}>
    ${track
      ? html`<div class="music-row"><${Art} track=${track} /><div class="item-copy" title=${track.name + " · " + track.artist}><strong>${track.name}</strong><small>${track.artist}</small><${Seek} cls="bar" /></div></div>
        <div class="music-row music-controls">
          <${Button} action="spotify-previous" icon="previous" cls="icon-button" aria-label="Önceki şarkı" />
          <${Button} action="spotify-toggle" icon=${playing.playing ? "pause" : "play"} cls="icon-button" aria-label=${playing.playing ? "Duraklat" : "Oynat"} />
          <${Button} action="spotify-next" icon="next" cls="icon-button" aria-label="Sonraki şarkı" />
          <${Volume} cls="mini" /></div>`
      : html`<p class="side-note">Bir şey çalınca burada görünür.</p>`}
  <//>`;
}
// Oyunlar widget'ı: önce indirimdekiler, sonra çıkışı yaklaşanlar; kapak, kısa durum ve fiyat.
function GamesCard() {
  const games = [...state.data.steam].sort((a, b) => (b.price?.discount || 0) - (a.price?.discount || 0) || watchOrder(a) - watchOrder(b)).slice(0, 3);
  const status = (g) => {
    const days = daysUntil(g);
    if (g.atTarget) return "hedef fiyatında";
    if (g.price?.discount > 0) return atLowest(g) ? "en düşük fiyat" : "indirimde";
    if (days != null) return days === 0 ? "bugün çıkıyor" : `${days} gün sonra çıkıyor`;
    if (g.comingSoon) return g.releaseDate || "bekleniyor";
    return g.latestUpdate ? "büyük güncelleme" : g.earlyAccess ? "erken erişim" : "çıktı";
  };
  // Her oyun iki satır: üstte ad, altta durum; fiyat varsa sağda (kullanıcı 3 Kasım 2026).
  return html`<${Widget} id="games">
    ${games.length
      ? html`<div class="side-list">${games.map((g) => html`<div class="side-game" key=${g.id}><${Cover} game=${g} /><div class="item-copy"><strong>${g.name}</strong><small>${status(g)}</small></div>${g.price && html`<${Price} price=${g.price} />`}</div>`)}</div>`
      : html`<p class="side-note">Takip ettiğin oyun yok.</p>`}
  <//>`;
}
function TodaySide() {
  const prefs = widgetPrefs();
  const routines = state.data.routines.slice(0, 3);
  const cards = {
    focus: () => html`<${FocusCard} />`,
    music: () => html`<${MusicCard} />`,
    games: () => html`<${GamesCard} />`,
    stock: () => html`<${StockWidget} />`,
    shortcuts: () => html`<${Widget} id="shortcuts">
      ${routines.length
        ? html`<div class="side-list">${routines.map((r) => html`<button type="button" key=${r.id} class="side-shortcut" data-action="shortcut-run" data-id=${r.id} title="Başlat"><${Icon} n="play" /><span class="item-copy"><strong>${r.name}</strong><small>${r.steps.length} adım</small></span></button>`)}</div>`
        : html`<${Button} action="shortcut-new" icon="plus" cls="ghost side-wide">Kısayol oluştur<//>`}
    <//>`,
  };
  const shown = prefs.order.filter((id) => !prefs.hidden.includes(id)),
    // Müzik yalnız bir şey çalarken yer kaplar (düzenlerken sıralanabilsin diye durur).
    listed = shown.filter((id) => id !== "music" || state.playing?.track || state.widgetEdit);
  return html`
    <div class="widgets-head"><${Button} action="widgets-edit" cls="text-button">${state.widgetEdit ? "Bitti" : "Düzenle"}<//></div>
    <div class=${"widgets" + (state.widgetEdit ? " is-editing" : "")}>${[0, 1].map((col) => html`<div class="widget-col" key=${col}>${listed.map((id, i) => i % 2 === col && html`<div class="widget-slot" key=${id} style=${{ order: i }}>${cards[id]()}</div>`)}</div>`)}</div>
    ${state.widgetEdit && html`<div class="widget-shelf"><p>Widget ekle</p>${prefs.hidden.length
      ? html`<div class="widget-options">${prefs.hidden.map((id) => html`<button type="button" key=${id} class="widget-option" data-action="widget-add" data-widget=${id} style=${{ "--w": WIDGETS[id].color }}><${Icon} n=${WIDGETS[id].icon} />${WIDGETS[id].title}</button>`)}</div>`
      : html`<small class="muted">Bütün widget'lar ekranda. Kaldırmak için köşedeki − düğmesine bas; sürükleyerek sırala.</small>`}</div>`}
    ${!shown.length && !state.widgetEdit && html`<p class="side-note">Bütün widget'lar kaldırıldı. Geri koymak için "Düzenle"ye bas.</p>`}`;
}
pageComponents.today = TodayPage;

// ---------------------------------------------------------------- Odak (pomodoro)
// Durum C#'ta (Core/Focus/FocusSession.cs) tutulur ve canlı durumla gelir (live.focus); kalan süre burada her saniye hesaplanır.
const FOCUS_LABEL = { Work: "Odak", Break: "Mola", LongBreak: "Uzun mola" };
function useSecondTick(active) {
  const [, set] = htmPreact.useState(0);
  htmPreact.useEffect(() => {
    if (!active) return;
    const t = setInterval(() => set((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, [active]);
}
const focusOf = () => state.data.live?.focus || { phase: "Idle", todayCount: 0, todayMinutes: 0 };
function focusLeft(f) {
  const s = Math.max(0, Math.round((new Date(f.endsAt) - Date.now()) / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
// Odak geçmişi (Forest gibi): son 7 günün odak dakikaları küçük çubuklarla; tur bitince ya da 5 dakikada bir yenilenir.
let focusHistory = { at: 0, days: [], busy: false };
function focusWeek() {
  if (Date.now() - focusHistory.at > 300000 && !focusHistory.busy) {
    focusHistory.busy = true;
    rpc("focus.history", { days: 7 })
      .then((days) => {
        focusHistory = { at: Date.now(), days: days || [], busy: false };
        if (state.page === "today" && !state.modal) render();
      })
      .catch(() => (focusHistory = { at: Date.now(), days: [], busy: false }));
  }
  return focusHistory.days;
}
function FocusWeek() {
  const days = focusWeek();
  const rounds = days.reduce((s, d) => s + d.count, 0),
    minutes = days.reduce((s, d) => s + d.minutes, 0);
  if (!rounds) return null;
  const max = Math.max(...days.map((d) => d.minutes), 1);
  return html`<div class="focus-week" title="Son 7 gün">
    <div class="focus-bars">${days.map((d) => html`<span key=${d.day} class=${d.day === today() ? "is-today" : ""} title=${`${new Date(d.day + "T12:00:00").toLocaleDateString("tr-TR", { weekday: "long" })}: ${d.count} tur · ${d.minutes} dk`}><i style=${{ height: Math.max(d.minutes ? 12 : 4, (d.minutes / max) * 100) + "%" }}></i><small>${new Date(d.day + "T12:00:00").toLocaleDateString("tr-TR", { weekday: "narrow" })}</small></span>`)}</div>
    <small class="side-note">Bu hafta ${rounds} tur · ${durationText(minutes)} odak</small>
  </div>`;
}
function FocusCard() {
  const f = focusOf(),
    running = f.phase !== "Idle";
  useSecondTick(running);
  return html`<${Widget} id="focus" cls=${"focus-card" + (running ? " is-" + f.phase.toLowerCase() : "")}>
    ${running
      ? html`<div class="focus-time" role="timer">${focusLeft(f)}</div>
          <small class="side-note">kaldı · ${FOCUS_LABEL[f.phase]} · ${f.round}. tur${f.task ? " · " + f.task : ""}</small>
          <div class="focus-actions">${f.phase !== "Work" && html`<${Button} action="focus-skip" icon="play" cls="ghost">Molayı geç<//>`}<${Button} action="focus-stop" icon="stop" cls="ghost">Bitir<//></div>`
      : html`<${Button} action="focus-start" icon="play" cls="ghost side-wide">Odaklan<//>`}
    ${f.todayCount > 0 && html`<small class="side-note">Bugün ${f.todayCount} tur · ${f.todayMinutes} dk odak</small>`}
    <${FocusWeek} />
  <//>`;
}
