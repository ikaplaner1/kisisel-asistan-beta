namespace KisiselAsistan;

public record SpeechProgress(string Stage, int Level = 0);
public record SpeechCaptureOptions(int Device = 0, bool AutoFinish = true, double SilenceSeconds = 1.8);
public record SpeechRecognitionOptions(string Language = "tr", IReadOnlyList<string>? Vocabulary = null);
public record SpeechAudio(float[] Samples, int SampleRate = 16000);
public interface ISpeechCapture
{
    // Finishing capture keeps the recorded audio for recognition.
    Task<SpeechAudio> CaptureAsync(SpeechCaptureOptions options, CancellationToken finish, IProgress<SpeechProgress>? progress = null);
}
public interface ISpeechToText
{
    Task WarmUpAsync(CancellationToken cancellationToken = default);
    Task<string> TranscribeAsync(SpeechAudio audio, SpeechRecognitionOptions options, CancellationToken cancellationToken = default);
}
public interface ITextToSpeech
{
    bool Enabled { get; }
    Task SpeakAsync(string text, CancellationToken cancellationToken = default);
}
// Konuşmayı metne çevirir; metnin komuta çevrilmesi CommandParser'dadır.
public sealed class SpeechPipeline(ISpeechCapture capture, ISpeechToText recognition, ITextToSpeech output)
{
    public Task WarmUpAsync(CancellationToken cancellationToken = default) => recognition.WarmUpAsync(cancellationToken);
    public async Task<string> ListenAsync(SpeechCaptureOptions captureOptions, SpeechRecognitionOptions recognitionOptions,
        CancellationToken finish, IProgress<SpeechProgress>? progress = null, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (recognitionOptions.Language is not ("tr" or "en")) throw new ArgumentException("Desteklenmeyen konuşma dili.");
        using var captureStop = CancellationTokenSource.CreateLinkedTokenSource(finish, cancellationToken);
        var audio = await capture.CaptureAsync(captureOptions, captureStop.Token, progress);
        cancellationToken.ThrowIfCancellationRequested();
        if (audio.Samples.Length < audio.SampleRate / 4) return "";
        progress?.Report(new("Konuşma çözümleniyor; ilk kullanım biraz daha uzun sürebilir"));
        return await recognition.TranscribeAsync(audio, recognitionOptions, cancellationToken);
    }
    public Task SpeakAsync(string text, CancellationToken cancellationToken = default)
        => output.Enabled ? output.SpeakAsync(text, cancellationToken) : Task.CompletedTask;
}
// Spoken responses are optional; today's application keeps its existing visual responses.
public sealed class DisabledTextToSpeech : ITextToSpeech
{
    public bool Enabled => false;
    public Task SpeakAsync(string text, CancellationToken cancellationToken = default) => Task.CompletedTask;
}
