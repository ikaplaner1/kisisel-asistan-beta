namespace KisiselAsistan;

// Hatırlatıcı görünümü: saati olan işleri (Item) eski Reminder biçiminde sunar ve hatırlatıcı
// işlemlerini işlere uygular. Tekrarlı bir işin her günü burada ayrı bir Reminder olarak görünür
// (kimliği Item.OccurrenceId), ama dosyada tek kural olarak durur.
// Görünüm: tek seferlik işlerin hepsi; tekrarlarda bugünden FutureDays gün sonrasına kadar olan günler
// ve son PastDays gündeki tamamlanmışlar. Kaçırılan geçmiş tekrarlar birikmez (geciken sayılmaz).
public sealed class ReminderStore
{
    internal const int PastDays = 60, FutureDays = 400;
    private readonly ItemStore store;
    private readonly Func<DateTimeOffset> clock;
    private (long Generation, DateOnly Today) viewKey = (-1, default);
    private List<Reminder> view = [];
    private Dictionary<Guid, (Guid Item, DateOnly Day)> occurrences = [];

    public ReminderStore(string path, bool migrateLegacy = true) : this(new ItemStore(path)) { }
    public ReminderStore(ItemStore store, Func<DateTimeOffset>? clock = null) { this.store = store; this.clock = clock ?? (() => DateTimeOffset.Now); }

    public List<Reminder> Items { get { Refresh(); return [.. view]; } }

    // ---------------------------------------------------------------- Görünüm
    private DateOnly Today => DateOnly.FromDateTime(clock().LocalDateTime);
    private void Refresh()
    {
        var items = store.Read();
        if (viewKey == (store.Generation, Today)) return;
        var today = Today; var list = new List<Reminder>(); var index = new Dictionary<Guid, (Guid, DateOnly)>();
        foreach (var item in items.Where(i => i.Timed)) {
            if (item.Repeat is null) { list.Add(ToReminder(item)); continue; }
            foreach (var day in item.Repeat.Days(today.AddDays(-PastDays), today.AddDays(FutureDays))) {
                var state = item.StateOn(day);
                if (state.Skipped || (day < today && !state.Done && !state.Active)) continue;
                if (ToReminder(item, day) is { } occurrence) { list.Add(occurrence); index[occurrence.Id] = (item.Id, day); }
            }
        }
        view = list; occurrences = index; viewKey = (store.Generation, today);
    }
    private static PlanDetails PlanOf(Item item) => new(item.Flexible ? PlanCertainty.Flexible : PlanCertainty.Fixed, item.DurationMinutes, item.Priority, item.Category, item.RemindDayBefore,
        item.Repeat is { } repeat ? new WeeklyRepeat(repeat.DaysMask, repeat.TimeMinutes ?? -1) { SeriesId = item.SeriesId ?? item.Id } : null);
    private static Reminder ToReminder(Item item)
    {
        var state = item.State ?? new();
        return new(item.Id, item.Title, item.At!.Value, item.Done, item.Notify, state.SentCount, state.NextNotice, item.Revision, state.Pressure, PlanOf(item), state.AdvanceSentForDue);
    }
    private static Reminder? ToReminder(Item item, DateOnly day)
    {
        var state = item.StateOn(day);
        var due = state.MovedTo ?? item.Repeat!.At(day);
        if (due is null) return null;
        // Kural, iş oluşturulmadan önceki bir güne ön bildirim göndermez.
        var advance = state.AdvanceSentForDue ?? (item.Created is { } created && due.Value.AddDays(-1) <= created ? due : null);
        return new(Item.OccurrenceId(item.Id, day), item.Title, due.Value, state.Done, item.Notify, state.SentCount, state.NextNotice, state.Revision, state.Pressure, PlanOf(item), advance);
    }
    // Bir hatırlatıcı kimliğini işe (ve tekrarlıysa güne) çözer.
    // Bir hatırlatıcı ya da tekrar günü kimliğini işin kimliğine ve (tekrarlıysa) gününe çevirir.
    internal (Guid Item, DateOnly? Day)? Locate(Guid id) => Resolve(store.Read(), id) is { } found ? (found.Item.Id, found.Day) : null;
    private (Item Item, DateOnly? Day)? Resolve(List<Item> items, Guid id)
    {
        var single = items.FirstOrDefault(i => i.Id == id && i.Repeat is null && i.Timed);
        if (single != null) return (single, null);
        Refresh();
        if (occurrences.TryGetValue(id, out var found) && items.FirstOrDefault(i => i.Id == found.Item) is { } item) return (item, found.Day);
        return null;
    }
    // Tek seferlik ya da tekrarın gününe göre durumu günceller.
    private static List<Item> Update(List<Item> items, (Item Item, DateOnly? Day) target, Func<Reminder, Item, Item> change)
    {
        var current = target.Day is { } day ? ToReminder(target.Item, day)! : ToReminder(target.Item);
        var next = change(current, target.Item);
        return items.Select(i => i.Id == target.Item.Id ? next : i).ToList();
    }
    private static Item Apply(Item item, DateOnly? day, Reminder updated)
    {
        if (day is not { } d) return item with { At = updated.Due, Day = DateOnly.FromDateTime(updated.Due.LocalDateTime), Done = updated.Done, Revision = updated.Revision,
            State = new(SentCount: updated.SentCount, NextNotice: updated.NextNotice, Pressure: updated.Pressure, AdvanceSentForDue: updated.AdvanceSentForDue) };
        var moved = updated.Due != item.Repeat!.At(d) ? updated.Due : (DateTimeOffset?)null;
        return item.WithState(d, new(updated.Done, MovedTo: moved, SentCount: updated.SentCount, NextNotice: updated.NextNotice, Revision: updated.Revision, Pressure: updated.Pressure, AdvanceSentForDue: updated.AdvanceSentForDue));
    }
    private void Change(Guid id, Func<Reminder, Reminder> change, bool required = true)
    {
        store.Modify(items => {
            var target = Resolve(items, id);
            if (target is null) { if (required) throw new InvalidOperationException("Bu hatırlatıcı artık listede yok."); return items; }
            return Update(items, target.Value, (reminder, item) => Apply(item, target.Value.Day, change(reminder)));
        });
    }

    // ---------------------------------------------------------------- İşlemler
    public void Add(string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null)
    {
        options?.Validate(); plan?.Validate();
        plan ??= new(DurationMinutes: PlanningPreferenceStore.Load().DefaultDuration);
        store.Modify(items => [.. items, NewItem(Guid.NewGuid(), text, due, options, plan, null)]);
    }
    private Item NewItem(Guid id, string text, DateTimeOffset due, ReminderOptions? options, PlanDetails plan, Guid? series)
    {
        var now = clock();
        var item = new Item(id, text, Priority: plan.Priority, Category: plan.Category, DurationMinutes: plan.DurationMinutes, Flexible: plan.Certainty == PlanCertainty.Flexible,
            Notify: options, RemindDayBefore: plan.RemindDayBefore, Created: now);
        if (plan.Weekly is { } weekly) {
            due = due.AddTicks(-(due.Ticks % TimeSpan.TicksPerMinute));
            var local = due.LocalDateTime;
            return item with { Repeat = new(weekly.DaysMask, DateOnly.FromDateTime(local), null, local.Hour * 60 + local.Minute), SeriesId = series ?? id };
        }
        return item with { At = due, Day = DateOnly.FromDateTime(due.LocalDateTime), State = new(AdvanceSentForDue: due.AddDays(-1) <= now ? due : null) };
    }
    public void Complete(Guid id) => Change(id, r => r with { Done = true, NextNotice = null, Revision = r.Revision + 1 }, required: false);
    public void Remove(Guid id) => store.Modify(items => {
        var target = Resolve(items, id);
        if (target is null) return items;
        // Tekrarın bir günü silinirse bütün seri silinir (arayüz "Haftalık seriyi sil" der).
        var series = target.Value.Item.Repeat is null ? (Guid?)null : target.Value.Item.SeriesId ?? target.Value.Item.Id;
        return items.Where(i => i.Id != target.Value.Item.Id && (series == null || (i.SeriesId ?? i.Id) != series || i.Repeat is null)).ToList();
    });
    public void Edit(Guid id, string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null)
    {
        options?.Validate(); plan?.Validate(); if (string.IsNullOrWhiteSpace(text)) throw new ArgumentException("Hatırlatma metni boş olamaz.");
        if (due <= DateTimeOffset.Now) throw new ArgumentException("Gelecekte bir tarih seç.");
        store.Modify(items => {
            var target = Resolve(items, id) ?? throw new InvalidOperationException("Bu hatırlatıcı artık listede yok.");
            var (item, day) = target;
            var original = day is { } d ? ToReminder(item, d)! : ToReminder(item);
            var changedPlan = plan ?? original.Plan ?? new();
            if (day is { } occurrenceDay) {
                // "Bu ve sonraki tekrarlar": seri bu günden itibaren ikiye bölünür; önceki günler (ve geçmiş tamamlanmalar) yerinde kalır.
                var kept = items.Select(i => i.Id == item.Id ? i with { Repeat = i.Repeat! with { Until = occurrenceDay.AddDays(-1) } } : i)
                    .Where(i => i.Id != item.Id || i.Repeat!.Until >= i.Repeat.Start).ToList();
                if (changedPlan.Weekly != null) return [.. kept, NewItem(Guid.NewGuid(), text.Trim(), due, options ?? item.Notify, changedPlan, item.SeriesId ?? item.Id)];
                // Tekrar kapatıldı: seri sona erer, geçmiş tamamlanmalar tek seferlik kayıt olarak kalır.
                var history = kept.Where(i => (i.SeriesId ?? i.Id) == (item.SeriesId ?? item.Id) && i.Repeat != null).SelectMany(i => (i.Occurrences ?? []).Where(o => o.Value.Done)
                    .Select(o => i.Repeat!.At(Item.ParseKey(o.Key)) is { } at ? new Item(Guid.NewGuid(), i.Title, Item.ParseKey(o.Key), at, Priority: i.Priority, Category: i.Category, DurationMinutes: i.DurationMinutes, Flexible: i.Flexible, Notify: i.Notify, Done: true) : null)
                    .OfType<Item>()).ToList();
                kept = kept.Where(i => (i.SeriesId ?? i.Id) != (item.SeriesId ?? item.Id) || i.Repeat is null).ToList();
                return [.. kept, .. history, NewItem(Guid.NewGuid(), text.Trim(), due, options ?? item.Notify, changedPlan, null)];
            }
            if (changedPlan.Weekly != null) return [.. items.Where(i => i.Id != item.Id), NewItem(item.Id, text.Trim(), due, options ?? item.Notify, changedPlan, null)];
            var state = item.State ?? new();
            var edited = item with {
                Title = text.Trim(), At = due, Day = DateOnly.FromDateTime(due.LocalDateTime), Done = false, Notify = options ?? item.Notify,
                Priority = changedPlan.Priority, Category = changedPlan.Category, DurationMinutes = changedPlan.DurationMinutes, Flexible = changedPlan.Certainty == PlanCertainty.Flexible, RemindDayBefore = changedPlan.RemindDayBefore,
                State = new(AdvanceSentForDue: due.AddDays(-1) <= DateTimeOffset.Now ? due : due == item.At ? state.AdvanceSentForDue : null), Revision = item.Revision + 1
            };
            return items.Select(i => i.Id == item.Id ? edited : i).ToList();
        });
    }
    public void Snooze(Guid id, TimeSpan delay)
    {
        if (delay <= TimeSpan.Zero) throw new ArgumentException("Erteleme süresi pozitif olmalı.");
        var rescheduled = DateTimeOffset.Now.Add(delay);
        Change(id, r => r with { Due = rescheduled, AdvanceSentForDue = delay <= TimeSpan.FromDays(1) ? rescheduled : null, Done = false, SentCount = 0, Pressure = 0, NextNotice = null, Revision = r.Revision + 1 });
    }
    public void ReportNotDone(Guid id, DateTimeOffset? now = null)
    {
        var answeredAt = now ?? DateTimeOffset.Now;
        store.Modify(items => {
            var target = Resolve(items, id);
            if (target is null) return items;
            var reminder = target.Value.Day is { } d ? ToReminder(target.Value.Item, d)! : ToReminder(target.Value.Item);
            if (reminder.Done) return items;
            if (reminder.Settings.Level != ReminderIntensity.Adhd) throw new InvalidOperationException("Bu seçenek ADHD modu için geçerli.");
            return Update(items, target.Value, (r, item) => Apply(item, target.Value.Day, r with { NextNotice = answeredAt.AddMinutes(ReminderEscalation.Minutes(r.Settings, r.Pressure + 1)), Revision = r.Revision + 1 }));
        });
    }

    // ---------------------------------------------------------------- Zamanlayıcı
    // Bildirim adayları: tek seferlik saatli işler ve tekrarlarda dün/bugün/yarın ile süren (ertelenmiş, tekrar eden) günler.
    private IEnumerable<(Item Item, DateOnly? Day, Reminder Reminder)> Candidates(List<Item> items, DateTimeOffset now)
    {
        var today = DateOnly.FromDateTime(now.LocalDateTime);
        foreach (var item in items.Where(i => i.Timed)) {
            if (item.Repeat is null) { yield return (item, null, ToReminder(item)); continue; }
            var days = item.Repeat.Days(today.AddDays(-1), today.AddDays(1)).Where(d => d >= today || item.StateOn(d).Active)
                .Concat((item.Occurrences ?? []).Where(o => o.Value.Active).Select(o => Item.ParseKey(o.Key))).Distinct();
            foreach (var day in days) if (!item.StateOn(day).Skipped && ToReminder(item, day) is { } reminder) yield return (item, day, reminder);
        }
    }
    public Reminder? TakeAdvance(DateTimeOffset now)
    {
        static bool Ready(Reminder r, DateTimeOffset now) => !r.Done && r.Plan?.RemindDayBefore == true && r.AdvanceSentForDue != r.Due && r.Due.AddDays(-1) <= now && now < r.Due;
        if (!Candidates(store.Read(), now).Any(c => Ready(c.Reminder, now))) return null;
        Reminder? result = null;
        store.Modify(items => {
            var candidate = Candidates(items, now).Where(c => Ready(c.Reminder, now)).OrderBy(c => c.Reminder.Due).FirstOrDefault();
            if (candidate.Item is null) return items;
            result = candidate.Reminder with { AdvanceSentForDue = candidate.Reminder.Due };
            return Update(items, (candidate.Item, candidate.Day), (_, item) => Apply(item, candidate.Day, result));
        });
        return result;
    }
    public Reminder? TakeDue(DateTimeOffset now)
    {
        if (!Candidates(store.Read(), now).Any(c => c.Reminder.CanNotify(now))) return null;
        Reminder? result = null;
        store.Modify(items => {
            var candidate = Candidates(items, now).Where(c => c.Reminder.CanNotify(now)).OrderBy(c => c.Reminder.NextNotice ?? c.Reminder.Due).FirstOrDefault();
            if (candidate.Item is null) return items;
            var due = candidate.Reminder; var adhd = due.Settings.Level == ReminderIntensity.Adhd; var pressure = adhd ? Math.Min(due.Pressure + 1, 30) : 0;
            result = due with { SentCount = Math.Min(due.SentCount, int.MaxValue - 1) + 1, Pressure = pressure, NextNotice = adhd ? now.AddMinutes(ReminderEscalation.Minutes(due.Settings, pressure)) : due.SentCount + 1 < due.Settings.Count ? now.AddMinutes(due.Settings.IntervalMinutes) : null };
            return Update(items, (candidate.Item, candidate.Day), (_, item) => Apply(item, candidate.Day, result));
        });
        return result;
    }
    internal List<Reminder> Singles() => store.Read().Where(i => i.Timed && i.Repeat is null).Select(i => ToReminder(i)).ToList();
    internal List<Item> Rules() => store.Read().Where(i => i.Timed && i.Repeat != null).ToList();
    public bool IsCurrent(Guid id, int revision) => Items.Any(r => r.Id == id && !r.Done && r.Revision == revision);
    // Tamamlanan tek seferlik hatırlatıcıları siler; tekrarların geçmişi kendiliğinden görünümden düşer.
    public void ClearCompleted() => store.Modify(items => items.Where(i => !(i.Timed && i.Repeat is null && i.Done)).ToList());

    // Google Calendar içe aktarımı: yalnızca tek seferlik hatırlatıcılar. İstek sürerken bildirim sayaçları
    // değişebileceği için karşılaştır-ve-uygula atomiktir.
    internal bool ApplyExternal(Guid id, Reminder? replacement, Func<Reminder?, bool> unchanged)
    {
        replacement?.Settings.Validate(); replacement?.Plan?.Validate();
        var applied = false;
        store.Modify(items => {
            var current = items.FirstOrDefault(i => i.Id == id && i.Repeat is null && i.Timed);
            if (!unchanged(current is null ? null : ToReminder(current))) return items;
            applied = true;
            if (replacement is null) return items.Where(i => i.Id != id).ToList();
            var item = LegacyItems.FromReminder(replacement with { Plan = replacement.Plan is null ? null : replacement.Plan with { Weekly = null } }) with { Created = current?.Created, Steps = current?.Steps, List = current?.List ?? "Görevler" };
            return current == null ? [.. items, item] : items.Select(i => i.Id == id ? item : i).ToList();
        });
        return applied;
    }
}
