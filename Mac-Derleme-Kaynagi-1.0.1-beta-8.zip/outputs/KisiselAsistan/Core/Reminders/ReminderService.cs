namespace KisiselAsistan;

public enum ReminderPromptKind { Due, Advance, Confirmation }
public enum ReminderResponse { Done, Confirmed, NotDone, Snooze, Acknowledge }
public record ReminderPrompt(Reminder Reminder, ReminderPromptKind Kind, bool MatchSentCount = true);

// Shared application operations: no windows, controls, or notification rendering.
public interface IReminderService
{
    IReadOnlyList<Reminder> Items { get; }
    event Action? Changed;
    event Action<string>? Feedback;
    void Add(string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null);
    void Edit(Guid id, string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null);
    void Remove(Guid id);
    void Snooze(Guid id, TimeSpan delay);
    void Move(Guid id, DateTimeOffset due);
    // Ön bildirim: asıl saatten kaç dakika önce (0 = kapalı, 1440 = bir gün önce).
    void SetLead(Guid id, int minutes);
    void ClearCompleted();
    IReadOnlyList<PlanSlot> SuggestTimes(DateTime firstDay, PlanDetails plan, Guid? excluding = null, PlanningPreferences? preferences = null);
    ReminderPrompt? RequestCompletion(Guid id);
    // away: kullanıcı bilgisayardan uzakta (klavye/fare bir süredir kullanılmadı); ilk bildirim gider, tekrarlar dönüşe kadar bekler.
    IReadOnlyList<ReminderPrompt> Poll(bool away = false);
    bool IsCurrent(ReminderPrompt prompt);
    ReminderPrompt? Respond(ReminderPrompt prompt, ReminderResponse response, int snoozeMinutes = 5);
}

public sealed class ReminderService : IReminderService
{
    private readonly ReminderStore store;
    private readonly ReminderScheduler scheduler;
    private readonly Func<DateTimeOffset> clock;
    private readonly Func<ReminderOptions>? defaultOptions;
    public IReadOnlyList<Reminder> Items => store.Items;
    // Google eşitlemesi için: tek seferlik hatırlatıcılar ve tekrar kuralları ayrı ayrı.
    internal List<Reminder> Singles() => store.Singles();
    internal List<Item> Rules() => store.Rules();
    // Arayüze giden liste: tek seferlikler ve tekrarların yaklaşık iki ay öncesi ile altı ay sonrası (takvimde gezinme payı).
    internal static List<Reminder> ForScreen(IEnumerable<Reminder> items, DateOnly today) => ForScreen(items, today.AddDays(-62), today.AddDays(190));
    internal static List<Reminder> ForScreen(IEnumerable<Reminder> items, DateOnly from, DateOnly to) => items.Where(r => r.Plan?.Weekly == null || DateOnly.FromDateTime(r.Due.LocalDateTime) is var day && day >= from && day <= to).ToList();
    public event Action? Changed;
    public event Action<string>? Feedback;

    public ReminderService(ReminderStore store, Func<DateTimeOffset>? clock = null, Func<ReminderOptions>? defaultOptions = null)
    {
        this.store = store;
        this.defaultOptions = defaultOptions;
        this.clock = clock ?? (() => DateTimeOffset.Now);
        scheduler = new(store, this.clock);
    }

    internal bool ApplyExternal(Guid id, Reminder? replacement, Func<Reminder?, bool> unchanged)
    {
        var applied = store.ApplyExternal(id, replacement, unchanged);
        if (applied) Changed?.Invoke();
        return applied;
    }
    private void Validate(string text, DateTimeOffset due)
    {
        if (string.IsNullOrWhiteSpace(text)) throw new ArgumentException("Hatırlatma metni boş olamaz.");
        if (due <= clock()) throw new ArgumentException("Gelecekte bir tarih seç.");
    }
    public void Add(string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null)
    {
        Validate(text, due); store.Add(text.Trim(), due, options ?? defaultOptions?.Invoke(), plan); Changed?.Invoke();
    }
    public void Edit(Guid id, string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null)
    {
        Validate(text, due); store.Edit(id, text.Trim(), due, options, plan); Changed?.Invoke();
    }
    public void Remove(Guid id) { store.Remove(id); Changed?.Invoke(); }
    public void Snooze(Guid id, TimeSpan delay) { store.Snooze(id, delay); Changed?.Invoke(); }
    public void Move(Guid id, DateTimeOffset due) { if (due <= clock()) throw new ArgumentException("Gelecekte bir tarih seç."); store.Move(id, due); Changed?.Invoke(); }
    public void SetLead(Guid id, int minutes) { store.SetLead(id, minutes); Changed?.Invoke(); }
    public void ClearCompleted() { store.ClearCompleted(); Changed?.Invoke(); }
    public IReadOnlyList<PlanSlot> SuggestTimes(DateTime firstDay, PlanDetails plan, Guid? excluding = null, PlanningPreferences? preferences = null)
        => PlanSuggestions.Find(firstDay, plan, preferences ?? PlanningPreferenceStore.Load(), Items, excluding, clock().LocalDateTime);
    private void Complete(Guid id) { store.Complete(id); Changed?.Invoke(); Feedback?.Invoke("Görev tamamlandı."); }

    public ReminderPrompt? RequestCompletion(Guid id)
    {
        var reminder = Items.FirstOrDefault(r => r.Id == id && !r.Done);
        if (reminder == null) return null;
        if (reminder.Settings.Level == ReminderIntensity.Adhd)
            return new(reminder, ReminderPromptKind.Confirmation, MatchSentCount: false);
        Complete(id); return null;
    }

    public IReadOnlyList<ReminderPrompt> Poll(bool away = false)
    {
        var prompts = scheduler.Poll(away);
        if (prompts.Count > 0) Changed?.Invoke();
        var due = prompts.FirstOrDefault(p => p.Kind == ReminderPromptKind.Due);
        if (due != null) Feedback?.Invoke("Hatırlatma: " + due.Reminder.Text);
        return prompts;
    }
    public bool IsCurrent(ReminderPrompt prompt)
    {
        var original = prompt.Reminder;
        var current = Items.FirstOrDefault(r => r.Id == original.Id);
        if (current == null || current.Done || current.Revision != original.Revision) return false;
        return prompt.Kind == ReminderPromptKind.Advance
            ? current.Due == original.Due && current.Plan?.Lead > 0
            : !prompt.MatchSentCount || current.SentCount == original.SentCount;
    }

    // Only valid answers for this particular notification can change the task.
    public ReminderPrompt? Respond(ReminderPrompt prompt, ReminderResponse response, int snoozeMinutes = 5)
    {
        if (!IsCurrent(prompt)) return null;
        var reminder = prompt.Reminder;
        var adhd = reminder.Settings.Level == ReminderIntensity.Adhd;
        if (prompt.Kind == ReminderPromptKind.Advance) {
            if (response != ReminderResponse.Acknowledge) throw new InvalidOperationException("Ön bildirim görevi tamamlamaz veya ertelemez.");
            return null;
        }
        switch (response) {
            case ReminderResponse.Done when prompt.Kind == ReminderPromptKind.Due:
                if (adhd) return prompt with { Kind = ReminderPromptKind.Confirmation };
                Complete(reminder.Id); break;
            case ReminderResponse.Confirmed when prompt.Kind == ReminderPromptKind.Confirmation && adhd:
                Complete(reminder.Id); break;
            case ReminderResponse.NotDone when adhd:
                store.ReportNotDone(reminder.Id, clock()); Changed?.Invoke();
                Feedback?.Invoke($"Görev henüz yapılmadı. {ReminderEscalation.Minutes(reminder.Settings, reminder.Pressure + 1)} dakika sonra yeniden sorulacak.");
                break;
            case ReminderResponse.Snooze when prompt.Kind == ReminderPromptKind.Due && !adhd:
                if (snoozeMinutes <= 0) throw new ArgumentException("Erteleme süresi pozitif olmalı.");
                Snooze(reminder.Id, TimeSpan.FromMinutes(snoozeMinutes));
                Feedback?.Invoke($"Hatırlatıcı {snoozeMinutes} dakika ertelendi."); break;
            default: throw new InvalidOperationException("Bu bildirim için geçersiz yanıt.");
        }
        return null;
    }
}
