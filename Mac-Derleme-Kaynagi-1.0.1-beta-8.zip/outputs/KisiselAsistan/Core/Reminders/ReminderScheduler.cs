namespace KisiselAsistan;

// The caller supplies a tick; this can be a desktop timer or a future background host.
public sealed class ReminderScheduler(ReminderStore store, Func<DateTimeOffset> clock)
{
    public IReadOnlyList<ReminderPrompt> Poll(bool away = false)
    {
        var now = clock();
        List<ReminderPrompt> prompts = [];
        var advance = store.TakeAdvance(now);
        if (advance != null) prompts.Add(new(advance, ReminderPromptKind.Advance));
        var due = store.TakeDue(now, holdRepeats: away);
        if (due != null) prompts.Add(new(due, ReminderPromptKind.Due));
        return prompts;
    }
}

internal static class ReminderEscalation
{
    // 10 → 5 → 3 → 3 … (başlangıç 3'ten kısaysa o kalır).
    internal static int Minutes(ReminderOptions settings, int pressure) => Math.Max(Math.Min(ReminderOptions.AdhdFloorMinutes, settings.IntervalMinutes), (int)Math.Ceiling(settings.IntervalMinutes / Math.Pow(2, Math.Clamp(pressure - 1, 0, 11))));
    internal static bool Center(Reminder reminder) => reminder.Settings.Level == ReminderIntensity.Adhd && reminder.Pressure >= 4;
}
