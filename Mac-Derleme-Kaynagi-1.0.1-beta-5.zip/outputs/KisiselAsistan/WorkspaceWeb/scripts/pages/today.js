"use strict";
// Bugün: gecikenler, saatli işler (şimdi çizgisiyle), gün içindeki işler, tamamlananlar ve "Bir ara".
// Büyük görünümde sağda Sıradaki, Müzik (arama dahil), Oyunlar ve Kısayollar kartları durur.
// Bileşen olarak çizilir (Preact + htm); olaylar data-action / data-task-check ile actions.js'te yakalanır.

// ---------------------------------------------------------------- Görev yardımcıları
function taskDone(t) {
  return t.dailyActivity ? (t.completedDays || []).includes(state.day) : t.done;
}
// Tekrarlı görev o gün var mı: başlangıçtan sonra ve haftanın seçili günlerinden biri (repeatDays bit 0 = pazar).
const repeatsOn = (t, key) =>
  key >= (t.startsOn || "0001-01-01") && ((t.repeatDays ?? 127) & (1 << new Date(key + "T12:00:00").getDay())) !== 0;
// "Bir ara": günü ve bitiş tarihi olmayan, acil olmayan tek seferlik görev. Zamanı gelince bugüne alınır.
const isSomeday = (t) => !t.dailyActivity && !t.myDay && !t.due;
const saveSomeday = (title) =>
  rpc("task.save", { task: { title, list: "Görevler", steps: [], dailyActivity: false, myDay: null, due: null, startsOn: today() } });
// Yanlışlıkla tamamlanan "bir ara" işini geri getirir: bu oturumda tamamlananlardan en sonuncusu.
// Hâlâ tamamlanmış ve tarihsiz olanlar sayılır; başka yerden geri alınan ya da silinen düşer.
function somedayPending() {
  state.somedayDone = state.somedayDone.filter((id) => state.data.tasks.some((t) => t.id === id && t.done && isSomeday(t)));
  return state.somedayDone;
}
const reminderLabel = (r) => (r.settings?.level === "Adhd" ? "Yapana kadar ısrar" : "");

// ---------------------------------------------------------------- Hızlı ekleme
// Metni C# tarafındaki tek tarih/saat ayrıştırıcısı çözer: saat varsa hatırlatıcı, yoksa göreve.
// "yarın 9'da diş hekimi", "17:30 annemi ara", "cuma akşam 7 toplantı", "bi ara dolabı düzenle".
// Dönen: { kind: "reminder" | "task" | "someday", text, due, day }
const parseQuick = (input) => rpc("quick.parse", { text: String(input || "") });
const quickLabel = (q) =>
  q.kind === "someday"
    ? "Bir ara · tarihsiz görev"
    : q.kind === "reminder" ? `Hatırlatıcı · ${relativeDay(q.due)} ${clock(q.due)}` : q.day === today() ? "Bugüne görev" : `Görev · ${relativeDay(q.day + "T12:00:00")}`;
async function saveQuick(q) {
  if (!q.text) throw new Error("Ne ekleneceğini yaz.");
  if (q.kind === "reminder") {
    const d = state.data.defaults;
    await rpc("reminder.save", {
      id: null,
      text: q.text,
      due: q.due,
      options: { level: d.level, count: d.count, intervalMinutes: d.intervalMinutes },
      plan: { certainty: "Fixed", durationMinutes: 30, priority: 2, category: "Personal" },
    });
  } else if (q.kind === "someday") await saveSomeday(q.text);
  else await rpc("task.save", { task: { title: q.text, list: "Görevler", steps: [], dailyActivity: false, myDay: q.day, startsOn: q.day } });
  toast(quickLabel(q) + " eklendi.");
}

// "48 dk", "2 sa 10 dk", "yarın 09:00"
function countdown(due) {
  const minutes = Math.max(0, Math.round((new Date(due) - new Date()) / 60000));
  if (minutes < 60) return `${minutes} dk`;
  if (minutes < 24 * 60) return `${Math.floor(minutes / 60)} sa${minutes % 60 ? ` ${minutes % 60} dk` : ""}`;
  return `${relativeDay(due)} ${clock(due)}`;
}
function lateness(due) {
  const minutes = Math.round((new Date() - new Date(due)) / 60000);
  if (minutes < 60) return `${Math.max(1, minutes)} dk gecikti`;
  if (minutes < 24 * 60) return `${Math.floor(minutes / 60)} saat gecikti`;
  return `${relativeDay(due)} kaldı`;
}

// ---------------------------------------------------------------- Satırlar
const PrioMark = ({ r }) =>
  r.plan?.priority === 3
    ? html`<span class="prio-mark" aria-label="Yüksek öncelik">!</span>`
    : r.plan?.priority === 1 ? html`<span class="prio-mark low" aria-label="Düşük öncelik">↓</span>` : null;

function TaskRow({ t, late = false }) {
  const done = taskDone(t);
  const repeat = t.dailyActivity ? ((t.repeatDays ?? 127) === 127 ? "Her gün" : "Seçili günler") : "";
  const meta = [repeat, t.list !== "Görevler" ? t.list : "", t.steps?.length ? `${t.steps.filter((s) => s.done).length}/${t.steps.length} adım` : ""].filter(Boolean).join(" · ");
  return html`<div class=${"task-row today-row" + (done ? " is-done" : "") + (late ? " is-overdue" : "")} data-row-task=${t.id}>
    <input type="checkbox" data-task-check=${t.id} checked=${done} aria-label=${t.title + " tamamlandı"} />
    <div class="task-copy">
      <strong>${t.title}</strong>
      ${(meta || late) && html`<small>${late && html`<${Chip} tone="danger">${relativeDay(t.due + "T12:00:00")} gecikti<//>`}${meta}</small>`}
    </div>
    <${Button} action="task-star" icon="star" cls=${"icon-button star" + (t.important ? " is-important" : "")} data-id=${t.id} aria-label="Önem işaretini değiştir" />
    <${Button} action="task-menu" icon="more" cls="icon-button row-more" data-id=${t.id} aria-label="Görev işlemleri" />
  </div>`;
}
function ReminderRow({ r, late = false, next = false }) {
  const meta = [r.plan?.weekly ? "Tekrarlı" : "", r.plan?.certainty === "Flexible" ? "Saati kayabilir" : "", next ? countdown(r.due) + " sonra" : ""].filter(Boolean).join(" · ");
  return html`<div class=${`task-row today-row ${planClass(r)}` + (r.done ? " is-done" : "") + (late ? " is-overdue" : "") + (next ? " is-next" : "")} data-row-reminder=${r.id} title=${planTitle(r)}>
    <input type="checkbox" data-reminder-check=${r.id} checked=${r.done} disabled=${r.done} aria-label=${r.text + " tamamlandı"} />
    <span class="time"><${PrioMark} r=${r} />${clock(r.due)}</span>
    <div class="task-copy">
      <strong>${r.text}</strong>
      ${(meta || late || reminderLabel(r)) && html`<small>${late && html`<${Chip} tone="danger">${lateness(r.due)}<//>`}${reminderLabel(r) && html`<${Chip} tone="accent">${reminderLabel(r)}<//>`}${meta}</small>`}
    </div>
    <${Button} action="reminder-menu" icon="more" cls="icon-button row-more" data-id=${r.id} aria-label="Hatırlatıcı işlemleri" />
  </div>`;
}
const Head = ({ icon, title, count, children }) =>
  html`<h2 class="today-head"><${Icon} n=${icon} /><span>${title}</span>${count ? html`<span class="badge">${count}</span>` : null}${children}</h2>`;
const HeadButton = ({ action, icon, children, ...rest }) => html`<${Button} action=${action} icon=${icon} cls="text-button head-add" ...${rest}>${children}<//>`;

// ---------------------------------------------------------------- Sayfa
function TodayPage() {
  state.day = today();
  const key = state.day,
    now = new Date();
  const reminders = state.data.reminders;
  const lateReminders = reminders.filter((r) => !r.done && new Date(r.due) < now).sort((a, b) => new Date(a.due) - new Date(b.due));
  const lateTasks = state.data.tasks.filter((t) => !t.dailyActivity && !t.done && t.due && t.due < key);
  // Tamamlanan hatırlatıcılar zaman akışında durmaz; "Tamamlananlar" bölümüne geçer.
  const timed = reminders.filter((r) => dayKey(new Date(r.due)) === key && !r.done && new Date(r.due) >= now).sort((a, b) => new Date(a.due) - new Date(b.due));
  const dayTasks = state.data.tasks.filter((t) => !lateTasks.includes(t) && (t.dailyActivity ? repeatsOn(t, key) : t.myDay === key || t.due === key));
  const open = dayTasks.filter((t) => !taskDone(t)),
    finished = dayTasks.filter(taskDone);
  const next = reminders.filter((r) => !r.done && new Date(r.due) > now).sort((a, b) => new Date(a.due) - new Date(b.due))[0];
  const todays = reminders.filter((r) => dayKey(new Date(r.due)) === key);
  const doneReminders = todays.filter((r) => r.done).sort((a, b) => new Date(a.due) - new Date(b.due));
  const total = dayTasks.length + todays.length,
    doneCount = finished.length + doneReminders.length,
    left = total - doneCount;
  const someday = state.data.tasks.filter((t) => isSomeday(t) && !t.done);
  const undo = somedayPending();
  const lastUndone = undo.length ? state.data.tasks.find((t) => t.id === undo[undo.length - 1]) : null;
  const plannable = open.some((t) => !t.dailyActivity) || lateTasks.length > 0;
  const late = [...lateReminders.map((r) => ({ r })), ...lateTasks.map((t) => ({ t }))];

  // Şimdi çizgisi zaman akışında ilk gelecek işin önüne girer.
  const firstFuture = timed.findIndex((r) => new Date(r.due) > now);
  const nowLine = html`<div class="today-now" key="now"><span>Şimdi · ${clock(now)}</span></div>`;
  const flow = timed.map((r) => html`<${ReminderRow} key=${r.id} r=${r} next=${r === next} />`);
  flow.splice(firstFuture < 0 ? flow.length : firstFuture, 0, nowLine);

  const main = html`<div class="today-main">
    <div class="today-heading">
      <div><h1>Bugün</h1><p>${now.toLocaleDateString("tr-TR", { day: "numeric", month: "long", weekday: "long" })} · ${left > 0 ? `${left} iş kaldı` : total ? "Hepsi tamam" : "Sakin bir gün"}</p></div>
      ${total > 0 && html`<div class="today-progress" title=${`${doneCount} / ${total} tamamlandı`}><span class="bar"><i style=${{ width: Math.round((doneCount / total) * 100) + "%" }}></i></span><small>${doneCount} / ${total}</small></div>`}
    </div>
    <form id="today-add" class="today-add"><${Icon} n="plus" /><input name="text" maxlength="500" autocomplete="off" placeholder=${compact() ? "Ekle… örn. “17:00 annemi ara”" : "Ne yapacaksın? “yarın 9’da diş hekimi”, “bi ara dolabı düzenle”…"} aria-label="Görev veya hatırlatıcı ekle" /><small id="today-add-hint"></small></form>

    ${late.length > 0 && html`<section class="today-section today-late">
      <${Head} icon="clock" title="Gecikenler" count=${late.length}><${HeadButton} action="late-menu" icon="calendar" aria-label="Gecikenleri toplu taşı">Toplu taşı<//><//>
      <div class="today-rows">${late.slice(0, 5).map((x) => (x.r ? html`<${ReminderRow} key=${x.r.id} r=${x.r} late />` : html`<${TaskRow} key=${x.t.id} t=${x.t} late />`))}</div>
      ${late.length > 5 && html`<${Button} action="navigate" cls="text-button" data-page="reminders">+${late.length - 5} daha · Takvimde gör<//>`}
    </section>`}

    <section class="today-section">
      <${Head} icon="calendar" title="Saatli"><${HeadButton} action="reminder-new" icon="plus" data-date=${key}>Saatli ekle<//><//>
      ${timed.length
        ? html`<div class="today-rows timeline">${flow}</div>`
        : html`<div class="today-empty">Bugün için saatli iş yok.${next && html` Sıradaki: <strong>${next.text}</strong> · ${relativeDay(next.due)} ${clock(next.due)}`}</div>`}
    </section>

    <section class="today-section">
      <${Head} icon="task" title="Gün içinde" count=${open.length}>
        ${plannable && html`<${HeadButton} action="day-plan" icon="clock" title="Saatsiz işleri bugünün boş saatlerine yerleştir">Günü planla<//>`}
        <${HeadButton} action="task-new" icon="plus">Görev<//>
      <//>
      <div class="today-rows" data-sortable>${open.length ? open.map((t) => html`<${TaskRow} key=${t.id} t=${t} />`) : html`<div class="today-empty">Bugün için bekleyen görev yok.</div>`}</div>
      ${finished.length + doneReminders.length > 0 && html`<details class="completed today-done" open=${state.completed} onToggle=${(e) => (state.completed = e.target.open)}>
        <summary>Tamamlananlar <span class="badge">${finished.length + doneReminders.length}</span></summary>
        <div class="today-rows">${doneReminders.map((r) => html`<${ReminderRow} key=${r.id} r=${r} />`)}${finished.map((t) => html`<${TaskRow} key=${t.id} t=${t} />`)}</div>
      </details>`}
    </section>

    <details class="today-section today-someday someday" open=${state.somedayOpen !== false} onToggle=${(e) => (state.somedayOpen = e.target.open)}>
      <summary class="today-head"><${Icon} n="right" /><span>Bir ara</span>${someday.length ? html`<span class="badge">${someday.length}</span>` : null}<small class="head-note">tarihi yok, acil değil</small></summary>
      <div class="today-rows" data-sortable>${someday.map((t) => html`<${TaskRow} key=${t.id} t=${t} />`)}</div>
      ${lastUndone && html`<div class="someday-undo"><${Button} action="someday-undo" icon="undo" cls="ghost">Geri al: <span class="someday-undo-title">${lastUndone.title}</span>${undo.length > 1 && html` <span class="muted">(+${undo.length - 1})</span>`}<//></div>`}
      <form id="someday-task" class="task-entry"><${Icon} n="plus" /><input name="title" maxlength="500" autocomplete="off" placeholder="Bir ara yapılacak…" aria-label="Bir ara yapılacak görev" /><button class="ghost">Ekle</button></form>
    </details>
    ${compact() && html`<${NowStrip} />`}
  </div>`;
  return compact() ? main : html`<div class="today-layout">${main}<aside class="today-side" aria-label="Özet"><${TodaySide} next=${next} /></aside></div>`;
}

// ---------------------------------------------------------------- Sağ kartlar
const SideHead = ({ title, page, children }) =>
  html`<header class="side-head"><h2>${title}</h2>${children}${page && html`<${Button} action="navigate" icon="right" cls="text-button" data-page=${page}>Aç<//>`}</header>`;
const Art = ({ track }) =>
  track?.coverUrl ? html`<img class="art" src=${spotifyCover(track.coverUrl)} alt="" />` : html`<span class="art"><${Icon} n="music" /></span>`;
// Küçük görünümde çalan şarkı ince bir şerit.
function NowStrip() {
  const playing = state.playing,
    track = playing?.track;
  if (!track) return html`<div id="today-player" hidden></div>`;
  return html`<div id="today-player" class="now-strip"><${Art} track=${track} /><div class="item-copy"><strong>${track.name}</strong><small>${track.artist}</small></div>
    <${Button} action="spotify-toggle" icon=${playing.playing ? "pause" : "play"} cls="icon-button" aria-label=${playing.playing ? "Duraklat" : "Oynat"} />
    <${Button} action="spotify-next" icon="next" cls="icon-button" aria-label="Sonraki şarkı" /></div>`;
}
// Müzik kartı: çalan şarkı, denetimler, ses ve arama (sonuca tek tık çalar, şarkı albümünün içinden çalınır).
function MusicCard() {
  const playing = state.playing,
    track = playing?.track,
    query = state.query.spotify || "";
  const progress = playing?.duration ? Math.min(100, (playing.position / playing.duration) * 100) : 0;
  return html`<section id="today-player" class="card side-card music-card">
    <${SideHead} title="Müzik"><${Button} action="spotify-settings" icon="settings" cls="icon-button" aria-label="Spotify hesabı" title="Spotify hesabı" /><//>
    ${track
      ? html`<div class="side-media"><${Art} track=${track} /><div class="item-copy"><strong>${track.name}</strong><small>${track.artist}</small></div></div>
          <div class="progress"><span style=${{ width: progress + "%" }}></span></div>
          <div class="side-controls">
            <${Button} action="spotify-previous" icon="previous" cls="icon-button" aria-label="Önceki şarkı" />
            <${Button} action="spotify-toggle" icon=${playing.playing ? "pause" : "play"} cls="primary round" aria-label=${playing.playing ? "Duraklat" : "Oynat"} />
            <${Button} action="spotify-next" icon="next" cls="icon-button" aria-label="Sonraki şarkı" />
          </div>
          ${playing.deviceId && html`<label class="volume mini"><${Icon} n="volume" /><input id="spotify-volume" type="range" min="0" max="100" value=${playing.volume ?? 50} style=${{ "--fill": (playing.volume ?? 50) + "%" }} aria-label="Spotify ses seviyesi" /><small>${playing.volume ?? "—"}%</small></label>`}`
      : html`<p class="side-note">Şu an çalan bir şey yok.</p><${Button} action="spotify-open" icon="external" cls="ghost side-wide">Spotify’ı aç<//>`}
    <label class="search-mini"><${Icon} n="search" /><input id="spotify-search" value=${query} autocomplete="off" placeholder="Şarkı ya da sanatçı ara…" aria-label="Spotify'da ara" /></label>
    ${query.trim() && html`<div class="side-tracks">${state.spotifyResults.length
      ? state.spotifyResults.slice(0, 6).map((t, i) => html`<div class="side-track is-pickable" tabindex="0" data-action="spotify-play" data-index=${i} title="Çalmak için tıkla"><${Art} track=${t} /><div class="item-copy"><strong>${t.name}</strong><small>${t.artist}</small></div><${Icon} n="play" /></div>`)
      : html`<p class="side-note">Aranıyor…</p>`}</div>`}
  </section>`;
}
function TodaySide({ next }) {
  const games = state.data.steam.slice(0, 3),
    routines = state.data.routines.slice(0, 3);
  return html`
    <section class="card side-card side-next"><${SideHead} title="Sıradaki" />
      ${next
        ? html`<div class="side-count">${countdown(next.due)}</div><strong>${next.text}</strong><small>${relativeDay(next.due)} ${clock(next.due)}${next.settings?.level === "Adhd" ? " · yapana kadar ısrar eder" : ""}</small>`
        : html`<p class="side-note">Sırada saatli iş yok.</p><${Button} action="reminder-new" icon="plus" cls="ghost side-wide">Saatli ekle<//>`}
    </section>
    <${MusicCard} />
    <section class="card side-card"><${SideHead} title="Oyunlar" page="steam" />
      ${games.length
        ? html`<div class="side-list">${games.map((g) => html`<div class="side-game" key=${g.id}><${Cover} game=${g} /><div class="item-copy"><strong>${g.name}</strong><small><${Chip} tone=${g.comingSoon ? "accent" : "success"}>${g.comingSoon ? "Bekleniyor" : g.earlyAccess ? "Erken erişim" : "Çıktı"}<//>${g.releaseDate || ""}</small></div></div>`)}</div>`
        : html`<p class="side-note">Takip ettiğin oyun yok.</p>`}
    </section>
    <section class="card side-card"><${SideHead} title="Kısayollar" page="shortcuts" />
      ${routines.length
        ? html`<div class="side-list">${routines.map((r) => html`<button type="button" key=${r.id} class="side-shortcut" data-action="shortcut-run" data-id=${r.id} title="Başlat"><${Icon} n="play" /><span>${r.name}</span><small>${r.steps.length} adım</small></button>`)}</div>`
        : html`<${Button} action="shortcut-new" icon="plus" cls="ghost side-wide">Kısayol oluştur<//>`}
    </section>`;
}
pageComponents.today = TodayPage;
