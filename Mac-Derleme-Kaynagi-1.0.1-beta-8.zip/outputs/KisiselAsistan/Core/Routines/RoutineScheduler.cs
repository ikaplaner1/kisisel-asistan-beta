namespace KisiselAsistan;

// Kısayolun kendiliğinden başlayacağı günler ve saat.
// Days: haftanın günleri bit olarak (1 << (int)DayOfWeek; Pazar = 1, hafta içi = 62, her gün = 127) — tekrarlı işlerle aynı.
// Minutes: gün içindeki saat, dakika olarak (09:30 = 570).
public record RoutineSchedule(int Days, int Minutes, bool Enabled = true)
{
    public bool Valid => Days is > 0 and <= 127 && Minutes is >= 0 and < 1440;
    public bool On(DateOnly day) => Enabled && (Days & (1 << (int)day.DayOfWeek)) != 0;
}
public enum RoutinePromptAnswer { Start, Snooze, Skip }
// Kullanıcıya sorulan "kısayol başlıyor" bildirimi. AutoStartAt'e kadar cevap gelmezse kısayol kendiliğinden başlar.
public sealed record RoutinePrompt(Guid RoutineId, string Name, DateOnly Day, DateTimeOffset AutoStartAt);
public sealed record RoutineTick(IReadOnlyList<RoutinePrompt> Show, IReadOnlyList<Guid> Start);

// Zamanlanmış kısayolları izler (arayüzden bağımsız; Windows bildirimleri ya da Mac kabuğu Poll sonucunu gösterir).
// Kurallar:
// - Seçili günde saat gelince bir kez sorulur. Uygulama o saatte kapalıysa, saatten sonraki LateWindow içinde açılırsa yine sorulur; daha geçse o gün atlanır.
// - Cevap: Başlat (hemen), Ertele (SnoozeMinutes sonra tekrar sorulur), Bugün atla. AskWindow içinde cevap yoksa kendiliğinden başlar.
// - O gün başlatılan ya da atlanan kısayol bir daha sorulmaz; bu bilgi dosyada tutulur (uygulama yeniden açılınca tekrar sormaz).
public sealed class RoutineScheduler(RoutineService routines, string statePath, Func<DateTimeOffset>? clock = null)
{
    public static readonly TimeSpan AskWindow = TimeSpan.FromMinutes(2);
    public static readonly TimeSpan LateWindow = TimeSpan.FromMinutes(30);
    public const int SnoozeMinutes = 10;
    private sealed record RunState(Guid Id, DateOnly? Handled, DateTimeOffset? SnoozedUntil);
    private readonly JsonListStore<RunState> store = new(statePath);
    private readonly Dictionary<Guid, RoutinePrompt> pending = [];
    private DateTimeOffset Now => clock?.Invoke() ?? DateTimeOffset.Now;

    public RoutineTick Poll()
    {
        var now = Now; var today = DateOnly.FromDateTime(now.LocalDateTime);
        var show = new List<RoutinePrompt>(); var start = new List<Guid>();
        var items = routines.Items; var states = store.Read().ToDictionary(s => s.Id);
        foreach (var key in pending.Keys.Where(id => !items.Any(r => r.Id == id && r.Schedule?.Enabled == true)).ToList()) pending.Remove(key);
        // Cevapsız kalan sorular: süre dolunca kısayol kendiliğinden başlar.
        foreach (var prompt in pending.Values.Where(p => now >= p.AutoStartAt).ToList()) {
            pending.Remove(prompt.RoutineId); Mark(prompt.RoutineId, prompt.Day, null); start.Add(prompt.RoutineId);
        }
        foreach (var routine in items) {
            if (routine.Schedule is not { Valid: true } schedule || !schedule.On(today) || routine.Steps.Count == 0 || pending.ContainsKey(routine.Id)) continue;
            states.TryGetValue(routine.Id, out var state);
            if (state?.Handled == today) continue;
            var at = new DateTimeOffset(today.ToDateTime(TimeOnly.MinValue), now.Offset).AddMinutes(schedule.Minutes);
            var snoozed = state?.SnoozedUntil is { } until && until.LocalDateTime.Date == now.LocalDateTime.Date;
            var due = snoozed ? now >= state!.SnoozedUntil : now >= at && now < at + LateWindow;
            if (!due) continue;
            var prompt = new RoutinePrompt(routine.Id, routine.Name, today, now + AskWindow);
            pending[routine.Id] = prompt; show.Add(prompt);
        }
        return new(show, start);
    }
    public bool IsCurrent(RoutinePrompt prompt) => pending.TryGetValue(prompt.RoutineId, out var current) && current == prompt;
    // Bildirimden gelen cevap. Başlat için true döner (kısayolu çağıran başlatır).
    public bool Answer(RoutinePrompt prompt, RoutinePromptAnswer answer)
    {
        if (!IsCurrent(prompt)) return false;
        pending.Remove(prompt.RoutineId);
        if (answer == RoutinePromptAnswer.Snooze) { Mark(prompt.RoutineId, null, Now.AddMinutes(SnoozeMinutes)); return false; }
        Mark(prompt.RoutineId, prompt.Day, null);
        return answer == RoutinePromptAnswer.Start;
    }
    // Kısayolun bir sonraki zamanı (liste ve form için).
    public static DateTimeOffset? Next(RoutineSchedule? schedule, DateTimeOffset now)
    {
        if (schedule is not { Valid: true, Enabled: true }) return null;
        for (var i = 0; i < 8; i++) {
            var day = DateOnly.FromDateTime(now.LocalDateTime).AddDays(i);
            var at = new DateTimeOffset(day.ToDateTime(TimeOnly.MinValue), now.Offset).AddMinutes(schedule.Minutes);
            if (schedule.On(day) && at > now) return at;
        }
        return null;
    }
    private void Mark(Guid id, DateOnly? handled, DateTimeOffset? snoozedUntil) =>
        store.Modify(list => [.. list.Where(s => s.Id != id), new RunState(id, handled ?? list.FirstOrDefault(s => s.Id == id)?.Handled, snoozedUntil)]);
}
