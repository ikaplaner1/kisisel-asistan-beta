namespace KisiselAsistan;

public record TaskAddRequest(string Title, DateOnly? Day = null, bool Important = false);
public record TaskIdRequest(Guid Id);
public record TaskSummary(Guid Id, string Title, DateOnly? Day, bool Done, bool Repeating, bool Important);

// Görevlerin ortak işlemleri: sesli komutlar ve Ollama görevlere bu kapıdan ulaşır.
public static class TaskOperations
{
    public static void Register(OperationRegistry operations, TaskRoutineService tasks, Func<DateOnly>? today = null)
    {
        DateOnly Today() => today?.Invoke() ?? DateOnly.FromDateTime(DateTime.Today);
        operations.Register<NoArguments, IReadOnlyList<TaskSummary>>("task.list", "Bugünün görevlerini listele (geciken ve bugüne ait, tamamlananlar dahil)", _ => {
            var day = Today();
            return tasks.Items.Where(t => TaskRoutineService.IsOnDay(t, day) || Done(t, day) && (t.DailyActivity || t.MyDay == day || t.Due == day) || !t.DailyActivity && !t.Done && t.Due < day)
                .Select(t => new TaskSummary(t.Id, t.Title, t.DailyActivity ? day : t.MyDay ?? t.Due, Done(t, day), t.DailyActivity, t.Important)).ToList();
        });
        operations.Register<TaskAddRequest, Guid>("task.add", "Saatsiz görev ekle. day verilmezse 'bir ara' listesine (tarihsiz) gider; bugün için bugünün tarihini ver", r => {
            var id = Guid.NewGuid();
            tasks.Save(new(id, r.Title.Trim(), "Görevler", [], r.Important, MyDay: r.Day, StartsOn: r.Day ?? Today()));
            return id;
        }, r => { if (string.IsNullOrWhiteSpace(r.Title) || r.Title.Length > 500) throw new ArgumentException("Görevin adı 1–500 karakter olmalı."); });
        operations.Register<TaskIdRequest, bool>("task.complete", "Görevi tamamla (tekrarlı görevde bugünü)", r => {
            var task = tasks.Items.FirstOrDefault(t => t.Id == r.Id) ?? throw new ArgumentException("Görev bulunamadı.");
            if (task.DailyActivity) tasks.CompleteDay(task.Id, Today()); else tasks.Complete(task.Id, Today());
            return true;
        });
    }
    private static bool Done(RoutineTask task, DateOnly day) => task.DailyActivity ? task.CompletedDays?.Contains(day) == true : task.Done;
}
