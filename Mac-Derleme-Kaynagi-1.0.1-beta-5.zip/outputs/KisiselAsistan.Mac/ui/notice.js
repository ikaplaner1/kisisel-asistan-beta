window.notice.get().then(item=>{
  const {reminder,kind}=item.prompt, adhd=reminder.settings.level==='Adhd';
  document.getElementById('body').textContent=reminder.text;
  document.getElementById('title').textContent=kind==='Confirmation'?'Gerçekten tamamladın mı?':kind==='Advance'?'Yarınki planın':'Hatırlatma';
  const actions=kind==='Advance'?[['Tamam','Acknowledge']]:kind==='Confirmation'?[['Evet, yaptım','Confirmed'],['Henüz yapmadım','NotDone']]:adhd?[['Yaptım','Done'],['Yapmadım','NotDone']]:[['Tamamladım','Done'],['5 dk ertele','Snooze',5],['15 dk ertele','Snooze',15]];
  for(const [label,response,minutes] of actions){const button=document.createElement('button');button.textContent=label;button.onclick=async()=>{try{button.disabled=true;await window.notice.respond(response,minutes??5);}catch(error){document.getElementById('error').textContent=error.message;button.disabled=false;}};document.getElementById('actions').append(button);}
}).catch(error=>{document.getElementById('error').textContent=error.message;});
