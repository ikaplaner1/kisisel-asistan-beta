"use strict";
// Steam: oyun arama ve çıkış/güncelleme takibi. Bileşen olarak yazılmış ilk sayfa (Preact + htm);
// yeni sayfalar bu örneği izler. Arama kutusu yazarken yeniden çizilse de odağını kaybetmez.

// Kapak görselleri Steam'in kendi sunucularından gelir ama uygulama üzerinden istenir
// (covers.assistant.local): uygulama görseli indirir, önbelleğe alır ve sayfaya verir.
// Kayıtta kapak adresi yoksa oyunun numarasından Steam'in standart kapağı denenir.
const coverUrl = (g) => `https://covers.assistant.local/steam?id=${Number(g.id) || 0}&u=${encodeURIComponent(g.coverUrl || "")}`;
const Cover = ({ game }) =>
  game.id || game.coverUrl ? html`<img class="cover" src=${coverUrl(game)} alt="" loading="lazy" />` : html`<span class="cover cover-empty"></span>`;
// Eski metin şablonlu sayfalar (Bugün kartı) için aynı kapak.
const cover = (g) => (g.id || g.coverUrl ? `<img class="cover" src="${coverUrl(g)}" alt="" loading="lazy">` : '<span class="cover cover-empty"></span>');

// Arama sonucu: çift tık (ya da Enter) takibe alır.
const SteamResult = ({ game, watched }) => html`
  <div class="item-row is-pickable" tabindex="0" data-dbl-action="steam-track" data-id=${game.id} title="Takibe almak için çift tıkla">
    <${Cover} game=${game} />
    <div class="item-copy">
      <strong>${game.name}</strong>
      <small>${watched && html`<${Chip} tone="accent">Takip ediliyor<//>`}${game.approximate ? "Yakın eşleşme" : "Steam mağazası"}</small>
    </div>
    <small class="pick-hint">Çift tıkla · takip et</small>
  </div>`;


// Çıkış tarihi okunabiliyorsa kalan gün ("22 Oct, 2026" gibi Steam tarihleri); okunamazsa null.
function daysUntil(game) {
  if (!game.comingSoon || !game.releaseDate) return null;
  const t = Date.parse(game.releaseDate);
  if (Number.isNaN(t)) return null;
  const days = Math.ceil((t - Date.now()) / 86400000);
  return days >= 0 && days <= 730 ? days : null;
}
const releaseTag = (game, days) =>
  days != null
    ? html`<${Chip} tone="secondary">${days === 0 ? "Bugün çıkıyor" : days === 1 ? "Yarın" : days + " gün"}<//>`
    : html`<${Chip} tone=${game.comingSoon ? "accent" : "success"}>${game.comingSoon ? "Bekleniyor" : game.earlyAccess ? "Erken erişim" : "Çıktı"}<//>`;
const SteamWatch = ({ game }) => {
  const days = daysUntil(game);
  return html`<div class="item-row" data-row-steam=${game.id}>
    <${Cover} game=${game} />
    <div class="item-copy"><strong>${game.name}</strong><small>${game.latestUpdate ? "Son duyuru: " + game.latestUpdate : game.releaseDate || "Güncellemeler takip ediliyor"}</small></div>
    <span class="release-tag">${releaseTag(game, days)}</span>
    <${Button} action="steam-remove" icon="close" cls="icon-button row-more" data-id=${game.id} aria-label="Takibi bırak" />
  </div>`;
};
// Sıra: çıkışı yaklaşanlar (en yakın önce), tarihi belirsiz bekleyenler, sonra çıkmış olanlar.
const watchOrder = (g) => (daysUntil(g) ?? (g.comingSoon ? 10000 : 20000));

function SteamPage() {
  const watchedIds = new Set(state.data.steam.map((g) => g.id));
  const filter = state.steamFilter || "Hepsi";
  const watched = [...state.data.steam]
    .filter((g) => filter === "Hepsi" || (filter === "Bekleniyor" ? g.comingSoon : !g.comingSoon))
    .sort((a, b) => watchOrder(a) - watchOrder(b) || a.name.localeCompare(b.name, "tr"));
  const searching = (state.query.steam || "").trim().length > 0;
  return html`
    <${Heading} title="Oyunlar" sub="Beklediğin oyunlar ve takip ettiğin güncellemeler (Steam).">
      <${Button} action="steam-check" icon="refresh" cls="ghost" title="Çıkış ve güncellemeleri şimdi kontrol et">Şimdi kontrol et<//>
    <//>
    <label class="search">
      <${Icon} n="search" />
      <input id="steam-search" value=${state.query.steam} placeholder="Oyun ara ya da Steam bağlantısı yapıştır… (çift tık takibe alır)" aria-label="Steam oyun ara" />
    </label>
    ${searching && html`<section class="card steam-results">
      <header class="card-header"><h2>Arama sonuçları</h2><small id="search-state"></small></header>
      <div class="rows">${state.steamResults.length
        ? state.steamResults.map((g) => html`<${SteamResult} key=${g.id} game=${g} watched=${watchedIds.has(g.id)} />`)
        : html`<${Empty} text="Sonuç bekleniyor…" />`}</div>
    </section>`}
    <div class="toolbar">
      <div class="segmented" role="group" aria-label="Takip süzgeci">${["Hepsi", "Bekleniyor", "Çıktı"].map((f) => html`<button type="button" key=${f} class=${filter === f ? "active" : ""} aria-pressed=${filter === f} onClick=${() => { state.steamFilter = f; render(); }}>${f}</button>`)}</div>
      <span class="spacer"></span><small class="muted">${state.data.steam.length} oyun takipte</small>
    </div>
    <section class="card"><div class="rows">${watched.length
      ? watched.map((g) => html`<${SteamWatch} key=${g.id} game=${g} />`)
      : html`<${Empty} text=${state.data.steam.length ? "Bu süzgeçte oyun yok." : "Takip ettiğin oyunlar burada görünecek. Yukarıdan ara ve çift tıkla."} />`}</div></section>`;
}
pageComponents.steam = SteamPage;
