namespace KisiselAsistan;

public record SteamQueryRequest(string Query);
public record SteamIdRequest(int Id);
public record SteamProfileRequest(string Profile);
// Price: kuruş cinsinden hedef fiyat (oyunun para biriminde); null hedefi kaldırır.
public record SteamTargetRequest(int Id, int? Price);
public record SteamImportResult(int Added, int Skipped, int Failed)
{
    public string Message => Added == 0 && Failed == 0 ? "İstek listendeki oyunların hepsi zaten takipte." : $"{Added} oyun takibe alındı" + (Skipped > 0 ? $", {Skipped} zaten takipteydi ya da sınır doldu" : "") + (Failed > 0 ? $", {Failed} oyun alınamadı (DLC ya da mağazada yok)" : "") + ".";
}
public record SteamCheckResult(int Errors, string Message, bool Busy = false) : IOperationOutcome { public bool Success => Errors == 0 && !Busy; }

// Store updates and notification decisions do not depend on a Steam panel.
public sealed class SteamService(ISteamCatalog client, SteamWatchStore store)
{
    private readonly SemaphoreSlim searchGate = new(1, 1);
    private readonly SemaphoreSlim mutationGate = new(1, 1);
    public IReadOnlyList<SteamWatch> Items => store.Items;
    public event Action? Changed;
    public event Action<string>? Released;
    public event Action<string>? Updated;
    public event Action<string>? Discounted;
    public event Action<string, IReadOnlyList<SteamSearchItem>>? SearchProgress;
    public async Task<List<SteamSearchItem>> SearchAsync(string query, CancellationToken token)
    {
        ValidateQuery(query); await searchGate.WaitAsync(token);
        try { return await client.SearchAsync(query.Trim(), token, items => SearchProgress?.Invoke(query, items)); }
        finally { searchGate.Release(); }
    }
    public async Task<SteamGame> TrackAsync(int id, CancellationToken token)
    {
        ValidateId(id); await mutationGate.WaitAsync(token);
        try {
            if (Items.Any(w => w.Id == id)) throw new InvalidOperationException("Bu oyun zaten takip listesinde.");
            var game = await client.GetAsync(id, token); token.ThrowIfCancellationRequested();
            if (game.Id != id || string.IsNullOrWhiteSpace(game.Name)) throw new InvalidDataException("Steam oyun bilgisi eşleşmedi.");
            List<SteamUpdate>? baseline = null;
            string? updateError = null;
            if (!game.ComingSoon) {
                try { baseline = await client.UpdatesAsync(id, token); }
                catch (OperationCanceledException) when (token.IsCancellationRequested) { throw; }
                catch (Exception ex) when (ex is HttpRequestException or IOException or InvalidOperationException or OperationCanceledException or System.Text.Json.JsonException or KeyNotFoundException) { updateError = "Güncelleme başlangıç kontrolü yapılamadı: " + ex.Message; }
            }
            // Do not report a cancelled operation after already saving a watch.
            token.ThrowIfCancellationRequested();
            store.Add(game);
            if (baseline != null) store.UpdateNews(id, baseline);
            if (updateError != null) store.Failure(id, updateError);
            Changed?.Invoke();
            return game;
        } finally { mutationGate.Release(); }
    }
    // İstek listesini içe aktarma: listedeki oyunlar sırayla takibe alınır (zaten takipte olanlar ve oyun olmayanlar atlanır).
    // Takip sınırı 50 oyun; dolunca durur. Profil gizliyse ya da liste boşsa Steam boş liste döner.
    public async Task<SteamImportResult> ImportWishlistAsync(string profile, CancellationToken token)
    {
        if (string.IsNullOrWhiteSpace(profile) || profile.Length > 200) throw new ArgumentException("Steam profil bağlantını ya da profil adını yaz.");
        var ids = await client.WishlistAsync(profile, token);
        if (ids.Count == 0) throw new InvalidOperationException("İstek listesi boş ya da gizli. Steam'de Profil → Gizlilik ayarlarından 'Oyun ayrıntıları'nı Herkese açık yap.");
        int added = 0, skipped = 0, failed = 0;
        foreach (var id in ids) {
            token.ThrowIfCancellationRequested();
            if (Items.Any(w => w.Id == id)) { skipped++; continue; }
            if (Items.Count >= 50) { skipped += ids.Count - added - skipped - failed; break; }
            try { await TrackAsync(id, token); added++; }
            catch (OperationCanceledException) when (token.IsCancellationRequested) { throw; }
            catch (Exception ex) when (ex is HttpRequestException or IOException or InvalidOperationException or OperationCanceledException or System.Text.Json.JsonException or KeyNotFoundException) { failed++; }
            await Task.Delay(300, token);
        }
        return new(added, skipped, failed);
    }
    public void SetTarget(int id, int? cents)
    {
        ValidateId(id);
        if (!Items.Any(w => w.Id == id)) throw new ArgumentException("Takip edilen oyun bulunamadı.");
        if (cents is < 1 or > 10_000_000) throw new ArgumentException("Hedef fiyat 0,01 ile 100.000 arasında olmalı.");
        store.SetTarget(id, cents); Changed?.Invoke();
    }
    public void Unwatch(int id) { ValidateId(id); if (!Items.Any(w => w.Id == id)) throw new ArgumentException("Takip edilen oyun bulunamadı."); store.Remove(id); Changed?.Invoke(); }
    public async Task<SteamCheckResult> CheckAsync(CancellationToken token)
    {
        if (!await mutationGate.WaitAsync(0, token)) return new(0, "Steam işlemi zaten sürüyor.", Busy: true);
        var errors = 0;
        try {
            foreach (var watch in Items.ToArray()) {
                token.ThrowIfCancellationRequested();
                try {
                    var game = await client.GetAsync(watch.Id, token); token.ThrowIfCancellationRequested();
                    if (game.Id != watch.Id) throw new InvalidDataException("Steam oyun bilgisi eşleşmedi.");
                    var released = store.Update(game, out var sale); Changed?.Invoke();
                    if (sale != null) Discounted?.Invoke(sale);
                    if (released) Released?.Invoke($"{game.Name} Steam'de çıktı{(game.EarlyAccess ? " (Erken Erişim)" : "")}.");
                    if (!game.ComingSoon && Items.Any(w => w.Id == game.Id)) {
                        var news = await client.UpdatesAsync(game.Id, token); token.ThrowIfCancellationRequested();
                        var fresh = store.UpdateNews(game.Id, news); Changed?.Invoke();
                        if (fresh.Count > 0) Updated?.Invoke(game.Name + " · " + fresh[0].Title + (fresh.Count > 1 ? $" (+{fresh.Count - 1} duyuru)" : ""));
                    }
                } catch (OperationCanceledException) when (token.IsCancellationRequested) { throw; }
                catch (Exception ex) when (ex is HttpRequestException or IOException or InvalidOperationException or OperationCanceledException or System.Text.Json.JsonException or KeyNotFoundException) { errors++; store.Failure(watch.Id, ex.Message); Changed?.Invoke(); }
                await Task.Delay(250, token);
            }
            return new(errors, errors == 0 ? $"Kontrol tamamlandı: {DateTime.Now:HH:mm}. Sonraki kontrol 30 dakika içinde." : $"{errors} oyun kontrol edilemedi. Bağlantıyı kontrol edip tekrar deneyebilirsin.");
        } finally { mutationGate.Release(); }
    }
    public void Register(OperationRegistry operations)
    {
        operations.Register<NoArguments, IReadOnlyList<SteamWatch>>("steam.list", "Takip edilen oyunları listele", _ => Items);
        operations.RegisterAsync<SteamQueryRequest, List<SteamSearchItem>>("steam.search", "Steam oyunlarını ara", (r, t) => SearchAsync(r.Query, t));
        operations.RegisterAsync<SteamQueryRequest, SteamGame>("steam.trackNamed", "Oyun adını ara; tek net eşleşme varsa çıkışını veya güncellemelerini takip et", async (r, t) => {
            var found = await SearchAsync(r.Query, t);
            var game = SelectNamed(r.Query, found) ?? throw new InvalidOperationException("Hangi oyun olduğu net değil. Steam sonuçlarından doğru oyunu seç.");
            return await TrackAsync(game.Id, t);
        }, r => ValidateQuery(r.Query));
        operations.RegisterAsync<SteamIdRequest, SteamGame>("steam.track", "Oyunun çıkışını veya güncellemelerini takip et", (r, t) => TrackAsync(r.Id, t));
        operations.Register<SteamIdRequest, bool>("steam.unwatch", "Oyun takibini bırak", r => { Unwatch(r.Id); return true; });
        operations.Register<SteamTargetRequest, bool>("steam.target", "Takip edilen oyuna hedef fiyat koy ya da kaldır", r => { SetTarget(r.Id, r.Price); return true; });
        operations.RegisterAsync<SteamProfileRequest, SteamImportResult>("steam.importWishlist", "Steam istek listesindeki oyunları takibe al", (r, t) => ImportWishlistAsync(r.Profile, t));
        operations.RegisterAsync<NoArguments, SteamCheckResult>("steam.check", "Çıkış ve güncelleme durumlarını kontrol et", (_, t) => CheckAsync(t));
    }
    private static void ValidateId(int id) { if (id <= 0) throw new ArgumentException("Geçerli bir Steam oyun numarası gerekli."); }
    private static void ValidateQuery(string query) { if (string.IsNullOrWhiteSpace(query) || query.Trim().Length > 150) throw new ArgumentException("Oyun adı 1–150 karakter olmalı."); }
    public static SteamSearchItem? SelectNamed(string name, IReadOnlyList<SteamSearchItem> games)
    {
        var normalized = GameNameMatcher.Normalize(name).Replace(" ", "");
        var unique = games.DistinctBy(g => g.Id).ToArray();
        var exact = unique.Where(g => GameNameMatcher.Normalize(g.Name).Replace(" ", "") == normalized || g.Id.ToString() == name.Trim()).ToArray();
        if (exact.Length > 0) return exact.Length == 1 ? exact[0] : null;
        if (normalized.Length < 4) return null;
        string Numbers(string text) => string.Join(" ", System.Text.RegularExpressions.Regex.Matches(GameNameMatcher.Normalize(text), @"\b(?:\d+|ii|iii|iv|v|vi|vii|viii|ix|x)\b").Select(m => m.Value));
        var ranked = unique.Where(g => Numbers(name) == Numbers(g.Name))
            .Where(g => { var candidate = GameNameMatcher.Normalize(g.Name).Replace(" ", ""); return Math.Abs(candidate.Length - normalized.Length) <= Math.Max(2, normalized.Length / 5); })
            .Select(g => (Game: g, Score: GameNameMatcher.Score(name, g.Name))).OrderByDescending(g => g.Score).ToArray();
        return ranked.Length > 0 && ranked[0].Score >= 0.8 && (ranked.Length == 1 || ranked[0].Score - ranked[1].Score >= 0.12) ? ranked[0].Game : null;
    }
}
