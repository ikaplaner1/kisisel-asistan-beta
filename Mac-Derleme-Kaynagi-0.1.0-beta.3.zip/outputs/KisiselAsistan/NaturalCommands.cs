using System.Text.RegularExpressions;

namespace KisiselAsistan;

internal static class NaturalCommands
{
    private const RegexOptions Options = RegexOptions.IgnoreCase | RegexOptions.CultureInvariant;
    private static Match Match(string text, string pattern) => Regex.Match(text, pattern, Options);
    internal static string Name(string text) => Regex.Replace(text.Trim().Trim('"', '“', '”'), @"['’](?:y?[ıiuü]|[dt][ae]n?|n[ıiuü]n)$", "", Options).Trim();
    internal static string Normalize(string text, string context = "")
    {
        var original = text.Trim().TrimEnd('.', '!', '?');
        text = Regex.Replace(original, @"^(?:(?:lütfen|please|bana|benim için)\s+)+", "", Options);
        text = Regex.Replace(text, @"\s+(?:lütfen|please)$", "", Options);
        text = Regex.Replace(text, @"\b(yapar|eder|açar|çalar|ekler|hatırlatır|bulur|yapabilir|edebilir|açabilir|çalabilir|ekleyebilir|hatırlatabilir|bulabilir)\s+m[ıi]s[ıi]n$", m => m.Groups[1].Value.ToLowerInvariant() switch { "yapar" or "yapabilir" => "yap", "eder" or "edebilir" => "et", "açar" or "açabilir" => "aç", "çalar" or "çalabilir" => "çal", "ekler" or "ekleyebilir" => "ekle", "hatırlatır" or "hatırlatabilir" => "hatırlat", _ => "bul" }, Options);
        // Do not interpret explicitly negated requests as positive actions.
        if (Match(text, @"\b(?:etme|ekleme|silme|açma|çalma|oynatma|kurma|hatırlatma|takip etme|don't|do not)\b").Success) return original;
        text = EnglishCommands.Conversational(text);
        var app = Match(text, @"^(steam|spotify)(?:\s*['’]?\s*(?:[dt][ae]n?|y?[ıi]))?\s*[, :]?\s+(.+)$");
        var domain = app.Success ? app.Groups[1].Value.ToLowerInvariant() : "";
        var body = app.Success ? app.Groups[2].Value : text;
        if (!app.Success) {
            var middle = Match(text, @"^(.+?)\s+(steam|spotify)(?:\s*['’]?\s*(?:[dt][ae]n?|y?[ıi]))?\s+(takip et|takibe al|ara|bul|çal|oynat)$");
            if (middle.Success) { domain = middle.Groups[2].Value.ToLowerInvariant(); body = middle.Groups[1].Value + " " + middle.Groups[3].Value; }
            var english = Match(text, @"^(track|find|search|play)\s+(.+?)\s+on\s+(steam|spotify)$");
            if (english.Success) { domain = english.Groups[3].Value.ToLowerInvariant(); body = english.Groups[1].Value + " " + english.Groups[2].Value; }
        }
        var effective = domain.Length > 0 ? domain : context;
        if (effective == "steam") {
            if (Match(body, @"^(?:takip et|takibe al|ekle|eklesene|takip etsene)$").Success) return "steam takip et";
            var ordinal = Match(body, @"^(ilk|birinci|ikinci|üçüncü|dördüncü|beşinci|\d+\.?)(?:yi|yı|yü|y[ıi])?\s+(?:oyunu\s+|sonucu\s+)?(seç|ekle|takip et|takibe al)$");
            if (ordinal.Success) {
                var number = ordinal.Groups[1].Value.ToLowerInvariant() switch { "ilk" or "birinci" => "1", "ikinci" => "2", "üçüncü" => "3", "dördüncü" => "4", "beşinci" => "5", _ => ordinal.Groups[1].Value.TrimEnd('.') };
                return "steam " + (ordinal.Groups[2].Value == "seç" ? "sonuç " + number + " seç" : "sonuç-ekle " + number);
            }
        }
        if (domain == "steam" || domain.Length == 0) {
            var named = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:takip et|takibe al|takip listeme ekle|takip listesine ekle|takibe ekle|takip etsene|takibe alsana|track)$");
            if (!named.Success) named = Match(body, @"^(.+?)\s+(?:oyunu\s+)?(?:çıktığında|çıkınca|yayınlandığında|yayınlanınca)\s+(?:bana\s+)?(?:haber ver|bildir|bildirim gönder)$");
            if (!named.Success) named = Match(body, @"^(?:takip et|takibe al|track)\s+(.+)$");
            if (!named.Success && effective == "steam") named = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:ekle|eklesene)$");
            if (named.Success && !Match(named.Groups[1].Value, @"^(?:seçili|seçili oyunu|şunu|bunu|bu oyunu)$").Success) return "steam takip-isim " + Name(named.Groups[1].Value);
            var remove = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:takibi bırak|takipten çıkar|takip listemden çıkar|takip listesinden kaldır|takibini bırak)$");
            if (remove.Success) return "steam takip-bırak-isim " + Name(remove.Groups[1].Value);
            if (domain == "steam") {
                var search = Match(body, @"^(?:ara|bul|oyun ara|oyun bul|search|find)\s+(.+)$");
                if (!search.Success) search = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:ara|bul|arasana|bulsana)$");
                if (search.Success) return "steam ara " + Name(search.Groups[1].Value);
            }
        }
        if (domain == "spotify" || domain.Length == 0) {
            if (effective == "spotify" && Match(body, @"^(?:şarkıyı|müziği)\s+(?:oynat|çal|devam ettir)$").Success) return "Spotify oynat";
            var song = Match(body, @"^(?:çal|oynat|play)\s+(.+)$");
            if (!song.Success) song = Match(body, @"^(.+?)\s+(?:şarkısını\s+)?(?:çal|oynat|çalsana|oynatsana)$");
            if (song.Success && song.Groups[1].Value != "Spotify") return "Spotify " + Name(song.Groups[1].Value) + " çal";
        }
        var duration = @"([\p{L}\d -]+?)\s+(saniye|dakika|saat)";
        var reminder = Match(text, "^" + duration + @"\s+sonra\s+(.+?)\s+(?:hatırlat|hatırlatsana)$");
        if (reminder.Success) return $"{reminder.Groups[1].Value} {reminder.Groups[2].Value} sonra {reminder.Groups[3].Value} hatırlat";
        var timer = Match(text, @"^(?:hatırlatıcı|zamanlayıcı|alarm)\s+(?:kur|ayarla|oluştur)\s+" + duration + "$");
        if (!timer.Success) timer = Match(text, "^" + duration + @"(?:lik|lık)?\s+(?:alarm|zamanlayıcı)(?:\s+(?:kur|ayarla|oluştur))?$");
        if (timer.Success) return $"{timer.Groups[1].Value} {timer.Groups[2].Value} hatırlatıcı";
        if (effective == "steam") {
            if (Match(body, @"^(?:şunu|bunu|bu oyunu|seçili oyunu)\s+(?:ekle|takibe al|takip et)$").Success) return "steam takip et";
            if (Match(body, @"^(?:takiplerimi|oyunlarımı|takip ettiğim oyunları|takip listemi|oyun listemi)\s+(?:göster|aç)$").Success) return "steam takipleri göster";
            if (Match(body, @"^(?:oyunları\s+)?(?:kontrol et|kontrol etsene|kontrol eder misin|güncelle)$").Success) return "steam kontrol et";
            var pick = Match(body, @"^(?:ilk|birinci|ikinci|üçüncü|sonuç\s+\d+)\s+(?:oyunu\s+)?(?:seç|ekle|takip et|takibe al)$");
            if (pick.Success) {
                var index = body.StartsWith("ikinci", StringComparison.OrdinalIgnoreCase) ? 2 : body.StartsWith("üçüncü", StringComparison.OrdinalIgnoreCase) ? 3 : Match(body, @"\d+").Success ? int.Parse(Match(body, @"\d+").Value) : 1;
                return "steam " + (Match(body, @"\bseç$").Success ? "sonuç " + index + " seç" : "sonuç-ekle " + index);
            }
        }
        if (effective == "spotify") {
            if (Match(body, @"^(?:duraklat|duraklatsana|müziği durdur|şarkıyı durdur|müziği duraklat|şarkıyı duraklat|pause)$").Success) return "Spotify duraklat";
            if (Match(body, @"^(?:devam et|oynat|çal|müziği devam ettir|play|resume)$").Success) return "Spotify oynat";
            if (Match(body, @"^(?:sonraki(?: şarkı)?|şarkıyı geç|sonraki şarkıya geç|next)$").Success) return "Spotify sonraki";
            if (Match(body, @"^(?:önceki(?: şarkı)?|önceki şarkıya geç|bir önceki şarkı|previous)$").Success) return "Spotify önceki";
        }
        if (Match(text, @"^(?:hatırlatıcılarımı|hatırlatmalarımı|hatırlatıcı listesini)\s+(?:göster|aç)$").Success) return "hatırlatıcıları göster";
        return text;
    }
    internal static void Verify()
    {
        var samples = new Dictionary<string, string> {
            ["steamden hades takip et"] = "steam takip-isim hades", ["steamde hades takip et"] = "steam takip-isim hades",
            ["Steam'den hades takip et"] = "steam takip-isim hades", ["Steam'de Hades'i takip et"] = "steam takip-isim Hades",
            ["Lütfen Steam’den Hades’i takip et"] = "steam takip-isim Hades", ["Hades'i takip listeme ekle"] = "steam takip-isim Hades",
            ["Hades çıkınca bana haber ver"] = "steam takip-isim Hades", ["Hades oyununu takip et"] = "steam takip-isim Hades",
            ["Steam takip et Hades"] = "steam takip-isim Hades", ["Hades'i takipten çıkar"] = "steam takip-bırak-isim Hades",
            ["Steam Hades'i bul"] = "steam ara Hades", ["Steam'de Hades ara"] = "steam ara Hades",
            ["Spotify'dan Tame Impala çal"] = "Spotify Tame Impala çal", ["Tame Impala çalsana"] = "Spotify Tame Impala çal",
            ["Spotify çal Please Please Me"] = "Spotify Please Please Me çal", ["bana on dakika sonra su içmeyi hatırlatır mısın"] = "on dakika sonra su içmeyi hatırlat",
            ["10 dakikalık alarm kur"] = "10 dakika hatırlatıcı", ["hatırlatıcı kur on dakika"] = "on dakika hatırlatıcı"
            , ["Hades'i Steam'de takip et"] = "steam takip-isim Hades", ["Steam Hades’i takip eder misin"] = "steam takip-isim Hades",
            ["track Hades on Steam"] = "steam takip-isim Hades", ["play Tame Impala on Spotify"] = "Spotify Tame Impala çal",
            ["Steam Hades ekle"] = "steam takip-isim Hades", ["Steam ilk oyunu takip et"] = "steam sonuç-ekle 1",
            ["Steam ikinciyi ekle"] = "steam sonuç-ekle 2", ["Steam 2. oyunu seç"] = "steam sonuç 2 seç",
            ["Steam takip listemi göster"] = "steam takipleri göster", ["Spotify müziği duraklat"] = "Spotify duraklat",
            ["hatırlatıcılarımı göster"] = "hatırlatıcıları göster", ["Spotify önceki şarkıya geç"] = "Spotify önceki"
        };
        // Polite reminder endings must retain their action rather than remove it.
        foreach (var sample in samples) if (Normalize(sample.Key) != sample.Value) throw new Exception("Doğal komut başarısız: " + sample.Key + " => " + Normalize(sample.Key));
        if (Normalize("ilk oyunu ekle", "steam") != "steam sonuç-ekle 1" || Normalize("duraklat", "spotify") != "Spotify duraklat" || Normalize("Hades takip etme") != "Hades takip etme" || Normalize("Spotify Don't Stop Me Now çal") != "Spotify Don't Stop Me Now çal") throw new Exception("Bağlam veya isim koruma başarısız.");
    }
}
