using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace KisiselAsistan;

public sealed class SpotifyPlayback(ISpotifySession session, HttpClient http) : ISpotifyPlayback
{
    public async Task<List<SpotifyTrack>> SearchAsync(string query, CancellationToken token)
    {
        if (string.IsNullOrWhiteSpace(query) || query.Length > 200) throw new ArgumentException("Şarkı ve sanatçı adı gir (en fazla 200 karakter).");
        using var json = await RequestAsync(HttpMethod.Get, "search?type=track&limit=10&q=" + Uri.EscapeDataString(query.Trim()), null, token);
        return json!.RootElement.GetProperty("tracks").GetProperty("items").EnumerateArray()
            .Where(x => !x.TryGetProperty("is_playable", out var playable) || playable.ValueKind != JsonValueKind.False)
            .Select(ParseTrack).ToList();
    }
    private static SpotifyTrack ParseTrack(JsonElement item) => new(item.GetProperty("uri").GetString()!, item.GetProperty("name").GetString()!,
        string.Join(", ", item.GetProperty("artists").EnumerateArray().Select(a => a.GetProperty("name").GetString())),
        item.TryGetProperty("album", out var album) && album.TryGetProperty("images", out var images) && images.GetArrayLength() > 0 ? images[images.GetArrayLength() > 1 ? 1 : 0].GetProperty("url").GetString() : null,
        album.ValueKind == JsonValueKind.Object && album.TryGetProperty("uri", out var albumUri) && SpotifyTrack.ValidAlbum(albumUri.GetString()) ? albumUri.GetString() : null);
    public async Task<SpotifyPlaying?> CurrentAsync(CancellationToken token)
    {
        using var json = await RequestAsync(HttpMethod.Get, "me/player", null, token);
        return json is null ? null : ParsePlaying(json.RootElement);
    }
    internal static SpotifyPlaying? ParsePlaying(JsonElement root)
    {
        if (!root.TryGetProperty("item", out var item) || item.ValueKind != JsonValueKind.Object || !item.TryGetProperty("artists", out _)) return null;
        return new(ParseTrack(item), root.TryGetProperty("progress_ms", out var progress) && progress.ValueKind == JsonValueKind.Number && progress.TryGetInt32(out var position) ? Math.Max(0, position) : 0,
            item.TryGetProperty("duration_ms", out var duration) && duration.TryGetInt32(out var milliseconds) ? Math.Max(0, milliseconds) : 0,
            root.TryGetProperty("is_playing", out var playing) && playing.ValueKind == JsonValueKind.True,
            root.TryGetProperty("device", out var device) && device.ValueKind == JsonValueKind.Object && device.TryGetProperty("name", out var name) ? name.GetString() ?? "Spotify" : "Spotify",
            device.ValueKind == JsonValueKind.Object && device.TryGetProperty("volume_percent", out var volume) && volume.ValueKind == JsonValueKind.Number && volume.TryGetInt32(out var percent) ? Math.Clamp(percent, 0, 100) : null,
            device.ValueKind == JsonValueKind.Object && device.TryGetProperty("id", out var id) ? id.GetString() : null,
            device.ValueKind == JsonValueKind.Object && device.TryGetProperty("supports_volume", out var supports) && supports.ValueKind == JsonValueKind.True,
            root.TryGetProperty("shuffle_state", out var shuffle) && shuffle.ValueKind == JsonValueKind.True,
            root.TryGetProperty("repeat_state", out var repeat) && repeat.ValueKind == JsonValueKind.String && SpotifyPlaying.ValidRepeat(repeat.GetString()) ? repeat.GetString()! : "off");
    }
    public async Task<string> SetVolumeAsync(int percent, string deviceId, CancellationToken token)
    {
        if (percent is < 0 or > 100 || string.IsNullOrWhiteSpace(deviceId) || deviceId.Length > 256) throw new ArgumentException("Geçerli cihaz ve 0–100 ses seviyesi gerekli.");
        using var result = await RequestAsync(HttpMethod.Put, "me/player/volume?volume_percent=" + percent + "&device_id=" + Uri.EscapeDataString(deviceId), null, token);
        return "Spotify sesi: %" + percent;
    }
    public async Task<string> SeekAsync(int positionMs, string deviceId, CancellationToken token)
    {
        if (positionMs < 0 || string.IsNullOrWhiteSpace(deviceId) || deviceId.Length > 256) throw new ArgumentException("Geçerli cihaz ve konum gerekli.");
        using var result = await RequestAsync(HttpMethod.Put, "me/player/seek?position_ms=" + positionMs + "&device_id=" + Uri.EscapeDataString(deviceId), null, token);
        return "Konum: " + TimeSpan.FromMilliseconds(positionMs).ToString(@"m\:ss");
    }
    // Şarkıyı çalan cihazın sırasına ekler; o an çalan bir şey yoksa Spotify 404 döner.
    public async Task<string> QueueAsync(SpotifyTrack track, CancellationToken token)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(track.Uri, "^spotify:track:[A-Za-z0-9]{22}$")) throw new ArgumentException("Geçersiz şarkı adresi.");
        try { using var result = await RequestAsync(HttpMethod.Post, "me/player/queue?uri=" + Uri.EscapeDataString(track.Uri), null, token); }
        catch (InvalidOperationException) {
            if (await CurrentAsync(token) is null) throw new InvalidOperationException("Sıraya eklemek için önce Spotify'da bir şarkı çalıyor olmalı.");
            throw;
        }
        return "Sıraya eklendi: " + track;
    }
    // Kullanıcının çalma listeleri (kendisininkiler ve takip ettikleri), Spotify'daki sırasıyla.
    // Şubat 2026'dan beri Spotify şarkı sayısını "tracks" yerine "items" altında veriyor; ikisi de okunur.
    public async Task<List<SpotifyPlaylist>> PlaylistsAsync(CancellationToken token)
    {
        if (!session.Allows("playlist-read-private")) throw new InvalidOperationException("Çalma listelerini görmek için Spotify hesabını bir kez yeniden bağla (Ayarlar → Spotify). Yeni izin gerekiyor.");
        using var json = await RequestAsync(HttpMethod.Get, "me/playlists?limit=50", null, token);
        return json!.RootElement.GetProperty("items").EnumerateArray().Where(x => x.ValueKind == JsonValueKind.Object && SpotifyPlaylist.Valid(x.GetProperty("uri").GetString()))
            .Select(x => new SpotifyPlaylist(x.GetProperty("uri").GetString()!, x.GetProperty("name").GetString() ?? "",
                x.TryGetProperty("owner", out var owner) && owner.TryGetProperty("display_name", out var by) ? by.GetString() ?? "" : "",
                Total(x, "items") ?? Total(x, "tracks") ?? 0,
                x.TryGetProperty("images", out var images) && images.ValueKind == JsonValueKind.Array && images.GetArrayLength() > 0 ? Cover(images[images.GetArrayLength() - 1].GetProperty("url").GetString()) : null))
            .ToList();
    }
    private static int? Total(JsonElement list, string name) => list.TryGetProperty(name, out var part) && part.ValueKind == JsonValueKind.Object && part.TryGetProperty("total", out var total) && total.TryGetInt32(out var count) ? count : null;
    // Kapak yalnız uygulamanın kapak önbelleğinin izin verdiği sunuculardan (karışık "mosaic" görselleri simgeyle gösterilir).
    private static string? Cover(string? url) => url is not null && (url.StartsWith("https://i.scdn.co/image/", StringComparison.Ordinal) || url.StartsWith("https://image-cdn-", StringComparison.Ordinal)) ? url : null;
    // Listeyi bu bilgisayarda baştan ya da karışık çalar. Spotify yeni listeyi verilen konumdan başlatır; konum
    // verilmezse ilk şarkıdan. Karışıkta rastgele bir şarkıdan başlanır (şarkı sayısı bilinmezse Spotify'ın karışık
    // başlangıcına bırakılır) ve karışık mod çalmadan önce de sonra da açılır: önceden açılanı yeni listede yok
    // sayabiliyor (gerçek denemede görüldü, 30 Ekim 2026).
    public async Task<string> PlayPlaylistAsync(string uri, bool shuffle, int tracks, CancellationToken token)
    {
        if (!SpotifyPlaylist.Valid(uri)) throw new ArgumentException("Geçersiz çalma listesi adresi.");
        var deviceId = await ComputerAsync(token);
        var device = "device_id=" + Uri.EscapeDataString(deviceId);
        // Kısayol adımı şarkı sayısını bilmez: rastgele başlangıç için liste kitaplıktan bulunur.
        if (shuffle && tracks <= 1)
            try { tracks = (await PlaylistsAsync(token)).FirstOrDefault(p => p.Uri == uri)?.Tracks ?? 0; } catch (Exception ex) when (ex is not OperationCanceledException) { }
        using (var mode = await RequestAsync(HttpMethod.Put, "me/player/shuffle?state=" + (shuffle ? "true" : "false") + "&" + device, null, token)) { }
        object body = !shuffle ? new { context_uri = uri, offset = new { position = 0 } }
            : tracks > 1 ? new { context_uri = uri, offset = new { position = Random.Shared.Next(tracks) } }
            : new { context_uri = uri };
        using (var sent = await RequestAsync(HttpMethod.Put, "me/player/play?" + device, JsonSerializer.Serialize(body), token)) { }
        if (!shuffle) return "Liste çalıyor.";
        await Task.Delay(400, token);
        using var on = await RequestAsync(HttpMethod.Put, "me/player/shuffle?state=true&" + device, null, token);
        return "Liste karışık çalıyor.";
    }
    // Karışık ve tekrar o an çalan cihazda ayarlanır (cihaz verilmeyince Spotify etkin cihazı kullanır).
    public async Task<string> ShuffleAsync(bool on, CancellationToken token)
    {
        using var result = await RequestAsync(HttpMethod.Put, "me/player/shuffle?state=" + (on ? "true" : "false"), null, token);
        return on ? "Karışık çalma açık." : "Karışık çalma kapalı.";
    }
    public async Task<string> RepeatAsync(string mode, CancellationToken token)
    {
        if (!SpotifyPlaying.ValidRepeat(mode)) throw new ArgumentException("Tekrar seçeneği geçersiz.");
        using var result = await RequestAsync(HttpMethod.Put, "me/player/repeat?state=" + mode, null, token);
        return mode switch { "context" => "Liste tekrarlanıyor.", "track" => "Şarkı tekrarlanıyor.", _ => "Tekrar kapalı." };
    }
    // Çalınacak bilgisayar: bu makinenin adındaki Spotify, yoksa tek açık bilgisayar (telefon seçilmez).
    private async Task<string> ComputerAsync(CancellationToken token)
    {
        using var devices = await RequestAsync(HttpMethod.Get, "me/player/devices", null, token);
        var computers = devices!.RootElement.GetProperty("devices").EnumerateArray()
            .Where(x => x.GetProperty("type").GetString() == "Computer" && !x.GetProperty("is_restricted").GetBoolean() && x.GetProperty("id").ValueKind == JsonValueKind.String).ToList();
        var machine = computers.Where(x => string.Equals(x.GetProperty("name").GetString(), Environment.MachineName, StringComparison.OrdinalIgnoreCase)).ToList();
        var candidates = machine.Count > 0 ? machine : computers;
        if (candidates.Count == 0) throw new InvalidOperationException("Spotify masaüstü uygulamasını açıp hesabına giriş yap, sonra tekrar dene. Kullanılabilir bilgisayar bulunamadı.");
        if (candidates.Count > 1) throw new InvalidOperationException("Birden fazla Spotify bilgisayarı açık. Diğer bilgisayarlarda Spotify'ı kapatıp tekrar dene.");
        return candidates[0].GetProperty("id").GetString()!;
    }
    public async Task<string> PlayAsync(SpotifyTrack track, CancellationToken token)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(track.Uri, "^spotify:track:[A-Za-z0-9]{22}$")) throw new ArgumentException("Geçersiz şarkı adresi.");
        var deviceId = await ComputerAsync(token);
        // Albümü belliyse şarkı albümün içinden çalınır (bitince albüm devam eder); değilse yalnız şarkı.
        var body = SpotifyTrack.ValidAlbum(track.AlbumUri)
            ? JsonSerializer.Serialize(new { context_uri = track.AlbumUri, offset = new { uri = track.Uri }, position_ms = 0 })
            : JsonSerializer.Serialize(new { uris = new[] { track.Uri }, position_ms = 0 });
        using var sent = await RequestAsync(HttpMethod.Put, "me/player/play?device_id=" + Uri.EscapeDataString(deviceId), body, token);
        for (var attempt = 0; attempt < 3; attempt++) {
            await Task.Delay(600, token);
            using var state = await RequestAsync(HttpMethod.Get, "me/player", null, token);
            if (state is not null && state.RootElement.TryGetProperty("is_playing", out var playing) && playing.GetBoolean() &&
                state.RootElement.TryGetProperty("item", out var item) && item.ValueKind == JsonValueKind.Object &&
                item.GetProperty("uri").GetString() == track.Uri && state.RootElement.GetProperty("device").GetProperty("id").GetString() == deviceId)
                return "Çalıyor: " + track;
        }
        return "Çalma isteği gönderildi: " + track + ". Spotify oynatma durumu henüz doğrulanmadı.";
    }
    private async Task<JsonDocument?> RequestAsync(HttpMethod method, string endpoint, string? body, CancellationToken token)
    {
        // Elle kurulan istek HttpClient'ın varsayılan sürümünü almaz; HTTP/2 tercihi buradan geçer.
        using var request = new HttpRequestMessage(method, "https://api.spotify.com/v1/" + endpoint) { Version = http.DefaultRequestVersion, VersionPolicy = http.DefaultVersionPolicy };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", await session.AccessAsync(token));
        if (body is not null) request.Content = new StringContent(body, Encoding.UTF8, "application/json");
        using var response = await http.SendAsync(request, token);
        if (!response.IsSuccessStatusCode) {
            var message = response.StatusCode switch {
                HttpStatusCode.Unauthorized => "Spotify bağlantısı geçersiz. Hesabını yeniden bağla.",
                HttpStatusCode.Forbidden => "Spotify oynatma izni vermedi. Premium hesabını ve Developer uygulamasının kullanıcı erişimini kontrol et.",
                HttpStatusCode.NotFound => "Spotify cihazı hazır değil. Masaüstü Spotify'ı açıp tekrar dene.",
                HttpStatusCode.TooManyRequests => "Spotify istek sınırına ulaşıldı. Biraz bekleyip tekrar dene.",
                _ => $"Spotify işlemi tamamlanamadı (HTTP {(int)response.StatusCode})." };
            throw new InvalidOperationException(message);
        }
        if (response.StatusCode == HttpStatusCode.NoContent) return null;
        // Oynatıcı komutları (seek, volume, play) başarıda boş ya da JSON olmayan gövde döndürebilir; okunacak bir şey yoktur.
        var text = await response.Content.ReadAsStringAsync(token);
        if (string.IsNullOrWhiteSpace(text)) return null;
        try { return JsonDocument.Parse(text); }
        catch (JsonException) when (method != HttpMethod.Get) { return null; }
    }
}
