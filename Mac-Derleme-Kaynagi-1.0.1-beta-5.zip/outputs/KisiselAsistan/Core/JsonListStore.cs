using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace KisiselAsistan;

public sealed class JsonListStore<T>(string path)
{
    private readonly string mutexName = (OperatingSystem.IsWindows() ? "Local\\KisiselAsistanData-" : "KisiselAsistanData-") + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Path.GetFullPath(path).ToUpperInvariant())));
    public List<T> Read() => Locked(ReadFile);
    public void Modify(Func<List<T>, List<T>> edit) => Locked(() => {
        var next = edit(ReadFile());
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temporary = path + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(next));
        // A scanner can briefly hold a newly written file on Windows. Keep the
        // atomic replacement and retry only transient access/sharing failures.
        for (var attempt = 0; ; attempt++) {
            try { File.Move(temporary, path, true); break; }
            catch (UnauthorizedAccessException) when (attempt < 4) { Thread.Sleep(50 * (attempt + 1)); }
            catch (IOException ex) when (attempt < 4 && (ex.HResult & 0xffff) is 32 or 33) { Thread.Sleep(50 * (attempt + 1)); }
        }
        return true;
    });
    private List<T> ReadFile() => File.Exists(path) ? JsonSerializer.Deserialize<List<T>>(File.ReadAllText(path))
        ?? throw new InvalidDataException("Kayıt dosyası okunamadı.") : [];
    private TResult Locked<TResult>(Func<TResult> action)
    {
        using var mutex = new Mutex(false, mutexName);
        var acquired = false;
        try {
            try { acquired = mutex.WaitOne(TimeSpan.FromSeconds(5)); } catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) throw new IOException("Kayıtlar meşgul. Tekrar dene.");
            return action();
        } finally { if (acquired) mutex.ReleaseMutex(); }
    }
}

