const {execFileSync} = require('node:child_process');
const path = require('node:path');
module.exports = async context => {
  const app = path.join(context.appOutDir, context.packager.appInfo.productFilename + '.app');
  // Validate the final signed bundle before either archive is produced.
  execFileSync('/usr/bin/codesign', ['--verify', '--deep', '--strict', '--verbose=2', app], {stdio:'inherit'});
  execFileSync('/usr/bin/codesign', ['--verify', '--strict', '--verbose=2', path.join(app,'Contents/Resources/host/Assistant.Host')], {stdio:'inherit'});
};
