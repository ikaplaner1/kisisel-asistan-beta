"use strict";
// İlk açılış tanıtımı: gerçek ekranın üstünde ışıklı tur. Sayfa kararır, anlatılan öğe aydınlanır, yanında kısa bir kart çıkar.
// Büyük görünümde bir kez kendiliğinden açılır (küçük görünümde açılırsa büyük görünüme geçince); Ayarlar → "Tanıtım" ile yeniden.
// Görüldüğü bu bilgisayarda localStorage "tour-v1" ile hatırlanır. Testte kendiliğinden açılmaz (live.testing).
// Düğmeler data-tour niteliği kullanır; sayfanın data-action yakalayıcısına karışmaz.

const TOUR_KEY = "tour-v1";
const TOUR_STEPS = [
  {
    title: "Kişisel Asistan'a hoş geldin",
    text: "Dört kısa adımda en çok işine yarayacak yerleri göstereyim. İstediğin an Esc ile çıkabilirsin.",
    next: "Başlayalım",
    skip: "Şimdi değil",
  },
  {
    target: ".command-bar",
    title: "Aklına geleni yaz ya da söyle",
    text: "Saat yazarsan plan olur: “yarın 9'da diş hekimi”. Saatsiz yazdığın bugünün işidir, “bir ara …” acelesi olmayanlara gider. “lo-fi çal” gibi komutlar da burada. Mikrofona basıp söyleyebilirsin; Ctrl+Alt+Boşluk asistan arkadayken bile çalışır.",
  },
  {
    target: ".now-card",
    title: "Şimdi ne var",
    text: "Sıradaki iş ya da sürmekte olan odak turu burada; altında günün saatli işleri. Uzun bir boşluğun varsa bu kart sana yapabileceğin bir iş önerir.",
  },
  {
    target: ".today-free",
    title: "Boş bir anında",
    text: "Saati olmayan işlerin hep göz önünde. Sağdaki müzik, oyun, stok ve kısayol kartlarını “Düzenle” ile kaldırıp sıralayabilirsin. Esc seni her yerden buraya getirir.",
  },
  {
    target: ".sidebar",
    title: "Bölümler ve ayarlar",
    text: "Takvim, Oyunlar, Stok (ürün fiyat ve stok takibi), Kısayollar ve AI soldaki menüde. Ders ya da iş programını Takvim → İçe aktar ile tek seferde ekleyebilirsin. Ayarlar'dan tema, sessiz saatler, sabah özeti ve odak sürelerini kendine göre ayarla.",
    next: "Bitir",
  },
];

let tourStep = -1;
let tourTried = false;

function tourSeen() {
  try {
    return localStorage.getItem(TOUR_KEY) === "done";
  } catch {
    return true;
  }
}
function markTourSeen() {
  try {
    localStorage.setItem(TOUR_KEY, "done");
  } catch {}
}
// render() her çizimden sonra çağırır; koşullar uygunsa bir kez başlatır.
function tourAutoStart() {
  if (tourTried || tourStep >= 0 || !state.data) return;
  if (state.data.live?.testing || compact() || state.modal || document.hidden) return;
  tourTried = true;
  if (!tourSeen()) setTimeout(() => !state.modal && startTour(), 600);
}
function startTour() {
  closeMenu();
  if (state.page !== "today") {
    state.page = "today";
    render();
  }
  let layer = $("#tour");
  if (!layer) {
    layer = document.createElement("div");
    layer.id = "tour";
    layer.innerHTML = `<div class="tour-spot"></div><section class="tour-card" role="dialog" aria-modal="true" aria-live="polite"></section>`;
    document.body.append(layer);
    layer.addEventListener("click", (e) => {
      const button = e.target.closest("[data-tour]");
      if (button) tourGo(button.dataset.tour);
    });
  }
  tourStep = 0;
  showTourStep();
}
function tourGo(where) {
  if (where === "skip" || where === "close") return closeTour();
  if (where === "back") tourStep = Math.max(0, tourStep - 1);
  else if (tourStep === TOUR_STEPS.length - 1) return closeTour(true);
  else tourStep++;
  showTourStep();
}
function closeTour(finished = false) {
  if (tourStep < 0) return;
  tourStep = -1;
  markTourSeen();
  const layer = $("#tour");
  if (layer && !reducedMotion()) layer.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 140, easing: "ease-in" }).onfinish = () => layer.remove();
  else layer?.remove();
  if (finished) toast("Hazırsın. Tanıtımı Ayarlar'dan yeniden açabilirsin.");
}
function showTourStep() {
  const step = TOUR_STEPS[tourStep],
    layer = $("#tour"),
    card = $(".tour-card", layer),
    last = tourStep === TOUR_STEPS.length - 1,
    dots = TOUR_STEPS.slice(1).map((_, i) => `<i class="${i + 1 === tourStep ? "on" : ""}"></i>`).join("");
  card.setAttribute("aria-label", step.title);
  card.innerHTML = `<header><h2>${esc(step.title)}</h2><button type="button" class="icon-button" data-tour="close" aria-label="Tanıtımı kapat">${I("close")}</button></header>
    <p>${esc(step.text)}</p>
    <footer>${tourStep > 0 ? `<span class="tour-dots" aria-label="${tourStep}. adım, toplam ${TOUR_STEPS.length - 1}">${dots}</span>` : ""}
      ${tourStep > 1 ? `<button type="button" class="ghost" data-tour="back">Geri</button>` : ""}
      ${tourStep === 0 ? `<button type="button" class="ghost" data-tour="skip">${esc(step.skip)}</button>` : ""}
      <button type="button" class="primary" data-tour="next">${esc(step.next || (last ? "Bitir" : "İleri"))}</button></footer>`;
  placeTour();
  if (!reducedMotion()) card.animate([{ opacity: 0, transform: "translateY(6px)" }, { opacity: 1, transform: "none" }], { duration: 180, easing: easeOut });
  $("[data-tour=next]", card).focus();
}
// Işık hedef öğenin üstüne, kart yanına (sağ, alt, üst, sol sırasıyla sığan ilk yere) konur. Hedef yoksa ikisi de ortadadır.
function placeTour() {
  const layer = $("#tour");
  if (!layer || tourStep < 0) return;
  const spot = $(".tour-spot", layer),
    card = $(".tour-card", layer),
    target = TOUR_STEPS[tourStep].target && $(TOUR_STEPS[tourStep].target);
  const box = target?.getBoundingClientRect();
  const margin = 12,
    w = card.offsetWidth,
    h = card.offsetHeight;
  if (!box || !box.width) {
    layer.classList.add("centered");
    Object.assign(spot.style, { left: innerWidth / 2 + "px", top: innerHeight / 2 + "px", width: "0px", height: "0px" });
    Object.assign(card.style, { left: (innerWidth - w) / 2 + "px", top: (innerHeight - h) / 2 + "px" });
    return;
  }
  layer.classList.remove("centered");
  const pad = 6,
    r = { left: box.left - pad, top: box.top - pad, right: box.right + pad, bottom: box.bottom + pad };
  Object.assign(spot.style, { left: r.left + "px", top: r.top + "px", width: r.right - r.left + "px", height: r.bottom - r.top + "px" });
  const clampX = (x) => Math.min(Math.max(margin, x), innerWidth - w - margin),
    clampY = (y) => Math.min(Math.max(margin, y), innerHeight - h - margin);
  const spots = [
    [innerWidth - r.right - margin >= w + margin, () => [r.right + margin, clampY(r.top)]],
    [innerHeight - r.bottom - margin >= h + margin, () => [clampX(r.left), r.bottom + margin]],
    [r.top - margin >= h + margin, () => [clampX(r.left), r.top - margin - h]],
    [r.left - margin >= w + margin, () => [r.left - margin - w, clampY(r.top)]],
  ];
  // Hiçbir yana tam sığmıyorsa (büyük Şimdi kartı, alçak pencere) hedefi en az örten yan seçilir; ortaya konmaz.
  const covered = ([x, y]) => Math.max(0, Math.min(x + w, r.right) - Math.max(x, r.left)) * Math.max(0, Math.min(y + h, r.bottom) - Math.max(y, r.top));
  const least = () => spots.map(([, at]) => at()).map(([x, y]) => [clampX(x), clampY(y)]).sort((a, b) => covered(a) - covered(b))[0];
  const [x, y] = (spots.find(([fits]) => fits)?.[1] ?? least)();
  Object.assign(card.style, { left: x + "px", top: y + "px" });
}
addEventListener("resize", () => tourStep >= 0 && placeTour());
document.addEventListener(
  "keydown",
  (e) => {
    if (tourStep < 0) return;
    // Tur açıkken klavye yalnız turu yönetir (Ctrl+K gibi kısayollar arkada çalışmasın).
    if (e.key === "Escape") closeTour();
    else if (e.key === "ArrowRight") tourGo("next");
    else if (e.key === "ArrowLeft" && tourStep > 1) tourGo("back");
    else if (e.key !== "Tab" && e.key !== "Enter" && e.key !== " ") e.preventDefault();
    else return;
    e.preventDefault();
    e.stopPropagation();
  },
  true,
);
