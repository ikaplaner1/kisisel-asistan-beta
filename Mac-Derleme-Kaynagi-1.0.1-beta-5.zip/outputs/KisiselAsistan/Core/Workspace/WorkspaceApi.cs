using System.Globalization;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace KisiselAsistan;

// Arayüzü taşıyan masaüstü kabuğunun (Windows penceresi ya da Mac Electron + host) sağladıkları.
// Platforma özgü işlemler (pencere, AI panelleri, hesap bağlantıları, ses, dosya seçme) DispatchAsync'e düşer.
public interface IWorkspaceHost
{
    bool Testing { get; }
    // Arayüzün canlı durumu: tema renkleri, görünüm, sesli asistanın aşaması …
    object Live();
    // Tema listesi (ad + 9 renk).
    IReadOnlyList<WorkspaceTheme> Themes();
    // Hatırlatıcıyı tamamla (ADHD hatırlatmasında onay bildirimle istenir).
    void CompleteReminder(Guid id);
    Task<object?> DispatchAsync(string method, JsonElement parameters);
}
public sealed record WorkspaceTheme(string Name, string[] Colors);
// Arayüz işlemlerinin dayandığı hizmetler (her iki kabukta da aynı şekilde kurulur).
public sealed record WorkspaceServices(
    ItemStore Items, ReminderService Reminders, TaskRoutineService Tasks, ItemEditor Editor, RoutineService Routines,
    SteamService Steam, ReminderDefaults Defaults, OperationRegistry Operations, CommandRunner Commands);

// Web arayüzünün (WorkspaceWeb) çağırdığı işlemler. Windows ve Mac aynı sınıfı kullanır; arayüz yalnızca
// buradaki yöntemleri çağırabilir. Veri işlemleri burada, platforma özgü olanlar IWorkspaceHost'ta.
public sealed class WorkspaceApi(WorkspaceServices services, IWorkspaceHost host)
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { Converters = { new JsonStringEnumConverter() } };
    // Arayüzün doğrudan çağırabileceği ortak işlemler (izin listesi).
    private static readonly HashSet<string> Operations = ["steam.list", "steam.search", "steam.track", "steam.unwatch", "steam.check", "spotify.search", "spotify.playTrack", "spotify.current", "spotify.volume", "spotify.open", "spotify.control", "spotify.status"];
    private static string Text(JsonElement p, string key) => p.GetProperty(key).GetString() ?? "";
    private static Guid Id(JsonElement p) => p.GetProperty("id").GetGuid();
    private static Guid? OptionalId(JsonElement p) => p.TryGetProperty("id", out var id) && id.ValueKind == JsonValueKind.String ? id.GetGuid() : null;
    private static T Read<T>(JsonElement value) => value.Deserialize<T>(Json) ?? throw new ArgumentException("Eksik alan.");

    public async Task<object?> DispatchAsync(string method, JsonElement p)
    {
        var tasks = services.Tasks; var reminders = services.Reminders;
        switch (method) {
            case "snapshot": return Snapshot(p);
            case "operation": return await Operation(Text(p, "name"), p.GetProperty("parameters"));
            case "task.save": {
                var node = JsonNode.Parse(p.GetProperty("task").GetRawText())!.AsObject();
                var id = node["id"] == null ? Guid.NewGuid() : Guid.Parse(node["id"]!.GetValue<string>());
                node["id"] = id.ToString();
                var task = node.Deserialize<RoutineTask>(Json)!;
                var old = tasks.Items.Find(t => t.Id == id);
                task = task with { Steps = task.Steps ?? [], Repeat = task.Repeat ?? "none", Done = old?.Done ?? false, CompletedDays = old?.CompletedDays, PreviousOccurrence = old?.PreviousOccurrence };
                tasks.Save(task); return id;
            }
            // Tek görev formu: görev ve hatırlatıcı aynı kayıt (Core/Items/ItemEditor.cs).
            case "item.get": return services.Editor.Get(Id(p)) ?? throw new ArgumentException("Kayıt bulunamadı.");
            case "item.save": return services.Editor.Save(Read<ItemForm>(p.GetProperty("form")));
            case "task.remove": tasks.Remove(Id(p)); return true;
            case "task.order": tasks.Reorder(Read<List<Guid>>(p.GetProperty("ids"))); return true;
            case "task.important": case "task.day": case "task.step": case "task.complete": {
                var task = tasks.Items.SingleOrDefault(t => t.Id == Id(p)) ?? throw new ArgumentException("Görev bulunamadı.");
                var day = p.TryGetProperty("day", out var d) ? DateOnly.Parse(d.GetString()!, CultureInfo.InvariantCulture) : DateOnly.FromDateTime(DateTime.Today);
                if (method == "task.complete") {
                    if (task.DailyActivity ? task.CompletedDays?.Contains(day) == true : task.Done) tasks.Restore(task.Id, day);
                    else if (task.DailyActivity) tasks.CompleteDay(task.Id, day);
                    else tasks.Complete(task.Id, DateOnly.FromDateTime(DateTime.Today));
                } else if (method == "task.important") tasks.Save(task with { Important = !task.Important });
                else if (method == "task.day") tasks.Save(task with { MyDay = task.MyDay == day ? null : day });
                else { var index = p.GetProperty("index").GetInt32(); if (index < 0 || index >= task.Steps.Count) throw new ArgumentException("Adım bulunamadı."); task.Steps[index] = task.Steps[index] with { Done = p.GetProperty("done").GetBoolean() }; tasks.Save(task); }
                return true;
            }
            case "reminder.save": {
                var options = Read<ReminderOptions>(p.GetProperty("options")); options.Validate();
                var node = JsonNode.Parse(p.GetProperty("plan").GetRawText())!.AsObject();
                // Seri kimliklerini hizmet üretir.
                if (node["weekly"] is JsonObject weekly && weekly["seriesId"] == null) weekly["seriesId"] = Guid.Empty.ToString();
                var plan = node.Deserialize<PlanDetails>(Json)!; plan.Validate();
                var id = OptionalId(p); var due = p.GetProperty("due").GetDateTimeOffset(); var text = Text(p, "text");
                if (id.HasValue) reminders.Edit(id.Value, text, due, options, plan); else reminders.Add(text, due, options, plan);
                return true;
            }
            case "reminder.remove": reminders.Remove(Id(p)); return true;
            case "reminder.clear": reminders.ClearCompleted(); return true;
            case "reminder.snooze": reminders.Snooze(Id(p), TimeSpan.FromMinutes(5)); return true;
            case "reminder.complete": host.CompleteReminder(Id(p)); return true;
            case "routine.save": services.Routines.Save(new(OptionalId(p) ?? Guid.NewGuid(), Text(p, "name"), Read<List<RoutineStep>>(p.GetProperty("steps")))); return true;
            case "routine.remove": services.Routines.Remove(Id(p)); return true;
            case "defaults.save": { var options = Read<ReminderOptions>(p).Normalize(); options.Validate(); services.Defaults.Set(options); return options; }
            case "options.describe": { var options = Read<ReminderOptions>(p).Normalize(); return new { name = options.Name, description = options.Description }; }
            case "preferences.get": return PlanningPreferenceStore.Load();
            case "preferences.save": { var preferences = Read<PlanningPreferences>(p); preferences.Validate(); if (!host.Testing) PlanningPreferenceStore.Save(preferences); return true; }
            case "reminder.suggest": {
                var plan = Read<PlanDetails>(p.GetProperty("plan")); plan.Validate();
                if (plan.Certainty != PlanCertainty.Flexible) throw new InvalidOperationException("Plan türünden Esnek seç; kesin planın saatini sen belirle.");
                var day = DateTime.Parse(Text(p, "day"), CultureInfo.InvariantCulture).Date;
                return reminders.SuggestTimes(day, plan, OptionalId(p)).Select(s => new { start = new DateTimeOffset(s.Start), end = new DateTimeOffset(s.End), preferred = s.Preferred });
            }
            case "day.plan": {
                var day = DateTime.Parse(Text(p, "day"), CultureInfo.InvariantCulture).Date;
                var plans = Read<List<PlanDetails>>(p.GetProperty("plans")).Select(x => x with { Certainty = PlanCertainty.Flexible, Weekly = null }).ToList();
                plans.ForEach(x => x.Validate());
                return PlanSuggestions.PlanDay(day, plans, PlanningPreferenceStore.Load(), reminders.Items).Select(s => s == null ? null : new { start = new DateTimeOffset(s.Start), end = new DateTimeOffset(s.End) });
            }
            // Hızlı ekleme ve Ctrl+K: metni uygulamanın tek tarih/saat ayrıştırıcısıyla çözer (kaydetmez).
            case "quick.parse": {
                var when = WhenParser.Parse(Text(p, "text"), DateTimeOffset.Now);
                return new { kind = when.Someday ? "someday" : when.Due != null ? "reminder" : "task", text = when.Text, due = when.Due, day = when.Day ?? DateOnly.FromDateTime(DateTime.Today) };
            }
        }
        return await host.DispatchAsync(method, p);
    }

    private async Task<object?> Operation(string name, JsonElement parameters)
    {
        if (!Operations.Contains(name)) throw new ArgumentException("Bu işleme çalışma alanından erişilemez.");
        if (host.Testing) {
            if (name is "steam.list") return services.Steam.Items;
            if (name is "steam.search" or "spotify.search") return Array.Empty<object>();
            if (name == "spotify.current") return null;
            throw new InvalidOperationException("Test görünümünde dış hizmet işlemleri kapalı.");
        }
        var result = await services.Operations.ExecuteAsync(name, parameters);
        if (!result.Success) throw new InvalidOperationException(result.Message);
        if (result.Data is { } data) services.Commands.Remember(name, data);
        return result.Data;
    }

    // Arayüze giden veri. Her parçanın (görevler, hatırlatıcılar, kısayollar, oyunlar …) bir sürümü vardır;
    // arayüz bildiği sürümleri gönderir, yalnızca değişen parçalar döner. İlk istekte hepsi gelir.
    // Hatırlatıcılarda tekrarlar yalnızca istenen tarih aralığı kadar gönderilir (from–to).
    private object Snapshot(JsonElement p)
    {
        var known = p.ValueKind == JsonValueKind.Object && p.TryGetProperty("known", out var k) && k.ValueKind == JsonValueKind.Object
            ? k.EnumerateObject().ToDictionary(x => x.Name, x => x.Value.ValueKind == JsonValueKind.String ? x.Value.GetString() ?? "" : "")
            : [];
        var today = DateOnly.FromDateTime(DateTime.Today);
        DateOnly Day(string name, DateOnly fallback) => p.ValueKind == JsonValueKind.Object && p.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String
            && DateOnly.TryParseExact(v.GetString(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var day) ? day : fallback;
        var from = Day("from", today.AddDays(-62)); var to = Day("to", today.AddDays(190));
        if (to < from || to.DayNumber - from.DayNumber > 900) throw new ArgumentException("Tarih aralığı geçersiz.");

        var result = new Dictionary<string, object?>();
        var versions = new Dictionary<string, string>();
        void Part(string name, string version, Func<object?> value)
        {
            versions[name] = version;
            if (!known.TryGetValue(name, out var seen) || seen != version) result[name] = value();
        }
        // Küçük parçalar: içeriğin özeti sürümdür.
        void Hashed(string name, object value)
        {
            var json = JsonSerializer.SerializeToUtf8Bytes(value, Json);
            Part(name, Convert.ToHexString(SHA256.HashData(json))[..16], () => JsonDocument.Parse(json).RootElement.Clone());
        }
        // Görev ve hatırlatıcılar aynı dosyadan gelir; dosya değişmedikçe sürüm aynıdır (yeniden hesaplanmaz).
        services.Items.Read();
        var generation = services.Items.Generation.ToString(CultureInfo.InvariantCulture);
        Part("tasks", generation, () => services.Tasks.Items);
        Part("reminders", $"{generation}|{today:yyyy-MM-dd}|{from:yyyy-MM-dd}|{to:yyyy-MM-dd}", () => ReminderService.ForScreen(services.Reminders.Items, from, to));
        Hashed("routines", services.Routines.Items);
        Hashed("steam", services.Steam.Items);
        Hashed("defaults", services.Defaults.Options);
        Hashed("themes", host.Themes().Select(t => new { name = t.Name, colors = t.Colors }).ToList());
        result["versions"] = versions;
        result["live"] = host.Live();
        return result;
    }
}
