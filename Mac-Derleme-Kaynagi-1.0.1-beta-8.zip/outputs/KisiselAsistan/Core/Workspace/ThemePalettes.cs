namespace KisiselAsistan;

// Temaların renkleri (platformdan bağımsız, onaltılık). Windows (Shell/Look/ThemeSettings) ve Mac aynı paleti kullanır.
// Renk uyumu: zemin nötre yakın (60), kart ve yazı (30), vurgu (10). Her temada ana vurgunun yanında renk çarkında
// karşısındaki (tamamlayıcı) ya da yanındaki (komşu) ikinci bir renk vardır; saatlerde, ilerleme çubuğunda ve
// "şimdi" çizgisinde kullanılır ("numbers" rolü). Sıra: zemin, kart, seçili, yazı, soluk yazı, vurgu, çizgi,
// ikinci renk, başlık (yazıyla aynı). Açık temalarda ikinci renk küçük yazıda okunacak kadar koyudur.
// 22 Ekim 2026: "tek düz" görünmesin diye nötrler vurgunun tonuna boyandı (Rosé Pine / Catppuccin gibi), kart zeminden
// belirgin ayrılır; dört açık, dört koyu. Kum Rosé Pine Dawn'dan (gül + çam), Şeftali Tiimo'nun sıcak zeminlerinden,
// Alacakaranlık Rosé Pine'dan (süsen + altın) esinlenir. Kurallar: yazı ≥ 7:1, soluk yazı ≥ 4.5:1, vurgu ≥ 3:1 (koyuda 4.5).
public static class ThemePalettes
{
    public static readonly string[] Names = ["Adaçayı", "Kum", "Açık", "Şeftali", "Gece mavisi", "Koyu", "Orman", "Alacakaranlık"];
    public const string Default = "Koyu";
    public static string[] Hex(string name)
    {
        string[] values = name switch {
            "Adaçayı" => ["#ECF1E8", "#FAFCF7", "#D9E7D0", "#1C2A21", "#56685B", "#2B7A52", "#D3DECB", "#B5552C"],
            "Kum" => ["#F6EEE4", "#FFFAF3", "#EFDFCF", "#33283C", "#73667A", "#B0566F", "#E6D7C7", "#286983"],
            "Açık" => ["#EDF1FA", "#FFFFFF", "#DCE4FA", "#161F38", "#56627F", "#3F57D6", "#D7DEEE", "#B8570C"],
            "Şeftali" => ["#FBEDE5", "#FFF8F3", "#F8DCCD", "#38211C", "#80605A", "#C24A22", "#F0D6C8", "#5B49C2"],
            "Gece mavisi" => ["#131729", "#1B2139", "#283156", "#E4E9FB", "#98A2C6", "#8EA6FF", "#283050", "#F6BB7C"],
            "Orman" => ["#0E1B16", "#15261F", "#20392D", "#E4F2E8", "#95B4A1", "#7FDC9C", "#1F3429", "#F1C46B"],
            "Alacakaranlık" => ["#1A1726", "#231F34", "#36304F", "#EAE5F7", "#A59EC0", "#C4A7E7", "#2E2A44", "#F6C177"],
            _ => ["#121316", "#1B1C21", "#27292F", "#ECEDF1", "#9A9DA8", "#5FDCB1", "#26282E", "#F38375"]
        };
        return [.. values, values[3]];
    }
    // Zeminin parlaklığına göre koyu tema mı (arayüzde renk şeması için).
    public static bool IsDark(string backgroundHex)
    {
        var value = Convert.ToInt32(backgroundHex.TrimStart('#'), 16);
        return ((value >> 16) * 0.299 + ((value >> 8) & 255) * 0.587 + (value & 255) * 0.114) < 128;
    }
    public static bool Valid(string name, IReadOnlyList<string> colors) =>
        Names.Contains(name) && colors.Count == 9 && colors.All(c => System.Text.RegularExpressions.Regex.IsMatch(c, "^#[0-9a-fA-F]{6}$"));
}
