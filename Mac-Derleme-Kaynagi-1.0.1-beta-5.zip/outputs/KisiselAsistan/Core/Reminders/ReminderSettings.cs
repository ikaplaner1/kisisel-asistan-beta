namespace KisiselAsistan;

// Keep the persisted numeric values of the former Low and Uber modes.
public enum ReminderIntensity { Normal = 1, Adhd = 3 }
public record ReminderOptions(ReminderIntensity Level = ReminderIntensity.Normal, int Count = 1, int IntervalMinutes = 15)
{
    public ReminderOptions Normalize() => this with { Level = Level == ReminderIntensity.Adhd ? ReminderIntensity.Adhd : ReminderIntensity.Normal };
    public static ReminderOptions Preset(ReminderIntensity level) => level == ReminderIntensity.Adhd ? new(level, 6, 3) : new(ReminderIntensity.Normal, 1, 15);
    public string Name => Level == ReminderIntensity.Adhd ? "ADHD" : "Normal";
    public bool Sound => Level == ReminderIntensity.Adhd;
    public int VisibleSeconds => Level == ReminderIntensity.Adhd ? 45 : 14;    public string Description => Level == ReminderIntensity.Adhd ? $"Sınırsız · başlangıç {IntervalMinutes} dk · giderek sıklaşır" : $"{Count} kez" + (Count > 1 ? $" · {IntervalMinutes} dakika arayla" : "") + (Sound ? " · sesli" : " · sessiz") + $" · ekranda {VisibleSeconds} sn";
    public void Validate() { if (!Enum.IsDefined(Level) || Count is < 1 or > 20 || IntervalMinutes is < 1 or > 1440) throw new ArgumentException("Tekrar sayısı 1–20, aralık 1–1440 dakika olmalı."); }
}

