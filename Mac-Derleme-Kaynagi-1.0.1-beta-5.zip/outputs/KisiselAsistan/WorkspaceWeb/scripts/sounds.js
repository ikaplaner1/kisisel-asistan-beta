"use strict";
// Arayüz sesleri: dosya yok, Web Audio ile anında üretilir. Kısa ve yumuşak tutulur;
// her tıklamaya değil, yalnızca bir şey başarıldığında ya da eklendiğinde çalar.

let audio = null;
function soundsOn() {
  try {
    return localStorage.getItem("ui-sounds") !== "off";
  } catch {
    return true;
  }
}
function setSoundsOn(on) {
  try {
    localStorage.setItem("ui-sounds", on ? "on" : "off");
  } catch {}
}
// Tek bir nota: hızlı yükselir, zil gibi söner.
function tone(freq, start, { length = 0.35, volume = 0.14, type = "sine", slide = 0 } = {}) {
  const t = audio.currentTime + start,
    osc = audio.createOscillator(),
    gain = audio.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (slide) osc.frequency.exponentialRampToValueAtTime(freq * slide, t + length);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(volume, t + 0.006);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + length);
  osc.connect(gain).connect(audio.destination);
  osc.start(t);
  osc.stop(t + length + 0.02);
}
const sounds = {
  // Görev tamamlandı: iki notalı marimba. Her notada kısa bir tokmak vuruşu ve alttan sıcak bir gövde var.
  done() {
    for (const [freq, start] of [[880, 0], [1318.5, 0.08]]) {
      tone(freq, start, { length: 0.32, volume: 0.17 });
      tone(freq * 4, start, { length: 0.06, volume: 0.05 });
      tone(freq / 2, start, { length: 0.18, volume: 0.07, type: "triangle" });
    }
  },
  // Günün her şeyi bitti: hızla tırmanan ince bir ışıltı, tebrik eder gibi. Günde en fazla bir kez çalar.
  allDone() {
    [2093, 2349, 2637, 3136, 3520, 4186].forEach((f, i) => tone(f, i * 0.045, { length: 0.5 + i * 0.06, volume: 0.042 }));
    tone(1046.5, 0, { length: 0.6, volume: 0.036, type: "triangle" });
  },
  // Alt adım işaretlendi: küçük, kuru bir tık.
  step() {
    tone(2200, 0, { length: 0.06, volume: 0.08, type: "triangle", slide: 0.7 });
  },
  // Kayıt eklendi: yumuşak bir "pop".
  add() {
    tone(520, 0, { length: 0.12, volume: 0.12, slide: 1.9 });
  },
  // Tamamlama geri alındı: hafifçe inen ton, ödül gibi değil.
  undo() {
    tone(660, 0, { length: 0.16, volume: 0.06, slide: 0.6 });
  },
};
function playSound(name, preview = false) {
  if ((!preview && !soundsOn()) || !sounds[name]) return;
  try {
    audio ??= new AudioContext();
    if (audio.state === "suspended") audio.resume();
    sounds[name]();
  } catch {}
}
