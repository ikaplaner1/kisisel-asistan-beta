using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace KisiselAsistan;

public sealed class JsonListStore<T>(string path)
{
    private readonly string mutexName = (OperatingSystem.IsWindows() ? "Local\\KisiselAsistanData-" : "KisiselAsistanData-") + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Path.GetFullPath(path).ToUpperInvariant())));
    public List<T> Read() => Locked(ReadFile);
    public void Modify(Func<List<T>, List<T>> edit) => Locked(() => {
        var next = edit(ReadFile());
        SafeFile.Write(path, JsonSerializer.Serialize(next));
        return true;
    });
    private List<T> ReadFile() => SafeFile.Read(path, text => JsonSerializer.Deserialize<List<T>>(text) ?? throw new InvalidDataException("Kayıt dosyası okunamadı."), []);
    private TResult Locked<TResult>(Func<TResult> action)
    {
        using var mutex = new Mutex(false, mutexName);
        var acquired = false;
        try {
            try { acquired = mutex.WaitOne(TimeSpan.FromSeconds(5)); } catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) throw new IOException("Kayıtlar meşgul. Tekrar dene.");
            return action();
        } finally { if (acquired) mutex.ReleaseMutex(); }
    }
}

