"use strict";
// Kısayollar: uygulama, web sayfası, bekleme ve hatırlatıcı adımlarından oluşan rutinler. Bileşen olarak çizilir.

function stepLabel(s) {
  return s.label || { web: s.target, wait: s.minutes + " dk bekle", reminder: s.minutes + " dk sonra hatırlat" }[s.kind] || "Uygulama";
}
function ShortcutsPage() {
  const status = state.data.live?.routineStatus || "";
  const routines = state.data.routines;
  return html`
    <${Heading} title="Kısayollar" sub="Uygulamalarını ve sekmelerini tek adımda hazırla."><${Button} action="shortcut-new" icon="plus" cls="primary">Yeni kısayol<//><//>
    ${status && html`<div class="toolbar running"><small id="routine-status">${status}</small><span class="spacer"></span><${Button} action="shortcut-stop" icon="stop">Durdur<//></div>`}
    <section class="card"><div class="rows">${routines.length
      ? routines.map((r) => html`<div class="item-row shortcut-row" key=${r.id} data-row-shortcut=${r.id}>
          <${Button} action="shortcut-run" icon="play" cls="icon-button run-button" data-id=${r.id} aria-label=${r.name + " başlat"} title="Başlat" />
          <div class="item-copy"><strong>${r.name}</strong><small>${r.steps.slice(0, 4).map(stepLabel).join(" · ")}${r.steps.length > 4 ? ` · +${r.steps.length - 4}` : ""}</small></div>
          <span class="badge">${r.steps.length} adım</span>
          <${Button} action="shortcut-menu" icon="more" cls="icon-button row-more" data-id=${r.id} aria-label="Kısayol işlemleri" />
        </div>`)
      : html`<${Empty} text="Sabah başlangıcı, odaklanma ya da mola için ilk kısayolunu oluştur." />`}</div></section>`;
}
pageComponents.shortcuts = ShortcutsPage;
