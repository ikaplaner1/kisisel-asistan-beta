const path = require('node:path');
const providers = Object.freeze({chatgpt:'https://chatgpt.com/',gemini:'https://gemini.google.com/',claude:'https://claude.ai/'});
function externalUrl(value) { try { const url = new URL(value); return ['https:','http:'].includes(url.protocol) && !url.username && !url.password; } catch { return false; } }
function trustedUi(url, entry) { return url === entry; }
function releaseAsset(assets, arch) { return assets.find(a => a.name.endsWith(`-mac-${arch}.dmg`) && /^https:\/\/api\.github\.com\/repos\/[^/]+\/[^/]+\/releases\/assets\/\d+$/.test(a.url)); }
// Kapak isteği (covers.assistant.local) → yalnız Steam ve Spotify kapak sunucuları (Windows'taki CoverCache ile aynı sınır).
function coverTarget(value) {
  let url; try { url = new URL(value); } catch { return null; }
  if (url.hostname !== 'covers.assistant.local') return null;
  const source = url.searchParams.get('u');
  let parsed = null; try { parsed = source ? new URL(source) : null; } catch {}
  const https = parsed && parsed.protocol === 'https:' && !parsed.username && !parsed.password;
  if (url.pathname === '/spotify') return https && parsed.hostname === 'i.scdn.co' && parsed.pathname.startsWith('/image/') ? parsed.href : null;
  if (url.pathname !== '/steam') return null;
  if (https && (parsed.hostname.endsWith('.steamstatic.com') || parsed.hostname === 'steamcdn-a.akamaihd.net')) return parsed.href;
  const id = Number(url.searchParams.get('id'));
  return Number.isInteger(id) && id > 0 ? `https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/${id}/header.jpg` : null;
}
// assistant://workspace/<yol> → arayüz klasöründeki dosya; klasör dışına çıkan yollar reddedilir.
function workspaceFile(root, value) {
  let url; try { url = new URL(value); } catch { return null; }
  if (url.protocol !== 'assistant:' || url.hostname !== 'workspace') return null;
  let relative; try { relative = decodeURIComponent(url.pathname).replace(/^\/+/, '') || 'index.html'; } catch { return null; }
  // Ters bölü ve ".." parçası hiçbir sistemde kabul edilmez (macOS'ta "\" dosya adının parçası sayılır).
  if (relative.includes('\\') || relative.split('/').includes('..') || relative.includes('\0')) return null;
  const full = path.resolve(root, relative), base = path.resolve(root) + path.sep;
  return full.startsWith(base) ? full : null;
}
module.exports = {providers, externalUrl, trustedUi, releaseAsset, coverTarget, workspaceFile};
