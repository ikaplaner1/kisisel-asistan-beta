namespace KisiselAsistan;
public enum PlanCertainty { Fixed, Flexible }
public enum PlanCategory { Personal, Work, Health, FreeTime }
public record PlanDetails(PlanCertainty Certainty = PlanCertainty.Fixed, int DurationMinutes = 30, int Priority = 2, PlanCategory Category = PlanCategory.Personal, bool RemindDayBefore = false, WeeklyRepeat? Weekly = null)
{
    public string TypeLabel => (Certainty == PlanCertainty.Fixed ? "Kesin" : "Esnek") + (Weekly == null ? "" : " · Haftalık");
    public string CategoryLabel => Category switch { PlanCategory.Work => "İş / çalışma", PlanCategory.Health => "Sağlık", PlanCategory.FreeTime => "Boş vakit", _ => "Kişisel" };
    public void Validate() { if (!Enum.IsDefined(Certainty) || !Enum.IsDefined(Category) || DurationMinutes is < 5 or > 720 || Priority is < 1 or > 3) throw new ArgumentException("Plan süresi 5–720 dakika, öncelik 1–3 olmalı."); Weekly?.Validate(); }
}
public record PlanningPreferences(int WeekdayStart = 18, int WeekdayEnd = 22, int WeekendStart = 10, int WeekendEnd = 22, int SleepStart = 23, int SleepEnd = 8, int PreferredStart = 18, int PreferredEnd = 21, int BreakMinutes = 10, int DailyLimitMinutes = 180, int DefaultDuration = 30, bool UseWeekdays = true, bool UseWeekends = true)
{
    public void Validate() { if (WeekdayStart < 0 || WeekdayEnd > 24 || WeekdayEnd <= WeekdayStart || WeekendStart < 0 || WeekendEnd > 24 || WeekendEnd <= WeekendStart || SleepStart is < 0 or > 23 || SleepEnd is < 0 or > 23 || PreferredStart < 0 || PreferredEnd > 24 || PreferredEnd <= PreferredStart || BreakMinutes is < 0 or > 120 || DailyLimitMinutes is < 5 or > 1440 || DefaultDuration is < 5 or > 720 || (!UseWeekdays && !UseWeekends)) throw new ArgumentException("Saat aralıklarını kontrol et; en az bir gün grubu açık olmalı."); }
}
internal static class PlanningPreferenceStore
{
    internal static string PathName => DeploymentPaths.Data("planning-preferences.json");
    internal static PlanningPreferences Load() { var items = new JsonListStore<PlanningPreferences>(PathName).Read(); return items.FirstOrDefault() ?? new(); }
    internal static void Save(PlanningPreferences preferences) { preferences.Validate(); new JsonListStore<PlanningPreferences>(PathName).Modify(_ => [preferences]); }
}
public record PlanSlot(DateTime Start, DateTime End, bool Preferred);
internal static class PlanSuggestions
{
    internal static List<PlanSlot> Find(DateTime firstDay, PlanDetails plan, PlanningPreferences preferences, IEnumerable<Reminder> reminders, Guid? excluding = null, DateTime? now = null, int days = 14)
    {
        preferences.Validate(); plan.Validate(); var current = now ?? DateTime.Now; var items = reminders.Where(r => !r.Done && r.Id != excluding).ToList(); var result = new List<PlanSlot>(); var load = new Dictionary<DateTime, int>();
        for (var dayIndex = 0; dayIndex < days; dayIndex++) {
            var day = firstDay.Date.AddDays(dayIndex); var weekend = day.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday;
            if (weekend ? !preferences.UseWeekends : !preferences.UseWeekdays) continue;
            var daily = items.Where(r => r.Due.LocalDateTime.Date == day).Sum(r => (r.Plan ?? new()).DurationMinutes);
            if (daily + plan.DurationMinutes > preferences.DailyLimitMinutes) continue;
            load[day] = daily;
            var from = day.AddHours(weekend ? preferences.WeekendStart : preferences.WeekdayStart); var until = day.AddHours(weekend ? preferences.WeekendEnd : preferences.WeekdayEnd);
            for (var start = from; start.AddMinutes(plan.DurationMinutes) <= until; start = start.AddMinutes(15)) {
                var end = start.AddMinutes(plan.DurationMinutes); if (start <= current) continue;
                bool asleep = false; for (var minute = start; minute < end; minute = minute.AddMinutes(1)) { var hour = minute.TimeOfDay.TotalHours; if (preferences.SleepStart != preferences.SleepEnd && (preferences.SleepStart > preferences.SleepEnd ? hour >= preferences.SleepStart || hour < preferences.SleepEnd : hour >= preferences.SleepStart && hour < preferences.SleepEnd)) { asleep = true; break; } }
                if (asleep || items.Any(r => start < r.Due.LocalDateTime.AddMinutes((r.Plan ?? new()).DurationMinutes + preferences.BreakMinutes) && end.AddMinutes(preferences.BreakMinutes) > r.Due.LocalDateTime)) continue;
                result.Add(new(start, end, start.TimeOfDay.TotalHours >= preferences.PreferredStart && end <= day.AddHours(preferences.PreferredEnd)));
            }
        }
        // Öncelik sıralamayı belirler: Yüksek en yakın günü, Normal tercih edilen saati,
        // Düşük tercih edilen saatler içinde en boş günü öne alır (yükü dağıtır).
        var ordered = plan.Priority switch {
            3 => result.OrderBy(s => s.Start.Date).ThenByDescending(s => s.Preferred).ThenBy(s => s.Start),
            1 => result.OrderByDescending(s => s.Preferred).ThenBy(s => load[s.Start.Date]).ThenBy(s => s.Start),
            _ => result.OrderByDescending(s => s.Preferred).ThenBy(s => s.Start),
        };
        return ordered.Take(24).ToList();
    }

    // "Günü planla": saatsiz işleri tek güne yerleştirir. Önce yüksek öncelikliler yer alır; her yerleşen iş
    // sonrakiler için dolu sayılır, böylece öneriler birbiriyle çakışmaz. Sığmayan işin karşılığı null olur.
    internal static List<PlanSlot?> PlanDay(DateTime day, IReadOnlyList<PlanDetails> plans, PlanningPreferences preferences, IEnumerable<Reminder> reminders, DateTime? now = null)
    {
        var placed = reminders.ToList(); var result = new PlanSlot?[plans.Count];
        foreach (var index in Enumerable.Range(0, plans.Count).OrderByDescending(i => plans[i].Priority)) {
            var slot = Find(day, plans[index], preferences, placed, now: now, days: 1).FirstOrDefault();
            if (slot == null) continue;
            result[index] = slot;
            placed.Add(new Reminder(Guid.NewGuid(), "", new DateTimeOffset(slot.Start), Plan: plans[index]));
        }
        return [.. result];
    }
}

