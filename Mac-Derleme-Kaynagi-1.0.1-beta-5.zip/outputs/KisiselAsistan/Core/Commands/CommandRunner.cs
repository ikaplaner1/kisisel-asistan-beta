using System.Text.Json;

namespace KisiselAsistan;

// Komutu çalıştıran yüzeyin (Windows penceresi ya da Mac kabuğu) yapabildikleri.
public interface ICommandSurface
{
    // Arayüzde bir bölüme geç ("today", "reminders", "steam", "shortcuts", "ai", "settings"; eski adlar Bugün'e düşer).
    void Navigate(string section);
    // Hatırlatıcıyı tamamla; ADHD hatırlatmasında onay bildirimle istenir.
    void CompleteReminder(Guid id);
    // Arama sonuçlarını arayüze gönder (type: "steam" | "spotify"; query: sesle arandıysa kutuya yazılacak metin).
    void ShowResults(string type, object items, string? query);
    // Modelin önerdiği silme işlemi için kullanıcıdan onay.
    Task<bool> ConfirmAsync(string question);
}
public sealed record CommandOutcome(string Message, string Phase);

// Tek komut yolu (Windows ve Mac): cümle → CommandParser (niyet) → CommandResolver (öneri) → RunProposal.
// Kalıba uymayan cümle, Ollama açıksa ona sorulur; onun önerisi de aynı RunProposal'dan geçer.
// Son arama sonuçları ve seçimler ("sonuç 2", "takip 1 seç", "hatırlatıcı 3 seç") burada tutulur.
public sealed class CommandRunner(OperationRegistry operations, IReminderService reminders, TaskRoutineService tasks, SteamService steam,
    IOperationInterpreter? ollama, Func<bool> ollamaEnabled, ICommandSurface surface)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
    private int? steamSelected, watchSelected;
    private Guid? reminderSelected;
    public List<SteamSearchItem> SteamResults { get; private set; } = [];
    public List<SpotifyTrack> SpotifyResults { get; private set; } = [];
    public string SteamQuery { get; private set; } = "";
    // Kısa komutların ("duraklat", "ilk oyunu ekle") hangi uygulamaya gittiği.
    public string LastApp { get; private set; } = "";
    public void ForgetSpotifyResults() => SpotifyResults = [];

    // Komutlarda "1. hatırlatıcı" bu sıradaki listeye göredir: önce bekleyenler, sonra tarihe göre.
    private Reminder[] ReminderList => reminders.Items.OrderBy(r => r.Done).ThenBy(r => r.Due).ToArray();
    public CommandContext State() => new(ReminderList, tasks.Items, SteamResults, SpotifyResults, steam.Items, SteamQuery, reminderSelected, steamSelected, watchSelected, DateTimeOffset.Now);

    // Arama sonuçlarını hem sesli komutlar ("sonuç 2") hem de arayüz için saklar.
    public void Remember(string operation, JsonElement data, string? query = null)
    {
        if (operation == "steam.search") {
            SteamResults = data.Deserialize<List<SteamSearchItem>>(Json) ?? []; steamSelected = null;
            if (query != null) SteamQuery = query;
            surface.ShowResults("steam", SteamResults, query);
        }
        if (operation is "spotify.search" or "spotify.searchAndPlay") {
            SpotifyResults = (operation == "spotify.searchAndPlay" ? data.GetProperty("tracks") : data).Deserialize<List<SpotifyTrack>>(Json) ?? [];
            surface.ShowResults("spotify", SpotifyResults, query);
        }
    }

    public async Task<CommandOutcome> RunAsync(string text, string context, CancellationToken token)
    {
        var phase = "Bitti";
        async Task<string> Run(OperationProposal proposal, bool fromModel) {
            var outcome = await RunProposal(proposal, fromModel, token);
            if (!outcome.Success) phase = "Anlaşılmadı";
            else if (outcome.Code == "clarification") phase = "Bir bilgi eksik";
            if (proposal.Operation.StartsWith("steam.")) LastApp = "steam";
            else if (proposal.Operation.StartsWith("spotify.")) LastApp = "spotify";
            return outcome.Message;
        }
        try {
            if (CommandParser.Parse(text, context) is { } intent) return new(await Run(CommandResolver.Resolve(intent, State()), false), phase);
            if (ollama is null || !ollamaEnabled())
                return new("Ne yapmamı istediğini çıkaramadım. Örneğin ‘Hades’i takip et’, ‘Tame Impala çal’, ‘yarın 9’da raporu hatırlat’ ya da ‘market alışverişi görevini ekle’ diyebilirsin.", "Anlaşılmadı");
            var state = JsonSerializer.Serialize(new {
                reminders = ReminderList.Take(25).Select(r => new { r.Id, Text = r.Text[..Math.Min(120, r.Text.Length)], r.Due, r.Done }),
                tasks = operations.Call<NoArguments, IReadOnlyList<TaskSummary>>("task.list", new()).Take(25).Select(t => new { t.Id, Title = t.Title[..Math.Min(120, t.Title.Length)], t.Done }),
                watches = steam.Items.Take(25).Select(w => new { w.Id, Name = w.Name[..Math.Min(120, w.Name.Length)] })
            }, new JsonSerializerOptions { Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping });
            var proposal = await ollama.ProposeAsync(text, context, state, token);
            if (proposal.Operation is "reminder.remove" or "reminder.clearCompleted" or "steam.unwatch" && !await surface.ConfirmAsync(Describe(proposal)))
                return new("İşlem uygulanmadı.", "İptal edildi");
            return new(await Run(proposal, true), phase);
        } catch (OperationCanceledException) { return new("Komut iptal edildi ya da yanıt zaman aşımına uğradı. Tekrar deneyebilirsin.", "İptal edildi"); }
        catch (HttpRequestException) { return new("Ollama'ya ulaşılamadı. Komut zekâsı ayarlarından yerel bağlantıyı kontrol et.", "Bağlantı yok"); }
        catch (JsonException) { return new("Model geçerli bir işlem öneremedi; model önerisinden hiçbir işlem yapılmadı.", "Anlaşılmadı"); }
        catch (Exception ex) when (ex is InvalidOperationException or ArgumentException or IOException) { return new("İşlem tamamlanamadı: " + ex.Message, "Hata"); }
    }
    // Modelin silme önerisini kullanıcıya soracak cümle.
    private string Describe(OperationProposal proposal) => proposal.Operation switch {
        "reminder.clearCompleted" => "Tamamlanan planlar silinsin mi?",
        "reminder.remove" => "Bu plan silinsin mi?\n" + reminders.Items.FirstOrDefault(r => r.Id == proposal.Parameters.GetProperty("id").GetGuid())?.Text,
        "steam.unwatch" => "Bu oyunun takibi bırakılsın mı?\n" + steam.Items.FirstOrDefault(w => w.Id == proposal.Parameters.GetProperty("id").GetInt32())?.Name,
        _ => "Bu işlem uygulansın mı?"
    };

    // Tek çalıştırma noktası. fromModel: öneri Ollama'dan geldiyse yalnızca izin verilen işlemler çalışır.
    public async Task<OperationResult> RunProposal(OperationProposal proposal, bool fromModel, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        var p = proposal.Parameters;
        OperationResult Done(string message) => new(true, "ok", message);
        switch (proposal.Operation) {
            case "none": return new(true, "clarification", proposal.Message);
            case "ui.selectResult" when !fromModel: steamSelected = p.GetProperty("index").GetInt32(); surface.Navigate("steam"); return Done(proposal.Message);
            case "ui.selectWatch" when !fromModel: watchSelected = p.GetProperty("id").GetInt32(); surface.Navigate("steam"); return Done(proposal.Message);
            case "ui.selectReminder" when !fromModel: reminderSelected = p.GetProperty("id").GetGuid(); surface.Navigate("reminders"); return Done(proposal.Message);
            case "ui.completeReminder" when !fromModel: {
                var id = p.GetProperty("id").GetGuid();
                surface.CompleteReminder(id);
                return Done((reminders.Items.FirstOrDefault(r => r.Id == id)?.Done == true ? "Tamamlandı: " : "Tamamlama onayını bildirimden verebilirsin: ") + proposal.Message);
            }
        }
        var result = fromModel && ollama is OllamaInterpreter model ? await model.ExecuteAsync(proposal, token) : await operations.ExecuteAsync(proposal.Operation, p, token);
        if (Section(proposal.Operation) is { } section) surface.Navigate(section);
        var query = p.ValueKind == JsonValueKind.Object && p.TryGetProperty("query", out var q) && q.ValueKind == JsonValueKind.String ? q.GetString() : null;
        if (!result.Success) {
            // Ad net değilse sonuçlar gösterilir; kullanıcı "ilk oyunu ekle" diyebilir.
            if (proposal.Operation == "steam.trackNamed" && query != null) {
                var found = await operations.ExecuteAsync("steam.search", JsonSerializer.SerializeToElement(new SteamQueryRequest(query), Json), token);
                if (found.Data is { } list) Remember("steam.search", list, query);
            }
            return result;
        }
        if (result.Data is { } data) Remember(proposal.Operation, data, query);
        return result with { Message = Message(proposal, result, fromModel) };
    }
    private static string? Section(string operation) => operation switch {
        _ when operation.StartsWith("steam.") => "steam",
        "spotify.searchAndPlay" or "spotify.playTrack" or "spotify.open" or "spotify.search" => "today",
        _ when operation.StartsWith("reminder.") => "reminders",
        _ when operation.StartsWith("task.") => "today",
        _ => null
    };
    // Sonucu kullanıcıya söylenecek tek cümleye çevirir.
    private static string Message(OperationProposal proposal, OperationResult result, bool fromModel)
    {
        var data = result.Data;
        int Count() => data is { ValueKind: JsonValueKind.Array } array ? array.GetArrayLength() : 0;
        string Names(string property) => data is { ValueKind: JsonValueKind.Array } array
            ? string.Join(" · ", array.EnumerateArray().Take(6).Select(item => item.TryGetProperty(property, out var value) ? value.GetString() : "")) : "";
        switch (proposal.Operation) {
            case "steam.search": return Count() == 0 ? "Bu adla oyun bulamadım; farklı bir ad deneyebilirsin." : $"{Count()} sonuç bulundu. ‘Steam sonuç 1 seç’ diyebilirsin.";
            case "steam.track" or "steam.trackNamed":
                return data?.GetProperty("name").GetString() + (data?.GetProperty("comingSoon").GetBoolean() == true ? " takibe alındı; çıktığında haber vereceğim." : " takip listene eklendi. Bu oyun Steam’de zaten çıkmış görünüyor.");
            case "steam.list": return $"Takip listesinde {Count()} oyun var." + (Count() > 0 ? " " + Names("name") : "");
            case "reminder.list": return $"{Count()} hatırlatıcı var.";
            case "task.list": return Count() == 0 ? "Bugün için görev yok." : $"Bugün {Count()} görev: {Names("title")}";
        }
        if (data is { ValueKind: JsonValueKind.String } text) return text.GetString() ?? "";
        if (result.Message != "İşlem tamamlandı.") return result.Message;
        if (!fromModel) return proposal.Message.Length > 0 ? proposal.Message : result.Message;
        return proposal.Operation switch {
            "reminder.add" => "Plan eklendi.", "reminder.edit" => "Plan güncellendi.",
            "reminder.remove" => "Plan silindi.", "reminder.snooze" => "Plan ertelendi.",
            "reminder.clearCompleted" => "Tamamlanan planlar temizlendi.",
            "steam.unwatch" => "Oyun takibi bırakıldı.",
            "task.add" => "Görev eklendi.", "task.complete" => "Görev tamamlandı.",
            _ => result.Message
        };
    }
}
