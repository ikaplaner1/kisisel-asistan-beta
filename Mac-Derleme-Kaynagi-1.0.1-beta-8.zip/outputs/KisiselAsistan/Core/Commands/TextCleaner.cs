using System.Text.RegularExpressions;

namespace KisiselAsistan;

// Komut metnini kurallara (CommandParser) ve modele (Ollama) vermeden önce ortak bir biçime çevirir.
// Yazılı ve sesli komut aynı yoldan geçer. Belirli cümlelere değil, genel dil kurallarına göre çalışır:
//   1) Saat: yazıyla 1–23 saat ekleriyle rakama ("akşam yedide" → "akşam 7:00'de", "dokuzu çeyrek geçe" → "9:15",
//      "dörde çeyrek kala" → "3:45", "sekiz buçukta" → "8:30'da"); "9 da" → "9'da"; "6 pm" → "18:00"; "dk" → "dakika".
//      Tarih/saat yine yalnızca WhenParser'da hesaplanır; burada yalnızca yazım rakama çevrilir.
//   2) Ses tanıma/klavye hataları: "spotifay" → "spotify", "stim de" → "steam'de".
//   3) Dolgu ve nezaket: "şey", "acaba", "hey", "lütfen" atılır; "duraklatır mısın", "başlatsana" → emir kipi.
//   4) Eş anlamlılar tek biçime: "müziği durdur" → "spotify durdur", "planlarımı göster" → "hatırlatıcılarımı göster" …
// Olumsuz cümlelere ("durdurma", "geçmeni istemiyorum") 4. adım uygulanmaz; anlamları değişmesin.
public static class TextCleaner
{
    private const RegexOptions Options = RegexOptions.IgnoreCase | RegexOptions.CultureInvariant;
    // Kalıplar bir kez derlenip saklanır: .NET'in kendi önbelleği 15 kalıp tutar; temizleyici + WhenParser bunu aşınca
    // her çağrıda yeniden derleniyor, komut başına yüzlerce milisaniye harcanıyordu (tarama testi, 23 Ekim 2026).
    private static readonly System.Collections.Concurrent.ConcurrentDictionary<string, Regex> Compiled = new();
    private static Regex R(string pattern) => Compiled.GetOrAdd(pattern, p => new Regex(p, Options));
    private static string Replace(string text, string pattern, string replacement) => R(pattern).Replace(text, replacement);
    private static string Replace(string text, string pattern, MatchEvaluator evaluator) => R(pattern).Replace(text, evaluator);
    private static bool Has(string text, string pattern) => R(pattern).IsMatch(text);

    // Birler ve onlar; her biri için yalın, -de (bulunma), -i (belirtme), -e (yönelme) biçimleri.
    private static readonly (string Word, int Value, string At, string Of, string To)[] Units = [
        ("bir", 1, "birde", "biri", "bire"), ("iki", 2, "ikide", "ikiyi", "ikiye"), ("üç", 3, "üçte", "üçü", "üçe"),
        ("dört", 4, "dörtte", "dördü", "dörde"), ("beş", 5, "beşte", "beşi", "beşe"), ("altı", 6, "altıda", "altıyı", "altıya"),
        ("yedi", 7, "yedide", "yediyi", "yediye"), ("sekiz", 8, "sekizde", "sekizi", "sekize"), ("dokuz", 9, "dokuzda", "dokuzu", "dokuza")];
    private static readonly (string Word, int Value, string At, string Of, string To)[] Tens = [
        ("on", 10, "onda", "onu", "ona"), ("yirmi", 20, "yirmide", "yirmiyi", "yirmiye")];
    // Ses yüzdesi için onluklar (yalın ve yönelme): "elli", "elliye".
    private static readonly (string Word, int Value, string To)[] VolumeTens = [
        ("on", 10, "ona"), ("yirmi", 20, "yirmiye"), ("otuz", 30, "otuza"), ("kırk", 40, "kırka"), ("elli", 50, "elliye"),
        ("altmış", 60, "altmışa"), ("yetmiş", 70, "yetmişe"), ("seksen", 80, "seksene"), ("doksan", 90, "doksana"), ("yüz", 100, "yüze")];

    private static readonly (string Ascii, string Turkish)[] AsciiTimeWords = [
        ("aksam", "akşam"), ("aksamleyin", "akşamleyin"), ("ogleden sonra", "öğleden sonra"), ("oglen", "öğlen"), ("ogle", "öğle"),
        ("yarin", "yarın"), ("yarindan sonra", "yarından sonra"), ("bugun", "bugün"), ("obur gun", "öbür gün"), ("gunu", "günü"),
        ("carsamba", "çarşamba"), ("persembe", "perşembe"), ("sali", "salı"), ("bucuk", "buçuk"), ("bucukta", "buçukta"),
        ("ceyrek", "çeyrek"), ("gece yarisi", "gece yarısı")];
    private const string AnchorWord = @"\b(?:saat|sabah|akşam|öğlen|öğleden\s+sonra|gece|yarın|bugün|öbür\s+gün|ertesi\s+gün|pazartesi|salı|çarşamba|perşembe|cuma|cumartesi|pazar)\b";
    private const string TimeAnchor = @"(?<=\b(?:saat|sabah|akşam|öğlen|öğleden\s+sonra|gece|yarın|bugün|öbür\s+gün|ertesi\s+gün|günü|pazartesi|salı|çarşamba|perşembe|cuma|cumartesi|pazar)\s+)";
    // "on bir", "yirmi üç", "dokuz" gibi saat sözcüğü + istenen ek biçimi. Grup: tens (isteğe bağlı), last (ekli son sözcük).
    private static string HourPattern(Func<(string Word, int Value, string At, string Of, string To), string> form)
    {
        var units = string.Join("|", Units.Select(form).Select(Regex.Escape));
        var tens = string.Join("|", Tens.Select(form).Select(Regex.Escape));
        return $@"(?<![\p{{L}}\d])(?:(?<tens>on|yirmi)\s+(?<last>{units})|(?<last>{units}|{tens}))(?![\p{{L}}\d])";
    }
    private static int? Minutes(string word) => word.ToLowerInvariant() switch {
        "beş" => 5, "on" => 10, "on beş" => 15, "yirmi" => 20, "yirmi beş" => 25, var digits => int.TryParse(digits, out var n) ? n : null };
    private static int? HourValue(Match m, Func<(string Word, int Value, string At, string Of, string To), string> form)
    {
        var last = m.Groups["last"].Value.ToLowerInvariant();
        var all = Units.Concat(Tens).ToArray();
        var found = all.FirstOrDefault(u => form(u).Equals(last, StringComparison.OrdinalIgnoreCase));
        if (found.Word is null) return null;
        var hour = found.Value + (m.Groups["tens"].Success ? (m.Groups["tens"].Value.Equals("yirmi", StringComparison.OrdinalIgnoreCase) ? 20 : 10) : 0);
        return hour is >= 1 and <= 23 ? hour : null;
    }

    // Hitap sözcükleri ("gardaş yarın 9'a dişçi", "… kanka"): baştan ve sondan atılır. Hızlı ekleme de kullanır (görev adına girmesin).
    public static string Address(string s)
    {
        s = Replace(s ?? "", @"^(?:(?:abi|abicim|kanka|kanki|kankam|gardaş|gardaşım|birader|bro|reis|dostum|aga|agam|moruk)[,!]?\s+)+", "");
        return Replace(s, @"(?:[,!]?\s+(?:kanka|kanki|kankam|abi|abicim|gardaş|gardaşım|birader|bro|reis|dostum|aga|agam|moruk))+$", "");
    }

    public static string Clean(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return text ?? "";
        var s = Regex.Replace(text.Trim(), @"\s+", " ");

        // 2) Ses tanıma ve klavye hataları.
        s = Replace(s, @"\b(?:spotifay|spotfy|spotifai|spotiy|spotify)\s*(?:'|’)?\s*(da|de|dan|den|ı|i|yı|yi)\b", m => "spotify'" + m.Groups[1].Value.ToLowerInvariant().TrimStart('y'));
        s = Replace(s, @"\b(?:spotifay|spotfy|spotifai|spotiy)\b", "spotify");
        s = Replace(s, @"\b(?:stim|steem|stiim)\s+(?:de|da)\b", "steam'de");
        s = Replace(s, @"\b(?:stim|steem|stiim)(?:de|da)\b", "steam'de");
        s = Replace(s, @"\b(?:stim|steem|stiim)\b", "steam");
        // Türkçe karaktersiz komut sözcükleri ("gorevini", "hatirlaticisini").
        s = Replace(s, @"\bgorev", "görev");
        // "hatırlat" kalın ünlülü olduğu için eklerindeki i'ler ı'dır: hatirlaticisini → hatırlatıcısını.
        s = Replace(s, @"\bhatirlat(\w*)", m => "hatırlat" + m.Groups[1].Value.Replace('i', 'ı').Replace("abılır", "abilir"));
        // Ayrı yazılmış belirtme eki ("hades i takipten çıkar", "elden ring i takibe al") ada bitişir.
        s = Replace(s, @"(?<=\p{L}{3})\s+(y?[ıiuü])\s+(?=(?:takip|takib|takipten|izlemeye|steam|sil|kaldır|çal|aç|ara|bul)\b)", "$1 ");

        // 3) Dolgu ve nezaket sözcükleri (başta ya da arada); "bana" yalnızca sonda.
        s = Replace(s, @"^(?:(?:şey|hey|ee+|ıı+|hmm+|acaba|lütfen|please)[,!]?\s+)+", "");
        s = Replace(s, @"\s+(?:acaba|lütfen|please)\b", "");
        s = Replace(s, @"\s+bana[.!]?$", "");
        s = Replace(s, @"[.!]+$", "");

        // Konuşma dolguları: baştaki "ya", "hele bi", "gardaş"; sondaki "kanka", "abi", "gari", "ha".
        for (var before = ""; before != s;) {
            before = s;
            s = Replace(s, @"^(?:(?:ya|hele(?:\s+bi)?|haa?)[,!]?\s+)+", "");
            s = Replace(s, @"(?:[,!]?\s+(?:gari|ha|be|lan))+$", "");
            s = Address(s);
        }
        s = Replace(s, @"\bgadar\b", "kadar");

        s = Times(s);

        // Kendini düzelten süre/saat: "yirmi dakika sonra… yok yok yarım saat sonra", "7:00'de ee yok yok 8:00'de" → sonraki geçerli.
        s = Replace(s, @"(?:\b(?:\d+|yarım|bir|bi|iki|üç|dört|beş|on|on beş|yirmi|otuz|kırk|elli)(?:\s+buçuk)?\s+(?:dakika|saat)\s+sonra|\b\d{1,2}(?:[:.]\d{2})?(?:['’]\p{L}+)?)[\s,.…]*(?:(?:ee+|ıı+|şey)[\s,.…]+)?(?:yok\s+yok|hayır\s+hayır|hayır|pardon|yanlış\s+dedim)[\s,.…]+(?=\S)", "");
        // Bir zamana "kadar": "yediye kadar ineği sağ" o saatte hatırlatılır.
        s = Replace(s, @"(\d{1,2}:\d{2}['’](?:a|e|ya|ye))\s+kadar\b", "$1");
        // "yayına yirmi dakika kaldı, beni uyar": o süre sonra hatırlat.
        s = Replace(s, @"^(.+?)(?:['’]?(?:y?[ae]))\s+((?:\d+|yarım|bir|iki|üç|beş|on|on beş|yirmi|otuz|kırk|elli)(?:\s+buçuk)?\s+(?:dakika|saat))\s+kaldı[,.]?\s+(?:beni\s+)?(?:uyar|hatırlat)\w*$", "$2 sonra $1 hatırlat");

        // "Steam'de var mı bi arasana" bir aramadır: "bi" atılmazsa emir kipine çevrilince "bi ara" ("bir ara" listesi) olurdu.
        s = Replace(s, @"\s+var\s+m[ıi](?=\s+(?:bi\s+|bir\s+)?(?:ara|bak)\w*)", "");
        s = Replace(s, @"\b(?:bi|bir)\s+(?=(?:arasana|arar\s+m[ıi]s[ıi]n|arayabilir\s+misin|baksana|bakar\s+m[ıi]s[ıi]n|bakabilir\s+misin)\b)", "");
        // Bitişik yazılan soru eki: "ertelermisin" → "erteler misin".
        s = Replace(s, @"\b(\w+(?:ar|er|ır|ir|ur|ür|abilir|ebilir))(m[ıiuü]s[ıiuü]n)\b", "$1 $2");
        // 3) Nezaket kipleri → emir: "duraklatır mısın", "geçer misin", "başlatsana", "ekleyebilir misin".
        s = Replace(s, @"\b(aç|başlat|çal|kapat|durdur|duraklat|geç|ekle|hatırlat|göster|ara|bul|bak|atla|oynat|listele|getir|koy|sil|ertele|kontrol et)(?:ar|er|ır|ir|ur|ür|r)\s+m[ıiuü]s[ıiuü]n\b",
            "$1");
        s = Replace(s, @"\b(aç|başlat|çal|kapat|durdur|duraklat|geç|ekle|hatırlat|göster|ara|bul|atla|oynat|listele|getir|koy|sil|ertele)(?:a|e|ya|ye)bilir\s+m[ıiuü]s[ıiuü]n\b", "$1");
        s = Replace(s, @"\b(aç|başlat|çal|kapat|durdur|duraklat|geç|göster|ara|bul|bak|atla|oynat|getir|koy|sil)(?:sana|sene)\b", "$1");
        s = Replace(s, @"\b(?:ekle|ekleye)(?:sene)\b", "ekle");

        // Spotify: "ara ama çalma" / "çalmana gerek yok" yalnız arama demektir (olumsuzluk sayılmaz).
        s = Replace(s, @",?\s+(?:ama\s+çalma|çalmana\s+gerek\s+yok|çalmadan)$", "");
        // "sadece ara, çalma: Sezen Aksu", "Sezen Aksu'yu bul ama oynatma": çalma yasağı müziği gösterir → Spotify'da yalnız arama.
        if (SearchWithoutPlay(s)) {
            var query = Replace(s, @"\b(?:spotify(?:'?(?:da|de|dan|den))?|sadece|yalnızca|ama|ara|bul|arat|search|çalma|oynatma|çalmadan|oynatmadan)\b|[,:;.!]", " ");
            query = Regex.Replace(Regex.Replace(query, @"\s+", " ").Trim(), @"['’](?:y?[ıiuü]|n[ıiuü])$", "");
            if (query.Length > 0) return "spotify ara " + query;
        }
        // 4) Eş anlamlılar; olumsuz isteklerde uygulanmaz.
        if (!IsNegative(s)) s = Canonical(s);
        return Regex.Replace(s, @"\s+", " ").Trim();
    }

    // 1) Yalnız saat ve süre yazımı (WhenParser girişinde de çalışır; hızlı ekleme, telefon, toplu ekleme aynı yoldan geçer).
    // Zaten rakamla yazılmış saate dokunmaz; iki kez çalıştırmak sonucu değiştirmez.
    public static string Times(string s)
    {
        if (string.IsNullOrEmpty(s)) return s ?? "";
        // Türkçe karakter olmadan yazılan zaman sözcükleri ("yarin aksam 7de") — yoksa "akşam" görülmez ve saat sabaha kurulur.
        foreach (var (ascii, turkish) in AsciiTimeWords) s = Replace(s, $@"\b{ascii}\b", turkish);
        s = Replace(s, @"\bbi\s+(?=(?:saat|dakika|gün|hafta)\b)", "bir ");
        s = Replace(s, @"\b(\d+)\s*(?:dk|dak)\.?(?=\s|$)", "$1 dakika");
        s = Replace(s, @"\b(\d+)\s*sn\.?(?=\s|$)", "$1 saniye");
        s = Replace(s, @"\b(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)(?![\p{L}])", m => {
            var hour = int.Parse(m.Groups[1].Value) % 12 + (m.Groups[3].Value.StartsWith("p", StringComparison.OrdinalIgnoreCase) ? 12 : 0);
            return $"{hour}:{(m.Groups[2].Success ? m.Groups[2].Value : "00")}";
        });
        s = Replace(s, @"\b(\d{1,2}(?:[:.]\d{2})?) (da|de|ta|te)\b", "$1'$2");
        // Dakikalı saatte ayrı yazılmış yönelme eki: "14:00 e al" → "14:00'e".
        s = Replace(s, @"\b(\d{1,2}[:.]\d{2}) (ya|ye|a|e)\b", "$1'$2");
        // Türkçe karaktersiz saat sözcüğü zaman sözcüğünden sonra: "gece uc de" → "gece üçte", "akşam bes te" → "akşam beşte".
        s = Replace(s, TimeAnchor + @"(uc|dort|bes|alti)\s?(?:de|da|te|ta)\b", m => m.Groups[1].Value.ToLowerInvariant() switch { "uc" => "üçte", "dort" => "dörtte", "bes" => "beşte", _ => "altıda" });
        // Kesmesiz ek ("yarın 9a", "akşam 7ye", "pazartesi 3te"): yalnız bir zaman sözcüğünden hemen sonra saattir; "9a sınıfı" saat değildir.
        s = Replace(s, TimeAnchor + @"(\d{1,2})(ya|ye|a|e|da|de|ta|te)\b(?!\s+(?:sınıf|şube))", m => int.Parse(m.Groups[1].Value) <= 24 ? $"{m.Groups[1].Value}'{m.Groups[2].Value}" : m.Value);
        // Gün bölümünün başka söylenişleri: "akşamüstü beşte" öğleden sonradır; "öğlene doğru", "akşama doğru" o bölümdür.
        s = Replace(s, @"\bakşam\s*(?:üstü|üzeri)(?:nde)?\b", "öğleden sonra");
        s = Replace(s, @"\b(öğlen|akşam|sabah)(?:e|a)\s+doğru\b", "$1");
        // Süre: "iki saate", "on dakikaya" = … sonra ("saate kadar" değil).
        s = Replace(s, @"\b((?:\d+|bir|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on|on beş|yirmi|otuz|kırk|elli|yarım)(?:\s+buçuk)?)\s+(saate|dakikaya)\b(?!\s+kadar)",
            m => m.Groups[1].Value + (m.Groups[2].Value.StartsWith("saat", StringComparison.OrdinalIgnoreCase) ? " saat sonra" : " dakika sonra"));
        // Yaklaşık saat: "on iki gibi", "beş civarı" → saat.
        s = Replace(s, HourPattern(u => u.Word) + @"\s+(?:gibi|civarı|civarında|sularında|raddelerinde)\b", m => HourValue(m, u => u.Word) is int h ? $"{h}:00'de" : m.Value);
        // Dakikalı: "altıyı yirmi geçe" → 6:20, "beşe on kala" → 4:50 (çeyrek ve buçuk aşağıda).
        s = Replace(s, HourPattern(u => u.Of) + @"\s+(?<min>\d{1,2}|beş|on|on beş|yirmi|yirmi beş)\s+geçe(?:ki)?\b", m => HourValue(m, u => u.Of) is int h && Minutes(m.Groups["min"].Value) is int min and > 0 and < 60 ? $"{h}:{min:00}" : m.Value);
        s = Replace(s, HourPattern(u => u.To) + @"\s+(?<min>\d{1,2}|beş|on|on beş|yirmi|yirmi beş)\s+kala\b", m => HourValue(m, u => u.To) is int h && Minutes(m.Groups["min"].Value) is int min and > 0 and < 60 ? $"{(h == 1 ? 12 : h - 1)}:{60 - min:00}" : m.Value);
        // "dokuzu çeyrek geçe" → 9:15, "dörde çeyrek kala" → 3:45, "sekiz buçukta" → 8:30'da, "yedide" → 7:00'de
        s = Replace(s, HourPattern(u => u.Of) + @"\s+çeyrek\s+geçe(?:ki)?\b", m => HourValue(m, u => u.Of) is int h ? $"{h}:15" : m.Value);
        s = Replace(s, HourPattern(u => u.To) + @"\s+çeyrek\s+kala\b", m => HourValue(m, u => u.To) is int h ? $"{(h == 1 ? 12 : h - 1)}:45" : m.Value);
        // "buçukta" saattir; "bir buçuk saat sonra" süredir, ona dokunulmaz.
        s = Replace(s, HourPattern(u => u.Word) + @"\s+buçukta\b", m => HourValue(m, u => u.Word) is int h ? $"{h}:30'da" : m.Value);
        // "onda", "ikide" saat dışında da geçer ("onda kaldı", "ikide bir"): yalnız bir zaman sözcüğünden sonra çevrilir.
        s = Replace(s, TimeAnchor + HourPattern(u => u.At), m => HourValue(m, u => u.At) is int h ? $"{h}:00'de" : m.Value);
        // Önünde zaman sözcüğü olmayan saat ("yarın sabah erkenden… yok yok altıda"): cümlede başka bir yerde zaman sözcüğü varsa
        // çevrilir; saat dışında sık geçen "birde", "ikide", "onda" bu durumda çevrilmez.
        if (Has(s, AnchorWord)) s = Replace(s, HourPattern(u => u.At), m => !m.Groups["tens"].Success && m.Groups["last"].Value.ToLowerInvariant() is "birde" or "ikide" or "onda" ? m.Value
            : HourValue(m, u => u.At) is int h ? $"{h}:00'de" : m.Value);
        // Yönelme: "yarın sabah dokuza al" → "yarın sabah 9:00'a al" (yine yalnız zaman sözcüğünden sonra).
        s = Replace(s, TimeAnchor + HourPattern(u => u.To), m => HourValue(m, u => u.To) is int h ? $"{h}:00'a" : m.Value);
        // Yalın: "pazartesi sabah dokuz olsun" → "sabah 9:00" (yalnız gün bölümünden sonra; ardından birim gelirse sayıdır: "sabah on sayfa").
        s = Replace(s, @"(?<=\b(?:saat|sabah|akşam|öğlen|öğleden\s+sonra|gece)\s+)" + HourPattern(u => u.Word) + @"(?!\s+(?:dakika|saat|gün|hafta|sayfa|kez|defa|tane|kişi|kilo|km|bardak|adım|şınav)\b)",
            m => HourValue(m, u => u.Word) is int h ? $"{h}:00" : m.Value);
        return s;
    }

    // "durdurma", "açma", "geçmeni istemiyorum", "gerek yok" … ("çalma listesi" olumsuz değildir).
    // Arama isteğindeki çalma yasağı ("sadece ara, çalma: Sezen Aksu") olumsuzluk sayılmaz: yalnız çalmayı yasaklar.
    // "unutma" listede yok: "ilacı unutma" bir hatırlatma isteğidir.
    internal static bool IsNegative(string s)
    {
        s = Replace(s, @"çalma\s+listesi\w*", "");
        if (SearchWithoutPlay(s)) s = Replace(s, @"\b(?:çalma|oynatma|çalmadan|oynatmadan)\b", "");
        return Has(s, @"\b(?:durdurma|duraklatma|geçme|atlama|değiştirme|açma|çalma|oynatma|kapatma|kurma|ekleme|silme|bırakma|erteleme|başlatma)\b|\b\w+m[ae]n[ıi]\s+istemiyorum\b|istemiyorum|istemem\b|\b\w+m[ae]y[ıi]\s+unut\b")
            // Bu fiiller isim de olur ("ödev yazma görevi", "ev temizleme"): yalnız cümle sonunda olumsuzluktur ("hadesi takipten çıkarma").
            || Has(s, @"\b(?:çıkarma|kaldırma|gönderme|işaretleme|temizleme|atma|yazma|dinletme|takip\s+etme|tamamlama)(?:\s+(?:lütfen|sakın|şimdi|artık|kalsın|dursun))*\s*[.!]?$");
    }
    private static bool SearchWithoutPlay(string s) =>
        Has(s, @"\b(?:ara|bul|arat|search)\b") && Has(s, @"\b(?:çalma(?!\s+listesi)|oynatma|çalmadan|oynatmadan)\b") && !Has(s, @"\bsteam\b");
    // İngilizce "don't" burada sayılmaz ("Don't Starve Together" bir oyun adı); kural yolu onu yalnız fiille ("don't play …") tanır.

    private static string Canonical(string s)
    {
        // Spotify'ı başlat → aç
        s = Replace(s, @"^spotify(?:'?[ıi])?(?:\s+uygulamasını)?\s+(?:başlat|çalıştır)$", "spotify aç");
        // Ses: "sesi yüzde 30 yap", "spotify sesini elliye çek", "sesi kıs yüzde on yap"
        var words = string.Join("|", VolumeTens.SelectMany(t => new[] { t.To, t.Word }).Select(Regex.Escape));
        var volume = R($@"^(?:spotify(?:'?[ıi]n)?\s+)?(?:sesi(?:ni)?|ses\s+seviyesini)\s+(?:(?:kıs|aç|azalt|artır|yükselt)\s+)?(?:yüzde\s*|%\s*)?(?<n>\d{{1,3}}|{words})(?:'?(?:e|a|ye|ya))?\s+(?:yap|çek|getir|indir|çıkar|ayarla|olsun|düşür)$").Match(s);
        if (volume.Success) {
            var n = volume.Groups["n"].Value;
            var value = int.TryParse(n, out var digits) ? digits : VolumeTens.First(t => t.Word.Equals(n, StringComparison.OrdinalIgnoreCase) || t.To.Equals(n, StringComparison.OrdinalIgnoreCase)).Value;
            if (value is >= 0 and <= 100) return $"spotify sesi {value}";
        }
        // Müzik/şarkı/parça → Spotify kontrolü (uygulama adı söylenmese de)
        if (!Has(s, @"\b(?:spotify|steam)\b") && Has(s, @"\b(?:müzi\w*|şarkı\w*|parça\w*)\b")) {
            if (Has(s, @"\b(?:çalan|hangi)\s+(?:şarkı|parça)\w*\b") || Has(s, @"^(?:şu an |şimdi |bu )?çalan\s+(?:şarkı|parça)\w*")) return "spotify çalan şarkı";
            if (Has(s, @"\b(?:durdur|duraklat|kes)\b")) return "spotify durdur";
            if (Has(s, @"\b(?:önceki|geri\s+(?:dön|al|sar))\b")) return "spotify önceki";
            if (Has(s, @"\b(?:sonraki|geç|atla)\b")) return "spotify sonraki";
            if (Has(s, @"\bdevam\s+(?:et|ettir)\b")) return "spotify devam et";
            // Adsız "şarkı aç", "biraz müzik aç": çalmayı sürdür (Spotify uygulamasını açmak değil).
            if (Has(s, @"^(?:bir\s+|bi\s+|biraz\s+)?(?:müzik|şarkı|parça)\s+(?:aç|çal|başlat|koy)$")) return "spotify devam et";
        }
        if (Has(s, @"^spotify(?:'?[dt][ae]|'?[ıi]n)?\s+(?:şu an |şimdi )?(?:çalan|hangi)\s+(?:şarkı|parça)")) return "spotify çalan şarkı";
        // Steam: takip listesi, güncelleme kontrolü, takibe alma eş anlamlıları
        if (Has(s, @"^(?:steam(?:'?[dt][ae])?\s+)?(?:takip\s+ettiğim\s+oyun\w*|takip\s+listem\w*|oyun\s+listem\w*|oyunlarım\w*|takiplerim\w*)\s+(?:göster|neler|ne\s+var|neler\s+var|listele)$")) return "steam takipleri göster";
        if (Has(s, @"\b(?:steam|oyun)\w*\s+(?:güncelleme\w*)\s+(?:kontrol\s+et|bak)\b") || Has(s, @"^steam(?:'?[ıi])?\s+kontrol\s+et\b")) return "steam kontrol et";
        s = Replace(s, @"\b(?:izlemeye|takibe|takip\s+listeme)\s+(?:al|ekle)$", "takibe al");
        s = Replace(s, @"\btakibini\s+(?:sonlandır|kaldır|bitir)$", "takibini bırak");
        // Hatırlatıcı listesi
        if (Has(s, @"^(?:bütün\s+|tüm\s+)?(?:hatırlatıcılarımı|hatırlatmalarımı|planlarımı|hatırlatıcıları)\s+(?:göster|listele|oku|söyle)$|^hangi\s+(?:hatırlatıcılarım|hatırlatmalarım|planlarım)\s+var$|^show\s+(?:my\s+|all\s+)?reminders$")) return "hatırlatıcılarımı göster";
        // Görev listesi
        if (Has(s, @"^(?:bugün(?:kü)?\s+)?(?:görevleri|görevlerimi|yapacaklarımı|işlerimi)\s+(?:göster|listele|oku|söyle)$|^görevlerim\s+(?:neler|ne)$|^bugün\s+neler?\s+(?:yapmam\s+lazım|yapacağım|var)$")) return "görevlerimi göster";
        // İngilizce görev ekleme
        s = Replace(s, @"^add\s+(.+?)\s+to\s+(?:my\s+)?(?:tasks|task\s+list|to-?do\s+list|todo)$", "görev ekle $1");
        return s;
    }
}
