using System.Text.Json;
using System.Text.RegularExpressions;
namespace KisiselAsistan;

internal sealed record BetaReleaseSettings(string RepositoryUrl = "", string GithubClientId = "")
{
    internal static string ValidateRepository(string value)
    {
        if (!Regex.IsMatch(value.Trim(), @"^https://github\.com/[A-Za-z0-9-]+/[A-Za-z0-9_.-]+/?$", RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(100)))
            throw new ArgumentException("Özel test deposunun https://github.com/kullanici/depo biçimindeki bağlantısını gir.");
        return value.Trim().TrimEnd('/');
    }
    internal static void ValidateClientId(string value)
    {
        if (!Regex.IsMatch(value, @"^Iv[A-Za-z0-9]{8,62}$", RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(100)))
            throw new ArgumentException("Güncelleme için oluşturulan GitHub App'in Client ID değerini gir. Client Secret gerekmez.");
    }
    internal static BetaReleaseSettings Load()
    {
        var json = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        foreach (var path in new[] { Path.Combine(DeploymentPaths.UserData, "beta-release.json"), Path.Combine(AppContext.BaseDirectory, "beta-release.json") }) {
            if (!File.Exists(path)) continue;
            try { return JsonSerializer.Deserialize<BetaReleaseSettings>(File.ReadAllText(path), json) ?? new(); }
            catch (JsonException) { }
        }
        return new();
    }
    internal void Save()
    {
        ValidateRepository(RepositoryUrl); ValidateClientId(GithubClientId);
        Directory.CreateDirectory(DeploymentPaths.UserData);
        File.WriteAllText(Path.Combine(DeploymentPaths.UserData, "beta-release.json"), JsonSerializer.Serialize(this, new JsonSerializerOptions(JsonSerializerDefaults.Web)));
    }
}
