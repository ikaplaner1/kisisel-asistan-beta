using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Schema;

namespace KisiselAsistan;

public record OperationParameter(string Name, string Type, bool Required);
public record OperationDefinition(string Name, string Description, IReadOnlyList<OperationParameter> Parameters, JsonElement? ParameterSchema = null);
public record OperationResult(bool Success, string Code, string Message, JsonElement? Data = null);
public record NoArguments;

// Only registered, typed application operations can be dispatched. This is not
// a code evaluator and has no dependency on desktop controls or a network host.
public sealed class OperationRegistry
{
    private readonly Dictionary<string, IOperation> entries = new(StringComparer.Ordinal);
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) {
        UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow,
        NumberHandling = JsonNumberHandling.Strict,
        RespectRequiredConstructorParameters = true,
        RespectNullableAnnotations = true,
        TypeInfoResolver = new System.Text.Json.Serialization.Metadata.DefaultJsonTypeInfoResolver(),
        Converters = { new JsonStringEnumConverter(allowIntegerValues: false) }
    };
    public IReadOnlyList<OperationDefinition> Definitions => entries.Values.Select(e => e.Definition).ToArray();
    public void Register<TRequest, TResult>(string name, string description, Func<TRequest, TResult> handler, Action<TRequest>? validate = null)
        where TRequest : notnull => Add(new Operation<TRequest, TResult>(name, description, handler, null, validate));
    public void RegisterAsync<TRequest, TResult>(string name, string description, Func<TRequest, CancellationToken, Task<TResult>> handler, Action<TRequest>? validate = null)
        where TRequest : notnull => Add(new Operation<TRequest, TResult>(name, description, null, handler, validate));
    private void Add(IOperation entry)
    {
        if (string.IsNullOrWhiteSpace(entry.Definition.Name) || !entries.TryAdd(entry.Definition.Name, entry))
            throw new InvalidOperationException("İşlem adı boş veya zaten kayıtlı: " + entry.Definition.Name);
    }
    private Operation<TRequest, TResult> Find<TRequest, TResult>(string name) where TRequest : notnull =>
        entries.TryGetValue(name, out var entry) && entry is Operation<TRequest, TResult> typed ? typed :
        throw new ArgumentException("Bilinmeyen işlem veya yanlış parametre türü: " + name);
    public TResult Call<TRequest, TResult>(string name, TRequest request) where TRequest : notnull => Find<TRequest, TResult>(name).Call(request);
    public Task<TResult> CallAsync<TRequest, TResult>(string name, TRequest request, CancellationToken token = default) where TRequest : notnull => Find<TRequest, TResult>(name).CallAsync(request, token);
    public OperationResult Validate(string name, JsonElement parameters)
    {
        if (!entries.TryGetValue(name, out var entry)) return new(false, "unknown_operation", "Bu işlem kayıtlı değil.");
        try { entry.ValidateParameters(parameters); return new(true, "ok", "İşlem doğrulandı."); }
        catch (JsonException) { return new(false, "invalid_parameters", "İşlem parametreleri eksik, fazla veya yanlış türde."); }
        catch (ArgumentException ex) { return new(false, "invalid_parameters", ex.Message); }
    }
    public async Task<OperationResult> ExecuteAsync(string name, JsonElement parameters, CancellationToken token = default)
    {
        if (!entries.TryGetValue(name, out var entry)) return new(false, "unknown_operation", "Bu işlem kayıtlı değil.");
        try {
            token.ThrowIfCancellationRequested();
            return await entry.ExecuteAsync(parameters, token);
        } catch (JsonException) { return new(false, "invalid_parameters", "İşlem parametreleri eksik, fazla veya yanlış türde."); }
        catch (ArgumentException ex) { return new(false, "invalid_parameters", ex.Message); }
        catch (OperationCanceledException) { return new(false, "cancelled", "İşlem iptal edildi."); }
        catch (Exception ex) when (ex is InvalidOperationException or IOException or HttpRequestException) { return new(false, "operation_failed", ex.Message); }
    }
    private interface IOperation
    {
        OperationDefinition Definition { get; }
        void ValidateParameters(JsonElement parameters);
        Task<OperationResult> ExecuteAsync(JsonElement parameters, CancellationToken token);
    }
    private sealed class Operation<TRequest, TResult> : IOperation where TRequest : notnull
    {
        private readonly Func<TRequest, TResult>? sync;
        private readonly Func<TRequest, CancellationToken, Task<TResult>>? asyncHandler;
        private readonly Action<TRequest>? validate;
        public OperationDefinition Definition { get; }
        public Operation(string name, string description, Func<TRequest, TResult>? sync, Func<TRequest, CancellationToken, Task<TResult>>? asyncHandler, Action<TRequest>? validate)
        {
            this.sync = sync; this.asyncHandler = asyncHandler; this.validate = validate;
            var constructor = typeof(TRequest).GetConstructors().OrderByDescending(c => c.GetParameters().Length).FirstOrDefault();
            Definition = new(name, description, constructor?.GetParameters().Where(p => p.ParameterType != typeof(TRequest)).Select(p =>
                new OperationParameter(JsonNamingPolicy.CamelCase.ConvertName(p.Name!), p.ParameterType.Name, !p.HasDefaultValue)).ToArray() ?? [],
                JsonSerializer.SerializeToElement(Json.GetJsonSchemaAsNode(typeof(TRequest))));
        }
        private void Validate(TRequest request) { ArgumentNullException.ThrowIfNull(request); validate?.Invoke(request); }
        public void ValidateParameters(JsonElement parameters) { _ = ReadParameters(parameters); }
        private TRequest ReadParameters(JsonElement parameters)
        {
            if (parameters.ValueKind != JsonValueKind.Object) throw new ArgumentException("İşlem parametreleri bir nesne olmalı.");
            var request = parameters.Deserialize<TRequest>(Json) ?? throw new ArgumentException("İşlem parametreleri boş olamaz.");
            Validate(request); return request;
        }
        public TResult Call(TRequest request)
        {
            if (sync == null) throw new InvalidOperationException("Bu işlem beklemeli çağrılmalı: " + Definition.Name);
            Validate(request); return sync(request);
        }
        public Task<TResult> CallAsync(TRequest request, CancellationToken token)
        {
            token.ThrowIfCancellationRequested(); Validate(request);
            return asyncHandler != null ? asyncHandler(request, token) : Task.FromResult(sync!(request));
        }
        public async Task<OperationResult> ExecuteAsync(JsonElement parameters, CancellationToken token)
        {
            var request = ReadParameters(parameters);
            var result = await CallAsync(request, token);
            if (result is IOperationOutcome outcome) return new(outcome.Success, outcome.Success ? "ok" : "operation_failed", outcome.Message, JsonSerializer.SerializeToElement(result, Json));
            return new(true, "ok", "İşlem tamamlandı.", JsonSerializer.SerializeToElement(result, Json));
        }
    }
}
