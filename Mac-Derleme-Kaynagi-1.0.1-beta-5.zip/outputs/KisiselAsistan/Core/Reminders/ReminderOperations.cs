namespace KisiselAsistan;

public record ReminderAddRequest(string Text, DateTimeOffset Due, ReminderOptions? Options = null, PlanDetails? Plan = null);
public record ReminderEditRequest(Guid Id, string Text, DateTimeOffset Due, ReminderOptions? Options = null, PlanDetails? Plan = null);
public record ReminderIdRequest(Guid Id);
public record ReminderSnoozeRequest(Guid Id, double Minutes);
public record ReminderSuggestionRequest(DateTime FirstDay, PlanDetails Plan, Guid? Excluding = null, PlanningPreferences? Preferences = null);
public record ReminderResponseRequest(ReminderPrompt Prompt, ReminderResponse Response, int SnoozeMinutes = 5);

// Existing UI and command consumers keep their small service interface, while
// every user operation goes through the same registry as structured clients.
public sealed class OperationReminderService : IReminderService
{
    private readonly IReminderService service;
    private readonly OperationRegistry operations;
    public OperationReminderService(IReminderService service, OperationRegistry operations)
    {
        this.service = service; this.operations = operations;
        operations.Register<NoArguments, IReadOnlyList<Reminder>>("reminder.list", "Hatırlatıcıları listele", _ => service.Items);
        operations.Register<ReminderAddRequest, bool>("reminder.add", "Hatırlatıcı oluştur", r => { service.Add(r.Text, r.Due, r.Options, r.Plan); return true; });
        operations.Register<ReminderEditRequest, bool>("reminder.edit", "Hatırlatıcıyı düzenle", r => { RequireId(r.Id); service.Edit(r.Id, r.Text, r.Due, r.Options, r.Plan); return true; });
        operations.Register<ReminderIdRequest, bool>("reminder.remove", "Hatırlatıcıyı sil", r => { RequireId(r.Id); service.Remove(r.Id); return true; });
        operations.Register<ReminderSnoozeRequest, bool>("reminder.snooze", "Hatırlatıcıyı ertele", r => { RequireId(r.Id); if (!double.IsFinite(r.Minutes) || r.Minutes <= 0 || r.Minutes > 525600) throw new ArgumentException("Erteleme süresi 0 ile 525600 dakika arasında olmalı."); service.Snooze(r.Id, TimeSpan.FromMinutes(r.Minutes)); return true; });
        operations.Register<NoArguments, bool>("reminder.clearCompleted", "Tamamlananları temizle", _ => { service.ClearCompleted(); return true; });
        operations.Register<ReminderIdRequest, ReminderPrompt?>("reminder.requestCompletion", "Görevi tamamla veya onay iste", r => { RequireId(r.Id); return service.RequestCompletion(r.Id); });
        operations.Register<ReminderSuggestionRequest, IReadOnlyList<PlanSlot>>("reminder.suggestTimes", "Uygun plan saatleri öner", r => service.SuggestTimes(r.FirstDay, r.Plan, r.Excluding, r.Preferences), r => { ArgumentNullException.ThrowIfNull(r.Plan); r.Plan.Validate(); r.Preferences?.Validate(); });
        operations.Register<ReminderResponseRequest, ReminderPrompt?>("reminder.respond", "Bildirime yanıt ver", r => service.Respond(r.Prompt, r.Response, r.SnoozeMinutes), r => { ArgumentNullException.ThrowIfNull(r.Prompt); ArgumentNullException.ThrowIfNull(r.Prompt.Reminder); if (!Enum.IsDefined(r.Response) || !Enum.IsDefined(r.Prompt.Kind)) throw new ArgumentException("Geçersiz bildirim yanıtı."); });
    }
    private void RequireId(Guid id) { if (id == Guid.Empty || !service.Items.Any(r => r.Id == id)) throw new ArgumentException("Hatırlatıcı bulunamadı."); }
    public IReadOnlyList<Reminder> Items => operations.Call<NoArguments, IReadOnlyList<Reminder>>("reminder.list", new());
    public event Action? Changed { add => service.Changed += value; remove => service.Changed -= value; }
    public event Action<string>? Feedback { add => service.Feedback += value; remove => service.Feedback -= value; }
    public void Add(string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null) => operations.Call<ReminderAddRequest, bool>("reminder.add", new(text, due, options, plan));
    public void Edit(Guid id, string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null) => operations.Call<ReminderEditRequest, bool>("reminder.edit", new(id, text, due, options, plan));
    public void Remove(Guid id) => operations.Call<ReminderIdRequest, bool>("reminder.remove", new(id));
    public void Snooze(Guid id, TimeSpan delay) => operations.Call<ReminderSnoozeRequest, bool>("reminder.snooze", new(id, delay.TotalMinutes));
    public void ClearCompleted() => operations.Call<NoArguments, bool>("reminder.clearCompleted", new());
    public ReminderPrompt? RequestCompletion(Guid id) => operations.Call<ReminderIdRequest, ReminderPrompt?>("reminder.requestCompletion", new(id));
    public IReadOnlyList<PlanSlot> SuggestTimes(DateTime firstDay, PlanDetails plan, Guid? excluding = null, PlanningPreferences? preferences = null) => operations.Call<ReminderSuggestionRequest, IReadOnlyList<PlanSlot>>("reminder.suggestTimes", new(firstDay, plan, excluding, preferences));
    public ReminderPrompt? Respond(ReminderPrompt prompt, ReminderResponse response, int snoozeMinutes = 5) => operations.Call<ReminderResponseRequest, ReminderPrompt?>("reminder.respond", new(prompt, response, snoozeMinutes));
    // Scheduling is an internal clock operation; consumers cannot forge a tick.
    public IReadOnlyList<ReminderPrompt> Poll() => service.Poll();
    public bool IsCurrent(ReminderPrompt prompt) => service.IsCurrent(prompt);
}
