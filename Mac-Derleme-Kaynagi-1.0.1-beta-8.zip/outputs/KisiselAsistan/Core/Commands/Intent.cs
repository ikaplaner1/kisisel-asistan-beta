using System.Globalization;

namespace KisiselAsistan;

// Kurallı ayrıştırıcının çıktısı: kullanıcının ne istediği, henüz hangi kayda dokunacağı çözülmeden.
// Kind işlem adıdır ("steam.search", "reminder.snooze" …). Text ad/sorgu, Number sayı (sıra, dakika, saniye, ses),
// Target kayıt hedefi ("su icme", "ikinci", "secili", "" = belirtilmedi), Due/Day zaman.
// Before: ön hatırlatma, asıl saatten kaç dakika önce ("15 dk önce hatırlat"; 0 = yok).
// CommandResolver bunu o anki listelere bakarak tek bir işlem önerisine (OperationProposal) çevirir.
public sealed record Intent(string Kind, string Text = "", int Number = 0, string? Target = null, DateTimeOffset? Due = null, DateOnly? Day = null, int Before = 0)
{
    // Testlerde karşılaştırma için kısa yazım: "reminder.snooze 5 [su icme]", "reminder.add 600 Mola", "reminder.add Toplantı @2026-10-20 15:00 önce:15".
    public override string ToString() => Kind + (Number != 0 ? " " + Number : "") + (Text.Length > 0 ? " " + Text : "") + (Target is null ? "" : " [" + Target + "]")
        + (Due is { } due ? " @" + due.LocalDateTime.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) : "")
        + (Day is { } day ? " @" + day.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : "")
        + (Before != 0 ? " önce:" + Before : "");
}
