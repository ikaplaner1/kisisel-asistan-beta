using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace KisiselAsistan;

public static class GameNameMatcher
{
    public static string Normalize(string name)
    {
        var decomposed = name.ToLowerInvariant().Replace('ı', 'i').Normalize(NormalizationForm.FormD);
        var clean = new string(decomposed.Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark).ToArray());
        return Regex.Replace(Regex.Replace(clean, @"[^a-z0-9]+", " ").Trim(), @"\s+", " ");
    }
    public static double Score(string query, string name)
    {
        var a = Normalize(query); var b = Normalize(name);
        if (a.Length == 0 || b.Length == 0) return 0;
        if (a == b) return 1;
        var compactA = a.Replace(" ", ""); var compactB = b.Replace(" ", "");
        if (compactA == compactB) return 0.99;
        if (b.StartsWith(a + " ", StringComparison.Ordinal)) return 0.95;
        var score = Similarity(compactA, compactB);
        var queryWords = a.Split(' '); var nameWords = b.Split(' ');
        if (queryWords.Length >= 2 && nameWords.Length >= queryWords.Length) {
            for (var start = 0; start <= nameWords.Length - queryWords.Length; start++) {
                var window = string.Concat(nameWords.Skip(start).Take(queryWords.Length));
                score = Math.Max(score, Similarity(compactA, window) - (nameWords.Length - queryWords.Length) * 0.035);
            }
        }
        // Do not suggest a different numbered sequel as a correction.
        var numbers = Regex.Matches(a, @"\b\d+\b").Select(m => m.Value).ToArray();
        var candidateNumbers = Regex.Matches(b, @"\b\d+\b").Select(m => m.Value).ToArray();
        if (numbers.Length > 0 && !numbers.SequenceEqual(candidateNumbers)) score -= 0.3;
        return Math.Max(0, score);
    }
    private static double Similarity(string a, string b)
    {
        if (a.Length > 250 || b.Length > 250) return 0;
        var d = new int[a.Length + 1, b.Length + 1];
        for (var i = 0; i <= a.Length; i++) d[i, 0] = i;
        for (var j = 0; j <= b.Length; j++) d[0, j] = j;
        for (var i = 1; i <= a.Length; i++) for (var j = 1; j <= b.Length; j++) {
            d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
            if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) d[i, j] = Math.Min(d[i, j], d[i - 2, j - 2] + 1);
        }
        return 1d - (double)d[a.Length, b.Length] / Math.Max(a.Length, b.Length);
    }
    public static IEnumerable<string> FallbackQueries(string query)
    {
        var words = Normalize(query).Split(' ', StringSplitOptions.RemoveEmptyEntries).Where(w => w.Length >= 3 && !w.All(char.IsDigit)).Take(3).ToArray();
        return words.Select(w => w[..Math.Min(w.Length, 4)])
            .Concat(words.Select(w => w[..3])).Concat(words).Distinct().Where(w => Normalize(query) != w).Take(6);
    }
}
