"use strict";
// Tek görev formu: görev ve hatırlatıcı aynı şeydir; saat eklenirse o saatte hatırlatılır.
// Veri C# tarafında tek kayıttır (item.get / item.save, Core/Items/ItemEditor.cs): saat eklemek ya da
// kaldırmak kaydın kimliğini değiştirmez. Sık kullanılanlar üstte (saat varsa süre ve ön hatırlatma da); öncelik, liste,
// alt adımlar ve son gün "Ayrıntılar" satırının altında.

const WEEKDAYS = [["Pzt", 1], ["Sal", 2], ["Çar", 3], ["Per", 4], ["Cum", 5], ["Cmt", 6], ["Paz", 0]];
const WORKDAYS = 0b0111110; // pazartesi–cuma (bit 0 = pazar)
const NOTIFY_PRESETS = {
  "Bir kez": { level: "Normal", count: 1, intervalMinutes: 15 },
  "Birkaç kez": { level: "Normal", count: 3, intervalMinutes: 10 },
  "Yapana kadar": { level: "Adhd", count: 6, intervalMinutes: 3 },
  // Takvimde görünür, bildirim vermez (ders programı, iş saatleri).
  Yok: { level: "Silent", count: 1, intervalMinutes: 15 },
};
const CATEGORY_NAMES = { Personal: "Kişisel", Work: "İş", School: "Okul", Health: "Sağlık", FreeTime: "Boş vakit" };
const minutesText = (m) => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
const textMinutes = (s) => (/^\d{1,2}:\d{2}$/.test(s || "") ? +s.slice(0, 2) * 60 + +s.slice(3) : null);
const notifyName = (n) =>
  Object.entries(NOTIFY_PRESETS).find(([, p]) => p.level === n.level && (n.level === "Adhd" || n.level === "Silent" || (p.count === n.count && p.intervalMinutes === n.intervalMinutes)))?.[0] || "Özel";
// Bugünse bir sonraki tam saat, başka günse 09:00.
const suggestedTime = (day) => (day === today() ? Math.min(23, new Date().getHours() + 1) * 60 : 9 * 60);

function whenSummary(f) {
  if (!f.day && !f.repeatDays) return "Bir ara · tarihi yok";
  const day = f.day === today() ? "bugün" : f.day === tomorrow() ? "yarın" : parseDay(f.day).toLocaleDateString("tr-TR", { day: "numeric", month: "long", weekday: "long" });
  const parts = [f.repeatDays ? `${day} başlayarak` : day];
  if (f.timeMinutes != null) parts[0] += " " + minutesText(f.timeMinutes);
  if (f.repeatDays) parts.push(f.repeatDays === 127 ? "her gün" : f.repeatDays === WORKDAYS ? "hafta içi her gün" : WEEKDAYS.filter(([, b]) => f.repeatDays & (1 << b)).map(([n]) => n).join(", "));
  parts.push(f.timeMinutes == null ? "hatırlatma yok" : { "Bir kez": "bir kez hatırlatır", "Birkaç kez": "birkaç kez hatırlatır", "Yapana kadar": "yapana kadar ısrar eder", Yok: "hatırlatmaz, takvimde görünür", Özel: "özel hatırlatma" }[notifyName(f.notify)]);
  return parts.join(" · ");
}

const ChipRow = ({ items, value, onPick, small = false, name }) =>
  html`<div class="choices" role="group" data-chips=${name}>${items.map(
    ([label, v]) => html`<button type="button" class=${"choice" + (small ? " small" : "") + (value(v) ? " on" : "")} aria-pressed=${value(v)} data-chip=${name} data-value=${String(v)} onClick=${() => onPick(v)}>${label}</button>`,
  )}</div>`;
// Ön hatırlatma (dakika; 1440 = bir gün önce). Sesle kurulan başka bir süre ("15 dk önce") de seçenek olarak görünür.
const leadText = (m) => (m === 0 ? "Yok" : m % 1440 === 0 ? m / 1440 + " gün" : m % 60 === 0 ? m / 60 + " saat" : m + " dk");
const leadChoices = (current) => [...new Set([0, 10, 30, 60, 1440, current])].sort((a, b) => a - b).map((m) => [leadText(m), m]);
const Toggle = ({ label, hint, on, onChange, name }) =>
  html`<label class="toggle-row"><span>${label}${hint && html`<small class="muted"> ${hint}</small>`}</span><input type="checkbox" class="switch" name=${name} checked=${on} onChange=${(e) => onChange(e.target.checked)} /></label>`;

function ItemFormView({ initial, isNew }) {
  const [f, setForm] = htmPreact.useState(initial);
  const [details, setDetails] = htmPreact.useState(false);
  const [slots, setSlots] = htmPreact.useState(null);
  const [description, setDescription] = htmPreact.useState("");
  const set = (patch) => setForm((old) => ({ ...old, ...patch }));
  const timed = f.timeMinutes != null,
    someday = !f.day && !f.repeatDays,
    notify = notifyName(f.notify),
    lead = f.remindBeforeMinutes || (f.remindDayBefore ? 1440 : 0);
  const whenChoice = someday ? "someday" : f.day === today() ? "today" : f.day === tomorrow() ? "tomorrow" : "date";
  const [error, setError] = htmPreact.useState("");
  htmPreact.useEffect(() => setError(""), [f]);
  // Geçmiş saat kaydedilmez (ItemEditor); kaydetmeden önce özette söylenir. Değişmeyen eski saat sorun değildir.
  const nowMinutes = new Date().getHours() * 60 + new Date().getMinutes(),
    past = timed && !f.repeatDays && !!f.day && (isNew || f.day !== initial.day || f.timeMinutes !== initial.timeMinutes) &&
      (f.day < today() || (f.day === today() && f.timeMinutes <= nowMinutes)),
    pastFix = f.day < today() && f.timeMinutes > nowMinutes ? ["Bugüne al", today()] : ["Yarına al", tomorrow()];
  // Hatırlatma ayarının açıklaması C# tarafındaki metinle aynıdır.
  htmPreact.useEffect(() => {
    if (!timed) return;
    let live = true;
    rpc("options.describe", f.notify).then((d) => live && setDescription(d.description), () => {});
    return () => (live = false);
  }, [timed, f.notify.level, f.notify.count, f.notify.intervalMinutes]);

  const pickWhen = (v) => {
    if (v === "someday") return set({ day: null, timeMinutes: null, repeatDays: 0 });
    if (v === "today") return set({ day: today() });
    if (v === "tomorrow") return set({ day: tomorrow() });
    set({ day: f.day && f.day !== today() && f.day !== tomorrow() ? f.day : addDays(today(), 2) });
  };
  const pickRepeat = (v) => {
    if (v === "none") return set({ repeatDays: 0 });
    if (v === "daily") return set({ repeatDays: 127, day: f.day || today() });
    if (v === "workdays") return set({ repeatDays: WORKDAYS, day: f.day || today() });
    const start = f.day || today();
    set({ repeatDays: f.repeatDays && f.repeatDays !== 127 && f.repeatDays !== WORKDAYS ? f.repeatDays : 1 << parseDay(start).getDay(), day: start });
  };
  const repeatChoice = !f.repeatDays ? "none" : f.repeatDays === 127 ? "daily" : f.repeatDays === WORKDAYS ? "workdays" : "days";
  async function suggest() {
    setSlots("loading");
    try {
      const found = await rpc("reminder.suggest", {
        id: f.id,
        day: f.day || today(),
        plan: { certainty: "Flexible", durationMinutes: f.durationMinutes, priority: f.priority, category: f.category },
      });
      setSlots(found.slice(0, 8));
    } catch (e) {
      setSlots([]);
      toast(e.message);
    }
  }
  async function save(e) {
    e.preventDefault();
    // Hata Kaydet satırında görünür; pencerenin sonundaki genel yer yapışkan satırın altında kalıyordu.
    try {
      const form = { ...f, title: f.title.trim(), steps: f.stepsText.split("\n").map((x) => x.trim()).filter(Boolean).map((text) => ({ text, done: f.steps.find((s) => s.text === text)?.done || false })) };
      delete form.stepsText;
      if (!form.title) throw new Error("Görevin adını yaz.");
      if (form.repeatDays === 0 && !timed && someday) form.day = null;
      await rpc("item.save", { form });
      if (isNew) playSound("add");
      closeDialog();
      await refresh();
    } catch (err) {
      setError(err.message);
    }
  }
  const lists = [...new Set(["Görevler", ...state.data.tasks.map((t) => t.list)])];
  return html`<form id="item-form" class="item-form" data-day=${f.day || ""} data-id=${f.id || ""} onSubmit=${save}>
    <input name="title" class="title-input" required maxlength="500" placeholder="Ne yapacaksın?" value=${f.title} onInput=${(e) => set({ title: e.target.value })} />
    <p class=${"item-summary" + (past ? " is-past" : "")} id="item-summary">${past
      ? html`${minutesText(f.timeMinutes)} geçti; ileri bir saat seç. <button type="button" class="text-button" data-past-fix onClick=${() => set({ day: pastFix[1] })}>${pastFix[0]}</button>`
      : whenSummary(f)}</p>

    <div class="form-block"><span class="form-label">Ne zaman</span>
      <${ChipRow} name="when" items=${[["Bugün", "today"], ["Yarın", "tomorrow"], ["Bir ara", "someday"], ["Tarih seç", "date"]]} value=${(v) => v === whenChoice} onPick=${pickWhen} />
      ${whenChoice === "date" && html`<input type="date" name="day" class="pill-input" value=${f.day} onChange=${(e) => e.target.value && set({ day: e.target.value })} />`}
    </div>

    ${!someday && html`<div class="form-block"><span class="form-label">Saat</span>
      ${timed
        ? html`<div class="time-box">
            <${ChipRow} name="time" small items=${[540, 720, 840, 1080, 1200].map((m) => [minutesText(m), m])} value=${(v) => v === f.timeMinutes} onPick=${(v) => set({ timeMinutes: v })} />
            <div class="time-line"><input type="time" name="time" class="pill-input" value=${minutesText(f.timeMinutes)} onChange=${(e) => textMinutes(e.target.value) != null && set({ timeMinutes: textMinutes(e.target.value) })} />
              <button type="button" class="text-button" data-remove-time onClick=${() => set({ timeMinutes: null })}>Saati kaldır</button>
              <button type="button" class="text-button" data-suggest onClick=${suggest} title="Boş saatlerine ve tercihlerine göre">${html`<${Icon} n="clock" />`}Uygun saat öner</button></div>
            ${slots === "loading" && html`<p class="muted small">Uygun saatler aranıyor…</p>`}
            ${Array.isArray(slots) && (slots.length
              ? html`<div class="slot-list">${slots.map((s) => html`<button type="button" class=${"slot" + (s.preferred ? " preferred" : "")} onClick=${() => { const d = new Date(s.start); set({ day: dayKey(d), timeMinutes: d.getHours() * 60 + d.getMinutes(), flexible: true }); setSlots(null); }}><strong>${new Date(s.start).toLocaleDateString("tr-TR", { day: "numeric", month: "short", weekday: "short" })}</strong><span>${clock(s.start)}</span></button>`)}</div>`
              : html`<p class="muted small">Önümüzdeki 14 gün için uygun saat yok; tercihlerini ya da süreyi değiştir.</p>`)}
            <span class="form-label">Ne kadar sürer? <small class="muted">${minutesText(f.timeMinutes)}–${minutesText((f.timeMinutes + (f.durationMinutes || 30)) % 1440)}</small></span>
            <${ChipRow} name="duration" small items=${[15, 30, 45, 60, 90, 120].map((m) => [m < 60 ? m + " dk" : m / 60 + " saat", m])} value=${(v) => v === f.durationMinutes} onPick=${(v) => set({ durationMinutes: v, durationSet: true })} />
            <span class="form-label">Önceden de hatırlat</span>
            <${ChipRow} name="advance" small items=${leadChoices(lead)} value=${(v) => v === lead} onPick=${(v) => set({ remindDayBefore: v === 1440, remindBeforeMinutes: v === 1440 ? 0 : v })} />
            <span class="form-label">Nasıl hatırlatayım?</span>
            <${ChipRow} name="notify" items=${[...Object.keys(NOTIFY_PRESETS), "Özel"].map((n) => [n, n])} value=${(v) => v === notify} onPick=${(v) => set({ notify: v === "Özel" ? { ...f.notify, level: "Normal" } : NOTIFY_PRESETS[v] })} />
            ${notify === "Özel" && html`<div class="custom-notify"><label>Kaç kez <input type="number" name="count" min="1" max="20" value=${f.notify.count} onChange=${(e) => set({ notify: { ...f.notify, count: Math.min(20, Math.max(1, +e.target.value || 1)) } })} /></label><label>Arası (dk) <input type="number" name="interval" min="1" max="1440" value=${f.notify.intervalMinutes} onChange=${(e) => set({ notify: { ...f.notify, intervalMinutes: Math.min(1440, Math.max(1, +e.target.value || 1)) } })} /></label></div>`}
            <p class="muted small">${description}</p>
          </div>`
        : html`<button type="button" class="add-time" data-add-time onClick=${() => set({ timeMinutes: suggestedTime(f.day) })}><${Icon} n="clock" />Saat ekle</button>
            <p class="muted small">Saat eklersen o saatte hatırlatırım ve takvimde saatinde durur.</p>`}
    </div>
    <div class="form-block"><span class="form-label">Tekrar</span>
      <${ChipRow} name="repeat" items=${[["Yok", "none"], ["Her gün", "daily"], ["Hafta içi", "workdays"], ["Her hafta", "days"]]} value=${(v) => v === repeatChoice} onPick=${pickRepeat} />
      ${repeatChoice === "days" && html`<p class="muted small">Hangi günlerde? Birden çok gün seçebilirsin.</p><${ChipRow} name="weekday" small items=${WEEKDAYS} value=${(b) => (f.repeatDays & (1 << b)) !== 0} onPick=${(b) => { const mask = f.repeatDays ^ (1 << b); if (mask) set({ repeatDays: mask }); }} />`}
      ${f.repeatDays > 0 && html`<label class="repeat-until">Bitiş <input type="date" name="repeatUntil" value=${f.repeatUntil || ""} min=${f.day || ""} onChange=${(e) => set({ repeatUntil: e.target.value || null })} /><small class="muted">${f.repeatUntil ? "" : "boşsa süresiz"}</small></label>`}
      ${f.editingDay && f.repeatDays > 0 && html`<p class="muted small">Değişiklik bu günden itibaren geçerli olur; önceki günler ve tamamlananlar olduğu gibi kalır.</p>`}
      ${f.id && f.repeatDays > 0 && f.timeMinutes == null && state.data.tasks.find((t) => t.id === f.id && t.dailyActivity) && html`<${StreakMap} task=${state.data.tasks.find((t) => t.id === f.id)} />`}
    </div>`}

    ${/* Takvimde Önemli anahtarı yok (kullanıcı isteği); öncelik Ayrıntılar → Öncelik'ten seçilir. */ ""}
    ${state.page !== "reminders" && html`<${Toggle} name="important" label=${html`<${Icon} n="star" /> Önemli`} on=${f.priority === 3} onChange=${(on) => set({ priority: on ? 3 : 2 })} />`}
    ${/* Saatsiz işte süre isteğe bağlıdır: seçilirse satırda görünür ve boş vakit önerisi sığan kısa işi öne alır; tekrar tıklamak kaldırır. */ ""}
    ${!timed && html`<div class="form-block"><span class="form-label">Ne kadar sürer? <small class="muted">${f.durationSet ? "" : "isteğe bağlı"}</small></span>
      <${ChipRow} name="estimate" small items=${[5, 15, 30, 60, 120].map((m) => [m < 60 ? m + " dk" : m / 60 + " saat", m])} value=${(v) => f.durationSet && v === f.durationMinutes}
        onPick=${(v) => set(f.durationSet && v === f.durationMinutes ? { durationSet: false } : { durationMinutes: v, durationSet: true })} /></div>`}
    <div class="form-block"><span class="form-label">Kategori</span><${ChipRow} name="category" small items=${Object.entries(CATEGORY_NAMES).map(([k, n]) => [n, k])} value=${(v) => v === f.category} onPick=${(v) => set({ category: v })} /></div>

    <button type="button" class=${"details-row" + (details ? " open" : "")} data-details onClick=${() => setDetails(!details)} aria-expanded=${details}>
      <${Icon} n="settings" /><span><b>Ayrıntılar</b> · ${[f.list, f.priority === 1 && "düşük öncelik", f.stepsText.trim() && f.stepsText.trim().split("\n").length + " adım", f.deadline && "son gün " + relativeDay(f.deadline + "T12:00:00")].filter(Boolean).join(" · ")}</span><${Icon} n="right" />
    </button>
    ${details && html`<div class="details-body">
      <div class="form-block"><span class="form-label">Öncelik</span><${ChipRow} name="priority" small items=${[["Düşük", 1], ["Normal", 2], ["Yüksek", 3]]} value=${(v) => v === f.priority} onPick=${(v) => set({ priority: v })} /></div>
      ${timed && html`<${Toggle} name="flexible" label="Saati kayabilir" hint="(günü planlarken ve öneride taşınabilir)" on=${f.flexible} onChange=${(on) => set({ flexible: on })} />`}
      <div class="form-grid">
        <label class="field">Liste<input name="list" list="item-lists" maxlength="100" value=${f.list} onInput=${(e) => set({ list: e.target.value })} /><datalist id="item-lists">${lists.map((l) => html`<option value=${l} />`)}</datalist></label>
        <label class="field">Son gün<input type="date" name="deadline" value=${f.deadline || ""} onChange=${(e) => set({ deadline: e.target.value || null })} /></label>
      </div>
      <label class="field full">Alt adımlar <small class="muted">(her satıra bir tane)</small><textarea name="steps" rows="3" value=${f.stepsText} onInput=${(e) => set({ stepsText: e.target.value })}></textarea></label>
    </div>`}
    <div class="dialog-actions">${error && html`<span class="form-error" role="alert">${error}</span>`}${!isNew && html`<button type="button" class="ghost danger form-delete" data-form-delete onClick=${() => confirmDialog("Sil", f.repeatDays ? "Bu tekrarlı işin bütün günleri silinsin mi?" : "Bu iş silinsin mi?", () => rpc("task.remove", { id: f.id }))}><${Icon} n="trash" />Sil</button>`}<button type="button" class="ghost" data-action="dialog-close">Vazgeç</button><button class="primary">Kaydet</button></div>
  </form>`;
}

// Formu açar. id: görev, hatırlatıcı ya da tekrar gününün kimliği. day/time: yeni kayıt için gün ve "HH:MM".
// withTime: düzenlenen kayda saat eklenerek açılır ("Saate bağla").
async function itemEditor({ id = null, day = null, time = null, withTime = false, origin = null } = {}) {
  const d = state.data.defaults;
  let form = id
    ? await rpc("item.get", { id })
    : {
        id: null, title: "", day: day || (state.page === "reminders" ? state.day : today()), timeMinutes: textMinutes(time), repeatDays: 0, priority: 2, category: "Personal",
        durationMinutes: 30, durationSet: false, flexible: false, remindDayBefore: false, remindBeforeMinutes: 0, notify: null, steps: [], list: "Görevler", deadline: null, editingDay: null, done: false,
      };
  form = { ...form, notify: form.notify || { level: d.level, count: d.count, intervalMinutes: d.intervalMinutes }, steps: form.steps || [] };
  form.stepsText = form.steps.map((s) => s.text).join("\n");
  if (withTime && form.timeMinutes == null) {
    if (!form.day || form.day < today()) form.day = today();
    if (form.day === today() && new Date().getHours() >= 22) form.day = tomorrow();
    form.timeMinutes = textMinutes(time) ?? suggestedTime(form.day);
  }
  const isNew = !id;
  openDialog(isNew ? "Yeni görev" : form.timeMinutes != null ? "Görevi düzenle" : "Görevi düzenle", '<div id="item-form-root"></div>', { origin });
  htmPreact.render(html`<${ItemFormView} initial=${form} isNew=${isNew} />`, $("#item-form-root"));
}
// Eski adlar (menüler, takvim, testler) aynı forma gider.
const taskEditor = (id) => run(() => itemEditor({ id, origin: rowOf("task", id) }));
const reminderEditor = (id, day, time, fromTask) =>
  run(() => itemEditor({ id: id || fromTask || null, day, time, withTime: !id || !!fromTask, origin: fromTask ? rowOf("task", fromTask) : rowOf("reminder", id) }));
