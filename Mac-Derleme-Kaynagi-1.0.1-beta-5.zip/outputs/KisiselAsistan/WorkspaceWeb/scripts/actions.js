"use strict";
// Kullanıcı işlemleri, olay dinleyicileri ve başlangıç.

async function action(a, b) {
  const id = b?.dataset.id;
  if (a === "navigate") {
    state.page = sectionOf(b.dataset.page);
    if (state.page === "today") state.day = today();
    await rpc("section", { page: state.page });
    render();
    if (state.page === "today") await updatePlaying(true);
    return;
  }
  if (a === "navigate-reminders") {
    state.page = "reminders";
    render();
    return;
  }
  if (a === "nav-scroll") {
    const nav = $("#navigation");
    nav.scrollBy({ left: (b.dataset.direction === "left" ? -1 : 1) * nav.clientWidth, behavior: "smooth" });
    return;
  }
  if (a === "dialog-close") {
    closeDialog();
    return;
  }
  if (a === "theme") {
    themeDialog();
    return;
  }
  if (a === "day-prev" || a === "day-next") {
    const d = parseDay(state.day);
    const delta = a === "day-prev" ? -1 : 1;
    if (state.page === "reminders" && state.calendar === "Ay") {
      d.setDate(1);
      d.setMonth(d.getMonth() + delta);
    } else d.setDate(d.getDate() + delta * (state.page === "reminders" && state.calendar === "Hafta" ? 7 : 1));
    state.day = dayKey(d);
    render();
    return;
  }
  if (a === "today") {
    state.day = today();
    render();
    return;
  }
  if (a === "calendar-mode") {
    state.calendar = b.dataset.mode;
    render();
    return;
  }
  if (a === "task-new" || a === "task-edit") {
    taskEditor(id);
    return;
  }
  if (a === "task-menu") {
    taskMenu(id, b);
    return;
  }
  if (a === "task-to-reminder") {
    // Saate bağla: aynı kayda saat eklenir (kimlik ve sıra değişmez).
    await itemEditor({ id, withTime: true, origin: rowOf("task", id) });
    return;
  }
  if (a === "reminder-to-task") {
    const key = await reminderToTask(state.data.reminders.find((x) => x.id === id));
    toast(`Göreve çevrildi · ${relativeDay(key + "T12:00:00")}`);
    await refresh();
    return;
  }
  if (a === "reminder-move") {
    const r = state.data.reminders.find((x) => x.id === id),
      due = moveTarget(b.dataset.to, r);
    await moveReminder(r, due);
    toast(`Ertelendi · ${relativeDay(due)} ${clock(due)}`);
    await refresh();
    return;
  }
  if (a === "task-move") {
    const key = b.dataset.to === "tomorrow" ? tomorrow() : today();
    await moveTask(state.data.tasks.find((x) => x.id === id), key);
    toast(key === today() ? "Bugüne taşındı." : "Yarına taşındı.");
    await refresh();
    return;
  }
  if (a === "someday-undo") {
    const back = somedayPending().pop();
    if (!back) return;
    // Tamamlanmış işte task.complete tamamlanmayı geri alır.
    await rpc("task.complete", { id: back, day: state.day });
    playSound("undo");
    toast("Geri alındı: " + (state.data.tasks.find((x) => x.id === back)?.title || ""));
    await refresh();
    return;
  }
  if (a === "task-someday") {
    await rpc("task.save", { task: { ...state.data.tasks.find((x) => x.id === id), myDay: null, due: null } });
    toast("Bir ara listesine alındı.");
    await refresh();
    return;
  }
  if (a === "late-menu") {
    lateMenu(b);
    return;
  }
  if (a === "late-move") {
    const { reminders, tasks } = lateItems();
    const later = b.dataset.to === "tomorrow";
    // "task": hepsi bugünün saatsiz görevi olur. "tomorrow": hepsi yarına, hatırlatıcılar kendi saatinde.
    // Haftalık seriler tek tek kaydırılamaz; onlar yerinde kalır.
    for (const r of reminders.filter((r) => !r.plan?.weekly)) await (later ? moveReminder(r, moveTarget("same-tomorrow", r)) : reminderToTask(r));
    for (const t of tasks) await moveTask(t, later ? tomorrow() : today());
    toast(later ? "Gecikenler yarına taşındı." : "Gecikenler bugünün görevleri oldu.");
    await refresh();
    return;
  }
  if (a === "day-plan") {
    await dayPlanner();
    return;
  }
  if (a === "task-remove") {
    confirmDialog("Görevi sil", "Bu görevi silmek istiyor musun?", () => rpc("task.remove", { id }));
    return;
  }
  if (a === "task-star" || a === "task-day" || a === "task-complete") {
    if (a === "task-complete") playSound(taskDone(state.data.tasks.find((t) => t.id === id)) ? "undo" : "done");
    await rpc({ "task-star": "task.important", "task-day": "task.day", "task-complete": "task.complete" }[a], { id, day: state.day });
    if (state.modal) closeDialog();
    await refresh();
    return;
  }
  if (a === "reminder-new" || a === "reminder-edit") {
    reminderEditor(id, b.dataset.date);
    return;
  }
  if (a === "reminder-menu") {
    reminderMenu(id, b);
    return;
  }
  if (a === "reminder-settings") {
    reminderSettingsMenu(b);
    return;
  }
  if (a === "reminder-remove") {
    confirmDialog("Planı sil", "Bu planı ve varsa haftalık serisini silmek istiyor musun?", () => rpc("reminder.remove", { id }));
    return;
  }
  if (a === "reminder-clear") {
    confirmDialog("Tamamlananları temizle", "Tamamlanan hatırlatıcı kayıtları silinecek.", () => rpc("reminder.clear"));
    return;
  }
  if (a === "reminder-complete" || a === "reminder-snooze") {
    if (a === "reminder-complete") playSound("done");
    await rpc(a === "reminder-complete" ? "reminder.complete" : "reminder.snooze", { id });
    if (state.modal) closeDialog();
    await refresh();
    return;
  }
  if (a === "defaults") {
    defaultsDialog();
    return;
  }
  const settings = { preferences: preferencesDialog, google: googleDialog, ollama: ollamaDialog, "spotify-settings": spotifyDialog }[a];
  if (settings) {
    await settings();
    return;
  }
  if (a === "shortcut-new") {
    shortcutEditor();
    return;
  }
  if (a === "shortcut-menu") {
    shortcutMenu(id, b);
    return;
  }
  if (a === "shortcut-edit") {
    shortcutEditor(id);
    return;
  }
  if (a === "shortcut-remove") {
    confirmDialog("Kısayolu sil", "Bu kısayolu silmek istiyor musun?", () => rpc("routine.remove", { id }));
    return;
  }
  if (a === "shortcut-run") {
    await rpc("routine.run", { id });
    toast("Kısayol başlatıldı.");
    return;
  }
  if (a === "shortcut-stop") {
    await rpc("routine.stop");
    return;
  }
  if (a === "steam-track") {
    await rpc("operation", { name: "steam.track", parameters: { id: +id } });
    await refresh();
    return;
  }
  if (a === "steam-remove") {
    confirmDialog("Takibi bırak", "Bu oyunun takibini bırakmak istiyor musun?", () =>
      rpc("operation", { name: "steam.unwatch", parameters: { id: +id } }),
    );
    return;
  }
  if (a === "steam-check") {
    toast("Takipler kontrol ediliyor…");
    const result = await rpc("operation", { name: "steam.check", parameters: {} });
    toast(result.message || "Kontrol tamamlandı.");
    await refresh();
    return;
  }
  if (a === "spotify-play") {
    await rpc("operation", { name: "spotify.playTrack", parameters: { track: state.spotifyResults[+b.dataset.index] } });
    await updatePlaying();
    return;
  }
  if (["spotify-previous", "spotify-next", "spotify-toggle", "spotify-open"].includes(a)) {
    await rpc("operation", {
      name: a === "spotify-open" ? "spotify.open" : "spotify.control",
      parameters: a === "spotify-open" ? {} : { action: a.slice(8) },
    });
    await updatePlaying();
    return;
  }
  if (a === "ai-view") {
    state.aiSingle = !state.aiSingle;
    render();
    return;
  }
  if (a === "ai-prev" || a === "ai-next") {
    state.aiProvider = (state.aiProvider + (a === "ai-prev" ? 2 : 1)) % 3;
    render();
    return;
  }
  if (["ai-refresh", "ai-new", "ai-one-reload", "ai-external"].includes(a)) {
    await rpc("ai.action", { action: a, index: b.dataset.index == null ? -1 : +b.dataset.index });
    toast(a === "ai-new" ? "Yeni sohbetler açıldı." : "İşlem tamamlandı.");
    return;
  }
  if (a === "speech-settings") {
    await speechSettings();
    return;
  }
  if (a === "help") {
    helpDialog();
    return;
  }
  if (a === "example") {
    $("#command").value = b.dataset.example;
    closeDialog();
    $("#command").focus();
    return;
  }
  if (a === "microphone") {
    await rpc("speech.listen");
    await refresh();
    return;
  }
  if (a === "cancel-command") {
    await rpc("speech.cancel");
    return;
  }
  if (a === "view") {
    await rpc("window.view");
    return;
  }
  if (a.startsWith("window-")) {
    await rpc("window.action", { action: a.slice(7) });
    return;
  }
  // Yenile ve geliştirici yayınlama (anahtar girildiği için yerel pencere kalır).
  if (a === "refresh" || a === "publish") {
    await rpc("dialog." + a);
    await refresh();
    return;
  }
}

let updatingPlaying = false;
async function updatePlaying(quiet = false) {
  if (updatingPlaying) return;
  updatingPlaying = true;
  try {
    state.playing = await rpc("operation", { name: "spotify.current", parameters: {} });
    // Bugün bileşen olarak çizildiği için yalnızca değişen kısım (Müzik kartı) güncellenir.
    if (state.page === "today" && !state.modal && !$(".menu") && document.activeElement?.id !== "spotify-volume") render();
  } catch (e) {
    if (!quiet) toast(e.message);
  } finally {
    updatingPlaying = false;
  }
}
setInterval(() => {
  if (state.page === "today" && !document.hidden && !state.modal) updatePlaying(true);
}, 10000);
// Bugün ekranındaki şimdi çizgisi, geri sayım ve gecikmeler dakikada bir güncellenir.
// Kullanıcı yazarken, menü veya pencere açıkken ekran yeniden çizilmez.
setInterval(() => {
  if (state.page !== "today" || !state.data || document.hidden || state.modal || $(".menu")) return;
  if (document.activeElement?.closest?.("#page input, #page textarea, #page select")) return;
  render();
}, 60000);

// Bir görevi tamamlarken tik dolar ve satır yumuşakça kapanır; kayıt hemen yapılır.
async function completeWithMotion(row, save) {
  const started = performance.now();
  const finishing = row && !row.classList.contains("is-done") && !reducedMotion();
  if (finishing) {
    row.style.height = row.offsetHeight + "px"; // yüksekliğin yumuşakça sıfıra inebilmesi için
    row.classList.add("completing");
  }
  await save();
  if (finishing) await wait(Math.max(0, 320 - (performance.now() - started)));
  await refresh();
  // Bileşen sayfasında aynı satır yeniden kullanılabilir; hareketin bıraktığı yükseklik temizlenir.
  if (row) {
    row.style.height = "";
    row.classList.remove("completing");
  }
}
// ---------------------------------------------------------------- Erteleme ve taşıma
const tomorrow = () => dayKey(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() + 1));
// Gecikmiş (saati geçmiş hatırlatıcı, günü geçmiş görev) kayıtlar; Bugün ekranındaki "Gecikenler" ile aynı.
function lateItems() {
  const now = new Date();
  return {
    reminders: state.data.reminders.filter((r) => !r.done && new Date(r.due) < now),
    tasks: state.data.tasks.filter((t) => !t.dailyActivity && !t.done && t.due && t.due < today()),
  };
}
// "hour": bir saat sonra (5 dakikaya yuvarlı), "evening": bu akşam 20:00, "tomorrow": yarın 09:00,
// "same-tomorrow": yarın, kaydın kendi saatinde.
function moveTarget(to, r) {
  const now = new Date(),
    at = (offset, h, m = 0) => new Date(now.getFullYear(), now.getMonth(), now.getDate() + offset, h, m);
  if (to === "hour") return new Date(Math.ceil((now.getTime() + 3600000) / 300000) * 300000);
  if (to === "evening") return at(0, 20);
  if (to === "same-tomorrow") {
    const d = new Date(r.due);
    return at(1, d.getHours(), d.getMinutes());
  }
  return at(1, 9);
}
const moveReminder = (r, due) => rpc("reminder.save", { id: r.id, text: r.text, due: due.toISOString(), options: r.settings, plan: r.plan });
const moveTask = (t, key) => rpc("task.save", { task: { ...t, due: key, myDay: key } });
// Saatten çıkar: aynı kayıt saatsiz göreve döner (kimlik değişmez). Geçmiş günse bugüne alınır.
async function reminderToTask(r) {
  const key = dayKey(new Date(r.due)) < today() ? today() : dayKey(new Date(r.due));
  const form = await rpc("item.get", { id: r.id });
  await rpc("item.save", { form: { ...form, timeMinutes: null, repeatDays: 0, day: key, editingDay: null } });
  return key;
}

// ---------------------------------------------------------------- Sürükle-bırak sıralama
// data-sortable listedeki görev satırı tutulup sürüklenir; satır imleci izler, diğerleri yumuşakça yer açar.
// Bırakınca yeni sıra task.order ile kaydedilir. Kutu, düğme ve menülere basmak sürüklemeyi başlatmaz.
let drag = null,
  dragJustEnded = false;
const sortRows = (list) => $$(":scope > [data-row-task]", list);
document.addEventListener("pointerdown", (e) => {
  if (e.button !== 0) return;
  const row = e.target.closest("[data-sortable] > [data-row-task]");
  if (!row || e.target.closest("input, button, a, select, textarea")) return;
  drag = { row, list: row.parentElement, pointerId: e.pointerId, startY: e.clientY, grab: e.clientY - row.getBoundingClientRect().top, before: sortRows(row.parentElement).map((r) => r.dataset.rowTask), active: false };
});
document.addEventListener("pointermove", (e) => {
  if (!drag || e.pointerId !== drag.pointerId) return;
  if (!drag.active) {
    if (Math.abs(e.clientY - drag.startY) < 6) return;
    drag.active = true;
    closeMenu();
    drag.row.classList.add("dragging");
    document.body.classList.add("is-sorting");
  }
  e.preventDefault();
  const others = sortRows(drag.list).filter((r) => r !== drag.row);
  const next = others.find((r) => {
    const b = r.getBoundingClientRect();
    return e.clientY < b.top + b.height / 2;
  });
  if ((next || null) !== drag.row.nextElementSibling || (!next && others.at(-1)?.nextElementSibling !== drag.row)) {
    const tops = new Map(others.map((r) => [r, r.getBoundingClientRect().top]));
    if (next) drag.list.insertBefore(drag.row, next);
    else others.at(-1)?.after(drag.row);
    if (!reducedMotion())
      for (const r of others) {
        const delta = tops.get(r) - r.getBoundingClientRect().top;
        if (delta) r.animate([{ transform: `translateY(${delta}px)` }, { transform: "none" }], { duration: 140, easing: easeOut });
      }
  }
  drag.row.style.transform = "none";
  drag.row.style.transform = `translateY(${e.clientY - drag.grab - drag.row.getBoundingClientRect().top}px)`;
});
function endDrag(e) {
  if (!drag || e.pointerId !== drag.pointerId) return;
  const { row, list, active, before } = drag;
  drag = null;
  if (!active) return;
  row.classList.remove("dragging");
  row.style.transform = "";
  document.body.classList.remove("is-sorting");
  dragJustEnded = true;
  setTimeout(() => (dragJustEnded = false), 0);
  if (!row.isConnected) return;
  const ids = sortRows(list).map((r) => r.dataset.rowTask);
  if (ids.join() === before.join()) return;
  // Satırlar bileşen tarafından çizilir: önce eski sıraya dönülür, yeni sırayı kayıt sonrası çizim getirir.
  const rows = new Map(sortRows(list).map((r) => [r.dataset.rowTask, r]));
  const anchor = sortRows(list).at(-1).nextSibling;
  for (const id of before) list.insertBefore(rows.get(id), anchor);
  run(async () => {
    await rpc("task.order", { ids });
    await refresh();
  });
}
document.addEventListener("pointerup", endDrag);
document.addEventListener("pointercancel", endDrag);
// Bırakma anındaki tıklama satırda bir işlem başlatmasın.
document.addEventListener(
  "click",
  (e) => {
    if (!dragJustEnded) return;
    dragJustEnded = false;
    e.stopPropagation();
    e.preventDefault();
  },
  true,
);

// Bugün ekranındaki son iş de bittiyse küçük bir kutlama sesi.
function celebrateIfDayDone() {
  if (state.page !== "today") return;
  const checks = $$(".today-main [data-task-check], .today-main [data-reminder-check]");
  if (checks.length && checks.every((c) => c.checked)) playSound("allDone");
}

// ---------------------------------------------------------------- Olaylar
document.addEventListener("click", (e) => {
  const inMenu = e.target.closest(".menu");
  if (!inMenu) closeMenu();
  const b = e.target.closest("[data-action]");
  if (b && !b.disabled) {
    if (inMenu) closeMenu();
    run(() => action(b.dataset.action, b));
    return;
  }
  if (inMenu) return;
  const day = e.target.closest("[data-date]");
  if (day) {
    state.day = day.dataset.date;
    state.calendar = "Gün";
    render();
    return;
  }
  // Gün ve Hafta görünümünde boş bir saate tıklamak o saat için plan açar (yarım saat hassasiyetle).
  const column = e.target.closest(".week-day");
  if (column && !e.target.closest(".week-event")) reminderEditor(null, column.dataset.weekDate, slotAt(column, e.clientY).time);
});
function slotAt(column, y) {
  const half = Math.max(0, Math.floor(((y - column.getBoundingClientRect().top) / hourHeight) * 2));
  const minutes = Math.min((24 - firstHour) * 60 - 30, half * 30);
  const hour = firstHour + Math.floor(minutes / 60);
  return { top: (minutes * hourHeight) / 60, time: `${String(hour).padStart(2, "0")}:${minutes % 60 ? "30" : "00"}` };
}
// Fare boş bir saatin üzerindeyken oraya eklenecek planın yeri ve saati gösterilir.
document.addEventListener("mousemove", (e) => {
  const column = e.target.closest?.(".week-day");
  const hint = column && !e.target.closest(".week-event") ? column.querySelector(".slot-hint") || column.appendChild(Object.assign(document.createElement("div"), { className: "slot-hint" })) : null;
  $$(".slot-hint").forEach((h) => h !== hint && h.remove());
  if (!hint) return;
  const slot = slotAt(column, e.clientY);
  hint.style.top = slot.top + "px";
  hint.style.height = hourHeight / 2 + "px";
  hint.textContent = "+ " + slot.time;
});

// ---------------------------------------------------------------- Takvim: gün boyu şeridinden sürükle-bırak
// Şeritteki saatsiz iş ızgaraya bırakılınca aynı kayda o saat eklenir (yarım saat hassasiyet);
// başka bir günün şeridine bırakılınca yalnızca günü değişir. Geçmiş saate bırakmak reddedilir.
let pillDrag = null;
const clearDropHints = () => {
  $$(".slot-hint").forEach((h) => h.remove());
  $$(".drop-target").forEach((x) => x.classList.remove("drop-target"));
};
document.addEventListener("dragstart", (e) => {
  const pill = e.target.closest?.("[data-pill-task]");
  if (!pill) return;
  pillDrag = pill.dataset.pillTask;
  e.dataTransfer.setData("text/plain", pillDrag);
  e.dataTransfer.effectAllowed = "move";
  closeMenu();
});
document.addEventListener("dragend", () => {
  pillDrag = null;
  clearDropHints();
});
document.addEventListener("dragover", (e) => {
  if (!pillDrag) return;
  const column = e.target.closest?.(".week-day"),
    strip = e.target.closest?.(".allday-cell");
  if (!column && !strip) return;
  e.preventDefault();
  clearDropHints();
  if (strip) return strip.classList.add("drop-target");
  const slot = slotAt(column, e.clientY),
    hint = column.appendChild(Object.assign(document.createElement("div"), { className: "slot-hint" }));
  hint.style.top = slot.top + "px";
  hint.style.height = hourHeight / 2 + "px";
  hint.textContent = "Saat ekle · " + slot.time;
});
document.addEventListener("drop", (e) => {
  if (!pillDrag) return;
  const id = pillDrag,
    column = e.target.closest?.(".week-day"),
    strip = e.target.closest?.(".allday-cell");
  pillDrag = null;
  clearDropHints();
  if (!column && !strip) return;
  e.preventDefault();
  const slot = column ? slotAt(column, e.clientY) : null;
  run(async () => {
    const form = await rpc("item.get", { id }),
      d = state.data.defaults;
    if (column) {
      const [h, m] = slot.time.split(":").map(Number);
      // Tekrarlı işte başlangıç günü değişmez; her tekrarına bu saat eklenir.
      await rpc("item.save", { form: { ...form, day: form.repeatDays ? form.day : column.dataset.weekDate, timeMinutes: h * 60 + m, notify: form.notify || { level: d.level, count: d.count, intervalMinutes: d.intervalMinutes } } });
      toast(`Saat eklendi · ${relativeDay(column.dataset.weekDate + "T12:00:00")} ${slot.time}`);
    } else {
      if (strip.dataset.alldayDate === form.day) return;
      if (form.repeatDays) throw new Error("Tekrarlı işin günleri formdan değişir (Tekrar).");
      await rpc("item.save", { form: { ...form, day: strip.dataset.alldayDate } });
      toast(`Günü değişti · ${relativeDay(strip.dataset.alldayDate + "T12:00:00")}`);
    }
    playSound("add");
    await refresh();
  });
});
// Steam sonuçları çift tıklamayla işlenir (takip listesine kalıcı ekleme olduğu için);
// Spotify sonuçları tek tıkla çalar. İkisi de seçiliyken Enter ile çalışır.
document.addEventListener("dblclick", (e) => {
  const row = e.target.closest("[data-dbl-action]");
  if (row) run(() => action(row.dataset.dblAction, row));
});
document.addEventListener("keydown", (e) => {
  const row = e.key === "Enter" && e.target.closest?.("[data-dbl-action], .is-pickable[data-action]");
  if (row) run(() => action(row.dataset.dblAction || row.dataset.action, row));
});
// Yüklenemeyen kapak görseli yerine sade bir yer tutucu gösterilir.
document.addEventListener(
  "error",
  (e) => {
    if (e.target.matches?.("img.cover")) e.target.replaceWith(Object.assign(document.createElement("span"), { className: "cover cover-empty" }));
  },
  true,
);
// Sağ tık: satırın kendi menüsü tıklanan noktada açılır.
document.addEventListener("contextmenu", (e) => {
  if (e.target.closest("input, textarea")) return;
  e.preventDefault();
  const point = { x: e.clientX, y: e.clientY };
  const task = e.target.closest("[data-row-task]"),
    reminder = e.target.closest("[data-row-reminder]"),
    event = e.target.closest(".calendar-event[data-id]"),
    shortcut = e.target.closest("[data-row-shortcut]");
  if (task) taskMenu(task.dataset.rowTask, point);
  else if (reminder) reminderMenu(reminder.dataset.rowReminder, point);
  else if (event) reminderMenu(event.dataset.id, point);
  else if (shortcut) shortcutMenu(shortcut.dataset.rowShortcut, point);
});
document.addEventListener("change", (e) =>
  run(async () => {
    const t = e.target;
    if (t.id === "task-filter") {
      state.filter = t.value;
      render();
    }
    if (t.id === "task-lane") {
      state.lane = t.value;
      render();
    }
    if (t.dataset.taskCheck) {
      const task = state.data.tasks.find((x) => x.id === t.dataset.taskCheck);
      // "Bir ara" işi tamamlanınca listeden kaybolur; altındaki "Geri al" düğmesi onu geri getirir.
      if (t.checked && task && isSomeday(task)) state.somedayDone = [...state.somedayDone.filter((id) => id !== task.id), task.id];
      playSound(t.checked ? "done" : "undo");
      await completeWithMotion(t.closest(".task-row"), () => rpc("task.complete", { id: t.dataset.taskCheck, day: state.day }));
      if (t.checked) celebrateIfDayDone();
    }
    if (t.dataset.reminderCheck) {
      playSound("done");
      await completeWithMotion(t.closest(".task-row"), () => rpc("reminder.complete", { id: t.dataset.reminderCheck }));
      celebrateIfDayDone();
    }
    if (t.dataset.stepTask) {
      if (t.checked) playSound("step");
      await rpc("task.step", { id: t.dataset.stepTask, index: +t.dataset.index, done: t.checked });
      await refresh();
    }
    if (t.dataset.aiTarget != null) state.targets[+t.dataset.aiTarget] = t.checked;
    if (t.id === "spotify-volume" && state.playing?.deviceId) {
      await rpc("operation", { name: "spotify.volume", parameters: { percent: +t.value, deviceId: state.playing.deviceId } });
      state.playing.volume = +t.value;
      t.nextElementSibling.textContent = t.value + "%";
    }
  }),
);
document.addEventListener("input", (e) => {
  if (e.target.id === "spotify-volume") e.target.style.setProperty("--fill", e.target.value + "%");
  // Hızlı eklemede Enter'a basınca ne olacağı yazarken görünür.
  if (e.target.closest("#today-add")) {
    const value = e.target.value.trim();
    const hint = $("#today-add-hint");
    if (!value) hint.textContent = "";
    else
      parseQuick(value).then((q) => {
        // Yanıt gelene kadar metin değiştiyse eski önizleme gösterilmez.
        if (e.target.value.trim() === value) hint.textContent = "Enter · " + quickLabel(q);
      }, () => {});
  }
  if (e.target.id === "ai-question") {
    state.aiQuestion = e.target.value;
    scheduleSlots();
  }
  const type = e.target.id === "steam-search" ? "steam" : e.target.id === "spotify-search" ? "spotify" : null;
  if (!type) return;
  const value = e.target.value;
  state.query[type] = value;
  clearTimeout(searchTimer);
  // Kutu boşalınca eski sonuçlar da gider.
  if (!value.trim()) {
    state[type === "steam" ? "steamResults" : "spotifyResults"] = [];
    render();
    return;
  }
  searchTimer = setTimeout(
    () =>
      run(async () => {
        const results = await rpc("operation", { name: type + ".search", parameters: { query: value } });
        if (state.query[type] !== value) return;
        state[type === "steam" ? "steamResults" : "spotifyResults"] = results;
        const start = e.target.selectionStart;
        render();
        const input = $("#" + type + "-search");
        if (input) {
          input.focus();
          input.setSelectionRange(start, start);
        }
      }),
    450,
  );
});
document.addEventListener("submit", (e) => {
  if (e.target.id === "shortcut-form") return;
  e.preventDefault();
  run(async () => {
    const f = e.target,
      d = new FormData(f);
    if (f.id === "command-form") {
      const text = d.get("command").trim();
      if (!text) return;
      $("#command").value = "";
      await rpc("speech.command", { text });
      await refresh();
    }
    if (f.id === "today-add") {
      const text = d.get("text").trim();
      if (!text) return;
      await saveQuick(await parseQuick(text));
      playSound("add");
      f.reset();
      $("#today-add-hint").textContent = "";
      await refresh();
      $("#today-add input")?.focus();
    }
    if (f.id === "someday-task") {
      if (!d.get("title").trim()) return;
      await saveSomeday(d.get("title").trim());
      playSound("add");
      f.reset();
      await refresh();
      $("#someday-task input")?.focus();
    }
    if (f.id === "quick-task") {
      if (!d.get("title").trim()) return;
      await rpc("task.save", {
        task: { title: d.get("title"), list: "Görevler", steps: [], dailyActivity: true, myDay: state.day, startsOn: state.day },
      });
      playSound("add");
      await refresh();
      $("#quick-task input")?.focus();
    }
    if (f.id === "speech-form") {
      await rpc("speech.configure", { microphone: +d.get("microphone"), language: +d.get("language"), wait: +d.get("wait") });
      setSoundsOn(d.has("uiSounds"));
      closeDialog();
    }
  });
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    if ($(".menu")) closeMenu();
    else closeDialog();
    return;
  }
  // Ctrl+K: her yerden ortadaki komut penceresini aç.
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
    e.preventDefault();
    if (state.modal === "Komut") closeDialog();
    else commandPalette();
    return;
  }
  if (e.target.id === "ai-question") {
    if (e.key === "Tab") {
      e.preventDefault();
      const t = e.target;
      t.setRangeText("\n", t.selectionStart, t.selectionEnd, "end");
      state.aiQuestion = t.value;
    }
    if (e.key === "Enter" && !e.isComposing) {
      e.preventDefault();
      const text = e.target.value.trim();
      if (!text) return;
      if (!state.targets.some(Boolean)) {
        toast("En az bir AI seç.");
        return;
      }
      e.target.value = "";
      state.aiQuestion = "";
      run(async () => {
        const result = await rpc("ai.send", { text, targets: state.targets });
        toast(result);
      });
    }
  }
  const trap = $(".menu") ? ".menu" : state.modal ? ".modal-layer:not(.closing) .dialog" : null;
  if (trap && e.key === "Tab" && e.target.id !== "ai-question") {
    const focus = $$(`${trap} button:not(:disabled),${trap} input:not(:disabled),${trap} select,${trap} textarea`).filter(
        (x) => x.offsetParent !== null,
      ),
      first = focus[0],
      last = focus.at(-1);
    if (e.shiftKey && e.target === first) {
      e.preventDefault();
      last?.focus();
    } else if (!e.shiftKey && e.target === last) {
      e.preventDefault();
      first?.focus();
    }
  }
});
// Küçük görünümde sekme şeridi fare tekerleğiyle yana kayar.
$("#navigation").addEventListener(
  "wheel",
  (e) => {
    if (!compact() || Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
    e.preventDefault();
    $("#navigation").scrollBy({ left: e.deltaY, behavior: "smooth" });
  },
  { passive: false },
);
$("#drag-area").addEventListener("mousedown", (e) => {
  if (e.button === 0 && e.detail === 1) rpc("window.drag").catch(() => {});
});
$("#drag-area").addEventListener("dblclick", () => rpc("window.action", { action: "maximize" }));
$("#page").addEventListener("scroll", () => {
  closeMenu();
  scheduleSlots();
});
new ResizeObserver(scheduleSlots).observe($("#page"));
window.addEventListener("resize", () => {
  closeMenu();
  scheduleSlots();
});
window.workspace = { ready: false, refresh, state, receive };
run(async () => {
  await refresh();
  window.workspace.ready = true;
});
