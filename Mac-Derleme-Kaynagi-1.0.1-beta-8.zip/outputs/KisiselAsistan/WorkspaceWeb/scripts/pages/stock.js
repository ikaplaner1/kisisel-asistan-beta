"use strict";
// Stok: ürün bağlantıları belirli aralıklarla okunur, stok gelince / fiyat düşünce bildirim gelir (Core/Stock).
// Sayfa, ekleme/düzenleme penceresi (önizlemeli), toplu ekleme, geçmiş ve satır menüsü bu dosyada.
// Olaylar actions.js'ten stockAction'a gelir (data-action="stock-…"); sağ tıkta stockMenu.

const STOCK_STATES = {
  inStock: { label: "Stokta", tone: "success" },
  outOfStock: { label: "Stokta yok", tone: "" },
  preOrder: { label: "Ön sipariş", tone: "secondary" },
  unknown: { label: "Belirsiz", tone: "warning" },
  blocked: { label: "Engellendi", tone: "danger" },
};
const stockKey = (s) => (s ? s[0].toLowerCase() + s.slice(1) : "unknown");
const stockState = (w) => (w.error && w.failures > 0 && !w.checks ? STOCK_STATES.blocked : STOCK_STATES[stockKey(w.state)] || STOCK_STATES.unknown);
const STOCK_INTERVALS = [
  [2, "2 dakikada bir"], [5, "5 dakikada bir"], [10, "10 dakikada bir"], [15, "15 dakikada bir"], [30, "30 dakikada bir"],
  [60, "Saatte bir"], [180, "3 saatte bir"], [360, "6 saatte bir"], [720, "12 saatte bir"], [1440, "Günde bir"],
];
const stockMoney = (value, currency) => {
  if (value == null) return "";
  try {
    return new Intl.NumberFormat("tr-TR", { style: "currency", currency: currency || "TRY", maximumFractionDigits: value % 1 ? 2 : 0 }).format(value);
  } catch {
    return value.toLocaleString("tr-TR") + " " + (currency || "");
  }
};
// "3 dk önce", "2 sa önce", "dün" …; gelecek için "12 dk sonra".
function stockAgo(when) {
  if (!when) return "";
  const minutes = Math.round((new Date(when) - Date.now()) / 60000),
    abs = Math.abs(minutes),
    tail = minutes > 0 ? " sonra" : " önce";
  if (abs < 1) return minutes > 0 ? "birazdan" : "az önce";
  if (abs < 60) return abs + " dk" + tail;
  if (abs < 60 * 24) return Math.round(abs / 60) + " sa" + tail;
  return Math.round(abs / 1440) + " gün" + tail;
}
const stockGroups = () => [...new Set(state.data.stock.map((w) => w.group).filter(Boolean))].sort((a, b) => a.localeCompare(b, "tr"));

// Ürün görseli doğrudan siteden gelir; yüklenmezse ürün adının baş harfi.
const stockInitial = (w) => ((w.name || w.site || "?").match(/[\p{L}\p{N}]/u) || ["?"])[0].toLocaleUpperCase("tr");
function StockImage({ watch }) {
  const [failed, setFailed] = htmPreact.useState("");
  const src = watch.imageUrl || "";
  return src && failed !== src
    ? html`<img class="stock-image" src=${src} alt="" loading="lazy" referrerpolicy="no-referrer" onError=${() => setFailed(src)} />`
    : html`<span class="stock-image stock-image-empty">${stockInitial(watch)}</span>`;
}
// Son fiyat değişimi düşüşse önceki fiyat (geçmiş yalnız değişimleri tutar); %1'den küçük oynamalar sayılmaz.
function stockDrop(w) {
  const h = w.priceHistory || [];
  if (w.price == null || h.length < 2 || h[h.length - 1].price !== w.price) return null;
  const old = h[h.length - 2].price,
    percent = Math.round(((old - w.price) / old) * 100);
  return old > w.price && percent >= 1 ? { old, percent } : null;
}
const StockPrice = ({ watch }) => {
  if (watch.price == null) return html`<small class="muted">Fiyat yok</small>`;
  const drop = stockDrop(watch);
  return drop
    ? html`<strong class="is-drop">${stockMoney(watch.price, watch.currency)}</strong><s class="stock-old">${stockMoney(drop.old, watch.currency)}</s><span class="sale-badge">-%${drop.percent}</span>`
    : html`<strong>${stockMoney(watch.price, watch.currency)}</strong>`;
};
// Fiyat geçmişi çizgisi; en az üç ölçümle çıkar. Üstüne gelince en yakın noktanın fiyatı ve tarihi görünür.
function StockTrend({ watch, w = 72, h = 22 }) {
  const [hover, setHover] = htmPreact.useState(-1);
  const points = watch.priceHistory || [];
  if (points.length < 3) return null;
  const values = points.map((p) => p.price),
    min = Math.min(...values),
    max = Math.max(...values),
    x = (i) => (i / (points.length - 1)) * w,
    y = (v) => (max === min ? h / 2 : 2 + ((max - v) / (max - min)) * (h - 4)),
    xy = values.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" "),
    move = (e) => {
      const box = e.currentTarget.getBoundingClientRect();
      setHover(Math.max(0, Math.min(points.length - 1, Math.round(((e.clientX - box.left) / box.width) * (points.length - 1)))));
    },
    p = points[hover];
  return html`<span class="stock-trend" onMouseMove=${move} onMouseLeave=${() => setHover(-1)}>
    <svg class="price-trend" viewBox="0 0 ${w} ${h}" width=${w} height=${h} role="img" aria-label=${`Fiyat geçmişi: ${points.length} ölçüm, en düşük ${stockMoney(min, watch.currency)}, en yüksek ${stockMoney(max, watch.currency)}`}>
      <polyline points=${xy} />${p && html`<circle cx=${x(hover)} cy=${y(p.price)} r="2.5" />`}
    </svg>
    ${p && html`<span class="trend-tip"><strong>${stockMoney(p.price, watch.currency)}</strong> · ${new Date(p.at).toLocaleString("tr-TR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>`}
  </span>`;
}
const StockBadge = ({ watch }) => {
  const s = stockState(watch);
  return html`<span class=${"chip stock-badge " + s.tone} title=${watch.evidence || ""}>${watch.paused ? "Duraklatıldı · " : ""}${s.label}</span>`;
};
function stockMeta(w) {
  if (w.paused) return "Duraklatıldı";
  if (w.error) return `Okunamadı: ${w.error}`;
  if (!w.checkedAt) return "İlk kontrol bekleniyor…";
  const since = w.state === "InStock" && w.inStockSince ? ` · ${stockAgo(w.inStockSince).replace(" önce", "dır")} stokta` : "";
  return `Kontrol ${stockAgo(w.checkedAt)}${since} · sıradaki ${stockAgo(w.nextCheck)}`;
}
const StockChips = ({ watch }) => html`
  ${watch.variant && html`<${Chip}>${watch.variant}<//>`}
  ${watch.targetPrice && html`<${Chip} tone=${watch.atTarget ? "success" : ""}>${watch.atTarget ? "Hedefte" : "Hedef"} ${stockMoney(watch.targetPrice, watch.currency)}<//>`}
  ${watch.price != null && watch.lowestPrice != null && (watch.priceHistory || []).length >= 2 && watch.price <= watch.lowestPrice && html`<${Chip} tone="success">En düşük fiyat<//>`}
  ${watch.usesBrowser && html`<${Chip} title="Bu site düz istekle okunamadı; görünmez tarayıcıyla okunuyor (en sık 30 dakikada bir).">Tarayıcıyla<//>`}`;

// Büyük görünüm kartı: tıklayınca düzenleme penceresi o karttan büyür; ⋯ ve sağ tık menüsü.
const StockCard = ({ watch }) => html`
  <article class=${"stock-card" + (watch.paused ? " is-paused" : "") + (watch.state === "InStock" ? " is-in" : "")} data-row-stock=${watch.id} data-action="stock-edit" data-id=${watch.id} tabindex="0">
    <div class="stock-top"><${StockImage} watch=${watch} /><div class="stock-head"><${StockBadge} watch=${watch} /><small class="stock-site">${watch.site}${watch.group ? " · " + watch.group : ""}</small></div>
      <${Button} action="stock-menu" icon="more" cls="icon-button row-more" data-id=${watch.id} aria-label="Diğer işlemler" /></div>
    <strong class="stock-name" title=${watch.name}>${watch.name}</strong>
    <div class="stock-price"><${StockPrice} watch=${watch} /><${StockTrend} watch=${watch} /></div>
    <div class="game-chips"><${StockChips} watch=${watch} /></div>
    <small class=${"stock-meta" + (watch.error ? " is-error" : "")} title=${watch.evidence || ""}>${stockMeta(watch)}</small>
  </article>`;
// Küçük görünüm satırı.
const StockRow = ({ watch }) => html`
  <div class="item-row stock-row" data-row-stock=${watch.id} data-action="stock-edit" data-id=${watch.id} tabindex="0">
    <${StockImage} watch=${watch} />
    <div class="item-copy"><strong>${watch.name}</strong><small class=${watch.error ? "is-error" : ""}>${watch.site} · ${stockMeta(watch)}</small></div>
    ${watch.price != null && html`<span class=${"price" + (stockDrop(watch) ? " on-sale" : "")}><${StockPrice} watch=${watch} /></span>`}
    <${StockBadge} watch=${watch} />
    <${Button} action="stock-menu" icon="more" cls="icon-button row-more" data-id=${watch.id} aria-label="Diğer işlemler" />
  </div>`;

const STOCK_FILTERS = ["Hepsi", "Stokta", "Yok", "Sorunlu", "Duraklatılan"];
const stockFilter = (w, f) =>
  f === "Hepsi" || (f === "Stokta" ? w.state === "InStock" && !w.paused : f === "Yok" ? w.state === "OutOfStock" : f === "Sorunlu" ? !!w.error || w.state === "Unknown" : w.paused);
// Sıra: stokta olanlar, sonra sorunlular, sonra yoklar; aynı durumda son değişen önce.
const stockRank = (w) => (w.paused ? 5 : w.state === "InStock" ? 0 : w.state === "PreOrder" ? 1 : w.error || w.state === "Unknown" ? 2 : 3);
const stockSorters = {
  Durum: (a, b) => stockRank(a) - stockRank(b) || new Date(b.events?.at(-1)?.at || b.addedAt) - new Date(a.events?.at(-1)?.at || a.addedAt),
  "Son eklenen": (a, b) => new Date(b.addedAt) - new Date(a.addedAt),
  Fiyat: (a, b) => (a.price ?? Infinity) - (b.price ?? Infinity),
  Ad: (a, b) => a.name.localeCompare(b.name, "tr"),
};

function StockPage() {
  const all = state.data.stock || [];
  const filter = state.stockFilter || "Hepsi",
    group = state.stockGroup || "",
    sort = state.stockSort || "Durum";
  const shown = all.filter((w) => stockFilter(w, filter) && (!group || w.group === group)).sort(stockSorters[sort] || stockSorters.Durum);
  const inStock = all.filter((w) => w.state === "InStock" && !w.paused).length,
    problems = all.filter((w) => w.error).length;
  const summary = all.length
    ? [`${all.length} bağlantı takipte`, inStock && `${inStock} stokta`, problems && `${problems} okunamıyor`].filter(Boolean).join(" · ")
    : "Ürün bağlantısını yapıştır; stok gelince ve fiyat düşünce haber vereyim.";
  const groups = stockGroups();
  return html`
    <${Heading} title="Stok" sub=${summary}>
      <${Button} action="stock-bulk" icon="plus" cls="ghost" title="Birden çok bağlantıyı bir kerede ekle">Toplu ekle<//>
      ${all.length > 0 && html`<${Button} action="stock-check-all" icon="refresh" cls="ghost" title="Duraklatılmamış bütün bağlantıları şimdi kontrol et">Hepsini kontrol et<//>`}
      <${Button} action="stock-new" icon="plus" cls="primary">Bağlantı ekle<//>
    <//>
    <form class="search stock-paste" data-stock-paste>
      <${Icon} n="search" />
      <input id="stock-url" autocomplete="off" placeholder="Ürün bağlantısını yapıştır ve Enter'a bas… (birden çok bağlantı da olur)" aria-label="Ürün bağlantısı" />
    </form>
    <div class="toolbar">
      <div class="segmented" role="group" aria-label="Stok süzgeci">${STOCK_FILTERS.map((f) => html`<button type="button" key=${f} class=${filter === f ? "active" : ""} aria-pressed=${filter === f} onClick=${() => { state.stockFilter = f; render(); }}>${f}</button>`)}</div>
      ${groups.length > 0 && html`<select aria-label="Grup" value=${group} onChange=${(e) => { state.stockGroup = e.target.value; render(); }}><option value="">Bütün gruplar</option>${groups.map((g) => html`<option key=${g} value=${g}>${g}</option>`)}</select>`}
      <span class="spacer"></span>
      <select aria-label="Sıralama" value=${sort} onChange=${(e) => { state.stockSort = e.target.value; render(); }}>${Object.keys(stockSorters).map((s) => html`<option key=${s} value=${s}>${s}</option>`)}</select>
    </div>
    ${!shown.length
      ? html`<section class="card"><${Empty} text=${all.length ? "Bu süzgeçte ürün yok." : "Takip ettiğin ürünler burada görünecek. Yukarıya bir ürün sayfasının bağlantısını yapıştır."} /></section>`
      : compact()
        ? html`<section class="card"><div class="rows">${shown.map((w) => html`<${StockRow} key=${w.id} watch=${w} />`)}</div></section>`
        : html`<div class="stock-grid">${shown.map((w) => html`<${StockCard} key=${w.id} watch=${w} />`)}</div>`}`;
}
pageComponents.stock = StockPage;

// Bugün widget'ı: önce stoktakiler, sonra son değişenler (en çok 4).
function StockWidget() {
  // Ana ekranda sakin kalsın (3 ajan, 3 Kasım 2026): en çok 3 ürün, görsel/baş harf kutusu yok, fiyat sağda.
  // Her ürün iki satır: üstte ad, altta durum · site (kullanıcı 3 Kasım 2026).
  const items = [...(state.data.stock || [])].filter((w) => !w.paused).sort(stockSorters.Durum).slice(0, 3);
  return html`<${Widget} id="stock">
    ${items.length
      ? html`<div class="side-list">${items.map((w) => html`<div class="side-game side-stock is-pickable" key=${w.id} data-row-stock=${w.id} data-action="stock-edit" data-id=${w.id} tabindex="0"><div class="item-copy"><strong>${w.name}</strong><small>${[stockState(w).label, w.site].filter(Boolean).join(" · ")}</small></div>${w.price != null && html`<span class="price">${stockMoney(w.price, w.currency)}</span>`}</div>`)}</div>`
      : html`<${Button} action="stock-new" icon="plus" cls="ghost side-wide">Ürün bağlantısı ekle<//>`}
  <//>`;
}

// ---------------------------------------------------------------- Menü ve işlemler
function stockMenu(id, target) {
  const w = state.data.stock.find((x) => x.id === id);
  if (!w) return;
  const data = `data-id="${id}"`;
  openMenu(
    target,
    menuItem("Şimdi kontrol et", "stock-check", "refresh", "", data) +
      menuItem("Siteyi aç", "stock-open", "external", "", data) +
      menuItem("Düzenle", "stock-edit", "edit", "", data) +
      menuItem("Geçmiş", "stock-history", "clock", "", data) +
      menuItem(w.paused ? "Sürdür" : "Duraklat", "stock-pause", w.paused ? "play" : "pause", "", data) +
      menuSeparator +
      menuItem("Takibi bırak", "stock-remove", "trash", "danger", data),
  );
}
async function stockAction(a, b) {
  const id = b?.dataset.id;
  const watch = id && state.data.stock.find((w) => w.id === id);
  if (a === "stock-menu") return stockMenu(id, b);
  if (a === "stock-new") return stockEditor(null, { url: b?.dataset.url || "" });
  if (a === "stock-edit") return watch && stockEditor(watch, { origin: rowOf("stock", id) });
  if (a === "stock-bulk") return stockBulkDialog();
  if (a === "stock-history") return watch && stockHistoryDialog(watch);
  if (a === "stock-open") return rpc("stock.open", { id });
  if (a === "stock-pause") {
    await rpc("stock.pause", { id, paused: !watch.paused });
    await refresh();
    return toast(watch.paused ? "Takip sürüyor." : "Duraklatıldı; kontrol edilmeyecek.");
  }
  if (a === "stock-remove")
    return confirmDialog("Takibi bırak", `${watch.name} artık kontrol edilmeyecek ve geçmişi silinecek.`, () => rpc("stock.remove", { id }));
  if (a === "stock-check") {
    toast(`${watch.name} kontrol ediliyor…`);
    const result = await rpc("stock.check", { id }, 120000);
    await refresh();
    return toast(result.error ? "Okunamadı: " + result.error : `${STOCK_STATES[stockKey(result.state)]?.label || "Belirsiz"}${result.price != null ? " · " + stockMoney(result.price, result.currency) : ""} · ${result.evidence || ""}`);
  }
  if (a === "stock-check-all") {
    toast("Bütün bağlantılar sırayla kontrol ediliyor… (aynı siteye 15 sn arayla)");
    const r = await rpc("stock.checkAll", {}, 30 * 60000);
    await refresh();
    return toast(`${r.checked} bağlantı kontrol edildi · ${r.inStock} stokta${r.errors ? ` · ${r.errors} okunamadı` : ""}.`);
  }
}
// Yapıştırma kutusu: tek bağlantı ekleme penceresini açar, birden çoksa toplu ekleme.
const stockUrls = (text) => (text.match(/(?:https?:\/\/|www\.)[^\s<>"']+/gi) || []).map((u) => u.replace(/[),.;]+$/, ""));
function stockPaste(text) {
  const urls = stockUrls(text);
  if (urls.length > 1) return stockBulkDialog(urls.join("\n"));
  stockEditor(null, { url: urls[0] || text.trim() });
}

// ---------------------------------------------------------------- Ekleme / düzenleme penceresi
// Bağlantı yapıştırılınca (ya da "Önizle") sayfa okunur ve ne bulunduğu gösterilir; kaydetmek ayrı.
function stockEditor(watch, { url = "", origin = null } = {}) {
  const w = watch || {};
  const editing = !!watch;
  const opt = (value, label, current) => `<option value="${value}" ${String(current) === String(value) ? "selected" : ""}>${esc(label)}</option>`;
  const groups = stockGroups();
  openDialog(
    editing ? "Stok takibi" : "Bağlantı ekle",
    `<form id="stock-form" class="stock-form">
      <div class="fields">
        ${field("Ürün bağlantısı", `<div class="button-row stock-url-row"><input name="url" required autocomplete="off" placeholder="https://…" value="${esc(w.url || url)}">${B("Önizle", "stock-preview", "search", "ghost")}</div>`, true)}
        <div id="stock-preview" class="stock-preview full" aria-live="polite">${editing ? stockPreviewHtml({ state: w.state, evidence: w.evidence, title: w.title, imageUrl: w.imageUrl, price: w.price, currency: w.currency, signals: [] }) : ""}</div>
        ${field("Ad", `<input name="title" maxlength="200" value="${esc(w.customTitle || "")}" placeholder="${esc(w.title || "Boş kalırsa sayfadaki ad")}">`)}
        ${field("Grup", `<input name="group" maxlength="40" list="stock-groups" value="${esc(w.group || "")}" placeholder="ör. Ekran kartı"><datalist id="stock-groups">${groups.map((g) => `<option value="${esc(g)}">`).join("")}</datalist>`)}
        ${field("Ne sıklıkla kontrol edilsin?", `<select name="interval">${STOCK_INTERVALS.map(([v, l]) => opt(v, l, w.intervalMinutes ?? 15)).join("")}</select>${w.usesBrowser ? `<small class="hint">Bu site görünmez tarayıcıyla okunuyor; bilgisayarı yormamak için en sık 30 dakikada bir kontrol edilir.</small>` : ""}`)}
        ${field("Beden / renk / model", `<input name="variant" maxlength="80" value="${esc(w.variant || "")}" placeholder="İsteğe bağlı · ör. 42, Siyah, 256 GB">`)}
        ${field("Hedef fiyat", `<input name="target" inputmode="decimal" autocomplete="off" value="${w.targetPrice ?? ""}" placeholder="Bu fiyata inince haber ver · ör. 12.999">`)}
      </div>
      <div class="stock-toggles">
        <label class="toggle-row"><span>Fiyat düşünce haber ver</span><input type="checkbox" class="switch" name="priceDrop" ${w.notifyPriceDrop ?? true ? "checked" : ""}></label>
        <label class="toggle-row"><span>Stok bitince de haber ver</span><input type="checkbox" class="switch" name="outOfStock" ${w.notifyOutOfStock ? "checked" : ""}></label>
        <label class="toggle-row"><span>Telefona da gönder<small class="muted"> Telefon bağlıysa (Ayarlar → Bildirimler).</small></span><input type="checkbox" class="switch" name="phone" ${w.phone ?? true ? "checked" : ""}></label>
      </div>
      <details class="stock-advanced" ${w.rule || (w.mode && w.mode !== "Auto") || w.note ? "open" : ""}>
        <summary>Gelişmiş: neye bakılacağını kendin seç</summary>
        <div class="fields">
          ${field("İzlenecek yazı", `<input name="rule" maxlength="120" value="${esc(w.rule?.text || "")}" placeholder="ör. Tükendi ya da Sepete Ekle">`)}
          ${field("Bu yazı…", `<select name="ruleMode">${opt("false", "kaybolunca stokta say (ör. Tükendi)", !!w.rule?.inStockWhenPresent)}${opt("true", "görününce stokta say (ör. Sepete Ekle)", !!w.rule?.inStockWhenPresent)}</select>`)}
          ${field("Sayfa nasıl okunsun?", `<select name="mode">${opt("Auto", "Otomatik (önce hızlı, olmazsa tarayıcı)", w.mode || "Auto")}${opt("Http", "Yalnız hızlı istek", w.mode || "Auto")}${opt("Browser", "Her zaman görünmez tarayıcıyla", w.mode || "Auto")}</select>`)}
          ${field("Not", `<input name="note" maxlength="500" value="${esc(w.note || "")}" placeholder="ör. indirim kodu, beden tablosu">`)}
        </div>
        <p class="hint">Otomatik okuma çoğu sitede yeter: önce ürün verisine (Google'ın da okuduğu), sonra "Tükendi / Sepete ekle" gibi yazılara bakarım. Yanlış karar verirse burada sayfada gördüğün bir yazıyı yaz.</p>
      </details>
      <div class="dialog-actions">${editing ? B("Takibi bırak", "stock-form-remove", "trash", "ghost push-left") : ""}${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">${editing ? "Kaydet" : "Takibe al"}</button></div>
    </form>`,
    { wide: true, origin },
  );
  const form = $("#stock-form");
  $$("#stock-preview img").forEach((img) => (img.onerror = () => img.remove()));
  const draft = () => {
    const f = form.elements;
    const target = f.target.value.trim() ? Number(f.target.value.trim().replace(/\s/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".")) : null;
    if (f.target.value.trim() && !(target > 0)) throw new Error("Hedef fiyatı sayı olarak yaz (ör. 12.999 ya da 1299,90).");
    return {
      url: f.url.value.trim(), title: f.title.value.trim() || null, group: f.group.value.trim() || null, note: f.note.value.trim() || null,
      intervalMinutes: +f.interval.value, mode: f.mode.value, ruleText: f.rule.value.trim() || null, ruleInStockWhenPresent: f.ruleMode.value === "true",
      variant: f.variant.value.trim() || null, targetPrice: target, notifyPriceDrop: f.priceDrop.checked, notifyOutOfStock: f.outOfStock.checked, phone: f.phone.checked,
    };
  };
  let previewing = 0;
  const preview = async () => {
    if (!form.elements.url.value.trim()) return;
    const ticket = ++previewing;
    $("#stock-preview").innerHTML = `<p class="muted">Sayfa okunuyor… (tarayıcı gerekirse 10–20 sn sürebilir)</p>`;
    try {
      const reading = await rpc("stock.preview", { draft: draft() }, 120000);
      if (ticket === previewing && form.isConnected) {
        setStockPreview(stockPreviewHtml(reading));
        if (!form.elements.title.value && reading.title) form.elements.title.placeholder = reading.title;
      }
    } catch (e) {
      if (ticket === previewing && form.isConnected) $("#stock-preview").innerHTML = `<p class="inline-error">${esc(e.message)}</p>`;
    }
  };
  $('#portal [data-action="stock-preview"]').onclick = (e) => {
    e.stopPropagation();
    preview();
  };
  form.elements.url.addEventListener("paste", () => setTimeout(preview, 30));
  const remove = $('#portal [data-action="stock-form-remove"]');
  if (remove) remove.onclick = (e) => {
    e.stopPropagation();
    stockAction("stock-remove", { dataset: { id: watch.id } });
  };
  form.onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    run(() =>
      busy("#stock-preview", editing ? "" : "Takibe alınıyor ve ilk kontrol yapılıyor…", async () => {
        const saved = editing ? await rpc("stock.save", { id: watch.id, draft: draft() }) : await rpc("stock.add", { draft: draft() }, 120000);
        closeDialog();
        playSound("add");
        await refresh();
        if (!editing && $("#stock-url")) $("#stock-url").value = "";
        toast(editing ? "Kaydedildi." : `${saved.name} takipte · ${STOCK_STATES[stockKey(saved.state)]?.label || "Belirsiz"}${saved.error ? " (okunamadı: " + saved.error + ")" : ""}`);
      }),
    );
  };
  if (url && !editing) preview();
}
// Yüklenemeyen ürün görseli kaldırılır (satır içi onerror güvenlik kuralına takılır).
function setStockPreview(markup) {
  const box = $("#stock-preview");
  box.innerHTML = markup;
  $$("img", box).forEach((img) => (img.onerror = () => img.remove()));
}
// Önizleme kutusu: ne okunduğu, neye bakıldığı; belirsizse ne yapılacağı.
function stockPreviewHtml(r) {
  const s = STOCK_STATES[stockKey(r.state)] || STOCK_STATES.unknown;
  const advice =
    r.state === "Blocked"
      ? "Site bot korumasına takıldı. Gelişmiş'ten “Her zaman görünmez tarayıcıyla”yı seçip tekrar önizle; yine olmazsa bu site otomatik okunamıyor."
      : r.state === "Unknown"
        ? "Stok bilgisi bulunamadı. Gelişmiş'e sayfada gördüğün bir yazıyı (ör. “Tükendi”) yazarsan ona bakarım."
        : "";
  return `<div class="stock-preview-box">
    ${r.imageUrl ? `<img class="stock-image" src="${esc(r.imageUrl)}" alt="" referrerpolicy="no-referrer">` : ""}
    <div class="item-copy"><strong>${esc(r.title || "Ad okunamadı")}</strong>
      <small><span class="chip ${s.tone}">${s.label}</span> ${r.price != null ? esc(stockMoney(r.price, r.currency)) : ""}${r.viaBrowser ? " · tarayıcıyla okundu" : ""}</small>
      <small class="muted">${esc(r.evidence || "")}</small>
      ${(r.signals || []).length > 1 ? `<ul class="stock-signals">${r.signals.slice(1, 5).map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}
      ${advice ? `<small class="stock-advice">${esc(advice)}</small>` : ""}
    </div></div>`;
}

// ---------------------------------------------------------------- Toplu ekleme ve geçmiş
function stockBulkDialog(text = "") {
  const groups = stockGroups();
  openDialog(
    "Toplu ekle",
    `<form id="stock-bulk-form"><p class="muted">Her satıra bir bağlantı yaz ya da bir listeyi olduğu gibi yapıştır; içindeki bağlantıları ben ayıklarım. Ayarlar hepsine aynı uygulanır, sonra tek tek değiştirebilirsin.</p>
      <div class="fields">${field("Bağlantılar", `<textarea name="urls" rows="7" placeholder="https://…&#10;https://…">${esc(text)}</textarea>`, true)}
      ${field("Grup", `<input name="group" maxlength="40" list="stock-bulk-groups"><datalist id="stock-bulk-groups">${groups.map((g) => `<option value="${esc(g)}">`).join("")}</datalist>`)}
      ${field("Ne sıklıkla kontrol edilsin?", `<select name="interval">${STOCK_INTERVALS.map(([v, l]) => `<option value="${v}" ${v === 15 ? "selected" : ""}>${l}</option>`).join("")}</select>`)}</div>
      <p id="stock-bulk-status" class="hint" role="status"></p>
      <div class="dialog-actions">${B("Vazgeç", "dialog-close", "", "ghost")}<button class="primary">Takibe al</button></div></form>`,
  );
  const form = $("#stock-bulk-form");
  const count = () => ($("#stock-bulk-status").textContent = `${stockUrls(form.elements.urls.value).length} bağlantı bulundu. İlk kontroller arka planda sırayla yapılır.`);
  form.elements.urls.addEventListener("input", count);
  if (text) count();
  form.onsubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const urls = stockUrls(form.elements.urls.value);
    if (!urls.length) return ($("#stock-bulk-status").textContent = "Bağlantı bulunamadı. https:// ile başlayan adresler yapıştır.");
    busy("#stock-bulk-status", "Ekleniyor…", async () => {
      const r = await rpc("stock.addMany", { urls, draft: { url: urls[0], group: form.elements.group.value.trim() || null, intervalMinutes: +form.elements.interval.value } });
      await refresh();
      if (!r.failed.length) {
        closeDialog();
        return toast(`${r.added} bağlantı takibe alındı; ilk kontroller birkaç dakika içinde.`);
      }
      $("#stock-bulk-status").textContent = `${r.added} eklendi. Eklenemeyenler: ${r.failed.join(" · ")}`;
    });
  };
}
function stockHistoryDialog(w) {
  const events = [...(w.events || [])].reverse();
  const prices = [...(w.priceHistory || [])].reverse();
  const when = (d) => new Date(d).toLocaleString("tr-TR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  openDialog(
    "Geçmiş",
    `<p class="muted"><strong>${esc(w.name)}</strong> · ${esc(w.site)} · ${w.checks} kontrol${w.addedAt ? ` · ${esc(when(w.addedAt))} tarihinden beri` : ""}</p>
    <div class="stock-history">
      <section><h3>Stok değişimleri</h3>${events.length ? `<ul>${events.map((e) => `<li><span class="chip ${(STOCK_STATES[stockKey(e.state)] || STOCK_STATES.unknown).tone}">${(STOCK_STATES[stockKey(e.state)] || STOCK_STATES.unknown).label}</span><small>${esc(when(e.at))}${e.price != null ? " · " + esc(stockMoney(e.price, w.currency)) : ""}</small></li>`).join("")}</ul>` : `<p class="muted">Henüz değişim yok.</p>`}</section>
      <section><h3>Fiyat${w.lowestPrice != null ? ` · en düşük ${esc(stockMoney(w.lowestPrice, w.currency))}` : ""}</h3>${prices.length ? `<ul>${prices.slice(0, 30).map((p) => `<li><strong>${esc(stockMoney(p.price, w.currency))}</strong><small>${esc(when(p.at))}</small></li>`).join("")}</ul>` : `<p class="muted">Fiyat okunmadı.</p>`}</section>
    </div>
    <p class="hint">Son karar: ${esc(w.evidence || "—")}</p>
    <div class="dialog-actions">${B("Siteyi aç", "stock-open", "external", "ghost", `data-id="${w.id}"`)}${B("Kapat", "dialog-close", "", "primary")}</div>`,
    { wide: true },
  );
}
