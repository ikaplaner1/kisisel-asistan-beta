using System.Text.RegularExpressions;

namespace KisiselAsistan;

// New panels can register handlers without changing speech recognition.
public sealed class VoiceCommands
{
    private readonly List<(Regex Pattern, Func<Match, Task<string>> Execute)> handlers = [];
    public void Register(string pattern, Func<Match, Task<string>> execute) =>
        handlers.Add((new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant), execute));
    public async Task<string?> ExecuteAsync(string text)
    {
        text = text.Trim().TrimEnd('.', '!', '?');
        foreach (var handler in handlers) {
            var match = handler.Pattern.Match(text);
            if (match.Success) return await handler.Execute(match);
        }
        return null;
    }
    public static string Number(string text) => text.ToLowerInvariant() switch {
        "bir" or "one" => "1", "iki" or "two" => "2", "üç" or "three" => "3",
        "dört" or "four" => "4", "beş" or "five" => "5", "altı" or "six" => "6",
        "yedi" or "seven" => "7", "sekiz" or "eight" => "8", "dokuz" or "nine" => "9",
        "on" or "ten" => "10", _ => text
    };
    public static void Verify()
    {
        var router = new VoiceCommands(); var calls = 0;
        router.Register(@"^steam (?:ara|search) (.+)$", m => { calls++; return Task.FromResult(m.Groups[1].Value); });
        if (router.ExecuteAsync("Steam ara Hades.").GetAwaiter().GetResult() != "Hades" ||
            router.ExecuteAsync("steam search Portal 2").GetAwaiter().GetResult() != "Portal 2" ||
            router.ExecuteAsync("Steam rastgele sil").GetAwaiter().GetResult() is not null || calls != 2 || Number("two") != "2")
            throw new Exception("Ses komutu yönlendirme testi başarısız.");
    }
}
