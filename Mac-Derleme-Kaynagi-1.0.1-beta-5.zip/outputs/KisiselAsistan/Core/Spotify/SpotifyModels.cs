namespace KisiselAsistan;
public interface ISpotifySession { Task<string> AccessAsync(CancellationToken token); }
// AlbumUri: şarkı albümünün içinden çalınır; böylece şarkı bitince albüm, albüm bitince
// (Spotify ayarlarında Otomatik oynat açıksa) Spotify'ın benzer şarkıları devam eder.
public record SpotifyTrack(string Uri, string Name, string Artist, string? CoverUrl = null, string? AlbumUri = null)
{
    public override string ToString() => Name + " · " + Artist;
    internal static bool ValidAlbum(string? uri) => uri is not null && System.Text.RegularExpressions.Regex.IsMatch(uri, "^spotify:album:[A-Za-z0-9]{22}$");
}
public record SpotifyPlaying(SpotifyTrack Track, int Position, int Duration, bool Playing, string Device, int? Volume = null, string? DeviceId = null, bool SupportsVolume = false);
