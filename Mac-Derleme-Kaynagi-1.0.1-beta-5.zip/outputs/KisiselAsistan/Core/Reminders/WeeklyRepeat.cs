namespace KisiselAsistan;

// Hatırlatıcı görünümündeki tekrar bilgisi; asıl kural işin ItemRepeat alanıdır.
public record WeeklyRepeat(int DaysMask, int TimeMinutes = -1)
{
    public Guid SeriesId { get; init; }
    public void Validate() { if (DaysMask is < 1 or > 127 || TimeMinutes is < -1 or > 1439) throw new ArgumentException("Haftalık tekrar için en az bir gün seç."); }
    internal bool Includes(DayOfWeek day) => (DaysMask & (1 << (int)day)) != 0;
}
