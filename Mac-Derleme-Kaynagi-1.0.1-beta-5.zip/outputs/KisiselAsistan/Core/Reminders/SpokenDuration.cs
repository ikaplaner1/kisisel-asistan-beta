using System.Text.RegularExpressions;
namespace KisiselAsistan;

internal static class SpokenDuration
{
    private static readonly Dictionary<string, int> Numbers = new() { ["bir"] = 1, ["iki"] = 2, ["uc"] = 3, ["dort"] = 4, ["bes"] = 5, ["alti"] = 6, ["yedi"] = 7, ["sekiz"] = 8, ["dokuz"] = 9, ["on"] = 10, ["yirmi"] = 20, ["otuz"] = 30, ["kirk"] = 40, ["elli"] = 50, ["altmis"] = 60, ["yetmis"] = 70, ["seksen"] = 80, ["doksan"] = 90 };
    internal static bool TryParse(string text, out int seconds)
    {
        seconds = 0;
        if (Regex.IsMatch(text, @"-\s*\d|\d[.,]\d")) return false;
        text = Regex.Replace(ReminderVoiceRemoval.Fold(text), @"\s+", " ");
        var parts = Regex.Matches(text, @"(?<amount>.+?)\s+(?<unit>saat|dakika|saniye)(?:\s+ve\s+|\s+|$)");
        if (parts.Count is < 1 or > 3 || string.Concat(parts.Select(p => p.Value)) != text) return false;
        double sum = 0; var units = new HashSet<string>();
        foreach (Match part in parts) {
            var amountText = part.Groups["amount"].Value;
            var half = amountText == "yarim" || amountText.EndsWith(" bucuk", StringComparison.Ordinal);
            if (half) amountText = amountText == "yarim" ? "" : amountText[..^6].Trim();
            double amount = 0;
            if (amountText.Length > 0) {
                if (int.TryParse(amountText, out var integer)) amount = integer;
                else {
                    var words = amountText.Split(' ');
                    if (words.Length is < 1 or > 2 || words.Any(w => !Numbers.ContainsKey(w)) || (words.Length == 2 && (Numbers[words[0]] < 10 || Numbers[words[1]] > 9))) return false;
                    amount = words.Sum(w => Numbers[w]);
                }
            }
            if (half) amount += 0.5;
            if (amount <= 0) return false;
            var unit = part.Groups["unit"].Value;
            if (!units.Add(unit)) return false;
            sum += amount * (unit == "saat" ? 3600 : unit == "dakika" ? 60 : 1);
        }
        if (sum < 1 || sum > 31536000 || sum != Math.Truncate(sum)) return false;
        seconds = (int)sum; return true;
    }
    internal static string Canonical(int seconds) => seconds % 3600 == 0 ? $"{seconds / 3600} saat" : seconds % 60 == 0 ? $"{seconds / 60} dakika" : $"{seconds} saniye";
}
