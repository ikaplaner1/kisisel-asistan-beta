namespace KisiselAsistan;
// Allows: hesap bu izni verdi mi (eski bağlantılarda çalma listesi izni yoktu; yeniden bağlanınca gelir).
public interface ISpotifySession { Task<string> AccessAsync(CancellationToken token); bool Allows(string scope) => true; }
// AlbumUri: şarkı albümünün içinden çalınır; böylece şarkı bitince albüm, albüm bitince
// (Spotify ayarlarında Otomatik oynat açıksa) Spotify'ın benzer şarkıları devam eder.
public record SpotifyTrack(string Uri, string Name, string Artist, string? CoverUrl = null, string? AlbumUri = null)
{
    public override string ToString() => Name + " · " + Artist;
    internal static bool ValidAlbum(string? uri) => uri is not null && System.Text.RegularExpressions.Regex.IsMatch(uri, "^spotify:album:[A-Za-z0-9]{22}$");
}
// Shuffle/Repeat: Spotify'ın karışık ve tekrar durumu (repeat: off = kapalı, context = liste/albüm, track = şarkı).
public record SpotifyPlaying(SpotifyTrack Track, int Position, int Duration, bool Playing, string Device, int? Volume = null, string? DeviceId = null, bool SupportsVolume = false, bool Shuffle = false, string Repeat = "off")
{
    internal static bool ValidRepeat(string? mode) => mode is "off" or "context" or "track";
}
public record SpotifyPlaylist(string Uri, string Name, string Owner, int Tracks, string? CoverUrl = null)
{
    internal static bool Valid(string? uri) => uri is not null && System.Text.RegularExpressions.Regex.IsMatch(uri, "^spotify:playlist:[A-Za-z0-9]{22}$");
}
