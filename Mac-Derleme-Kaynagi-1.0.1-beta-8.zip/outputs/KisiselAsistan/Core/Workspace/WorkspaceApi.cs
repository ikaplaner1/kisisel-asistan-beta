using System.Globalization;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace KisiselAsistan;

// Arayüzü taşıyan masaüstü kabuğunun (Windows penceresi ya da Mac Electron + host) sağladıkları.
// Platforma özgü işlemler (pencere, AI panelleri, hesap bağlantıları, ses, dosya seçme) DispatchAsync'e düşer.
public interface IWorkspaceHost
{
    bool Testing { get; }
    // Arayüzün canlı durumu: tema renkleri, görünüm, sesli asistanın aşaması …
    object Live();
    // Tema listesi (ad + 9 renk).
    IReadOnlyList<WorkspaceTheme> Themes();
    // Hatırlatıcıyı tamamla (ADHD hatırlatmasında onay bildirimle istenir).
    void CompleteReminder(Guid id);
    Task<object?> DispatchAsync(string method, JsonElement parameters);
}
public sealed record WorkspaceTheme(string Name, string[] Colors);
// Arayüz işlemlerinin dayandığı hizmetler (her iki kabukta da aynı şekilde kurulur).
public sealed record WorkspaceServices(
    ItemStore Items, ReminderService Reminders, TaskRoutineService Tasks, ItemEditor Editor, RoutineService Routines,
    SteamService Steam, ReminderDefaults Defaults, OperationRegistry Operations, CommandRunner Commands,
    NotificationSettingsStore? Notifications = null, DailyDigest? Digest = null, PhoneLink? Phone = null, FocusSession? Focus = null, OllamaInterpreter? Ollama = null,
    StockService? Stock = null, CommandFeedback? Feedback = null);

// Web arayüzünün (WorkspaceWeb) çağırdığı işlemler. Windows ve Mac aynı sınıfı kullanır; arayüz yalnızca
// buradaki yöntemleri çağırabilir. Veri işlemleri burada, platforma özgü olanlar IWorkspaceHost'ta.
public sealed class WorkspaceApi(WorkspaceServices services, IWorkspaceHost host)
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { Converters = { new JsonStringEnumConverter() } };
    // Arayüzün doğrudan çağırabileceği ortak işlemler (izin listesi).
    private static readonly HashSet<string> Operations = ["steam.list", "steam.search", "steam.track", "steam.importWishlist", "steam.target", "steam.unwatch", "steam.check", "spotify.search", "spotify.playTrack", "spotify.queue", "spotify.playlists", "spotify.playPlaylist", "spotify.shuffle", "spotify.repeat", "spotify.current", "spotify.volume", "spotify.seek", "spotify.open", "spotify.control", "spotify.status"];
    private static string Text(JsonElement p, string key) => p.GetProperty(key).GetString() ?? "";
    private static Guid Id(JsonElement p) => p.GetProperty("id").GetGuid();
    private static Guid? OptionalId(JsonElement p) => p.TryGetProperty("id", out var id) && id.ValueKind == JsonValueKind.String ? id.GetGuid() : null;
    private static T Read<T>(JsonElement value) => value.Deserialize<T>(Json) ?? throw new ArgumentException("Eksik alan.");
    // Seçilen dosyayı okuyup önizleme için programa çevirir (Windows ve Mac kabuğu ortak kullanır).
    private PhoneLink Phone() => services.Phone ?? throw new InvalidOperationException("Telefon bağlantısı bu sürümde yok.");
    private CommandFeedback Feedback() => services.Feedback ?? throw new InvalidOperationException("Komut geri bildirimi bu sürümde yok.");
    private FocusSession Focus() => services.Focus ?? throw new InvalidOperationException("Odak bu sürümde yok.");
    private StockService Stock() => services.Stock ?? throw new InvalidOperationException("Stok takibi bu sürümde yok.");
    // Stok kontrolleri sayfa başına 25 sn'ye kadar sürebilir (tarayıcıyla okuma dahil).
    private static CancellationToken StockTimeout(int seconds = 90) => new CancellationTokenSource(TimeSpan.FromSeconds(seconds)).Token;
    public static object ReadSchedule(string fileName, byte[] data)
    {
        var parsed = ScheduleParser.Parse(ScheduleReader.Read(fileName, data));
        return new { file = Path.GetFileName(fileName), entries = parsed.Entries, notes = parsed.Notes };
    }

    public async Task<object?> DispatchAsync(string method, JsonElement p)
    {
        var tasks = services.Tasks; var reminders = services.Reminders;
        switch (method) {
            case "snapshot": return Snapshot(p);
            case "operation": return await Operation(Text(p, "name"), p.GetProperty("parameters"));
            case "task.save": {
                var node = JsonNode.Parse(p.GetProperty("task").GetRawText())!.AsObject();
                var id = node["id"] == null ? Guid.NewGuid() : Guid.Parse(node["id"]!.GetValue<string>());
                node["id"] = id.ToString();
                var task = node.Deserialize<RoutineTask>(Json)!;
                var old = tasks.Items.Find(t => t.Id == id);
                task = task with { Steps = task.Steps ?? [], Repeat = task.Repeat ?? "none", Done = old?.Done ?? false, CompletedDays = old?.CompletedDays, PreviousOccurrence = old?.PreviousOccurrence };
                tasks.Save(task); return id;
            }
            // Tek görev formu: görev ve hatırlatıcı aynı kayıt (Core/Items/ItemEditor.cs).
            case "item.get": return services.Editor.Get(Id(p)) ?? throw new ArgumentException("Kayıt bulunamadı.");
            case "item.save": return services.Editor.Save(Read<ItemForm>(p.GetProperty("form")));
            case "task.remove": tasks.Remove(Id(p)); return true;
            case "task.order": tasks.Reorder(Read<List<Guid>>(p.GetProperty("ids"))); return true;
            case "task.important": case "task.day": case "task.step": case "task.complete": {
                var task = tasks.Items.SingleOrDefault(t => t.Id == Id(p)) ?? throw new ArgumentException("Görev bulunamadı.");
                var day = p.TryGetProperty("day", out var d) ? DateOnly.Parse(d.GetString()!, CultureInfo.InvariantCulture) : DateOnly.FromDateTime(DateTime.Today);
                if (method == "task.complete") {
                    if (task.DailyActivity ? task.CompletedDays?.Contains(day) == true : task.Done) tasks.Restore(task.Id, day);
                    else if (task.DailyActivity) tasks.CompleteDay(task.Id, day);
                    else tasks.Complete(task.Id, DateOnly.FromDateTime(DateTime.Today));
                } else if (method == "task.important") tasks.Save(task with { Important = !task.Important });
                else if (method == "task.day") tasks.Save(task with { MyDay = task.MyDay == day ? null : day });
                else { var index = p.GetProperty("index").GetInt32(); if (index < 0 || index >= task.Steps.Count) throw new ArgumentException("Adım bulunamadı."); task.Steps[index] = task.Steps[index] with { Done = p.GetProperty("done").GetBoolean() }; tasks.Save(task); }
                return true;
            }
            case "reminder.save": {
                var options = Read<ReminderOptions>(p.GetProperty("options")); options.Validate();
                var node = JsonNode.Parse(p.GetProperty("plan").GetRawText())!.AsObject();
                // Seri kimliklerini hizmet üretir.
                if (node["weekly"] is JsonObject weekly && weekly["seriesId"] == null) weekly["seriesId"] = Guid.Empty.ToString();
                var plan = node.Deserialize<PlanDetails>(Json)!; plan.Validate();
                var id = OptionalId(p); var due = p.GetProperty("due").GetDateTimeOffset(); var text = Text(p, "text");
                if (id.HasValue) reminders.Edit(id.Value, text, due, options, plan); else reminders.Add(text, due, options, plan);
                return true;
            }
            case "reminder.remove": reminders.Remove(Id(p)); return true;
            case "reminder.clear": reminders.ClearCompleted(); return true;
            case "reminder.snooze": reminders.Snooze(Id(p), TimeSpan.FromMinutes(5)); return true;
            case "reminder.move": reminders.Move(Id(p), p.GetProperty("due").GetDateTimeOffset()); return true;
            case "reminder.complete": host.CompleteReminder(Id(p)); return true;
            case "routine.save": services.Routines.Save(new(OptionalId(p) ?? Guid.NewGuid(), Text(p, "name"), Read<List<RoutineStep>>(p.GetProperty("steps")),
                p.TryGetProperty("schedule", out var schedule) && schedule.ValueKind == JsonValueKind.Object ? Read<RoutineSchedule>(schedule) : null)); return true;
            case "routine.remove": services.Routines.Remove(Id(p)); return true;
            // Ders programı / iş saati içe aktarma. Dosya seçimi kabuktadır (Windows: schedule.pick); Mac kabuğu dosyayı base64 olarak buraya gönderir.
            case "schedule.read": {
                var data = Convert.FromBase64String(Text(p, "data"));
                return ReadSchedule(Text(p, "name"), data);
            }
            case "schedule.import": return ScheduleImport.Save(services.Editor, Read<ScheduleImportRequest>(p.GetProperty("request")));
            case "schedule.programs": return ScheduleImport.Programs(services.Items);
            case "schedule.remove": return ScheduleImport.Remove(services.Items, Text(p, "name"));
            case "defaults.save": { var options = Read<ReminderOptions>(p).Normalize(); options.Validate(); services.Defaults.Set(options); return options; }
            case "options.describe": { var options = Read<ReminderOptions>(p).Normalize(); return new { name = options.Name, description = options.Description }; }
            case "preferences.get": return PlanningPreferenceStore.Load();
            // Bildirim ayarları (sabah özeti, toplama) ve özetin önizlemesi.
            case "notifications.get": return services.Notifications?.Current ?? new NotificationSettings();
            case "notifications.save": {
                var settings = Read<NotificationSettings>(p); settings.Validate();
                if (!host.Testing) (services.Notifications ?? throw new InvalidOperationException("Bildirim ayarları hazır değil.")).Save(settings);
                return true;
            }
            // Komut geri bildirimi (Ayarlar → Ses ve komutlar). Mac'te hizmet yok: available=false, kayıt da yok.
            case "feedback.get": {
                if (services.Feedback is not { } feedback) return new { available = false, supported = false };
                var s = feedback.Settings;
                return new { available = feedback.Available, supported = true, share = s.Share, noticeShown = s.NoticeShown, installId = s.InstallId,
                    entries = feedback.Recent().Select(e => new { at = e.At, text = e.Text, phase = e.Phase, path = e.Path, status = e.Sent ? "sent" : e.Share ? "waiting" : "local" }) };
            }
            case "feedback.save": Feedback().SetShare(p.GetProperty("share").GetBoolean()); return true;
            case "feedback.notice": Feedback().MarkNoticeShown(); return true;
            case "feedback.clear": Feedback().Clear(); return true;
            // Odak (pomodoro). Durum ayrıca canlı durumda (live.focus) gelir.
            case "focus.state": return Focus().State();
            case "focus.start": return Focus().Start(p.TryGetProperty("task", out var focusTask) && focusTask.ValueKind == JsonValueKind.String ? focusTask.GetString() : null);
            case "focus.stop": return Focus().Stop();
            case "focus.skip": return Focus().SkipBreak();
            case "focus.settings": return Focus().Settings;
            case "focus.save": Focus().Save(Read<FocusSettings>(p)); return true;
            case "focus.history": return Focus().History(p.TryGetProperty("days", out var historyDays) && historyDays.TryGetInt32(out var hd) ? hd : 28);
            // Adımlara böl (yerel Ollama): öneri döner, kaydetmez; ekleme arayüzde onaydan sonra task.save ile.
            case "task.breakdown":
                if (host.Testing) return new[] { "Birinci adım", "İkinci adım", "Üçüncü adım" };
                return await (services.Ollama ?? throw new InvalidOperationException("Ollama bu sürümde yok.")).BreakdownAsync(Text(p, "title"));
            // Telefon (ntfy). Konu adı yalnız bağlarken ve "göster" denince arayüze gider.
            case "phone.status": return Phone().Status();
            case "phone.link": { var topic = Phone().Link(); return new { topic, server = Phone().Settings.Server }; }
            case "phone.topic": return new { topic = Phone().Topic, server = Phone().Settings.Server };
            case "phone.save": Phone().Save(Read<PhoneSettings>(p)); return Phone().Status();
            case "phone.unlink": Phone().Unlink(); return Phone().Status();
            case "phone.test": {
                if (host.Testing) throw new InvalidOperationException("Testte telefona gönderilmez.");
                return await Phone().SendAsync("Kişisel Asistan", "Deneme bildirimi: telefon bağlantın çalışıyor. Buraya \"yarın 9'da dişçi\" gibi yazarsan bilgisayardaki asistana eklenir.", force: true)
                    ? "Deneme bildirimi gönderildi. Telefonunda göründü mü?"
                    : throw new InvalidOperationException("Gönderilemedi. İnternet bağlantını ve sunucu adresini kontrol et.");
            }
            case "notifications.preview": {
                var digest = services.Digest ?? throw new InvalidOperationException("Özet hazır değil.");
                var now = DateTimeOffset.Now;
                return digest.Build(DateOnly.FromDateTime(now.LocalDateTime), now);
            }
            case "preferences.save": { var preferences = Read<PlanningPreferences>(p); preferences.Validate(); if (!host.Testing) PlanningPreferenceStore.Save(preferences); return true; }
            case "reminder.suggest": {
                var plan = Read<PlanDetails>(p.GetProperty("plan")); plan.Validate();
                if (plan.Certainty != PlanCertainty.Flexible) throw new InvalidOperationException("Plan türünden Esnek seç; kesin planın saatini sen belirle.");
                var day = DateTime.Parse(Text(p, "day"), CultureInfo.InvariantCulture).Date;
                return reminders.SuggestTimes(day, plan, OptionalId(p)).Select(s => new { start = new DateTimeOffset(s.Start), end = new DateTimeOffset(s.End), preferred = s.Preferred });
            }
            case "day.plan": {
                var day = DateTime.Parse(Text(p, "day"), CultureInfo.InvariantCulture).Date;
                var plans = Read<List<PlanDetails>>(p.GetProperty("plans")).Select(x => x with { Certainty = PlanCertainty.Flexible, Weekly = null }).ToList();
                plans.ForEach(x => x.Validate());
                return PlanSuggestions.PlanDay(day, plans, PlanningPreferenceStore.Load(), reminders.Items).Select(s => s == null ? null : new { start = new DateTimeOffset(s.Start), end = new DateTimeOffset(s.End) });
            }
            // Toplu ekleme önizlemesi: metin işlere bölünür, her biri hızlı eklemeyle aynı biçimde çözülür (kaydetmez).
            case "quick.split": {
                var now = DateTimeOffset.Now;
                return BrainDump.Split(Text(p, "text")).Select(part => { var when = WhenParser.Parse(part, now); return new { kind = when.Someday ? "someday" : when.Due != null ? "reminder" : "task", text = when.Text, due = when.Due, day = when.Day ?? DateOnly.FromDateTime(DateTime.Today) }; });
            }
            case "day.load": {
                var load = PlanSuggestions.Load(DateTime.Parse(Text(p, "day"), CultureInfo.InvariantCulture).Date, PlanningPreferenceStore.Load(), reminders.Items);
                return new { free = load.FreeMinutes, busy = load.BusyMinutes, limit = load.LimitMinutes };
            }
            // Stok takibi (Core/Stock). Önizleme kaydetmez; ekleme ilk okumayı da yapar.
            case "stock.info": return new { browser = Stock().BrowserAvailable, limit = StockService.Limit, intervals = StockDraft.Intervals };
            case "stock.preview": return await Stock().PreviewAsync(Read<StockDraft>(p.GetProperty("draft")), StockTimeout());
            case "stock.add": return await Stock().AddAsync(Read<StockDraft>(p.GetProperty("draft")), StockTimeout());
            case "stock.addMany": {
                var (added, failed) = await Stock().AddManyAsync(Read<List<string>>(p.GetProperty("urls")), Read<StockDraft>(p.GetProperty("draft")), StockTimeout());
                return new { added, failed };
            }
            case "stock.save": return Stock().Edit(Id(p), Read<StockDraft>(p.GetProperty("draft")));
            case "stock.remove": Stock().Remove(Id(p)); return true;
            case "stock.pause": Stock().SetPaused(Id(p), p.GetProperty("paused").GetBoolean()); return true;
            case "stock.check": return await Stock().CheckAsync(Id(p), StockTimeout());
            case "stock.checkAll": return await Stock().CheckAllAsync(StockTimeout(30 * 60));
            // Hızlı ekleme ve Ctrl+K: metni uygulamanın tek tarih/saat ayrıştırıcısıyla çözer (kaydetmez).
            case "quick.parse": {
                var when = WhenParser.Parse(TextCleaner.Address(Text(p, "text").Trim()), DateTimeOffset.Now);
                return new { kind = when.Someday ? "someday" : when.Due != null ? "reminder" : "task", text = when.Text, due = when.Due, day = when.Day ?? DateOnly.FromDateTime(DateTime.Today) };
            }
        }
        return await host.DispatchAsync(method, p);
    }

    private async Task<object?> Operation(string name, JsonElement parameters)
    {
        if (!Operations.Contains(name)) throw new ArgumentException("Bu işleme çalışma alanından erişilemez.");
        if (host.Testing) {
            if (name is "steam.list") return services.Steam.Items;
            if (name is "steam.target") { var r = parameters.Deserialize<SteamTargetRequest>(new JsonSerializerOptions(JsonSerializerDefaults.Web))!; services.Steam.SetTarget(r.Id, r.Price); return true; }   // yerel kayıt, testte de çalışır
            if (name is "steam.search" or "spotify.search" or "spotify.playlists") return Array.Empty<object>();
            if (name == "spotify.current") return null;
            throw new InvalidOperationException("Test görünümünde dış hizmet işlemleri kapalı.");
        }
        var result = await services.Operations.ExecuteAsync(name, parameters);
        if (!result.Success) throw new InvalidOperationException(result.Message);
        if (result.Data is { } data) services.Commands.Remember(name, data);
        return result.Data;
    }

    // Arayüze giden veri. Her parçanın (görevler, hatırlatıcılar, kısayollar, oyunlar …) bir sürümü vardır;
    // arayüz bildiği sürümleri gönderir, yalnızca değişen parçalar döner. İlk istekte hepsi gelir.
    // Hatırlatıcılarda tekrarlar yalnızca istenen tarih aralığı kadar gönderilir (from–to).
    private object Snapshot(JsonElement p)
    {
        var known = p.ValueKind == JsonValueKind.Object && p.TryGetProperty("known", out var k) && k.ValueKind == JsonValueKind.Object
            ? k.EnumerateObject().ToDictionary(x => x.Name, x => x.Value.ValueKind == JsonValueKind.String ? x.Value.GetString() ?? "" : "")
            : [];
        var today = DateOnly.FromDateTime(DateTime.Today);
        DateOnly Day(string name, DateOnly fallback) => p.ValueKind == JsonValueKind.Object && p.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String
            && DateOnly.TryParseExact(v.GetString(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var day) ? day : fallback;
        var from = Day("from", today.AddDays(-62)); var to = Day("to", today.AddDays(190));
        if (to < from || to.DayNumber - from.DayNumber > 900) throw new ArgumentException("Tarih aralığı geçersiz.");

        var result = new Dictionary<string, object?>();
        var versions = new Dictionary<string, string>();
        void Part(string name, string version, Func<object?> value)
        {
            versions[name] = version;
            if (!known.TryGetValue(name, out var seen) || seen != version) result[name] = value();
        }
        // Küçük parçalar: içeriğin özeti sürümdür.
        void Hashed(string name, object value)
        {
            var json = JsonSerializer.SerializeToUtf8Bytes(value, Json);
            Part(name, Convert.ToHexString(SHA256.HashData(json))[..16], () => JsonDocument.Parse(json).RootElement.Clone());
        }
        // Görev ve hatırlatıcılar aynı dosyadan gelir; dosya değişmedikçe sürüm aynıdır (yeniden hesaplanmaz).
        services.Items.Read();
        var generation = services.Items.Generation.ToString(CultureInfo.InvariantCulture);
        Part("tasks", generation, () => services.Tasks.Items);
        Part("reminders", $"{generation}|{today:yyyy-MM-dd}|{from:yyyy-MM-dd}|{to:yyyy-MM-dd}", () => ReminderService.ForScreen(services.Reminders.Items, from, to));
        Hashed("routines", services.Routines.Items);
        Hashed("steam", services.Steam.Items);
        if (services.Stock is { } stock) Part("stock", stock.Version.ToString(CultureInfo.InvariantCulture), () => stock.Items);
        Hashed("defaults", services.Defaults.Options);
        Hashed("themes", host.Themes().Select(t => new { name = t.Name, colors = t.Colors }).ToList());
        result["versions"] = versions;
        result["live"] = host.Live();
        return result;
    }
}
