namespace KisiselAsistan;

internal sealed class GoogleCalendarConnection : IDisposable
{
    internal readonly GoogleCalendarAccount Account = new();
    internal readonly GoogleCalendarSync Sync;
    private readonly GoogleCalendarApi api;
    private readonly ReminderService reminders;
    private readonly CancellationTokenSource lifetime = new();
    private DateTimeOffset nextSync = DateTimeOffset.MinValue;
    private string observed = "";
    private bool busy;
    internal string Status { get; private set; } = "Google Calendar bağlı değil.";
    internal event Action<string>? StatusChanged;
    internal GoogleCalendarConnection(ReminderService reminders)
    {
        this.reminders = reminders;
        Account.Progress += Report;
        api = new(Account);
        Sync = new(reminders, api, Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KisiselAsistan", "google-calendar-sync.json"), () => Account.AccountKey);
        observed = Sync.LocalFingerprint;
        if (Account.Connected) Status = "Google Calendar bağlı · eşitleme bekleniyor.";
        reminders.Changed += LocalChanged;
    }
    private void LocalChanged()
    {
        var fingerprint = Sync.LocalFingerprint;
        if (fingerprint == observed) return;
        observed = fingerprint;
        if (!busy) nextSync = DateTimeOffset.Now.AddSeconds(3);
    }
    private void Report(string text) { Status = text; StatusChanged?.Invoke(text); }
    internal void ImportCredentials(string json)
    {
        if (busy) throw new InvalidOperationException("Eşitleme bitince dosyayı tekrar seç.");
        Account.ImportCredentials(json);
        Report("Bağlantı dosyası hazır. Google ile bağlan’a bas.");
    }
    internal async Task ConnectAsync(CancellationToken token)
    {
        if (busy) throw new InvalidOperationException("Eşitleme bitince tekrar dene.");
        busy = true;
        try {
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(token, lifetime.Token);
            Report("Tarayıcıdan Google hesabına giriş yapıp takvim iznini ver…");
            await Account.ConnectAsync(linked.Token);
            Report("Google hesabı bağlandı. Kişisel Asistan takvimi hazırlanıyor…");
            await Sync.EnsureCalendarAsync(linked.Token);
            Report((await Sync.SyncAsync(linked.Token)).Message);
            nextSync = DateTimeOffset.Now.AddMinutes(5);
        } catch (Exception ex) { Report("Google bağlantısı: " + (ex is OperationCanceledException ? "İşlem iptal edildi." : ex.Message)); throw; }
        finally { busy = false; }
    }
    internal async Task<string> SyncNowAsync(CancellationToken token)
    {
        if (busy) return "Eşitleme zaten sürüyor.";
        if (!Account.Connected) throw new InvalidOperationException("Önce Google hesabını bağla.");
        busy = true;
        try {
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(token, lifetime.Token);
            Report("Google Calendar eşitleniyor…");
            if (Sync.State.CalendarId.Length == 0) await Sync.EnsureCalendarAsync(linked.Token);
            Report((await Sync.SyncAsync(linked.Token)).Message);
            return Status;
        } catch (Exception ex) { Report("Google Calendar: " + (ex is OperationCanceledException ? "İşlem iptal edildi." : ex.Message)); throw; }
        finally { nextSync = DateTimeOffset.Now.AddMinutes(5); busy = false; }
    }
    internal async Task TickAsync()
    {
        if (busy || !Account.Connected || lifetime.IsCancellationRequested) return;
        LocalChanged();
        if (DateTimeOffset.Now < nextSync) return;
        try { await SyncNowAsync(lifetime.Token); } catch { /* Status is visible; retry after five minutes. */ }
    }
    internal async Task DisconnectAsync(CancellationToken token)
    {
        if (busy) throw new InvalidOperationException("Eşitleme bitince tekrar dene.");
        await Account.DisconnectAsync(token);
        Report("Google bağlantısı kesildi. Planların iki tarafta da saklanıyor.");
    }
    public void Dispose() { reminders.Changed -= LocalChanged; lifetime.Cancel(); api.Dispose(); Account.Dispose(); }
}

#if WINDOWS
internal sealed class GoogleCalendarDialog : Form
{
    private readonly CancellationTokenSource closing = new();
    internal GoogleCalendarDialog(GoogleCalendarConnection connection)
    {
        Text = "Google Calendar bağlantısı"; Width = 680; Height = 550;
        StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        Font = new Font("Segoe UI", 10);
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(22), ColumnCount = 1, RowCount = 6 };
        layout.RowStyles.Add(new(SizeType.Absolute, 42)); layout.RowStyles.Add(new(SizeType.Percent, 100)); layout.RowStyles.Add(new(SizeType.Absolute, 52)); layout.RowStyles.Add(new(SizeType.Absolute, 52)); layout.RowStyles.Add(new(SizeType.Absolute, 66)); layout.RowStyles.Add(new(SizeType.Absolute, 34));
        layout.Controls.Add(Appearance.Heading("Planların telefonunda da yanında"), 0, 0);
        layout.Controls.Add(new Label { Dock = DockStyle.Fill, Text = "1. Google Cloud’da Calendar API’yi etkinleştir.\n2. Google Auth Platform’da Desktop app türünde istemci oluştur ve JSON dosyasını indir. Test kullanıcısı olarak Gmail adresini ekle.\n3. Dosyayı seç ve Google ile bağlan.\n\nGoogle’da ayrı bir Kişisel Asistan takvimi kullanılır. Bu takvimdeki saatli, tek seferlik planlar iki yönlü eşitlenir. Otomatik kontrol 5 dakikada bir yapılır. Özel bildirimler asistan açıkken çalışır." }, 0, 1);
        var import = new RoundedButton { Text = "Bağlantı dosyasını seç (.json)", AutoSize = true };
        var cloud = new RoundedButton { Text = "Google kurulumunu aç", AutoSize = true };
        var first = new FlowLayoutPanel { Dock = DockStyle.Fill }; first.Controls.AddRange([import, cloud]); layout.Controls.Add(first, 0, 2);
        var connect = new RoundedButton { Text = "Google ile bağlan", AutoSize = true };
        var sync = new RoundedButton { Text = "Şimdi eşitle", AutoSize = true };
        var disconnect = new RoundedButton { Text = "Bağlantıyı kes", AutoSize = true };
        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill }; actions.Controls.AddRange([connect, sync, disconnect]); layout.Controls.Add(actions, 0, 3);
        var result = new Label { Dock = DockStyle.Fill, Text = connection.Status }; layout.Controls.Add(result, 0, 4);
        void UpdateStatus(string text) { if (!IsDisposed) result.Text = text; }
        connection.StatusChanged += UpdateStatus;
        FormClosed += (_, _) => connection.StatusChanged -= UpdateStatus;
        layout.Controls.Add(new Label { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 9), Text = "Telefonunda Google Calendar’ın Kişisel Asistan takvimini görünür yap." }, 0, 5);
        Controls.Add(layout); Appearance.Apply(this);
        async Task Run(Func<Task> action)
        {
            import.Enabled = connect.Enabled = sync.Enabled = disconnect.Enabled = false;
            try { result.Text = "İşlem sürüyor…"; await action(); if (!IsDisposed) result.Text = connection.Status; }
            catch (Exception ex) { if (!IsDisposed) result.Text = ex is OperationCanceledException ? "İşlem iptal edildi." : ex.Message; }
            finally { if (!IsDisposed) import.Enabled = connect.Enabled = sync.Enabled = disconnect.Enabled = true; }
        }
        import.Click += (_, _) => {
            using var picker = new OpenFileDialog { Filter = "Google bağlantı dosyası (*.json)|*.json", Title = "Google Desktop app bağlantı dosyasını seç" };
            if (picker.ShowDialog(this) != DialogResult.OK) return;
            try { connection.ImportCredentials(File.ReadAllText(picker.FileName)); result.Text = connection.Status; } catch (Exception ex) { result.Text = ex.Message; }
        };
        cloud.Click += (_, _) => System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://console.cloud.google.com/apis/library/calendar-json.googleapis.com") { UseShellExecute = true });
        connect.Click += async (_, _) => await Run(() => connection.ConnectAsync(closing.Token));
        sync.Click += async (_, _) => await Run(async () => { await connection.SyncNowAsync(closing.Token); });
        disconnect.Click += async (_, _) => await Run(() => connection.DisconnectAsync(closing.Token));
        FormClosing += (_, _) => closing.Cancel();
    }
    internal static void Render(string directory)
    {
        Directory.CreateDirectory(directory);
        var reminders = new ReminderService(new ReminderStore(Path.Combine(directory, "preview-reminders.json"), false));
        using var connection = new GoogleCalendarConnection(reminders);
        using var dialog = new GoogleCalendarDialog(connection) { ShowInTaskbar = false, StartPosition = FormStartPosition.Manual, Location = new(-20000, -20000) };
        dialog.Show(); Application.DoEvents();
        using var bitmap = new Bitmap(dialog.Width, dialog.Height);
        dialog.DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size));
        bitmap.Save(Path.Combine(directory, "google-calendar.png")); dialog.Close();
    }
}

#endif

