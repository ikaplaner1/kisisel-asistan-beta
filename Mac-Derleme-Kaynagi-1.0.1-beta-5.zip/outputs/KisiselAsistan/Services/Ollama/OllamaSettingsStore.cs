namespace KisiselAsistan;

internal sealed class OllamaSettingsStore
{
    private readonly JsonListStore<OllamaSettings> store;
    internal OllamaSettings Current { get; private set; }
    internal OllamaSettingsStore()
    {
        store = new(DeploymentPaths.Data("ollama-settings.json"));
        try { Current = store.Read().FirstOrDefault() ?? new(); Current = Current with { Model = Current.Model ?? "" }; }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.Text.Json.JsonException) { Current = new(); }
    }
    internal void Save(OllamaSettings settings) { store.Modify(_ => [settings]); Current = settings; }
}
