namespace KisiselAsistan;

// Önizlemede onaylanan programı takvime yazar. Her satır haftalık tekrarlı, normal bir kayıt olur (formdan düzenlenebilir).
// Program adı kayıtların listesidir (Item.List); böylece program tek seferde kaldırılabilir ve listelenebilir.
public sealed record ScheduleImportRequest(string Name, DateOnly Start, DateOnly? Until, PlanCategory Category, bool Remind, List<ScheduleEntry> Entries);
public sealed record ScheduleProgram(string Name, int Count, DateOnly? Until);

public static class ScheduleImport
{
    public const int MaxEntries = 200;
    public static int Save(ItemEditor editor, ScheduleImportRequest request)
    {
        var name = request.Name?.Trim() ?? "";
        if (name.Length is 0 or > 100) throw new ArgumentException("Programa bir ad ver (en fazla 100 karakter).");
        if (name == "Görevler") throw new ArgumentException("Bu ad görev listesine ait; başka bir ad seç.");
        if (request.Entries.Count is 0 or > MaxEntries) throw new ArgumentException($"Eklenecek 1–{MaxEntries} satır olmalı.");
        if (request.Until is { } until && until < request.Start) throw new ArgumentException("Bitiş günü başlangıçtan önce olamaz.");
        foreach (var e in request.Entries) {
            if (string.IsNullOrWhiteSpace(e.Title)) throw new ArgumentException("Her satırın bir adı olmalı.");
            if (e.Start is < 0 or > 1439 || e.End - e.Start is < 5 or > 720) throw new ArgumentException($"{e.Title}: saatleri kontrol et (en az 5 dakika, en fazla 12 saat).");
        }
        var notify = request.Remind ? ReminderOptions.Preset(ReminderIntensity.Normal) : ReminderOptions.Preset(ReminderIntensity.Silent);
        foreach (var e in request.Entries) {
            var first = request.Start.AddDays(((int)e.Day - (int)request.Start.DayOfWeek + 7) % 7);
            if (request.Until is { } end && first > end) continue;
            editor.Save(new ItemForm(null, e.Title.Trim(), first, e.Start, 1 << (int)e.Day, Category: request.Category, DurationMinutes: e.End - e.Start,
                Notify: notify, List: name, RepeatUntil: request.Until, DurationSet: true));
        }
        return request.Entries.Count;
    }
    // İçe aktarılmış programlar: görev listesi olmayan, tekrarlı ve saatli kayıtların liste adları.
    public static List<ScheduleProgram> Programs(ItemStore store) => store.Read()
        .Where(i => i.Repeat is { TimeMinutes: not null } && i.List != "Görevler")
        .GroupBy(i => i.List).Select(g => new ScheduleProgram(g.Key, g.Count(), g.Max(i => i.Repeat!.Until))).OrderBy(p => p.Name).ToList();
    public static int Remove(ItemStore store, string name)
    {
        var removed = 0;
        store.Modify(items => { var kept = items.Where(i => !(i.Repeat is { TimeMinutes: not null } && i.List == name)).ToList(); removed = items.Count - kept.Count; return kept; });
        return removed;
    }
}
