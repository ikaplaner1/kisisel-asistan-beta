namespace KisiselAsistan;

public sealed class ReminderStore
{
    private readonly JsonListStore<Reminder> data;
    public List<Reminder> Items => data.Read();
    public ReminderStore(string path, bool migrateLegacy = true)
    {
        data = new(path); if (migrateLegacy) MigrateLegacy(); else _ = Items;
    }
    public void MigrateLegacy()
    {
        if (Items.Any(r => r.Options != null && r.Options.Level != r.Options.Normalize().Level))
            data.Modify(items => items.Select(r => r.Options == null ? r : r with { Options = r.Options.Normalize() }).ToList());
    }
    public void Add(string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null) { options?.Validate(); plan?.Validate(); data.Modify(items => [.. items, new(Guid.NewGuid(), text, due, Options: options, Plan: plan ?? new(DurationMinutes: PlanningPreferenceStore.Load().DefaultDuration), AdvanceSentForDue: due.AddDays(-1) <= DateTimeOffset.Now ? due : null)]); }
    public void Complete(Guid id) => data.Modify(items => items.Select(r => r.Id == id ? r with { Done = true, NextNotice = null, Revision = r.Revision + 1 } : r).ToList());
    public void Remove(Guid id) => data.Modify(items => items.Where(r => r.Id != id).ToList());
    public void Edit(Guid id, string text, DateTimeOffset due, ReminderOptions? options = null, PlanDetails? plan = null)
    {
        options?.Validate(); plan?.Validate(); if (string.IsNullOrWhiteSpace(text)) throw new ArgumentException("Hatırlatma metni boş olamaz.");
        if (due <= DateTimeOffset.Now) throw new ArgumentException("Gelecekte bir tarih seç.");
        data.Modify(items => {
            if (!items.Any(r => r.Id == id)) throw new InvalidOperationException("Bu hatırlatıcı artık listede yok.");
            return items.Select(r => r.Id == id ? r with { Text = text.Trim(), Due = due, Done = false, Options = options ?? r.Options, Plan = plan ?? r.Plan, AdvanceSentForDue = due.AddDays(-1) <= DateTimeOffset.Now ? due : due == r.Due ? r.AdvanceSentForDue : null, SentCount = 0, Pressure = 0, NextNotice = null, Revision = r.Revision + 1 } : r).ToList();
        });
    }
    public void Snooze(Guid id, TimeSpan delay)
    {
        if (delay <= TimeSpan.Zero) throw new ArgumentException("Erteleme süresi pozitif olmalı.");
        var rescheduled = DateTimeOffset.Now.Add(delay);
        data.Modify(items => {
            if (!items.Any(r => r.Id == id)) throw new InvalidOperationException("Bu hatırlatıcı artık listede yok.");
            return items.Select(r => r.Id == id ? r with { Due = rescheduled, AdvanceSentForDue = delay <= TimeSpan.FromDays(1) ? rescheduled : null, Done = false, SentCount = 0, Pressure = 0, NextNotice = null, Revision = r.Revision + 1 } : r).ToList();
        });
    }
    public void ReportNotDone(Guid id, DateTimeOffset? now = null)
    {
        var answeredAt = now ?? DateTimeOffset.Now;
        data.Modify(items => {
            var reminder = items.FirstOrDefault(r => r.Id == id);
            if (reminder == null || reminder.Done) return items;
            if (reminder.Settings.Level != ReminderIntensity.Adhd) throw new InvalidOperationException("Bu seçenek ADHD modu için geçerli.");
            return items.Select(r => r.Id == id ? r with { NextNotice = answeredAt.AddMinutes(ReminderEscalation.Minutes(r.Settings, r.Pressure + 1)), Revision = r.Revision + 1 } : r).ToList();
        });
    }
    public Reminder? TakeAdvance(DateTimeOffset now)
    {
        bool Ready(Reminder r) => !r.Done && r.Plan?.RemindDayBefore == true && r.AdvanceSentForDue != r.Due && r.Due.AddDays(-1) <= now && now < r.Due;
        if (!Items.Any(Ready)) return null;
        Reminder? result = null;
        data.Modify(items => {
            var candidate = items.Where(Ready).OrderBy(r => r.Due).FirstOrDefault(); if (candidate == null) return items;
            result = candidate with { AdvanceSentForDue = candidate.Due };
            return items.Select(r => r.Id == candidate.Id ? result : r).ToList();
        });
        return result;
    }
    public Reminder? TakeDue(DateTimeOffset now)
    {
        Reminder? result = null;
        if (!Items.Any(r => r.CanNotify(now))) return null;
        data.Modify(items => {
            var due = items.Where(r => r.CanNotify(now)).OrderBy(r => r.NextNotice ?? r.Due).FirstOrDefault();
            if (due == null) return items;
            var adhd = due.Settings.Level == ReminderIntensity.Adhd; var pressure = adhd ? Math.Min(due.Pressure + 1, 30) : 0;
            result = due with { SentCount = Math.Min(due.SentCount, int.MaxValue - 1) + 1, Pressure = pressure, NextNotice = adhd ? now.AddMinutes(ReminderEscalation.Minutes(due.Settings, pressure)) : due.SentCount + 1 < due.Settings.Count ? now.AddMinutes(due.Settings.IntervalMinutes) : null };
            return items.Select(r => r.Id == due.Id ? result : r).ToList();
        });
        return result;
    }
    public bool IsCurrent(Guid id, int revision) => Items.Any(r => r.Id == id && !r.Done && r.Revision == revision);
    public void ClearCompleted() => data.Modify(items => items.Where(r => !r.Done).ToList());
    // Atomic compare-and-apply for calendar imports. Runtime notification
    // counters can change while an HTTP request is in flight.
    internal bool ApplyExternal(Guid id, Reminder? replacement, Func<Reminder?, bool> unchanged)
    {
        replacement?.Settings.Validate(); replacement?.Plan?.Validate();
        var applied = false;
        data.Modify(items => {
            var current = items.FirstOrDefault(r => r.Id == id);
            if (!unchanged(current)) return items;
            applied = true;
            return replacement == null ? items.Where(r => r.Id != id).ToList()
                : current == null ? [.. items, replacement] : items.Select(r => r.Id == id ? replacement : r).ToList();
        });
        return applied;
    }
}
