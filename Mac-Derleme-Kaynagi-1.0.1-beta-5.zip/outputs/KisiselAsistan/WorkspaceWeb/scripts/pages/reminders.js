"use strict";
// Takvim: Ay / Hafta / Gün / Liste. Bileşen olarak çizilir (Preact + htm).
// Gün ve Hafta görünümünde saatsiz işler üstteki "gün boyu" şeridinde durur; şeritteki bir işi ızgarada
// bir saate sürüklemek aynı kayda saat ekler (hatırlatılır), başka günün şeridine bırakmak gününü değiştirir.
// Boş bir saate tıklamak o saate yeni iş açar (yarım saat hassasiyet, actions.js).

const hourHeight = 44; // hafta görünümünde bir saatin yüksekliği (px)
const firstHour = 0; // ızgara gece yarısından başlar; açılışta sabaha ya da ilk işe kaydırılır
const weekdayNames = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];

// Kategori rengi ve öncelik işareti: renk kategoriyi, "!" yüksek, "↓" düşük önceliği gösterir.
const categories = { Personal: "Kişisel", Work: "İş", Health: "Sağlık", FreeTime: "Boş vakit" };
const priorityName = (p) => ({ 1: "Düşük", 3: "Yüksek" })[p] || "Normal";
const planClass = (r) => `cat-${r.plan?.category || "Personal"} prio-${r.plan?.priority || 2}`;
const planTitle = (r) => `${r.text} · ${categories[r.plan?.category] || "Kişisel"} · ${priorityName(r.plan?.priority)} öncelik`;
// Metin şablonları için (Günü planla penceresi).
const prioMark = (r) =>
  r.plan?.priority === 3 ? '<span class="prio-mark" aria-label="Yüksek öncelik">!</span>' : r.plan?.priority === 1 ? '<span class="prio-mark low" aria-label="Düşük öncelik">↓</span>' : "";

const CalendarEvent = ({ r }) =>
  html`<button type="button" data-action="reminder-menu" data-id=${r.id} title=${planTitle(r)} class=${`calendar-event ${planClass(r)}` + (r.plan?.certainty === "Flexible" ? " is-flexible" : "")}>
    <span class="event-time"><${PrioMark} r=${r} />${clock(r.due)}</span><span class="event-text">${r.text}</span>
  </button>`;
// Gün boyu şeridindeki saatsiz iş: tıklayınca düzenlenir, sürüklenince saate ya da başka güne taşınır.
const DayTask = ({ t, day }) => {
  const done = t.dailyActivity ? (t.completedDays || []).includes(day) : t.done;
  return html`<button type="button" class=${"day-task" + (t.important ? " is-important" : "") + (done ? " is-done" : "") + (t.dailyActivity ? " is-repeating" : "")} draggable="true" data-pill-task=${t.id} data-action="task-edit" data-id=${t.id}
    title=${t.dailyActivity ? "Tekrarlı iş · bir saate sürüklersen her tekrarına o saat eklenir" : "Düzenlemek için tıkla · bir saate sürükle: saat eklenir"}>${t.important && html`<span class="prio-mark">!</span>`}${t.dailyActivity && html`<${Icon} n="refresh" />`}<span class="day-task-title">${t.title}</span></button>`;
};
// O günün saatsiz işleri: o güne konmuş (ya da son günü o gün olan) tek seferlikler ve o gün tekrar eden işler.
// Geçmiş günlerde tamamlanmış tek seferlikler şeridi doldurmasın diye gösterilmez.
const untimedOn = (key) =>
  state.data.tasks.filter((t) => (t.dailyActivity ? repeatsOn(t, key) : (t.myDay === key || (!t.myDay && t.due === key)) && (!t.done || key >= today())));

function MonthView({ reminders, selected }) {
  const first = new Date(selected.getFullYear(), selected.getMonth(), 1, 12);
  first.setDate(first.getDate() - ((first.getDay() + 6) % 7));
  const cells = Array.from({ length: 42 }, (_, i) => {
    const d = new Date(first);
    d.setDate(d.getDate() + i);
    const key = dayKey(d),
      items = reminders.filter((r) => dayKey(new Date(r.due)) === key).sort((a, b) => new Date(a.due) - new Date(b.due)),
      tasks = untimedOn(key).filter((t) => !t.dailyActivity && !t.done);
    return html`<div key=${key} class=${"day-cell" + (d.getMonth() !== selected.getMonth() ? " outside" : "") + (key === today() ? " today" : "")} data-date=${key} tabindex="0" role="button" aria-label=${d.toLocaleDateString("tr-TR")}>
      <span class="day-number">${d.getDate()}</span>${items.slice(0, 3).map((r) => html`<${CalendarEvent} key=${r.id} r=${r} />`)}
      ${items.length > 3 && html`<small>+${items.length - 3} saatli</small>`}${tasks.length > 0 && html`<small class="day-tasks-count">${tasks.length} saatsiz iş</small>`}
    </div>`;
  });
  return html`<div class="calendar-grid">${weekdayNames.map((x) => html`<div class="weekday" key=${x}>${x}</div>`)}${cells}</div>`;
}
function WeekView({ reminders, selected, single = false }) {
  const start = new Date(selected);
  if (!single) start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  const days = Array.from({ length: single ? 1 : 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    return d;
  });
  const hours = Array.from({ length: 24 - firstHour }, (_, i) => firstHour + i);
  const now = new Date(),
    nowTop = ((now.getHours() - firstHour) * 60 + now.getMinutes()) * (hourHeight / 60);
  return html`<div class=${"week-view" + (single ? " day-view" : "")} style=${{ "--hour": hourHeight + "px", "--days": days.length }}>
    <div class="week-head"><div class="hour-gutter"></div>${days.map((d) => html`<div key=${dayKey(d)} class=${"week-head-day" + (dayKey(d) === today() ? " today" : "")}><small>${weekdayNames[(d.getDay() + 6) % 7]}</small><span>${d.getDate()}</span></div>`)}</div>
    <div class="week-allday"><div class="hour-gutter allday-label">gün boyu</div>${days.map((d, i) => {
      const key = dayKey(d);
      return html`<div key=${key} class="allday-cell" data-allday-date=${key}>${untimedOn(key).map((t) => html`<${DayTask} key=${t.id} t=${t} day=${key} />`)}
        ${i === 0 && days.every((x) => !untimedOn(dayKey(x)).length) && html`<span class="allday-empty">Saatsiz işler burada görünür; birini bir saate sürüklersen saat eklenir.</span>`}</div>`;
    })}</div>
    <div class="week-body"><div class="hours">${hours.map((h) => html`<span key=${h}>${String(h).padStart(2, "0")}:00</span>`)}</div>${days.map((d) => {
      const key = dayKey(d);
      return html`<div key=${key} class=${"week-day" + (key === today() ? " today" : "")} data-week-date=${key} title="Boş bir saate tıklayarak o saate iş ekle">
        ${reminders.filter((r) => dayKey(new Date(r.due)) === key).map((r) => {
          const due = new Date(r.due),
            minutes = Math.max(0, (due.getHours() - firstHour) * 60 + due.getMinutes()),
            height = Math.max(24, ((r.plan?.durationMinutes || 30) * hourHeight) / 60 - 2);
          return html`<div key=${r.id} class=${"week-event" + (height < 40 ? " is-short" : "")} style=${{ top: (minutes * hourHeight) / 60 + "px", height: height + "px" }}><${CalendarEvent} r=${r} /></div>`;
        })}
        ${key === today() && nowTop >= 0 && html`<div class="now-line" style=${{ top: nowTop + "px" }}></div>`}
      </div>`;
    })}</div>
  </div>`;
}
function ListView({ reminders }) {
  const items = [...reminders].sort((a, b) => new Date(a.due) - new Date(b.due));
  return items.length
    ? html`<div class="rows">${items.map((r) => html`<div key=${r.id} class=${"item-row " + planClass(r)} data-row-reminder=${r.id}>
        <span class=${"cat-dot " + planClass(r)} title=${categories[r.plan?.category] || "Kişisel"}></span><span class="time"><${PrioMark} r=${r} />${clock(r.due)}</span>
        <div class="item-copy"><strong>${r.text}</strong><small>${r.settings?.level === "Adhd" && html`<${Chip} tone="accent">Yapana kadar<//>`}${relativeDay(r.due)} · ${r.plan?.durationMinutes || 30} dk · ${r.plan?.certainty === "Flexible" ? "Saati kayabilir" : "Kesin saat"} · ${categories[r.plan?.category] || "Kişisel"}</small></div>
        <${Button} action="reminder-menu" icon="more" cls="icon-button row-more" data-id=${r.id} aria-label="İşlemler" />
      </div>`)}</div>`
    : html`<${Empty} text="Bu görünümde bekleyen saatli iş yok." />`;
}
function CalendarPage() {
  const reminders = state.data.reminders.filter((r) => !r.done);
  const selected = parseDay(state.day);
  const views = {
    Ay: () => html`<${MonthView} reminders=${reminders} selected=${selected} />`,
    Hafta: () => html`<${WeekView} reminders=${reminders} selected=${selected} />`,
    Gün: () => html`<${WeekView} reminders=${reminders} selected=${selected} single />`,
    Liste: () => html`<${ListView} reminders=${reminders} />`,
  };
  const title =
    state.calendar === "Ay" || state.calendar === "Hafta"
      ? selected.toLocaleDateString("tr-TR", { month: "long", year: "numeric" })
      : state.calendar === "Liste" ? "Bekleyen bütün saatli işler" : selected.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" });
  const label = selected.toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" });
  return html`
    <${Heading} title="Takvim" sub="Saatli işlerin ızgarada, saatsizler gün boyu şeridinde."><${Button} action="reminder-new" icon="plus" cls="primary" data-date=${state.day}>Ekle<//><//>
    <div class="toolbar">
      <div class="date-nav"><${Button} action="day-prev" icon="left" cls="arrow" aria-label="Önceki" /><span class="date">${label}</span><${Button} action="day-next" icon="right" cls="arrow" aria-label="Sonraki" /></div>
      ${state.day !== today() && html`<${Button} action="today" cls="ghost">Bugün<//>`}
      <span class="spacer"></span>
      <div class="segmented" role="group" aria-label="Takvim görünümü">${Object.keys(views).map((t) => html`<${Button} key=${t} action="calendar-mode" cls=${state.calendar === t ? "active" : ""} data-mode=${t} aria-pressed=${state.calendar === t}>${t}<//>`)}</div>
    </div>
    <section class=${"card calendar view-" + (state.calendar === "Ay" ? "month" : state.calendar === "Liste" ? "list" : "week")}>
      <div class="calendar-toolbar"><strong>${title}</strong>
        <div class="calendar-legend" aria-label="Renk açıklaması">${Object.entries(categories).map(([key, name]) => html`<span key=${key}><i class=${"cat-dot cat-" + key}></i>${name}</span>`)}<span><b class="prio-mark">!</b>Yüksek</span><span><b class="prio-mark low">↓</b>Düşük öncelik</span></div>
      </div>
      ${views[state.calendar]()}
    </section>`;
}
pageComponents.reminders = CalendarPage;
