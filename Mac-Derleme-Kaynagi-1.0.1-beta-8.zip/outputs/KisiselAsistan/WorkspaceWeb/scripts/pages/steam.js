"use strict";
// Steam: oyun arama ve çıkış/güncelleme takibi. Bileşen olarak yazılmış ilk sayfa (Preact + htm);
// yeni sayfalar bu örneği izler. Arama kutusu yazarken yeniden çizilse de odağını kaybetmez.

// Kapak görselleri Steam'in kendi sunucularından gelir ama uygulama üzerinden istenir
// (covers.assistant.local): uygulama görseli indirir, önbelleğe alır ve sayfaya verir.
// Kayıtta kapak adresi yoksa oyunun numarasından Steam'in standart kapağı denenir.
const coverUrl = (g) => `https://covers.assistant.local/steam?id=${Number(g.id) || 0}&u=${encodeURIComponent(g.coverUrl || "")}`;
// Yüklenemeyen kapak yerine sade yer tutucu. Bileşenin kendi durumu tutulur; DOM elle değiştirilmez
// (Preact sonraki çizimde görseli yeniden ekleyip iki kutu gösteriyordu). Kapak adresi değişirse yeniden denenir.
function Cover({ game }) {
  const src = game.id || game.coverUrl ? coverUrl(game) : "";
  const [failed, setFailed] = htmPreact.useState("");
  return src && failed !== src
    ? html`<img class="cover" src=${src} alt="" loading="lazy" onError=${() => setFailed(src)} />`
    : html`<span class="cover cover-empty"></span>`;
}

// Fiyat: indirim varsa eski fiyat üstü çizili, yanında indirimli fiyat ve yüzde (Steam mağazasındaki gibi).
// Fiyatı bilinmeyen (ör. henüz çıkmamış) oyunda hiçbir şey gösterilmez.
const money = (cents, currency) => {
  try {
    return new Intl.NumberFormat("tr-TR", { style: "currency", currency }).format(cents / 100);
  } catch {
    return (cents / 100).toFixed(2) + " " + currency;
  }
};
const Price = ({ price }) =>
  !price
    ? null
    : price.free
      ? html`<span class="price">Ücretsiz</span>`
      : price.discount > 0
        ? html`<span class="price on-sale" title=${"%" + price.discount + " indirim"}><span class="sale-badge">-%${price.discount}</span><s>${money(price.initial, price.currency)}</s><strong>${money(price.final, price.currency)}</strong></span>`
        : html`<span class="price">${money(price.final, price.currency)}</span>`;

// Arama sonucu: çift tık (ya da Enter) takibe alır.
const SteamResult = ({ game, watched }) => html`
  <div class="item-row is-pickable" tabindex="0" data-dbl-action="steam-track" data-id=${game.id} title="Takibe almak için çift tıkla">
    <${Cover} game=${game} />
    <div class="item-copy">
      <strong>${game.name}</strong>
      <small>${watched && html`<${Chip} tone="accent">Takip ediliyor<//>`}${game.approximate ? "Yakın eşleşme" : "Steam mağazası"}</small>
    </div>
    <${Price} price=${game.price} />
    <small class="pick-hint">Çift tıkla · takip et</small>
  </div>`;


// Çıkış tarihi okunabiliyorsa kalan gün ("22 Oct, 2026" gibi Steam tarihleri); okunamazsa null.
function daysUntil(game) {
  if (!game.comingSoon || !game.releaseDate) return null;
  const t = Date.parse(game.releaseDate);
  if (Number.isNaN(t)) return null;
  const days = Math.ceil((t - Date.now()) / 86400000);
  return days >= 0 && days <= 730 ? days : null;
}
const releaseTag = (game, days) =>
  days != null
    ? html`<${Chip} tone="secondary">${days === 0 ? "Bugün çıkıyor" : days === 1 ? "Yarın" : days + " gün"}<//>`
    : html`<${Chip} tone=${game.comingSoon ? "accent" : "success"}>${game.comingSoon ? "Bekleniyor" : game.earlyAccess ? "Erken erişim" : "Çıktı"}<//>`;
// Fiyat geçmişi: uygulamanın gördüğü fiyat değişimlerinden küçük bir çizgi. En az iki nokta gerekir.
const PriceTrend = ({ game }) => {
  const points = game.priceHistory || [];
  if (points.length < 2 || !game.price) return null;
  const values = points.map((p) => p.final),
    min = Math.min(...values),
    max = Math.max(...values),
    w = 56,
    h = 18,
    xy = values.map((v, i) => `${((i / (values.length - 1)) * w).toFixed(1)},${(max === min ? h / 2 : 2 + ((max - v) / (max - min)) * (h - 4)).toFixed(1)}`).join(" ");
  return html`<svg class="price-trend" viewBox="0 0 ${w} ${h}" width=${w} height=${h} role="img" aria-label=${"Fiyat geçmişi, en düşük " + money(min, game.price.currency)}><title>${"Fiyat geçmişi · en düşük " + money(min, game.price.currency)}</title><polyline points=${xy} /></svg>`;
};
// Şu anki fiyat şimdiye kadar görülen en düşükse (ve indirimdeyse) rozet.
const atLowest = (g) => g.price && g.price.discount > 0 && (g.priceHistory || []).length >= 2 && g.price.final <= g.lowestPrice;
// Hedef fiyat: konmuşsa rozet ("Hedef $10,00"; fiyat hedefteyse yeşil "Hedefte"). Rozete basınca hedef penceresi açılır.
const TargetChip = ({ game }) =>
  game.targetPrice
    ? html`<button type="button" class=${"chip target-chip" + (game.atTarget ? " success" : "")} data-action="steam-target" data-id=${game.id} title="Hedef fiyatı değiştir"><${Icon} n="target" />${game.atTarget ? "Hedefte · " : "Hedef "}${money(game.targetPrice, game.price?.currency || "USD")}</button>`
    : null;
const SteamWatch = ({ game }) => {
  const days = daysUntil(game);
  return html`<div class="item-row" data-row-steam=${game.id}>
    <${Cover} game=${game} />
    <div class="item-copy"><strong>${game.name}</strong><small>${game.latestUpdate ? "Son büyük güncelleme: " + game.latestUpdate : game.releaseDate || "Güncellemeler takip ediliyor"}</small></div>
    <${PriceTrend} game=${game} />
    ${atLowest(game) && html`<${Chip} tone="success">En düşük fiyat<//>`}
    <${TargetChip} game=${game} />
    ${!game.targetPrice && game.price && !game.price.free && html`<${Button} action="steam-target" icon="target" cls="icon-button" data-id=${game.id} aria-label="Hedef fiyat koy" title="Hedef fiyat koy" />`}
    <${Price} price=${game.price} />
    <span class="release-tag">${releaseTag(game, days)}</span>
    <${Button} action="steam-remove" icon="close" cls="icon-button row-more" data-id=${game.id} aria-label="Takibi bırak" />
  </div>`;
};
// Büyük görünümde takip listesi mağaza gibi kapak ızgarasıdır (Steam / GG.deals): kapakta çıkış rozeti,
// altta durum, fiyat çizgisi ve fiyat; son büyük güncelleme kartın altında. Küçük görünümde satır listesi kalır.
const GameCard = ({ game }) => {
  const days = daysUntil(game);
  const status = game.comingSoon ? game.releaseDate || "Tarih yok" : game.earlyAccess ? "Erken erişim" : "Çıktı";
  return html`<article class="game-card" data-row-steam=${game.id}>
    <div class="game-art"><${Cover} game=${game} /><span class="release-tag game-badge">${releaseTag(game, days)}</span>
      <span class="game-tools">${game.price && !game.price.free && html`<${Button} action="steam-target" icon="target" cls="icon-button game-tool" data-id=${game.id} aria-label="Hedef fiyat" title="Hedef fiyat: o fiyata inince haber ver" />`}
      <${Button} action="steam-remove" icon="close" cls="icon-button game-tool game-remove" data-id=${game.id} aria-label="Takibi bırak" title="Takibi bırak" /></span></div>
    <div class="game-info">
      <strong title=${game.name}>${game.name}</strong>
      <div class="game-meta"><span>${status}</span><${PriceTrend} game=${game} /><${Price} price=${game.price} /></div>
      ${(atLowest(game) || game.targetPrice) && html`<div class="game-chips">${atLowest(game) && html`<${Chip} tone="success">En düşük fiyat<//>`}<${TargetChip} game=${game} /></div>`}
      ${game.latestUpdate && html`<div class="game-update" title=${game.latestUpdate}>Son büyük güncelleme: ${game.latestUpdate}</div>`}
    </div>
  </article>`;
};
// Sıra: çıkışı yaklaşanlar (en yakın önce), tarihi belirsiz bekleyenler, sonra çıkmış olanlar.
const watchOrder = (g) => (daysUntil(g) ?? (g.comingSoon ? 10000 : 20000));

function SteamPage() {
  const watchedIds = new Set(state.data.steam.map((g) => g.id));
  const filter = state.steamFilter || "Hepsi";
  const watched = [...state.data.steam]
    .filter((g) => filter === "Hepsi" || (filter === "İndirimde" ? g.price?.discount > 0 : filter === "Bekleniyor" ? g.comingSoon : !g.comingSoon))
    .sort((a, b) => watchOrder(a) - watchOrder(b) || a.name.localeCompare(b.name, "tr"));
  const searching = (state.query.steam || "").trim().length > 0;
  // Başlık altı özet: kaç oyun takipte, kaçı indirimde, bu hafta çıkan var mı.
  const onSale = state.data.steam.filter((g) => g.price?.discount > 0).length,
    thisWeek = state.data.steam.filter((g) => (daysUntil(g) ?? 99) <= 7).length;
  const summary = state.data.steam.length
    ? [`${state.data.steam.length} oyun takipte`, onSale && `${onSale} indirimde`, thisWeek && `${thisWeek} oyun bu hafta çıkıyor`].filter(Boolean).join(" · ")
    : "Beklediğin oyunlar, büyük güncellemeler ve indirimler (Steam).";
  return html`
    <${Heading} title="Oyunlar" sub=${summary}>
      <${Button} action="steam-wishlist" icon="plus" cls="ghost" title="Steam istek listendeki oyunları takibe al">İstek listesini al<//>
      <${Button} action="steam-check" icon="refresh" cls="ghost" title="Çıkış ve güncellemeleri şimdi kontrol et">Şimdi kontrol et<//>
    <//>
    <label class="search">
      <${Icon} n="search" />
      <input id="steam-search" value=${state.query.steam} placeholder="Oyun ara ya da Steam bağlantısı yapıştır… (çift tık takibe alır)" aria-label="Steam oyun ara" />
    </label>
    ${searching && html`<section class="card steam-results">
      <header class="card-header"><h2>Arama sonuçları</h2><small id="search-state"></small></header>
      <div class="rows">${state.steamResults.length
        ? state.steamResults.map((g) => html`<${SteamResult} key=${g.id} game=${g} watched=${watchedIds.has(g.id)} />`)
        : html`<${Empty} text="Sonuç bekleniyor…" />`}</div>
    </section>`}
    <div class="toolbar">
      <div class="segmented" role="group" aria-label="Takip süzgeci">${["Hepsi", "Bekleniyor", "Çıktı", "İndirimde"].map((f) => html`<button type="button" key=${f} class=${filter === f ? "active" : ""} aria-pressed=${filter === f} onClick=${() => { state.steamFilter = f; render(); }}>${f}</button>`)}</div>
      <span class="spacer"></span><small class="muted">${state.data.steam.length} oyun takipte</small>
    </div>
    ${!watched.length
      ? html`<section class="card"><${Empty} text=${state.data.steam.length ? "Bu süzgeçte oyun yok." : "Takip ettiğin oyunlar burada görünecek. Yukarıdan ara ve çift tıkla."} /></section>`
      : compact()
        ? html`<section class="card"><div class="rows">${watched.map((g) => html`<${SteamWatch} key=${g.id} game=${g} />`)}</div></section>`
        : html`<div class="game-grid">${watched.map((g) => html`<${GameCard} key=${g.id} game=${g} />`)}</div>`}`;
}
pageComponents.steam = SteamPage;
