using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace KisiselAsistan;



public sealed class SpotifyAccount : ISpotifySession, IDisposable
{
    public const string RedirectUri = "http://127.0.0.1:38761/callback";
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(20) };
    private readonly SemaphoreSlim gate = new(1, 1);
    private readonly string path = DeploymentPaths.Data("spotify-account.bin");
    private AccountData? data;
    public string ClientId => data?.ClientId ?? "";
    public bool Connected => !string.IsNullOrEmpty(data?.RefreshToken);
    public SpotifyAccount()
    {
        if (File.Exists(path)) {
            try { data = JsonSerializer.Deserialize<AccountData>(WindowsSecret.Decode(File.ReadAllBytes(path))); }
            catch { data = null; }
        }
    }
    public async Task ConnectAsync(string clientId, CancellationToken token)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(clientId.Trim(), "^[a-fA-F0-9]{32}$")) throw new ArgumentException("Spotify Developer sayfasındaki 32 karakterli Client ID değerini gir. Client Secret gerekmez.");
        await gate.WaitAsync(token);
        try {
            var verifier = Base64Url(RandomNumberGenerator.GetBytes(64));
            var state = Base64Url(RandomNumberGenerator.GetBytes(32));
            var challenge = Base64Url(SHA256.HashData(Encoding.ASCII.GetBytes(verifier)));
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token); timeout.CancelAfter(TimeSpan.FromMinutes(3));
            using var listener = new TcpListener(IPAddress.Loopback, 38761);
            listener.Start();
            var url = "https://accounts.spotify.com/authorize?" + Query(new Dictionary<string, string> {
                ["client_id"] = clientId.Trim(), ["response_type"] = "code", ["redirect_uri"] = RedirectUri,
                ["scope"] = "user-read-playback-state user-modify-playback-state", ["state"] = state, ["show_dialog"] = "true",
                ["code_challenge_method"] = "S256", ["code_challenge"] = challenge });
            using var browser = Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            string? code = null;
            while (code is null) {
                using var socket = await listener.AcceptTcpClientAsync(timeout.Token);
                using var stream = socket.GetStream();
                var buffer = new byte[8192]; var length = 0;
                using var readTimeout = CancellationTokenSource.CreateLinkedTokenSource(timeout.Token); readTimeout.CancelAfter(TimeSpan.FromSeconds(5));
                while (length < buffer.Length) {
                    var count = await stream.ReadAsync(buffer.AsMemory(length), readTimeout.Token);
                    if (count == 0) break;
                    length += count;
                    if (Encoding.ASCII.GetString(buffer, 0, length).Contains("\r\n\r\n")) break;
                }
                var first = Encoding.ASCII.GetString(buffer, 0, length).Split("\r\n")[0].Split(' ');
                var valid = first.Length == 3 && first[0] == "GET" && Uri.TryCreate("http://127.0.0.1" + first[1], UriKind.Absolute, out var ignored);
                var callback = valid ? new Uri("http://127.0.0.1" + first[1]) : null;
                var args = callback is null ? new Dictionary<string, string>() : ParseQuery(callback.Query);
                var matched = callback?.AbsolutePath == "/callback" && args.GetValueOrDefault("state") == state;
                var html = matched ? "Spotify izni alindi. Bu sekmeyi kapatip asistana donebilirsin." : "Gecersiz istek.";
                var body = Encoding.UTF8.GetBytes(html);
                await stream.WriteAsync(Encoding.ASCII.GetBytes($"HTTP/1.1 {(matched ? "200 OK" : "400 Bad Request")}\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: {body.Length}\r\nConnection: close\r\n\r\n"), timeout.Token);
                await stream.WriteAsync(body, timeout.Token);
                if (!matched) continue;
                if (args.ContainsKey("error")) throw new InvalidOperationException("Spotify bağlantı izni verilmedi.");
                code = args.GetValueOrDefault("code") ?? throw new InvalidOperationException("Spotify bağlantı kodu gelmedi.");
            }
            var result = await TokenAsync(new() { ["client_id"] = clientId.Trim(), ["grant_type"] = "authorization_code", ["code"] = code, ["redirect_uri"] = RedirectUri, ["code_verifier"] = verifier }, timeout.Token);
            var connected = new AccountData(clientId.Trim(), result.AccessToken, result.RefreshToken ?? throw new InvalidOperationException("Spotify yenileme anahtarı gelmedi."), DateTimeOffset.UtcNow.AddSeconds(result.ExpiresIn));
            Save(connected); data = connected;
        } catch (OperationCanceledException) when (!token.IsCancellationRequested) { throw new InvalidOperationException("Spotify bağlantısı zaman aşımına uğradı. Yeniden Bağlan'a bas."); }
        finally { gate.Release(); }
    }
    public async Task<string> AccessAsync(CancellationToken token)
    {
        await gate.WaitAsync(token);
        try {
            var current = data;
            if (current is null) throw new InvalidOperationException("Önce Spotify sekmesinden hesabını bağla.");
            if (current.ExpiresAt > DateTimeOffset.UtcNow.AddMinutes(1)) return current.AccessToken;
            var result = await TokenAsync(new() { ["client_id"] = current.ClientId, ["grant_type"] = "refresh_token", ["refresh_token"] = current.RefreshToken }, token);
            var refreshed = current with { AccessToken = result.AccessToken, RefreshToken = result.RefreshToken ?? current.RefreshToken, ExpiresAt = DateTimeOffset.UtcNow.AddSeconds(result.ExpiresIn) };
            Save(refreshed); data = refreshed; return refreshed.AccessToken;
        } finally { gate.Release(); }
    }
    public async Task DisconnectAsync(CancellationToken token)
    {
        await gate.WaitAsync(token);
        try { if (File.Exists(path)) File.Delete(path); data = null; }
        finally { gate.Release(); }
    }
    private async Task<TokenResult> TokenAsync(Dictionary<string, string> fields, CancellationToken token)
    {
        using var response = await http.PostAsync("https://accounts.spotify.com/api/token", new FormUrlEncodedContent(fields), token);
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException("Spotify hesabı bağlanamadı veya bağlantı süresi doldu. Client ID ve yönlendirme adresini kontrol edip yeniden bağlan.");
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync(token)); var root = json.RootElement;
        return new(root.GetProperty("access_token").GetString()!, root.TryGetProperty("refresh_token", out var refresh) ? refresh.GetString() : null, root.GetProperty("expires_in").GetInt32());
    }
    private void Save(AccountData value)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temporary = path + ".tmp";
        File.WriteAllBytes(temporary, WindowsSecret.Encode(JsonSerializer.SerializeToUtf8Bytes(value)));
        File.Move(temporary, path, true);
    }
    internal static string Base64Url(byte[] bytes) => Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    internal static string Query(Dictionary<string, string> values) => string.Join("&", values.Select(x => Uri.EscapeDataString(x.Key) + "=" + Uri.EscapeDataString(x.Value)));
    internal static Dictionary<string, string> ParseQuery(string text) => text.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries).Select(x => x.Split('=', 2)).GroupBy(x => Uri.UnescapeDataString(x[0])).ToDictionary(x => x.Key, x => Uri.UnescapeDataString(x.Last().ElementAtOrDefault(1) ?? ""));
    public void Dispose() { http.Dispose(); }
    private record AccountData(string ClientId, string AccessToken, string RefreshToken, DateTimeOffset ExpiresAt);
    private record TokenResult(string AccessToken, string? RefreshToken, int ExpiresIn);
}



