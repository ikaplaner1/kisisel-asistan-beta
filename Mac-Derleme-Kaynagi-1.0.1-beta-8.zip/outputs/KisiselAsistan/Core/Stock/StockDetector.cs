using System.Globalization;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace KisiselAsistan;

// Ürün sayfasından stok durumu, ad, görsel ve fiyat okur. Site bilmeden çalışır; sırayla en güvenilir kaynağa bakar:
// 1) kullanıcının kuralı ("şu yazı görünce/kaybolunca"), 2) sayfadaki ürün verisi (schema.org JSON-LD, Google'ın da okuduğu),
// 3) meta etiketleri (product:availability, itemprop), 4) sayfa içi JSON'daki stok alanları (isInStock, stockStatus …),
// 5) görünen yazılar ("Tükendi", "Sepete ekle", "Out of stock" …). İlk kesin sonuç kazanır; hepsi Signals'a yazılır.
// Bot koruması (Cloudflare, captcha, 403/429) ayrıca tanınır: Blocked.
public static partial class StockDetector
{
    public static StockReading Read(string html, int status = 200, string? variant = null, StockRule? rule = null)
    {
        html ??= "";
        var signals = new List<string>();
        var meta = Metas(html);
        var products = JsonLd(html).ToList();
        var offers = products.SelectMany(p => p.Offers).ToList();
        var title = Clean(products.Select(p => p.Name).FirstOrDefault(n => n != null) ?? Meta(meta, "og:title", "twitter:title") ?? TitleTag(html));
        var image = Absolute(products.Select(p => p.Image).FirstOrDefault(i => i != null) ?? Meta(meta, "og:image", "twitter:image"));
        var variantOffers = string.IsNullOrWhiteSpace(variant) ? offers : offers.Where(o => Fold(o.Name ?? "").Contains(Fold(variant!))).ToList();
        if (!string.IsNullOrWhiteSpace(variant)) signals.Add(variantOffers.Count > 0 ? $"'{variant}' seçeneği ürün verisinde bulundu ({variantOffers.Count})." : $"'{variant}' seçeneği ürün verisinde yok; genel durum kullanılıyor.");
        var priced = (variantOffers.Count > 0 ? variantOffers : offers).Where(o => o.Price is > 0).ToList();
        var inStockPriced = priced.Where(o => o.State == StockState.InStock).ToList();
        var priceOffer = (inStockPriced.Count > 0 ? inStockPriced : priced).OrderBy(o => o.Price).FirstOrDefault();
        var price = priceOffer?.Price ?? ParsePrice(Meta(meta, "product:price:amount", "og:price:amount", "price"));
        var currency = priceOffer?.Currency ?? Meta(meta, "product:price:currency", "og:price:currency", "pricecurrency");
        if (currency is "TL" or "₺") currency = "TRY";
        var text = VisibleText(html);

        StockReading Done(StockState state, string evidence)
        {
            signals.Insert(0, evidence);
            return new(state, evidence, title, image, price, currency?.ToUpperInvariant(), signals);
        }

        // Bot koruması: hata kodu ya da doğrulama sayfası (ürün verisi de yoksa).
        var challenge = Challenge(html, title);
        if ((status is 401 or 403 or 429 or 503 || challenge != null) && products.Count == 0 && price == null)
            return Done(StockState.Blocked, challenge ?? $"Site isteği geri çevirdi (HTTP {status}); bot koruması olabilir.");
        if (status == 404 || status == 410) return Done(StockState.Unknown, $"Sayfa bulunamadı (HTTP {status}). Bağlantı değişmiş olabilir.");

        if (rule != null) {
            var present = text.Contains(Fold(rule.Text)) || Fold(html).Contains(Fold(rule.Text));
            var inStock = present == rule.InStockWhenPresent;
            return Done(inStock ? StockState.InStock : StockState.OutOfStock, $"Kuralın: '{rule.Text}' yazısı sayfada {(present ? "var" : "yok")}.");
        }

        var structured = (variantOffers.Count > 0 ? variantOffers : string.IsNullOrWhiteSpace(variant) ? offers : []).Where(o => o.State != StockState.Unknown).ToList();
        if (structured.Count > 0) {
            var state = Combine(structured.Select(o => o.State));
            var counts = structured.Count > 1 ? $" ({structured.Count(o => o.State == StockState.InStock)}/{structured.Count} seçenek stokta)" : "";
            return Done(state, "Ürün verisi: " + Describe(state) + counts + ".");
        }

        var metaState = Availability(Meta(meta, "product:availability", "og:availability", "availability"));
        if (metaState != StockState.Unknown) return Done(metaState, "Meta etiketi: " + Describe(metaState) + ".");

        if (string.IsNullOrWhiteSpace(variant)) {
            var flags = EmbeddedFlags(html);
            if (flags.Count > 0) {
                var distinct = flags.Distinct().ToList();
                signals.Add($"Sayfa içi stok alanları: {flags.Count(f => f == StockState.InStock)} stokta, {flags.Count(f => f == StockState.OutOfStock)} yok.");
                if (distinct.Count == 1) return Done(distinct[0], "Sayfa içi veri: " + Describe(distinct[0]) + ".");
            }
        }

        var outs = OutPhrases.Where(p => HasPhrase(text, Fold(p))).ToList();
        var ins = InPhrases.Where(p => HasPhrase(text, Fold(p))).ToList();
        var pre = PrePhrases.Where(p => HasPhrase(text, Fold(p))).ToList();
        if (outs.Count > 0) signals.Add("Tükendi yazıları: " + string.Join(", ", outs.Take(3)));
        if (ins.Count > 0) signals.Add("Satın alma yazıları: " + string.Join(", ", ins.Take(3)));
        if (pre.Count > 0 && outs.Count == 0 && ins.Count == 0) return Done(StockState.PreOrder, $"Sayfada '{pre[0]}' yazıyor.");
        if (outs.Count > 0 && ins.Count == 0) return Done(StockState.OutOfStock, $"Sayfada '{outs[0]}' yazıyor.");
        if (ins.Count > 0 && outs.Count == 0) return Done(StockState.InStock, $"Sayfada '{ins[0]}' yazıyor, tükendi yazısı yok.");
        if (ins.Count > 0) return Done(StockState.Unknown, $"Sayfada hem '{ins[0]}' hem '{outs[0]}' var. İzlenecek yazıyı sen seç.");
        return Done(StockState.Unknown, text.Length < 400 ? "Sayfa neredeyse boş geldi; tarayıcıyla okumak gerekebilir." : "Stok bilgisi bulunamadı. İzlenecek yazıyı sen seç.");
    }

    // Shopify mağazaları /products/<ad>.js ile seçenekleri ve stoklarını verir (en güvenilir kaynak).
    public static bool IsShopify(string html, Uri url) => url.AbsolutePath.Contains("/products/", StringComparison.OrdinalIgnoreCase) && (html.Contains("cdn.shopify.com") || html.Contains("Shopify.shop"));
    public static Uri ShopifyJson(Uri url)
    {
        var path = url.AbsolutePath.TrimEnd('/');
        var start = path.IndexOf("/products/", StringComparison.OrdinalIgnoreCase);
        var end = path.IndexOf('/', start + 10);
        if (end > 0) path = path[..end];
        return new UriBuilder(url.Scheme, url.Host, url.IsDefaultPort ? -1 : url.Port, path + ".js").Uri;
    }
    public static StockReading? ReadShopify(string json, StockReading page, string? variant)
    {
        try {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;
            if (!root.TryGetProperty("variants", out var variants) || variants.ValueKind != JsonValueKind.Array) return null;
            var all = variants.EnumerateArray().Select(v => (Title: v.TryGetProperty("title", out var t) ? t.GetString() ?? "" : "",
                Available: v.TryGetProperty("available", out var a) && a.ValueKind == JsonValueKind.True,
                Price: v.TryGetProperty("price", out var p) && p.TryGetInt64(out var cents) ? cents / 100m : (decimal?)null)).ToList();
            var chosen = string.IsNullOrWhiteSpace(variant) ? all : all.Where(v => Fold(v.Title).Contains(Fold(variant!))).ToList();
            if (chosen.Count == 0) return null;
            var available = chosen.Where(v => v.Available).ToList();
            var state = available.Count > 0 ? StockState.InStock : StockState.OutOfStock;
            var evidence = $"Mağaza verisi (Shopify): {available.Count}/{chosen.Count} seçenek stokta" + (available.Count is > 0 and <= 4 && chosen.Count > 1 ? " · " + string.Join(", ", available.Select(v => v.Title)) : "") + ".";
            var price = (available.Count > 0 ? available : chosen).Select(v => v.Price).Where(p => p > 0).DefaultIfEmpty(page.Price).Min();
            var title = root.TryGetProperty("title", out var name) ? name.GetString() : null;
            return page with { State = state, Evidence = evidence, Title = page.Title ?? title, Price = price, Signals = [evidence, .. page.Signals.Skip(1)] };
        } catch (JsonException) { return null; }
    }

    // ------------------------------------------------------------- Ürün verisi (JSON-LD)
    private sealed record Offer(string? Name, StockState State, decimal? Price, string? Currency);
    private sealed record Product(string? Name, string? Image, List<Offer> Offers);
    private static IEnumerable<Product> JsonLd(string html)
    {
        foreach (Match m in LdScript().Matches(html)) {
            var doc = ParseLd(m.Groups[1].Value.Trim());
            if (doc == null) continue;
            using (doc) foreach (var p in Walk(doc.RootElement, 0)) yield return p;
        }
    }
    // Birçok site JSON-LD'ye satır sonu, sekme gibi kaçışsız karakterler ya da HTML yorumu koyuyor; bunlar temizlenip bir kez daha denenir.
    private static JsonDocument? ParseLd(string text)
    {
        var options = new JsonDocumentOptions { AllowTrailingCommas = true, CommentHandling = JsonCommentHandling.Skip };
        try { return JsonDocument.Parse(text, options); }
        catch (JsonException) { }
        var cleaned = Control().Replace(text.Replace("<!--", "").Replace("-->", "").Replace("<![CDATA[", "").Replace("]]>", ""), " ");
        try { return JsonDocument.Parse(cleaned, options); }
        catch (JsonException) { return null; }
    }
    // Sözcük sınırıyla arama: "on siparis" "…tasyon sipariş" içinde bulunmamalı.
    private static bool HasPhrase(string text, string phrase)
    {
        for (var i = text.IndexOf(phrase, StringComparison.Ordinal); i >= 0; i = text.IndexOf(phrase, i + 1, StringComparison.Ordinal)) {
            var before = i == 0 || !char.IsLetterOrDigit(text[i - 1]);
            var end = i + phrase.Length;
            if (before && (end >= text.Length || !char.IsLetterOrDigit(text[end]))) return true;
        }
        return false;
    }
    private static IEnumerable<Product> Walk(JsonElement e, int depth)
    {
        if (depth > 8) yield break;
        if (e.ValueKind == JsonValueKind.Array) { foreach (var x in e.EnumerateArray()) foreach (var p in Walk(x, depth + 1)) yield return p; yield break; }
        if (e.ValueKind != JsonValueKind.Object) yield break;
        var type = TypeOf(e);
        if (type.Contains("product") || type.Contains("productgroup") || type.Contains("individualproduct")) {
            var name = Str(e, "name");
            var offers = new List<Offer>();
            if (e.TryGetProperty("offers", out var o)) CollectOffers(o, name, offers, 0);
            if (e.TryGetProperty("hasVariant", out var variants))
                foreach (var v in variants.ValueKind == JsonValueKind.Array ? variants.EnumerateArray() : Enumerable.Repeat(variants, 1))
                    if (v.ValueKind == JsonValueKind.Object && v.TryGetProperty("offers", out var vo)) CollectOffers(vo, VariantName(v) ?? name, offers, 0);
            yield return new(name, ImageOf(e), offers);
        }
        foreach (var key in new[] { "@graph", "mainEntity", "itemListElement", "item" })
            if (e.TryGetProperty(key, out var child)) foreach (var p in Walk(child, depth + 1)) yield return p;
    }
    private static string? VariantName(JsonElement v)
    {
        var parts = new[] { Str(v, "name"), Str(v, "size"), Str(v, "color"), Str(v, "sku") }.Where(s => s != null);
        var joined = string.Join(" ", parts);
        return joined.Length > 0 ? joined : null;
    }
    private static void CollectOffers(JsonElement o, string? name, List<Offer> into, int depth)
    {
        if (depth > 4) return;
        if (o.ValueKind == JsonValueKind.Array) { foreach (var x in o.EnumerateArray()) CollectOffers(x, name, into, depth + 1); return; }
        if (o.ValueKind != JsonValueKind.Object) return;
        if (o.TryGetProperty("offers", out var inner)) CollectOffers(inner, name, into, depth + 1);
        var offerName = string.Join(" ", new[] { name, Str(o, "name"), Str(o, "sku") }.Where(s => s != null).Distinct());
        var price = Number(o, "price") ?? Number(o, "lowPrice");
        if (price == null && o.TryGetProperty("priceSpecification", out var spec)) price = spec.ValueKind == JsonValueKind.Array ? spec.EnumerateArray().Select(s => Number(s, "price")).FirstOrDefault(p => p != null) : Number(spec, "price");
        var availability = Availability(Str(o, "availability"));
        if (availability != StockState.Unknown || price != null) into.Add(new(offerName, availability, price, Str(o, "priceCurrency")));
    }
    private static string TypeOf(JsonElement e) => !e.TryGetProperty("@type", out var t) ? "" :
        t.ValueKind == JsonValueKind.Array ? string.Join(" ", t.EnumerateArray().Select(x => x.ToString().ToLowerInvariant())) : t.ToString().ToLowerInvariant();
    private static string? Str(JsonElement e, string key) => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(key, out var v)
        ? v.ValueKind switch { JsonValueKind.String => NullIfEmpty(v.GetString()), JsonValueKind.Number => v.GetRawText(), JsonValueKind.Object => Str(v, "name") ?? Str(v, "@id"), _ => null } : null;
    private static decimal? Number(JsonElement e, string key) => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(key, out var v)
        ? v.ValueKind == JsonValueKind.Number && v.TryGetDecimal(out var d) ? d : v.ValueKind == JsonValueKind.String ? ParsePrice(v.GetString()) : null : null;
    private static string? ImageOf(JsonElement e)
    {
        if (!e.TryGetProperty("image", out var i)) return null;
        if (i.ValueKind == JsonValueKind.Array) i = i.EnumerateArray().FirstOrDefault();
        return i.ValueKind == JsonValueKind.String ? i.GetString() : i.ValueKind == JsonValueKind.Object ? Str(i, "url") ?? Str(i, "contentUrl") : null;
    }

    // ------------------------------------------------------------- Durum sözcükleri
    public static StockState Availability(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return StockState.Unknown;
        var v = Fold(value).Replace("http://schema.org/", "").Replace("https://schema.org/", "").Replace(" ", "").Replace("_", "").Replace("-", "");
        v = v[(v.LastIndexOf('/') + 1)..];
        return v switch {
            "instock" or "instoreonly" or "onlineonly" or "limitedavailability" or "available" or "true" or "yes" or "1" or "stokta" or "var" => StockState.InStock,
            "outofstock" or "soldout" or "discontinued" or "oos" or "unavailable" or "false" or "no" or "0" or "tukendi" or "yok" or "notavailable" => StockState.OutOfStock,
            "preorder" or "presale" or "backorder" or "preorderable" => StockState.PreOrder,
            _ => StockState.Unknown,
        };
    }
    private static StockState Combine(IEnumerable<StockState> states)
    {
        var list = states.ToList();
        return list.Contains(StockState.InStock) ? StockState.InStock : list.Contains(StockState.PreOrder) ? StockState.PreOrder : list.Contains(StockState.OutOfStock) ? StockState.OutOfStock : StockState.Unknown;
    }
    public static string Describe(StockState state) => state switch {
        StockState.InStock => "stokta", StockState.OutOfStock => "stokta yok", StockState.PreOrder => "ön siparişte",
        StockState.Blocked => "site engelledi", _ => "belirsiz",
    };
    private static List<StockState> EmbeddedFlags(string html)
    {
        var list = new List<StockState>();
        foreach (Match m in BoolFlag().Matches(html)) {
            var yes = m.Groups[2].Value.Equals("true", StringComparison.OrdinalIgnoreCase);
            if (m.Groups[1].Value.Equals("isSoldOut", StringComparison.OrdinalIgnoreCase)) yes = !yes;
            list.Add(yes ? StockState.InStock : StockState.OutOfStock);
        }
        foreach (Match m in StatusFlag().Matches(html)) { var s = Availability(m.Groups[2].Value); if (s != StockState.Unknown) list.Add(s); }
        return list.Take(200).ToList();
    }
    // Sayfada aranan yazılar; karşılaştırma Fold edilmiş hâlleriyle yapılır, kararda asıl yazım gösterilir ("Tükendi").
    private static readonly string[] OutPhrases = [.. new[] {
        "tükendi", "stokta yok", "stokta bulunmamaktadır", "stoklarımızda bulunmamaktadır", "stok bulunmamaktadır", "stoklarda yok", "gelince haber ver", "stoğa girince haber ver",
        "stoklara girince haber ver", "gelince bildir", "geçici olarak temin edilemiyor", "şu anda satışta değil", "satışta değil", "temin edilemiyor", "satışa kapalı",
        "out of stock", "sold out", "currently unavailable", "temporarily unavailable", "notify me when available", "notify when available", "email when available", "no longer available",
        "ausverkauft", "nicht verfügbar", "épuisé", "agotado" }];
    private static readonly string[] InPhrases = [.. new[] {
        "sepete ekle", "sepete at", "hemen al", "şimdi al", "stokta var", "add to cart", "add to bag", "add to basket", "buy now", "in stock", "in den warenkorb", "ajouter au panier", "añadir al carrito" }];
    private static readonly string[] PrePhrases = [.. new[] { "ön sipariş ver", "ön siparişe açık", "pre-order now", "preorder now", "pre-order", "ön sipariş" }];

    private static string? Challenge(string html, string? title)
    {
        var t = Fold(title ?? "");
        if (t.Contains("just a moment") || t.Contains("bir dakika") || html.Contains("cf-browser-verification") || html.Contains("challenge-platform") && html.Length < 60_000) return "Cloudflare doğrulaması çıktı; bot koruması.";
        if (t.Contains("captcha") || t.Contains("robot or human") || t.Contains("are you a robot") || html.Contains("px-captcha") || html.Contains("captcha-delivery.com") || html.Contains("g-recaptcha") && html.Length < 60_000) return "Doğrulama (captcha) istendi; bot koruması.";
        // Amazon: doğrulama formu ya da küçük "Üzgünüz / Sorry" hata sayfası.
        if (html.Contains("validateCaptcha") || html.Contains("opfcaptcha") || html.Length < 20_000 && (t.StartsWith("uzgunuz") || t.StartsWith("sorry!") || t.Contains("robot check")))
            return "Site otomatik erişimi engelledi (doğrulama ya da hata sayfası).";
        if (t.Contains("access denied") || t.Contains("pardon our interruption") || t.Contains("erişim engellendi") || t.Contains("request blocked")) return "Site erişimi engelledi; bot koruması.";
        return null;
    }

    // ------------------------------------------------------------- HTML yardımcıları
    private static Dictionary<string, string> Metas(string html)
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (Match tag in MetaTag().Matches(html)) {
            var attrs = Attributes(tag.Value);
            var key = attrs.GetValueOrDefault("property") ?? attrs.GetValueOrDefault("name") ?? attrs.GetValueOrDefault("itemprop");
            var value = attrs.GetValueOrDefault("content") ?? attrs.GetValueOrDefault("href");
            if (key != null && value != null && !map.ContainsKey(key)) map[key] = WebUtility.HtmlDecode(value);
        }
        return map;
    }
    private static Dictionary<string, string> Attributes(string tag)
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (Match a in Attribute().Matches(tag)) map.TryAdd(a.Groups[1].Value, a.Groups[3].Success ? a.Groups[3].Value : a.Groups[4].Success ? a.Groups[4].Value : a.Groups[5].Value);
        return map;
    }
    private static string? Meta(Dictionary<string, string> map, params string[] keys) => keys.Select(k => map.GetValueOrDefault(k)).FirstOrDefault(v => !string.IsNullOrWhiteSpace(v));
    private static string? TitleTag(string html) { var m = TitleRegex().Match(html); return m.Success ? WebUtility.HtmlDecode(m.Groups[1].Value) : null; }
    public static string VisibleText(string html)
    {
        var text = Hidden().Replace(html, " ");
        text = Tag().Replace(text, " ");
        text = WebUtility.HtmlDecode(text);
        return Fold(Space().Replace(text, " "));
    }
    private static string? Clean(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        // "&#39da" gibi noktalı virgülsüz sayı kodları da çözülsün.
        var t = Space().Replace(WebUtility.HtmlDecode(BareEntity().Replace(text, "$0;")), " ").Trim();
        return t.Length > 200 ? t[..200] : t;
    }
    private static string? NullIfEmpty(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
    private static string? Absolute(string? url) => url == null ? null : url.StartsWith("//") ? "https:" + url : url.StartsWith("http") ? url : null;
    // "1.299,90", "1,299.90", "1299.9", "₺1.299" → sayı. İki ayraç varsa sondaki ondalıktır; tek ayraç birden çok kez geçiyorsa
    // ya da arkasında tam 3 rakam varsa binliktir (Türkçe "12.999" = 12999).
    public static decimal? ParsePrice(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var digits = new string(value.Where(c => char.IsDigit(c) || c is '.' or ',').ToArray()).Trim('.', ',');
        if (digits.Length == 0) return null;
        int dot = digits.LastIndexOf('.'), comma = digits.LastIndexOf(',');
        var sep = Math.Max(dot, comma);
        string number;
        if (dot >= 0 && comma >= 0) number = digits[..sep].Replace(".", "").Replace(",", "") + "." + digits[(sep + 1)..];
        else if (sep >= 0) {
            var c = digits[sep];
            var thousands = digits.Count(x => x == c) > 1 || digits.Length - sep - 1 == 3;
            number = thousands ? digits.Replace(c.ToString(), "") : digits.Replace(c, '.');
        } else number = digits;
        return decimal.TryParse(number, NumberStyles.Number, CultureInfo.InvariantCulture, out var d) && d > 0 && d < 100_000_000 ? d : null;
    }
    public static string Fold(string text)
    {
        var lower = text.Replace('İ', 'i').Replace('I', 'ı').ToLowerInvariant().Replace('ı', 'i');
        var sb = new StringBuilder(lower.Length);
        foreach (var c in lower.Normalize(NormalizationForm.FormD))
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
        return sb.ToString().Replace('’', '\'');
    }

    [GeneratedRegex(@"<script[^>]*type\s*=\s*[""']application/ld\+json[""'][^>]*>(.*?)</script>", RegexOptions.IgnoreCase | RegexOptions.Singleline)] private static partial Regex LdScript();
    [GeneratedRegex(@"<(?:meta|link)\b[^>]*>", RegexOptions.IgnoreCase)] private static partial Regex MetaTag();
    [GeneratedRegex(@"([\w:-]+)\s*=\s*(""([^""]*)""|'([^']*)'|([^\s>]+))")] private static partial Regex Attribute();
    [GeneratedRegex(@"<title[^>]*>(.*?)</title>", RegexOptions.IgnoreCase | RegexOptions.Singleline)] private static partial Regex TitleRegex();
    [GeneratedRegex(@"<(script|style|noscript|svg|template|head)\b[^>]*>.*?</\1>|<!--.*?-->", RegexOptions.IgnoreCase | RegexOptions.Singleline)] private static partial Regex Hidden();
    [GeneratedRegex(@"<[^>]+>")] private static partial Regex Tag();
    [GeneratedRegex(@"[\u0000-\u001F]")] private static partial Regex Control();
    [GeneratedRegex(@"&#\d{2,5}(?![\d;])")] private static partial Regex BareEntity();
    [GeneratedRegex(@"\s+")] private static partial Regex Space();
    [GeneratedRegex(@"""(isInStock|inStock|in_stock|isAvailable|hasStock|isSellable|stockAvailable|isSoldOut)""\s*:\s*(true|false)", RegexOptions.IgnoreCase)] private static partial Regex BoolFlag();
    [GeneratedRegex(@"""(stockStatus|stock_status|availabilityStatus|inventoryStatus)""\s*:\s*""([A-Za-z_ \-]{2,30})""", RegexOptions.IgnoreCase)] private static partial Regex StatusFlag();
}
