using System.Globalization;
using System.Text.RegularExpressions;

namespace KisiselAsistan;

// Uygulamanın tek tarih/saat ayrıştırıcısı. Sesli komut, hızlı ekleme, Ctrl+K ve Ollama'nın önerdiği
// hatırlatma zamanı hep buradan geçer. Metinden zamanı çıkarır, kalan metni iş adı olarak bırakır.
//   "yarın 9'da diş hekimi"      → Due yarın 09:00, Text "Diş hekimi"
//   "on dakika sonra su iç"      → Due şimdi+10 dk (Relative)
//   "cuma akşam 7 toplantı"      → Due cuma 19:00
//   "yarın market"               → Day yarın (saatsiz)
//   "bir ara dolabı düzenle"     → Someday
public sealed record WhenResult(string Text, DateOnly? Day = null, DateTimeOffset? Due = null, bool Someday = false, int? RelativeSeconds = null, bool Conflict = false);

public static class WhenParser
{
    private const RegexOptions Options = RegexOptions.IgnoreCase | RegexOptions.CultureInvariant;
    private static readonly CultureInfo Turkish = new("tr-TR");
    private static readonly string[] Months = ["ocak", "şubat", "mart", "nisan", "mayıs", "haziran", "temmuz", "ağustos", "eylül", "ekim", "kasım", "aralık"];
    // Haftanın günleri (DayOfWeek sırasıyla). "pazar" tek başına "çarşı" da demek olduğu için "günü" ister.
    private static readonly string[] Weekdays = ["pazar", "pazartesi", "salı", "çarşamba", "perşembe", "cuma", "cumartesi"];
    private static readonly Dictionary<string, int> HourWords = new() {
        ["bir"] = 1, ["iki"] = 2, ["üç"] = 3, ["dört"] = 4, ["beş"] = 5, ["altı"] = 6, ["yedi"] = 7, ["sekiz"] = 8, ["dokuz"] = 9, ["on"] = 10, ["on bir"] = 11, ["on iki"] = 12
    };
    // Saat eki: 9'da, 9da, 10'de, 3'te, 7'deki …
    private const string Suffix = @"(?:['’]?(?:da|de|ta|te)(?:ki)?)?";

    public static WhenResult Parse(string input, DateTimeOffset now)
    {
        var raw = Regex.Replace((input ?? "").Trim(), @"\s+", " ");
        // "bir ara" / konuşma dilinde "bi ara": başta ("bi ara yemek ye") ya da sonda ("yemek ye bi ara").
        var someday = Regex.Match(raw, @"^(?:bir|bi)\s+ara(?:\s+da)?[,:]?\s+(.+)$", Options);
        if (!someday.Success) someday = Regex.Match(raw, @"^(.+?)[,]?\s+(?:bir|bi)\s+ara(?:\s+(?:yap|yapayım|yapılacak|yapmam lazım))?$", Options);
        if (someday.Success) return new(Capitalize(someday.Groups[1].Value.Trim()), Someday: true);
        var text = " " + raw + " ";
        var today = DateOnly.FromDateTime(now.LocalDateTime);

        // 1) Göreli süre: "10 dakika sonra", "yarım saat sonra", "in 20 minutes".
        var relatives = new List<int>();
        text = RemoveRelative(text, relatives);

        // 2) Gün
        DateOnly? day = null; var dayGiven = false;
        void SetDay(DateOnly value) { day = value; dayGiven = true; }
        string Take(string pattern, Func<Match, bool> apply)
        {
            var match = Regex.Match(text, pattern, Options);
            if (match.Success && apply(match)) text = text.Remove(match.Index, match.Length).Insert(match.Index, " ");
            return text;
        }
        Take(@"\s(?:yarından sonra|öbür gün|ertesi gün)\s", _ => { SetDay(today.AddDays(2)); return true; });
        if (!dayGiven) Take(@"\s(?:yarın|tomorrow)\s", _ => { SetDay(today.AddDays(1)); return true; });
        if (!dayGiven) Take(@"\s(?:bugün|today)\s", _ => { SetDay(today); return true; });
        if (!dayGiven) Take(@"\s(\d{1,2})\s+(" + string.Join("|", Months) + @")(?:\s+(\d{4}))?(?:['’]?(?:da|de|ta|te|nda|nde|ında|inde|unda|ünde))?\s", m => {
            var month = Array.IndexOf(Months, m.Groups[2].Value.ToLower(Turkish)) + 1;
            var number = int.Parse(m.Groups[1].Value);
            var year = m.Groups[3].Success ? int.Parse(m.Groups[3].Value) : today.Year;
            if (month < 1 || number < 1 || number > DateTime.DaysInMonth(year, month)) return false;
            var date = new DateOnly(year, month, number);
            if (!m.Groups[3].Success && date < today) date = date.AddYears(1);
            SetDay(date); return true;
        });
        if (!dayGiven) Take(@"\s(" + string.Join("|", Weekdays.Select((w, i) => (w, i)).OrderByDescending(x => x.w.Length).Select(x => x.w)) + @")(\s+günü|['’](?:ya|ye|da|de|ta|te|nda|nde)|ya|ye)?\s", m => {
            var name = m.Groups[1].Value.ToLower(Turkish);
            if (name == "pazar" && !m.Groups[2].Success) return false;
            var target = (DayOfWeek)Array.IndexOf(Weekdays, name);
            var ahead = ((int)target - (int)today.DayOfWeek + 7) % 7;
            SetDay(today.AddDays(ahead)); return true;
        });

        // 3) Gün bölümü ve saat
        // "bu akşam" günü de söyler; diğer gün bölümleri ancak bir saate ya da güne bağlıysa zamandır
        // ("sabah koşusu" bir iş adıdır, "yarın sabah" ve "akşam 7" zamandır).
        var period = "";
        Take(@"\sbu\s+(akşam|sabah|gece|öğlen)\s", m => { period = m.Groups[1].Value.ToLower(Turkish); SetDay(today); return true; });
        var periodWord = period == "" ? Regex.Match(text, @"\s(sabah|öğleden sonra|akşam|gece|öğlen)(?:ı|leyin)?\s", Options) : Match.Empty;
        int? hour = null; var minute = 0;
        bool Time(int h, int min) { if (h > 23 || min > 59) return false; hour = h; minute = min; return true; }
        Take(@"\s(?:saat\s*)?(\d{1,2})[:.](\d{2})" + Suffix + @"\s", m => Time(int.Parse(m.Groups[1].Value), int.Parse(m.Groups[2].Value)));
        if (hour == null) Take(@"\s(?:saat\s*)?(\d{1,2})(\s+buçuk)?['’]?(?:da|de|ta|te)(?:ki)?\s", m => Time(int.Parse(m.Groups[1].Value), m.Groups[2].Success ? 30 : 0));
        if (hour == null) Take(@"\s(?:saat|at)\s*(\d{1,2})(\s+buçuk)?\s", m => Time(int.Parse(m.Groups[1].Value), m.Groups[2].Success ? 30 : 0));
        if (hour == null) Take(@"\ssaat\s+(on bir|on iki|bir|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on)(?:['’]?(?:de|da|te|ta)(?:ki)?)?(\s+buçuk)?\s", m => Time(HourWords[m.Groups[1].Value.ToLower(Turkish)], m.Groups[2].Success ? 30 : 0));
        // "akşam 7", "sabah 9": gün bölümünün hemen ardından gelen yalın saat
        if (hour == null && periodWord.Success) Take(@"\s(sabah|öğleden sonra|akşam|gece)(?:ı|leyin)?\s+(\d{1,2})\s", m => int.Parse(m.Groups[2].Value) is >= 1 and <= 12 && Time(int.Parse(m.Groups[2].Value), 0) && (period = m.Groups[1].Value.ToLower(Turkish)) != "");
        if (period == "" && periodWord.Success && (hour != null || dayGiven || periodWord.Groups[1].Value.ToLower(Turkish) == "öğlen")) {
            period = periodWord.Groups[1].Value.ToLower(Turkish);
            Take(@"\s" + Regex.Escape(periodWord.Groups[1].Value) + @"(?:ı|leyin)?\s", _ => true);
        }
        if (hour is int h0) {
            if (period is "akşam" or "öğleden sonra" && h0 < 12) hour = h0 + 12;
            if (period == "gece" && h0 is >= 6 and < 12) hour = h0 + 12;
            if (period is "gece" or "sabah" && h0 == 12) hour = 0;
        } else if (period != "") {
            // "yarın sabah", "bu akşam", "öğlen": saat söylenmediyse gün bölümünün olağan saati.
            hour = period switch { "sabah" => 9, "öğlen" => 12, "öğleden sonra" => 15, "akşam" => 20, _ => 22 };
        }

        var rest = Capitalize(Regex.Replace(text, @"\s+", " ").Trim().Trim(',', ':', '-', '–').Trim());
        var conflict = relatives.Count > 1 || (relatives.Count == 1 && (hour != null || dayGiven));
        if (relatives.Count > 0) return new(rest, Due: now.AddSeconds(relatives[0]), RelativeSeconds: relatives[0], Conflict: conflict);
        if (hour is int hh) {
            var date = day ?? today;
            var due = At(date, hh, minute);
            // Gün söylenmediyse ve saat geçtiyse ertesi gün kastedilmiştir.
            if (!dayGiven && due <= now) due = At(date.AddDays(1), hh, minute);
            return new(rest, DateOnly.FromDateTime(due.LocalDateTime), due, Conflict: conflict);
        }
        return new(rest, day, Conflict: conflict);
    }
    private static DateTimeOffset At(DateOnly day, int hour, int minute)
    {
        var local = DateTime.SpecifyKind(day.ToDateTime(new TimeOnly(hour, minute)), DateTimeKind.Unspecified);
        // Yaz saati geçişinde var olmayan saat bir saat ileri kayar.
        if (TimeZoneInfo.Local.IsInvalidTime(local)) local = local.AddHours(1);
        return new(local, TimeZoneInfo.Local.GetUtcOffset(local));
    }
    // "… N birim sonra" ifadelerini bulur (en fazla 6 kelimelik süre). İngilizce "in N minutes" de kabul edilir.
    private static string RemoveRelative(string text, List<int> found)
    {
        var words = text.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToList();
        for (var i = 0; i < words.Count; i++) {
            var word = words[i].ToLower(Turkish).TrimEnd(',', '.');
            if (word is "sonra" or "later") {
                for (var k = Math.Min(6, i); k >= 1; k--) {
                    if (!SpokenDuration.TryParse(string.Join(" ", words.Skip(i - k).Take(k)), out var seconds)) continue;
                    found.Add(seconds); words.RemoveRange(i - k, k + 1); i -= k + 1; break;
                }
            } else if (word == "in" && i + 2 < words.Count) {
                for (var k = Math.Min(3, words.Count - i - 1); k >= 2; k--) {
                    var phrase = string.Join(" ", words.Skip(i + 1).Take(k)).TrimEnd(',', '.');
                    if (EnglishDuration(phrase) is not int seconds) continue;
                    found.Add(seconds); words.RemoveRange(i, k + 1); i--; break;
                }
            }
        }
        return " " + string.Join(" ", words) + " ";
    }
    // "five minutes", "twenty-five seconds", "2 hours"
    internal static int? EnglishDuration(string text)
    {
        var match = Regex.Match(text.Trim(), @"^([a-z\d -]+?)\s+(seconds?|minutes?|hours?)$", Options);
        if (!match.Success || !EnglishNumber(match.Groups[1].Value, out var amount)) return null;
        var seconds = (long)amount * (match.Groups[2].Value.ToLowerInvariant().StartsWith("second") ? 1 : match.Groups[2].Value.ToLowerInvariant().StartsWith("minute") ? 60 : 3600);
        return seconds is >= 1 and <= 31536000 ? (int)seconds : null;
    }
    internal static bool EnglishNumber(string text, out int number)
    {
        if (int.TryParse(text, out number)) return number > 0 && number <= 100000;
        var words = new Dictionary<string, int> { ["one"] = 1, ["two"] = 2, ["three"] = 3, ["four"] = 4, ["five"] = 5, ["six"] = 6, ["seven"] = 7, ["eight"] = 8, ["nine"] = 9, ["ten"] = 10, ["eleven"] = 11, ["twelve"] = 12, ["thirteen"] = 13, ["fourteen"] = 14, ["fifteen"] = 15, ["sixteen"] = 16, ["seventeen"] = 17, ["eighteen"] = 18, ["nineteen"] = 19, ["twenty"] = 20, ["thirty"] = 30, ["forty"] = 40, ["fifty"] = 50, ["sixty"] = 60, ["seventy"] = 70, ["eighty"] = 80, ["ninety"] = 90 };
        var tokens = text.ToLowerInvariant().Replace('-', ' ').Split(' ', StringSplitOptions.RemoveEmptyEntries);
        number = 0;
        if (tokens.Length is < 1 or > 2 || tokens.Any(t => !words.ContainsKey(t))) return false;
        if (tokens.Length == 2 && (words[tokens[0]] < 20 || words[tokens[1]] > 9)) return false;
        number = tokens.Sum(t => words[t]); return true;
    }
    internal static string Capitalize(string text) => text.Length == 0 ? text : char.ToUpper(text[0], Turkish) + text[1..];
}
