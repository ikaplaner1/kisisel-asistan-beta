namespace KisiselAsistan;

// The caller supplies a tick; this can be a desktop timer or a future background host.
public sealed class ReminderScheduler(ReminderStore store, Func<DateTimeOffset> clock)
{
    public IReadOnlyList<ReminderPrompt> Poll()
    {
        var now = clock();
        List<ReminderPrompt> prompts = [];
        var advance = store.TakeAdvance(now);
        if (advance != null) prompts.Add(new(advance, ReminderPromptKind.Advance));
        var due = store.TakeDue(now);
        if (due != null) prompts.Add(new(due, ReminderPromptKind.Due));
        return prompts;
    }
}

internal static class ReminderEscalation
{
    internal static int Minutes(ReminderOptions settings, int pressure) => Math.Max(1, (int)Math.Ceiling(settings.IntervalMinutes / Math.Pow(2, Math.Clamp(pressure - 1, 0, 11))));
    internal static bool Center(Reminder reminder) => reminder.Settings.Level == ReminderIntensity.Adhd && reminder.Pressure >= 4;
}
