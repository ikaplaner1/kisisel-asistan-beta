using System.Text.RegularExpressions;
namespace KisiselAsistan;

internal static class ReminderTimeTarget
{
    // Parse only a complete date/time description, never a fragment of a reminder title.
    internal static bool TryFind(string text, IReadOnlyList<Reminder> items, DateTime today, out Reminder[] matches, out string? error)
    {
        matches = []; error = null;
        text = Regex.Replace(ReminderVoiceRemoval.Fold(text), @"\s+", " ");
        var numbers = new Dictionary<string, int> { ["bir"] = 1, ["iki"] = 2, ["uc"] = 3, ["dort"] = 4, ["bes"] = 5, ["alti"] = 6, ["yedi"] = 7, ["sekiz"] = 8, ["dokuz"] = 9, ["on"] = 10, ["yirmi"] = 20, ["otuz"] = 30, ["kirk"] = 40, ["elli"] = 50 };
        var ones = "bir|iki|uc|dort|bes|alti|yedi|sekiz|dokuz";
        text = Regex.Replace(text, @"\b(on|yirmi|otuz|kirk|elli)(?:\s+(" + ones + @"))?(?=\b|(?:deki|daki|teki|taki|de|da|te|ta)\b)", m => (numbers[m.Groups[1].Value] + (m.Groups[2].Success ? numbers[m.Groups[2].Value] : 0)).ToString());
        text = Regex.Replace(text, @"\b(" + ones + @")(?=\b|(?:deki|daki|teki|taki|de|da|te|ta)\b)", m => numbers[m.Value].ToString());
        const string months = "ocak|subat|mart|nisan|mayis|haziran|temmuz|agustos|eylul|ekim|kasim|aralik";
        var match = Regex.Match(text, @"^(?:(?<relative>bugun|yarin)|(?<day>\d{1,2})\s+(?<month>" + months + @"|\d{1,2})(?:\s+(?<year>\d{4}))?)(?:\s+(?<period>sabah|aksam|ogle|gece))?(?:\s+(?:saat\s+)?(?<hour>\d{1,2})(?:\s+(?<minute>\d{2}))?\s*(?:deki|daki|teki|taki|de|da|te|ta)?)?(?:\s+(?:olan|tarihindeki|tarihli))?$");
        if (!match.Success) return false;
        int? year = match.Groups["year"].Success ? int.Parse(match.Groups["year"].Value) : null;
        int day, month;
        if (match.Groups["relative"].Success) {
            var date = today.Date.AddDays(match.Groups["relative"].Value == "yarin" ? 1 : 0); day = date.Day; month = date.Month; year = date.Year;
        } else {
            day = int.Parse(match.Groups["day"].Value);
            month = int.TryParse(match.Groups["month"].Value, out var numericMonth) ? numericMonth : Array.IndexOf(months.Split('|'), match.Groups["month"].Value) + 1;
        }
        if (month is < 1 or > 12 || year is < 1 or > 9999 || day < 1 || day > DateTime.DaysInMonth(year ?? 2000, Math.Clamp(month, 1, 12))) { error = "Tarih geçersiz. Gün, ay ve saati tekrar söyle."; return true; }
        int? hour = match.Groups["hour"].Success ? int.Parse(match.Groups["hour"].Value) : null;
        var minute = match.Groups["minute"].Success ? int.Parse(match.Groups["minute"].Value) : 0;
        if (hour is > 23 || minute > 59 || (hour is null && match.Groups["period"].Success)) { error = "Saat geçersiz. Örneğin 15 Ekim saat 19:30 de."; return true; }
        var period = match.Groups["period"].Value;
        if (period.Length > 0 && hour.HasValue) {
            if (hour > 12 && period is "sabah" or "gece") { error = "Saat ve sabah/akşam ifadesi uyuşmuyor. Saati 24 saat biçiminde söyle."; return true; }
            if (period is "aksam" or "ogle" && hour is >= 1 and < 12) hour += 12;
            if (period is "sabah" or "gece" && hour == 12) hour = 0;
        }
        var ambiguousHour = hour is >= 1 and <= 12 && period.Length == 0 && !match.Groups["minute"].Success && !match.Groups["hour"].Value.StartsWith('0');
        matches = items.Where(r => {
            var due = r.Due.LocalDateTime;
            return due.Day == day && due.Month == month && (!year.HasValue || due.Year == year) &&
                (!hour.HasValue || (due.Minute == minute && (due.Hour == hour || (ambiguousHour && due.Hour == (hour + 12) % 24))));
        }).ToArray();
        return true;
    }
}
