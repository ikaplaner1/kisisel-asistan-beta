using System.Text.Json;

namespace KisiselAsistan;

// Kayıt dosyalarının ortak yazma/okuma yolu.
// Yazarken: önce geçici dosya, sonra yerine geçirme; bir önceki sağlam sürüm "<ad>.bak" olarak kalır.
// Okurken: dosya bozuksa (yarım, boş, çöp) silinmez, "<ad>.bozuk-<zaman>" adıyla kenara alınır ve
// son sağlam sürüme (.bak) dönülür; o da yoksa boş başlanır. Kilit/erişim hataları kurtarma sayılmaz, yukarı çıkar.
public static class SafeFile
{
    // Kurtarma olduğunda (dosya adı, kullanıcıya gösterilecek cümle). Uygulama bunu bildirim olarak gösterir.
    public static event Action<string, string>? Recovered;

    public static void Write(string path, string text)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temporary = path + ".tmp";
        File.WriteAllText(temporary, text);
        // A scanner can briefly hold a newly written file on Windows. Keep the
        // atomic replacement and retry only transient access/sharing failures.
        for (var attempt = 0; ; attempt++) {
            try {
                if (File.Exists(path)) File.Replace(temporary, path, path + ".bak", ignoreMetadataErrors: true);
                else File.Move(temporary, path);
                break;
            }
            catch (UnauthorizedAccessException) when (attempt < 4) { Thread.Sleep(50 * (attempt + 1)); }
            catch (IOException ex) when (attempt < 4 && (ex.HResult & 0xffff) is 32 or 33) { Thread.Sleep(50 * (attempt + 1)); }
        }
    }

    public static T Read<T>(string path, Func<string, T> parse, T empty)
    {
        if (!File.Exists(path)) return empty;
        var text = File.ReadAllText(path);
        try { return parse(text); }
        catch (Exception ex) when (ex is JsonException or InvalidDataException or NotSupportedException) { }
        var name = Path.GetFileName(path);
        File.Move(path, path + ".bozuk-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff"));
        var backup = path + ".bak";
        if (File.Exists(backup)) {
            try {
                var restored = parse(File.ReadAllText(backup));
                File.Copy(backup, path, true);
                Recovered?.Invoke(name, $"{name} okunamadı; son sağlam kopyaya dönüldü. Bozuk dosya yanında saklandı.");
                return restored;
            } catch (Exception ex) when (ex is JsonException or InvalidDataException or NotSupportedException) { }
        }
        Recovered?.Invoke(name, $"{name} okunamadı ve sağlam kopyası yok; boş başlandı. Bozuk dosya yanında saklandı.");
        return empty;
    }
}
