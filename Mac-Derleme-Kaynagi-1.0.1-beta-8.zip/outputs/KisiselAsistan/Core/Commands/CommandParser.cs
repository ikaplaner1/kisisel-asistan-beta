using System.Text.RegularExpressions;

namespace KisiselAsistan;

// Kurallı komut ayrıştırıcısı: Türkçe/İngilizce cümleyi doğrudan bir niyete (Intent) çevirir.
// Ara bir metin dili yoktur; hatırlatıcı, görev, Steam, Spotify ve kısayol komutlarının hepsi buradadır.
// context: kullanıcının son kullandığı bölüm ("steam", "spotify" ya da ""); "duraklat", "ilk oyunu ekle" gibi kısa komutlar ona göre anlaşılır.
// Anlaşılamayan cümle için null döner (Ollama açıksa ona sorulur).
public static class CommandParser
{
    private const RegexOptions Options = RegexOptions.IgnoreCase | RegexOptions.CultureInvariant;
    private static Match Match(string text, string pattern) => Regex.Match(text, pattern, Options);
    private const string SpotifyOpenPattern = @"^(?:spotify(?:\s*['’]?\s*y?[ıi])?(?:\s+uygulamasını)?\s+(?:aç|açsana|açar\s+mısın|açabilir\s+misin)|open\s+spotify|spotify\s+open)$";
    // "… diye hatırlatıcı kur" da hatırlatma isteğidir; saat söylenmezse sorulur (göreve düşmez).
    private const string RemindVerb = @"(?:hatırlat|hatırlatsana|anımsat|(?:(?:diye|için)\s+)?(?:bir\s+)?(?:hatırlatıcı|hatırlatma|alarm)\s+(?:kur|ayarla|oluştur))";
    private const string DefaultReminderText = "Hatırlatma zamanı";

    // Oyun/şarkı adının sonundaki Türkçe eki atar: "Hades'i" → "Hades".
    internal static string Name(string text) => Regex.Replace(text.Trim().Trim('"', '“', '”'), @"['’](?:y?[ıiuü]|[dt][ae]n?|n[ıiuü]n)$", "", Options).Trim();
    // "iki" → 2, "3." → 3; sayı değilse -1.
    internal static int Number(string text)
    {
        var value = text.ToLowerInvariant().TrimEnd('.') switch {
            "bir" or "one" or "ilk" or "birinci" => "1", "iki" or "two" or "ikinci" => "2", "üç" or "three" or "üçüncü" => "3",
            "dört" or "four" or "dördüncü" => "4", "beş" or "five" or "beşinci" => "5", "altı" or "six" => "6",
            "yedi" or "seven" => "7", "sekiz" or "eight" => "8", "dokuz" or "nine" => "9", "on" or "ten" => "10", var other => other
        };
        return int.TryParse(value, out var number) ? number : -1;
    }

    public static Intent? Parse(string text, string context = "", DateTimeOffset? now = null) => Sense(ParseRaw(text, context, now), text);

    // Kalıba uyan ama adı anlamsız ("asdkj çal", "yarın lkjhg") ya da saati yarım kalan ("yarın saat") cümle sessizce iş açmaz, sorulur.
    // Target sorunun bekleyen metnidir: "Tarkan" cevabı "çal"a eklenir (CommandRunner), anlamsız sözcük cümlede kalmaz.
    private static Intent? Sense(Intent? intent, string text)
    {
        if (intent is null) return null;
        var question = intent.Kind switch {
            "spotify.play" => "Ne çalayım? Örneğin ‘Tarkan çal’.",
            "spotify.search" => "Ne arayayım? Örneğin ‘Tarkan ara’.",
            "steam.search" or "steam.trackNamed" or "steam.unwatchNamed" => "Hangi oyun? Örneğin ‘Hades’i takip et’.",
            "task.add" => "Neyi ekleyeyim? Örneğin ‘süt al ekle’.",
            "reminder.add" => "Neyi hatırlatayım? Örneğin ‘yarın 9’da raporu hatırlat’.",
            _ => null
        };
        if (question is null || intent.Text.Length == 0) return intent;
        var words = Regex.Split(intent.Text.Trim(), @"\s+");
        if (words.All(Nonsense)) {
            var rest = text;
            foreach (var word in words.Distinct(StringComparer.OrdinalIgnoreCase)) rest = Regex.Replace(rest, @"(?<!\S)" + Regex.Escape(word) + @"\S*", "", Options);
            rest = Regex.Replace(rest, @"\s+", " ").Trim();
            var heard = string.Join(' ', words.Where(w => !Filler(w))).ToLower(System.Globalization.CultureInfo.GetCultureInfo("tr-TR"));
            return new("clarify", (heard.Length > 0 ? $"‘{heard}’ kısmını anlayamadım. " : "") + question, Target: rest);
        }
        // "yarın saat", "yarın toplantı saat": saat sözcüğü var, sayısı yok. Cevap ("9'da") cümlenin sonuna eklenir.
        if (intent.Kind is "task.add" or "reminder.add" && Match(intent.Text, @"(?:^|\s)saat(?:te|ta|inde|i)?$").Success) {
            var name = Regex.Replace(intent.Text, @"\s*\bsaat\w*$", "", Options);
            return new("clarify", name.Length == 0 ? "Saat kaçta, ne için? Örneğin ‘yarın 9’da raporu hatırlat’." : $"‘{name}’ saat kaçta? Örneğin ‘9’da’.", Target: text.Trim());
        }
        return intent;
    }
    // Dolgu sözcüğü ("ee", "şey", "bi") ya da klavyede gelişigüzel basılmış harfler ("asdkj", "lkjhg", "qwerty", "xkcd").
    // Büyük harfli kısaltmalar ("BTS", "MGMT") ad sayılır.
    private static bool Filler(string word) => Match(word, @"^(?:e+|ı+|a+|h?m+|hm+|ş+ey|bi|bir|o|bu|şu|um+|uh+|eh+|yani|işte)$").Success;
    internal static bool Nonsense(string word)
    {
        var letters = new string(word.Where(char.IsLetter).ToArray());
        if (Filler(word) || letters.Length > 0 && Filler(letters)) return true;
        if (letters.Length < 3) return false;
        var lower = letters.ToLowerInvariant();
        if (lower.Length >= 4 && !lower.Any(c => "aeıioöuüyâî".Contains(c)) && letters != letters.ToUpperInvariant()) return true;
        // Klavye sırasındaki harf üçlüleri; adlarda geçen "wer", "rty", "tre", "poi" gibileri bilerek alınmadı.
        return Regex.IsMatch(lower, "asd|sdf|dfg|fgh|ghj|hjk|jkl|lkj|kjh|jhg|hgf|gfd|fds|dsa|qw|zxc|xcv|cvb|vbn|bnm|mnb|nbv|bvc|vcx|cxz");
    }

    private static Intent? ParseRaw(string text, string context, DateTimeOffset? now)
    {
        var at = now ?? DateTimeOffset.Now;
        text = Regex.Replace(text.Trim().TrimEnd('.', '!', '?'), @"\s+", " ");
        if (text.Length == 0) return null;
        text = Regex.Replace(text, @"^(?:(?:lütfen|please|bana|benim için)\s+)+", "", Options);
        text = Regex.Replace(text, @"\s+(?:lütfen|please)$", "", Options);
        text = Regex.Replace(text, @"\b(yapar|eder|açar|çalar|ekler|hatırlatır|bulur|yapabilir|edebilir|açabilir|çalabilir|ekleyebilir|hatırlatabilir|bulabilir)\s+m[ıi]s[ıi]n$", m => m.Groups[1].Value.ToLowerInvariant() switch { "yapar" or "yapabilir" => "yap", "eder" or "edebilir" => "et", "açar" or "açabilir" => "aç", "çalar" or "çalabilir" => "çal", "ekler" or "ekleyebilir" => "ekle", "hatırlatır" or "hatırlatabilir" => "hatırlat", _ => "bul" }, Options);
        // Açıkça reddedilen istek olumlu işleme çevrilmez ve modele de gönderilmez: model "hades takibini bırakma"yı
        // takibi bırak diye okuyabiliyordu (ölçüm, 23 Ekim 2026). Kısa bir "tamam" ile kapanır.
        if (Match(text, @"\b(?:etme|ekleme|silme|açma|çalma|oynatma|kurma|hatırlatma|takip etme|erteleme|tamamlama|başlatma|çalıştırma)\s*$|^(?:don't|don’t|do not)\s+(?:play|open|run|start|delete|remove|track|search|find|pause|stop|remind|set)\b").Success
            || TextCleaner.IsNegative(text)) return new("decline");
        if (LeadRequest(text, context, at) is { } lead) return lead;

        // "tamamlanan/biten hatırlatıcıları temizle": "biten" adlı bir planı silmek değildir.
        if (Match(text, @"^(?:tamamlanan|tamamlanmış|biten|bitmiş|eski)\s+(?:hatırlatıcıları|hatırlatmaları|planları)\s+(?:temizle|sil|kaldır)$|^clear\s+completed\s+reminders$").Success) return new("reminder.clearCompleted");
        if (ReminderVoiceRemoval.Parse(text) is { } removal) return new("reminder.remove", Target: removal);
        if (ReminderAction(text, at) is { } reminderAction) return reminderAction;
        if (Task(text, at) is { } task) return task;
        var routine = Match(text, @"^(.+?)\s+(?:rutin(?:ini|imi|i|im)?|kısayol(?:unu|umu|u|um)?)\s+(?:başlat|çalıştır|başlatsana|çalıştırsana|başlatır mısın|başlatabilir misin|çalıştırır mısın|çalıştırabilir misin)$");
        if (!routine.Success) routine = Match(text, @"^(?:(?:rutin|kısayol)\s+(?:başlat|çalıştır)|(?:start|run)\s+routine)\s+(.+)$");
        if (routine.Success) return new("routine.start", Name(routine.Groups[1].Value));

        text = Regex.Replace(text, @"^(?:lütfen\s+|please\s+)(?=(?:spotify|steam|hatırlatıcı)\b)", "", Options);
        if (Match(text, SpotifyOpenPattern).Success) return new("spotify.open");
        var spotifySimple = Match(text, @"^spotify\s+(duraklatsana|oynatsana|sonraki\s+şarkıya\s+geç|önceki\s+şarkıya\s+geç)$");
        if (spotifySimple.Success) return Control(spotifySimple.Groups[1].Value.ToLowerInvariant() switch { "duraklatsana" => "pause", "oynatsana" => "play", "sonraki şarkıya geç" => "next", _ => "previous" });

        // Uygulama adı başta ("Steam'de …", "Spotify'dan …"), ortada ("Hades'i Steam'de takip et") ya da İngilizce sonda olabilir.
        var app = Match(text, @"^(steam|spotify)(?:\s*['’]?\s*(?:[dt][ae]n?|y?[ıi]))?\s*[, :]?\s+(.+)$");
        var domain = app.Success ? app.Groups[1].Value.ToLowerInvariant() : "";
        var body = app.Success ? app.Groups[2].Value : text;
        if (!app.Success) {
            var middle = Match(text, @"^(.+?)\s+(steam|spotify)(?:\s*['’]?\s*(?:[dt][ae]n?|y?[ıi]))?\s+(takip et|takibe al|ara|bul|çal|oynat)$");
            if (middle.Success) { domain = middle.Groups[2].Value.ToLowerInvariant(); body = middle.Groups[1].Value + " " + middle.Groups[3].Value; }
            var english = Match(text, @"^(track|find|search|play)\s+(.+?)\s+on\s+(steam|spotify)$");
            if (english.Success) { domain = english.Groups[3].Value.ToLowerInvariant(); body = english.Groups[1].Value + " " + english.Groups[2].Value; }
            var englishFor = Match(text, @"^(search|find)\s+(steam|spotify)\s+for\s+(.+)$");
            if (englishFor.Success) { domain = englishFor.Groups[2].Value.ToLowerInvariant(); body = "search " + englishFor.Groups[3].Value; }
        }
        var effective = domain.Length > 0 ? domain : context;
        if (Direct(text) is { } direct) return direct;

        if (effective == "steam") {
            if (Match(body, @"^(?:takip et|takibe al|ekle|eklesene|takip etsene)$").Success) return new("steam.trackSelected");
            var ordinal = Match(body, @"^(ilk|birinci|ikinci|üçüncü|dördüncü|beşinci|\d+\.?)(?:yi|yı|yü|y[ıi])?\s+(?:oyunu\s+|sonucu\s+)?(seç|ekle|takip et|takibe al)$");
            if (ordinal.Success) return new(ordinal.Groups[2].Value == "seç" ? "steam.selectResult" : "steam.trackResult", Number: Number(ordinal.Groups[1].Value));
        }
        if (domain == "steam" || domain.Length == 0) {
            var named = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:takip et|takibe al|takip listeme ekle|takip listesine ekle|takibe ekle|takip etsene|takibe alsana|track)$");
            if (!named.Success) named = Match(body, @"^(.+?)\s+(?:oyunu\s+)?(?:çıktığında|çıkınca|yayınlandığında|yayınlanınca)\s+(?:bana\s+)?(?:haber ver|bildir|bildirim gönder)$");
            if (!named.Success) named = Match(body, @"^(?:takip et|takibe al|track)\s+(.+)$");
            if (!named.Success && effective == "steam") named = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:ekle|eklesene)$");
            // "takibe al baldurs gate 3 u listeye ekle" (sorulan soruya cevap önceki cümleye eklenir): "listeye ekle" ve ayrı ek addan atılır.
            if (named.Success && !Match(named.Groups[1].Value, @"^(?:seçili|seçili oyunu|şunu|bunu|bu oyunu)$").Success)
                return new("steam.trackNamed", Name(Regex.Replace(named.Groups[1].Value, @"(?:\s+listeye ekle)?(?:\s(?:y?[ıiuü]))?(?:\s+listeye ekle)?$", "", Options)));
            var remove = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:takibi bırak|takipten çıkar|takip listemden çıkar|takip listesinden kaldır|takibini bırak)$");
            if (remove.Success) return new("steam.unwatchNamed", Name(remove.Groups[1].Value));
            if (effective == "steam") {
                var search = Match(body, @"^(?:ara|bul|oyun ara|oyun bul|search|find)\s+(.+)$");
                if (!search.Success) search = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:ara|bul|arasana|bulsana)$");
                if (search.Success) return new("steam.search", Name(search.Groups[1].Value));
            }
            // "oyun" sözcüğü Steam'i söyler: "Hades oyununu ara", "oyun bul Celeste"
            var game = Match(body, @"^(.+?)\s+(?:oyununu|oyunu|adlı oyunu)\s+(?:ara|bul|arasana|bulsana)$");
            if (!game.Success) game = Match(body, @"^oyun\s+(?:ara|bul)\s+(.+)$");
            if (game.Success) return new("steam.search", Name(game.Groups[1].Value));
        }
        if (domain == "spotify" || domain.Length == 0) {
            if (effective == "spotify") {
                var volume = Match(body, @"^(?:sesi|ses|ses seviyesini)\s+(?:%\s*|yüzde\s*)?(\d{1,3})(?:\s+(?:yap|ayarla|olsun))?$");
                if (volume.Success) return new("spotify.volume", Number: int.Parse(volume.Groups[1].Value));
                var search = Match(body, @"^(?:ara|bul|search|find)\s+(.+)$");
                if (!search.Success) search = Match(body, @"^(.+?)\s+(?:ara|bul|arasana|bulsana)$");
                if (search.Success) return new("spotify.search", Name(search.Groups[1].Value));
                if (Match(body, @"^(?:şarkıyı|müziği)\s+(?:oynat|çal|devam ettir)$").Success) return Control("play");
            }
            // Şarkı: "X çal", "X dinle", "X şarkısını aç", "Tarkan'dan bir şarkı çal"
            var song = Match(body, @"^(?:çal|oynat|play|dinlet)\s+(.+)$");
            if (!song.Success) song = Match(body, @"^(.+?)['’]?(?:dan|den|tan|ten)\s+(?:bir\s+)?(?:şarkı|parça)\s+(?:çal|aç|oynat|dinlet|dinleyelim)$");
            if (!song.Success) song = Match(body, @"^(.+?)\s+(?:şarkısını|şarkısı|parçasını|albümünü)\s+(?:çal|oynat|aç|dinlet|dinle)$");
            if (!song.Success) song = Match(body, @"^(.+?)\s+(?:çal|oynat|çalsana|oynatsana|dinle|dinlet|dinleyelim|dinlemek istiyorum|çalsın|çalalım)$");
            if (!song.Success && domain == "spotify") song = Match(body, @"^(.+?)\s+aç$");
            // "müzik çal", "biraz müzik dinle": belirli bir şarkı değil, kaldığı yerden devam
            if (song.Success && Match(song.Groups[1].Value, @"^(?:müzik|biraz müzik|şarkı|bir şarkı|bir şey|bişey|müziği|şarkıyı)$").Success) return Control("play");
            if (song.Success && !song.Groups[1].Value.Equals("spotify", StringComparison.OrdinalIgnoreCase)) return new("spotify.play", Name(song.Groups[1].Value));
        }
        if (Reminder(text, at) is { } reminder) return reminder;
        if (effective == "steam") {
            if (Match(body, @"^(?:şunu|bunu|bu oyunu|seçili oyunu)\s+(?:ekle|takibe al|takip et)$").Success) return new("steam.trackSelected");
            if (Match(body, @"^(?:takiplerimi|oyunlarımı|takip ettiğim oyunları|takip listemi|oyun listemi)\s+(?:göster|aç)$").Success) return new("steam.list");
            if (Match(body, @"^(?:oyunları\s+)?(?:kontrol et|kontrol etsene|kontrol eder misin|güncelle)$").Success) return new("steam.check");
            var pick = Match(body, @"^(ilk|birinci|ikinci|üçüncü|sonuç\s+\d+)\s+(?:oyunu\s+)?(seç|ekle|takip et|takibe al)$");
            if (pick.Success) {
                var number = Number(Regex.Replace(pick.Groups[1].Value, @"^sonuç\s+", "", Options));
                return new(pick.Groups[2].Value == "seç" ? "steam.selectResult" : "steam.trackResult", Number: number);
            }
        }
        if (effective == "spotify") {
            if (Match(body, @"^(?:duraklat|duraklatsana|müziği durdur|şarkıyı durdur|müziği duraklat|şarkıyı duraklat|pause)$").Success) return Control("pause");
            if (Match(body, @"^(?:devam et|oynat|çal|müziği devam ettir|play|resume)$").Success) return Control("play");
            if (Match(body, @"^(?:sonraki(?: şarkı)?|şarkıyı geç|sonraki şarkıya geç|next)$").Success) return Control("next");
            if (Match(body, @"^(?:önceki(?: şarkı)?|önceki şarkıya geç|bir önceki şarkı|previous)$").Success) return Control("previous");
        }
        if (Match(text, @"^(?:hatırlatıcılarımı|hatırlatmalarımı|hatırlatıcı listesini)\s+(?:göster|aç)$").Success) return new("reminder.list");
        return QuickAdd(text, at);
    }

    // Hiçbir kalıba uymayan cümle, içinde zaman varsa Bugün'deki hızlı ekleme gibi işlenir:
    // "yarın çamaşır yıka" → yarına görev, "akşam 8'de ilaç iç" → hatırlatıcı, "süt al ekle" → bugüne görev.
    // Soru cümleleri ("yarın hava nasıl") iş sayılmaz.
    private static Intent? QuickAdd(string text, DateTimeOffset now)
    {
        if (Match(text, @"\?\s*$|\b(?:mı|mi|mu|mü|mısın|misin|musun|müsün|nasıl|neden|niye|niçin|kaç|hangi|nedir|ne|neler|ne zaman|var mı)\b").Success) return null;
        // Düzeltme cümlesi ("raporu gönder yarın değil pazartesi olsun") var olan kaydı değiştirir; yeni iş açılmaz, model yapar.
        if (Match(text, @"\bdeğil\b").Success) return null;
        // Selamlaşma ve sohbet ("naber, bugün çok yorgunum") iş değildir; içinde "bugün" geçse de görev açılmaz.
        if (Match(text, @"^(?:naber|merhaba|selam|selamlar|hey|nasılsın|günaydın|iyi akşamlar|iyi geceler|hello|hi)\b").Success) return null;
        // Var olan bir plana atıf ("Raporu gönder planını yarın 16:00'ya al", "… hatırlatıcısının saatini …") yeni iş değildir; değiştirme işini model yapar.
        // ("proje planını hazırla" yeni iştir: yalnız taşıma/değiştirme fiiliyle biten cümleler).
        if (Match(text, @"\b\S+\s+(?:plan|hatırlatıcı|hatırlatma)(?:ını|ının|sını|sının)\b.*\b(?:al|yap|taşı|kaydır|değiştir|çek|getir)$").Success) return null;
        // "baldurs gate 3 u listeye ekle": "liste" Steam takip listesi de olabilir. Ekli, birden çok sözcüklü ya da sayılı ad sorulur
        // ("sütü listeye ekle" görevdir). Cevap ("takibe al" / "görev") önceki cümleye eklenince aşağıdaki iki kalıptan biri çalışır.
        var list = Match(text, @"^(?:(steam|oyun|takip|görev)\s+)?(.+?)\s+listeye ekle(?:\s+(steam|oyun|oyunu|takibe al|takip et|takip|görev|görevlere|görev olarak))?$");
        if (list.Success) {
            var choice = (list.Groups[1].Value + list.Groups[3].Value).ToLowerInvariant();
            var item = list.Groups[2].Value;
            if (choice.Length > 0 && !choice.StartsWith("görev")) return new("steam.trackNamed", Name(Regex.Replace(item, @"\s(?:y?[ıiuü])$", "", Options)));
            if (choice.Length == 0 && Match(item, @"(?:\s(?:u|ü|i|ı|yu|yü|yi|yı)|['’]\p{L}+|\p{L}(?:yu|yü|yi|yı|u|ü|i|ı))$").Success && Match(item, @"\d|\s").Success)
                return new("clarify", $"‘{item}’ görevlere mi eklensin, Steam takibine mi? ‘görev’ ya da ‘takibe al’ de.");
        }
        var generic = Match(list.Success ? list.Groups[2].Value + " listeye ekle" : text, @"^(.+?)\s+(?:ekle|eklesene|not al|not et|kaydet|listeye ekle|yapılacaklara ekle)$");
        var when = WhenParser.Parse(generic.Success ? generic.Groups[1].Value : text, now);
        if (when.Text.Length == 0 || when.Conflict) return null;
        // Tek başına "şey" (zaman da "ekle" de yok) ekleme isteği değildir; anlaşılmadı sayılır.
        if (Vague(when.Text) && !generic.Success && when is { Day: null, Due: null, RelativeSeconds: null, Someday: false }) return null;
        if (Vague(when.Text)) return new("clarify", "Neyi ekleyeyim? Örneğin ‘süt al ekle’.");
        if (when.Someday) return new("task.add", when.Text, Target: "someday");
        if (when.RelativeSeconds is int after) return new("reminder.add", when.Text, after);
        if (when.Due is { } due) return new("reminder.add", when.Text, Due: due);
        if (when.Day != null || generic.Success) return new("task.add", when.Text, Day: when.Day);
        return null;
    }
    private static Intent Control(string action) => new("spotify.control", action);
    // İş adı olamayacak kadar belirsiz ("bir şey ekle"): sormak, "Bir şey" adlı görev açmaktan iyidir.
    private static bool Vague(string title) => Match(title, @"^(?:bir\s+şey(?:ler)?|bi\s*şey(?:ler)?|şey|bişey|something|anything|bunu|şunu)$").Success;

    // Yazılı kısa komutlar ve İngilizce kalıplar ("steam sonuç 2 seç", "spotify next", "show reminders" …).
    private static Intent? Direct(string text)
    {
        Match m;
        if ((m = Match(text, @"^spotify (?:sonuç (\S+) çal|play result (\S+))$")).Success) return new("spotify.playResult", Number: Number(m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value));
        if (Match(text, @"^spotify (?:durum|status)$").Success) return new("spotify.status");
        if (Match(text, @"^(?:spotify (?:çalan şarkı|ne çalıyor)|what(?:'s| is) playing(?: on spotify)?)$").Success) return new("spotify.current");
        if ((m = Match(text, @"^play on spotify (.+)$")).Success) return new("spotify.play", Name(m.Groups[1].Value));
        if ((m = Match(text, @"^spotify (?:search|ara) (.+)$")).Success) return new("spotify.search", m.Groups[1].Value.Trim());
        var control = text.ToLowerInvariant() switch {
            "spotify play" or "spotify resume" or "spotify oynat" or "spotify devam et" => "play",
            "spotify pause" or "spotify stop" or "spotify duraklat" or "spotify durdur" => "pause",
            "spotify next" or "spotify next track" or "spotify sonraki" or "spotify sonraki şarkı" => "next",
            "spotify previous" or "spotify previous track" or "spotify önceki" or "spotify önceki şarkı" => "previous",
            "spotify oynat duraklat" => "toggle", _ => null
        };
        if (control != null) return Control(control);
        if ((m = Match(text, @"^steam (?:select result (\S+)|sonuç (\S+) seç)$")).Success) return new("steam.selectResult", Number: Number(m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value));
        if ((m = Match(text, @"^steam (?:takip (\S+) seç|select watch (\S+))$")).Success) return new("steam.selectWatch", Number: Number(m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value));
        if ((m = Match(text, @"^steam sonuç-ekle (\d+)$")).Success) return new("steam.trackResult", Number: Number(m.Groups[1].Value));
        if (Match(text, @"^steam (?:takibi bırak|unwatch selected)$").Success) return new("steam.unwatchSelected");
        if (Match(text, @"^steam (?:seçili oyunu takip et|takip et|track selected)$").Success) return new("steam.trackSelected");
        if (Match(text, @"^steam (?:takipleri göster|list|show watches)$").Success) return new("steam.list");
        if (Match(text, @"^steam (?:kontrol et|check)$").Success) return new("steam.check");
        if (Match(text, @"^(?:hatırlatıcıları göster|show reminders)$").Success) return new("reminder.list");
        if ((m = Match(text, @"^(?:hatırlatıcı (\S+) seç|select reminder (\S+))$")).Success) return new("reminder.select", Number: Number(m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value));
        if (Match(text, @"^delete selected reminder$").Success) return new("reminder.remove", Target: "secili");
        // İngilizce zamanlayıcı ve hatırlatıcı: "set a timer for ten seconds", "remind me in 20 minutes to stretch"
        var detailed = Match(text, @"^remind\s+me\s+in\s+(.+?)\s+to\s+(.+)$");
        if (detailed.Success && WhenParser.EnglishDuration(detailed.Groups[1].Value) is int after) return new("reminder.add", WhenParser.Capitalize(detailed.Groups[2].Value.Trim()), after);
        var timer = Match(text, @"^(?:set\s+(?:a\s+)?(?:timer|reminder)\s+for\s+)?([a-z\d -]+?\s+(?:seconds?|minutes?|hours?))(?:\s+(?:timer|reminder))?$");
        if (timer.Success && (text.Contains("timer", StringComparison.OrdinalIgnoreCase) || text.Contains("reminder", StringComparison.OrdinalIgnoreCase)) && WhenParser.EnglishDuration(timer.Groups[1].Value) is int seconds)
            return new("reminder.add", DefaultReminderText, seconds);
        return null;
    }

    // Hatırlatıcı kurma: süreyle ("on dakika sonra su içmeyi hatırlat"), zamanla ("yarın 9'da raporu hatırlat")
    // ya da zamanlayıcı ("10 dakikalık alarm kur", "hatırlatıcı kur on dakika").
    private static Intent? Reminder(string text, DateTimeOffset now)
    {
        var timer = Match(text, @"^(?:hatırlatıcı|zamanlayıcı|alarm)\s+(?:kur|ayarla|oluştur)\s+(.+)$");
        if (!timer.Success) timer = Match(text, @"^(.+?)(?:lik|lık|lük|luk)?\s+(?:alarm|zamanlayıcı|hatırlatıcı)(?:\s+(?:kur|ayarla|oluştur))?$");
        if (timer.Success && SpokenDuration.TryParse(Regex.Replace(timer.Groups[1].Value, @"(?<=(?:saniye|dakika|saat))(?:lik|lık)$", "", Options), out var seconds))
            return new("reminder.add", DefaultReminderText, seconds);
        var remind = Match(text, @"^(.+?)\s+" + RemindVerb + "$");
        // Fiil sonda ("yarın 9'da raporu hatırlat") ya da başta ("hatırlat yarın 9'da rapor") olabilir.
        if (!remind.Success) remind = Match(text, @"^(?:bana\s+)?(?:hatırlat|hatırlatsana|hatırlatma kur|hatırlatıcı kur)\s+(.+)$");
        if (!remind.Success) return null;
        var (spoken, repeat) = Repeat(remind.Groups[1].Value);
        var when = WhenParser.Parse(spoken, now);
        if (repeat is not null && when.Due is { } first && when.RelativeSeconds is null && when.Text.Length > 0)
            return new("reminder.add", when.Text, Target: repeat, Due: first);
        if (when.Conflict) return new("clarify", "Tek bir zaman söyle: ya süre (on dakika sonra) ya da gün ve saat (yarın 9'da).");
        var name = when.Text.Length == 0 ? DefaultReminderText : when.Text;
        if (when.RelativeSeconds is int after) return new("reminder.add", name, after);
        // "yarın sabah dokuzda hatırlat": zamanlayıcı değil ve ne hatırlatılacağı yok; boş bir hatırlatıcı açmak yerine sorulur.
        if (when.Text.Length == 0 && when.Due is not null) return new("clarify", "Neyi hatırlatayım? Örneğin ‘yarın 9’da raporu hatırlat’.");
        if (when.Due is { } due) return new("reminder.add", name, Due: due);
        // Gün söylendi, saat söylenmedi ("ayın 3'ünde … hatırlatıcı kur"): yalnız saat sorulur; "9'da" cevabı önceki cümleyle birleşir.
        if (when.Day is { } onDay)
            return new("clarify", onDay.ToString("d MMMM", System.Globalization.CultureInfo.GetCultureInfo("tr-TR")) + " günü saat kaçta hatırlatayım? Örneğin ‘9’da’.");
        return new("clarify", "Ne zaman hatırlatayım? Örneğin ‘yarın 9’da " + remind.Groups[1].Value.Trim() + " hatırlat’ ya da ‘on dakika sonra …’.");
    }

    // Ön hatırlatma: "yarın 3'te toplantı, 15 dk önce hatırlat", "toplantıyı yarın 3'te hatırlat, yarım saat önce",
    // "yarın 9'da dişçi bir gün önceden haber ver". Süre cümleden ayrılır (başlığa karışmaz), kalanı hatırlatıcı olarak okunur.
    // Saat yoksa var olan plana kurulur: "toplantıdan 15 dk önce hatırlat", "dişçi için yarım saat önce uyar".
    // Hatırlatma fiili yoksa ("toplantıdan 10 dakika önce çık") dokunulmaz.
    // Yalnız istek: "hatırlattın" (geçmiş) ön hatırlatma isteği değildir. "hatırlatır mısın" ParseRaw'da "hatırlat"a döner.
    private const string LeadVerb = @"(?:hatırlat(?:sana)?|anımsat|haber ver(?:sene|ir misin)?|uyar(?:sana|ır mısın)?|bildir(?:im (?:gönder|at))?)";
    private static Intent? LeadRequest(string text, string context, DateTimeOffset now)
    {
        var phrase = Match(text, @"(?<!\S)(?<unit>dakika|dk|saat|gün)\s+(?:önce(?:den)?|kala)(?:\s+(?:de|da))?(?<verb>\s+" + LeadVerb + @")?(?=$|[\s,])");
        if (!phrase.Success || !(phrase.Groups["verb"].Success || Match(text, @"(?<!\S)" + LeadVerb + @"(?=$|[\s,])").Success)) return null;
        // Birimin önündeki en uzun süre: "1 saat 30 dakika", "on beş dakika", "yarım saat", "bir gün".
        var before = text[..phrase.Index];
        var words = Regex.Matches(before, @"\S+");
        int minutes = -1, start = -1;
        for (var take = Math.Min(4, words.Count); take >= 1 && minutes < 0; take--) {
            var amount = before[words[words.Count - take].Index..].Trim().TrimEnd(',');
            var unit = phrase.Groups["unit"].Value.ToLowerInvariant();
            if (unit == "gün") { if (take == 1 && Number(amount) is > 0 and var days) { minutes = days * AdvanceLead.DayBefore; start = words[^1].Index; } continue; }
            if (SpokenDuration.TryParse(amount + " " + (unit == "dk" ? "dakika" : unit), out var seconds) && seconds % 60 == 0) { minutes = seconds / 60; start = words[words.Count - take].Index; }
        }
        if (minutes < 0) return null;
        if (minutes > AdvanceLead.Max) return new("clarify", "En fazla bir gün önceden hatırlatabilirim. Örneğin ‘bir saat önce hatırlat’.");
        var name = text[..start].Trim().TrimEnd(',').Trim();
        var rest = Regex.Replace((name + " " + text[(phrase.Index + phrase.Length)..].Trim().TrimStart(',')).Trim(), @"\s+var$", "", Options);
        if (!Match(rest, @"(?<!\S)(?:" + RemindVerb + @"|hatırlat)(?=$|[\s,])").Success) rest += " hatırlat";
        var parsed = ParseRaw(rest, context, now);
        if (parsed is { Kind: "reminder.add" }) return parsed with { Before = minutes };
        // Saat söylenmedi: var olan plan ("toplantıdan", "dişçi için", "toplantı planından").
        var target = Match(name, @"^(.+?)(?:['’]?(?:[dt][ae]n)|\s+için)$");
        if (target.Success && !Match(name, @"\d|\b(?:yarın|bugün|akşam|sabah|gece|öğlen?)\b").Success) {
            var stem = Regex.Replace(target.Groups[1].Value, @"(?<=[aeıioöuü])n$", "", Options);
            stem = Regex.Replace(stem, @"\s+(?:plan|hatırlatıcı|hatırlatma)\w*$", "", Options);
            return new("reminder.lead", Number: minutes, Target: ReminderVoiceRemoval.Fold(stem));
        }
        return parsed;
    }

    // Tekrar: "her gün", "her gece", "her sabah" → her gün; "her pazartesi" → o gün her hafta. Hedef "weekly:<gün maskesi>"
    // (bit = DayOfWeek, pazar 0). Gün bölümü saati yorumlamak için cümlede kalır ("her gece üçte" 03:00); "her" atılır.
    private static readonly string[] RepeatDays = ["pazar", "pazartesi", "salı", "çarşamba", "perşembe", "cuma", "cumartesi"];
    internal static (string Text, string? Repeat) Repeat(string text)
    {
        var m = Match(text, @"\bher\s+(gün|sabah|akşam|gece|öğlen|öğleden sonra|pazartesi|salı|çarşamba|perşembe|cuma|cumartesi|pazar)(?:ı|i|leri|ları)?\b");
        if (!m.Success) return (text, null);
        var word = m.Groups[1].Value.ToLowerInvariant();
        var day = Array.IndexOf(RepeatDays, word);
        var rest = text[..m.Index] + (word == "gün" ? "" : word == "pazar" ? "pazar günü" : word) + text[(m.Index + m.Length)..];
        return (Regex.Replace(rest, @"\s+", " ").Trim(), "weekly:" + (day >= 0 ? 1 << day : 127));
    }

    // Hatırlatıcı erteleme ve tamamlama: "su içme hatırlatıcısını beş dakika ertele", "seçili planı yaptım".
    internal static Intent? ReminderAction(string text, DateTimeOffset? now = null)
    {
        if (Regex.IsMatch(text, @"-\s*\d|\b(?:erteleme|tamamlama|tamamlamadım|yapmadım)\b", Options)) return null;
        var folded = Regex.Replace(ReminderVoiceRemoval.Fold(text), @"\s+", " ");
        // Dolaylı erteleme kurala çevrilir; yoksa modele gidiyor, model "bi saat kadar"ı 30 dk sanabiliyordu (bağımsız 5, madde 4):
        // "bi saat kadar öteleyebilir misin su olanı", "su içi bir saatliğine ertele", "yarım saat kadar sonraya at", "45 dk ileri al", "bir saat kaydırır mısın".
        folded = Regex.Replace(folded, @"\bbi(?=\s+(?:saat|dakika|bucuk)\b)", "bir");
        folded = Regex.Replace(folded, @"\b(saat|dakika)(?:ligine|ligina|lik)\b", "$1");
        folded = Regex.Replace(folded, @"\b(saat|dakika)\s+kadar\b", "$1");
        folded = Regex.Replace(folded, @"(?<=\b(?:saat|dakika))\s+(?:sonraya at(?:sana|ar misin)?|(?:ileri(?:ye)?|sonraya) al(?:sana|ir misin)?|kaydir(?:sana|ir misin|abilir misin)?)$", " ertele");
        var front = Regex.Match(folded, @"^(.+?\s+(?:dakika|saat))\s+(ertele|otele|ertelesene|erteler misin|erteleyebilir misin|oteler misin|oteleyebilir misin)\s+(.+)$");
        if (front.Success) folded = front.Groups[3].Value + " " + front.Groups[1].Value + " " + front.Groups[2].Value;
        var snooze =Regex.Match(folded, @"^(.*\b(?:hatirlatici\w*|hatirlatma\w*|plan\w*)(?:\s+\d+(?=\s+(?:\d+|[a-z]+)\s+(?:dakika|saat)))?)\s+(.+?)\s+(?:ertele|ertelesene|erteler misin|erteleyebilir misin)$");
        if (snooze.Success && SpokenDuration.TryParse(snooze.Groups[2].Value, out var seconds) && seconds % 60 == 0) {
            var target = ReminderVoiceRemoval.Parse(snooze.Groups[1].Value + " sil");
            if (target is not null) return new("reminder.snooze", Number: seconds / 60, Target: target);
        }
        // "hatırlatıcı" denmeden: "su içi yarım saat ertele". Süre sondaki sözcüklerden okunur, kalan ad var olan bir planla eşleşmezse sorulur.
        var bare = Regex.Match(folded, @"^(.+?)\s+(?:ertele|otele|ertelesene|erteler misin|erteleyebilir misin|oteler misin|oteleyebilir misin)$");
        if (bare.Success && !Regex.IsMatch(bare.Groups[1].Value, @"\b(?:sonra|once)$")) {
            // "su içi bir saat daha ertele", "raporu gönder olanı 30 dakika ertele": "daha" ve "olanı" ada karışmaz.
            var words = Regex.Replace(bare.Groups[1].Value, @"\s+(?:daha|olan(?:i|ini|in)?)\b", "").Split(' ');
            for (var take = Math.Min(4, words.Length - 1); take >= 1; take--) {
                var duration = string.Join(' ', words[^take..]);
                if (SpokenDuration.TryParse(duration, out var delay) && delay >= 60 && delay % 60 == 0)
                    return new("reminder.snooze", Number: delay / 60, Target: string.Join(' ', words[..^take]));
            }
        }
        // Var olan planın zamanını değiştirme: "raporu gönder hatırlatıcısını öğleden sonra ikiye al", "raporu gönder yarın değil pazartesi olsun".
        // "olsun" yalnız "değil" ya da plan sözcüğüyle birlikte (yoksa "yarın 9'da toplantı olsun" yeni plan olabilir).
        var move = Match(text, @"^(.+?)\s+(?:al|çek|kaydır|taşı|ayarla|olsun)$");
        if (move.Success && (Match(text, @"\b(?:al|çek|kaydır|taşı|ayarla)$").Success || Match(text, @"\bdeğil\b|\b(?:hatırlatıcı|hatırlatma|plan)\w*").Success)
            && Match(move.Groups[1].Value, @"\b(?:hatırlatıcı|hatırlatma|plan)\w*|\bdeğil\b").Success) {
            // Reddedilen zaman atılır: "yarın değil", "9'da değil", "bir saat sonraya değil".
            var body = Regex.Replace(move.Groups[1].Value, @"\b(?:yarın|bugün|pazartesi|salı|çarşamba|perşembe|cuma|cumartesi|pazar|sabah|akşam|öğlen|\d{1,2}(?:[:.]\d{2})?['’]?\w*|(?:\S+\s+)?(?:buçuk\s+)?(?:dakika|saat|gün)\s+sonra(?:ya)?)\s+değil\b", "", Options);
            body = Regex.Replace(body, @"\bsonraya\b", "sonra", Options);
            // Gün söylenmediyse (yalnız saat) planın kendi günü korunur: Text = "saat". Saat de günün başına göre okunur;
            // yoksa öğleden sonra söylenen "saat 11'e" bugünün 11'i geçtiği için 23:00 sanılırdı.
            var dayGiven = Match(body, @"\b(?:(?:dakika|saat|gün|hafta)\s+sonra|yarın\w*|bugün\w*|öbür gün|ertesi gün|haftaya|pazartesi\w*|salı\w*|çarşamba\w*|perşembe\w*|cuma\w*|cumartesi\w*|pazar\w*|ayın|\d{1,2}\s+(?:ocak|şubat|mart|nisan|mayıs|haziran|temmuz|ağustos|eylül|ekim|kasım|aralık))\b").Success;
            var current = now ?? DateTimeOffset.Now;
            var when = WhenParser.Parse(body, dayGiven ? current : new DateTimeOffset(current.Date, current.Offset));
            var name = Regex.Replace(when.Text, @"\b(?:hatırlatıcı|hatırlatma|plan)\w*", "", Options).Trim();
            // Gün adıyla söylendiyse ("pazartesi olsun") resolver bugünün geçmiş saatini gelecek haftaya taşır; "bugüne al" taşınmaz, sorulur.
            var weekday = Match(body, @"\b(?:pazartesi|salı|çarşamba|perşembe|cuma|cumartesi|pazar)\w*").Success;
            if ((when.Due is not null || when.Day is not null) && name.Length > 0)
                return new("reminder.edit", !dayGiven ? "saat" : weekday ? "gün adı" : "", Target: name, Due: when.Due, Day: when.Due is null ? when.Day : null);
        }
        var complete = Regex.Match(folded, @"^(.+?)\s+(?:tamamla|tamamladim|yaptim|bitti|tamamlandi|tamamlar misin|tamamlayabilir misin)$");
        if (complete.Success) {
            var target = ReminderVoiceRemoval.Parse(complete.Groups[1].Value + " sil");
            if (target is not null) return new("reminder.complete", Target: target);
        }
        return null;
    }

    // Görevler: ekleme ("yarın market alışverişi görevini ekle", "bir ara dolabı düzenle"), tamamlama, bugünü sorma.
    private static Intent? Task(string text, DateTimeOffset now)
    {
        if (Match(text, @"^(?:bugün(?: için)? ne(?:ler)? var|bugün ne(?:ler)? yapmam (?:lazım|gerek|gerekiyor)|bugün(?:kü)? (?:görevlerimi|işlerimi|planımı) (?:göster|söyle|oku)|görevlerimi (?:göster|söyle|listele)|yapılacakları göster|show (?:my )?tasks|what(?:'s| is) on today)$").Success) return new("task.list");
        // "bugün faturayı öde görevini bitirdim tamamla": baştaki "bugün" ve art arda iki fiil olabilir.
        var done = Match(text, @"^(?:bugün(?:kü)?\s+)?(.+?)\s+(?:görevini|görevi|işini)\s+(?:(?:tamamla|tamamladım|yaptım|bitirdim|bitti|tamamlandı)\s*)+$");
        // "market alışverişini bitirdim": "görevini" denmese de; ad açık bir görevle eşleşmezse sorulur.
        if (!done.Success) done = Match(text, @"^(?:bugün\s+)?(.+?)\s+(?:bitirdim|tamamladım|hallettim)(?:\s+(?:tamamla|işaretle))?$");
        // Konuşma dili: "bulaşıklar tamam", "çamaşır oldu", "market bitti". Ad açık bir görevle eşleşmezse sorulur.
        if (!done.Success) done = Match(text, @"^(?!(?:evet|peki|ok|okey|tamam|anladım|iyi|güzel|süper|harika)\b)(?:bugün(?:kü)?\s+)?(.+?)\s+(?:tamam|tamamdır|oldu|bitti|yapıldı|halloldu|tamamlandı)$");
        if (done.Success) return new("task.complete", Target: ReminderVoiceRemoval.Fold(Name(done.Groups[1].Value)));
        var add = Match(text, @"^(?:görev ekle|yeni görev|yapılacaklara ekle|add task|görev(?=\s*:))\s*[:,]?\s+(.+)$");
        if (!add.Success) add = Match(text, @"^(.+?)\s+(?:görevini|görevi|diye (?:bir )?görev|işini)\s+(?:ekle|oluştur|yaz|kaydet)$");
        if (!add.Success) add = Match(text, @"^(.+?)\s+(?:yapılacaklara|görevlere|görev listeme)\s+ekle$");
        // "görevlere şey ekle haftaya salı …": ekleme fiili başta.
        if (!add.Success) add = Match(text, @"^(?:yapılacaklara|görevlere|görev listeme)\s+(?:(?:bir\s+)?şey\s+)?ekle\s*[:,]?\s+(.+)$");
        // "bi ara yemek ye", "yemek ye bir ara" (hatırlatma isteği değilse)
        var someday = !add.Success && !Match(text, RemindVerb + "$").Success && WhenParser.Parse(text, now).Someday;
        if (!add.Success && !someday) return null;
        var when = WhenParser.Parse(add.Success ? add.Groups[1].Value : text, now);
        if (when.Text.Length == 0 || Vague(when.Text)) return new("clarify", "Görevin adını da söyle. Örneğin ‘yarın market alışverişi görevini ekle’.");
        if (when.Someday) return new("task.add", when.Text, Target: "someday");
        // Saat söylenen iş bildirimli olur (hatırlatıcı); saatsiz iş görevdir.
        // Yalnız gün bölümü ("haftaya salı gece vardiyası öncesi …") saat değildir: açıkça görev istendiği için o güne görev olur.
        if (when.Due is { } due && !when.Conflict && !when.PeriodOnly) return new("reminder.add", when.Text, Due: due);
        return new("task.add", when.Text, Day: when.Day);
    }
}
