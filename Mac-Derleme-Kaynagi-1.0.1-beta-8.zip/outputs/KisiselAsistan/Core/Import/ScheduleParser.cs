using System.Globalization;
using System.Text.RegularExpressions;

namespace KisiselAsistan;

// Haftalık programın bir satırı: hangi gün, kaçtan kaça, ne (ders adı, vardiya, toplantı…).
public sealed record ScheduleEntry(DayOfWeek Day, int Start, int End, string Title);
public sealed record ScheduleParse(List<ScheduleEntry> Entries, List<string> Notes);

// Tablodan haftalık programı çıkarır. Üç yaygın düzeni tanır:
//  1) Izgara: başlık satırında günler (Pazartesi…Cuma), her satırın başında saat (08:30-09:20), hücrede ders.
//  2) Ters ızgara: başlık satırında saatler, her satırın başında gün.
//  3) Liste: her satırda bir gün, bir saat aralığı (ya da başlangıç ve bitiş ayrı sütunda) ve bir ad.
// Aynı gün arka arkaya gelen aynı ad (iki saatlik ders) tek kayda birleşir. Emin olunamayanlar önizlemede kullanıcıya bırakılır.
public static class ScheduleParser
{
    private static readonly CultureInfo Turkish = CultureInfo.GetCultureInfo("tr-TR");
    private static readonly Dictionary<string, DayOfWeek> Days = new() {
        ["pazartesi"] = DayOfWeek.Monday, ["pzt"] = DayOfWeek.Monday, ["pts"] = DayOfWeek.Monday, ["pt"] = DayOfWeek.Monday, ["monday"] = DayOfWeek.Monday, ["mon"] = DayOfWeek.Monday,
        ["salı"] = DayOfWeek.Tuesday, ["sali"] = DayOfWeek.Tuesday, ["sal"] = DayOfWeek.Tuesday, ["tuesday"] = DayOfWeek.Tuesday, ["tue"] = DayOfWeek.Tuesday,
        ["çarşamba"] = DayOfWeek.Wednesday, ["carsamba"] = DayOfWeek.Wednesday, ["çar"] = DayOfWeek.Wednesday, ["car"] = DayOfWeek.Wednesday, ["çrş"] = DayOfWeek.Wednesday, ["wednesday"] = DayOfWeek.Wednesday, ["wed"] = DayOfWeek.Wednesday,
        ["perşembe"] = DayOfWeek.Thursday, ["persembe"] = DayOfWeek.Thursday, ["per"] = DayOfWeek.Thursday, ["prş"] = DayOfWeek.Thursday, ["thursday"] = DayOfWeek.Thursday, ["thu"] = DayOfWeek.Thursday,
        ["cuma"] = DayOfWeek.Friday, ["cum"] = DayOfWeek.Friday, ["friday"] = DayOfWeek.Friday, ["fri"] = DayOfWeek.Friday,
        ["cumartesi"] = DayOfWeek.Saturday, ["cmt"] = DayOfWeek.Saturday, ["cts"] = DayOfWeek.Saturday, ["saturday"] = DayOfWeek.Saturday, ["sat"] = DayOfWeek.Saturday,
        ["pazar"] = DayOfWeek.Sunday, ["paz"] = DayOfWeek.Sunday, ["sunday"] = DayOfWeek.Sunday, ["sun"] = DayOfWeek.Sunday,
    };
    private static readonly Regex Range = new(@"(?<!\d)(\d{1,2})[:.](\d{2})\s*(?:-|–|—|/|ile)\s*(\d{1,2})[:.](\d{2})(?!\d)");
    private static readonly Regex Single = new(@"^\s*(\d{1,2})[:.](\d{2})\s*$");
    private static readonly Regex HourRange = new(@"^\s*(\d{1,2})\s*(?:-|–)\s*(\d{1,2})\s*$");
    private static readonly Regex Date = new(@"^\s*(\d{1,2})[./](\d{1,2})[./](\d{4})\s*$");

    // Hücre bir gün mü? "Pazartesi", "PZT", "Pazartesi 20.10" ya da "20.10.2026" (tarihin günü).
    public static DayOfWeek? DayOf(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        if (Date.Match(text) is { Success: true } d && DateTime.TryParseExact($"{d.Groups[1].Value.PadLeft(2, '0')}.{d.Groups[2].Value.PadLeft(2, '0')}.{d.Groups[3].Value}", "dd.MM.yyyy", Turkish, DateTimeStyles.None, out var date)) return date.DayOfWeek;
        // Gün adından sonra yalnızca tarih gelebilir ("Pazartesi 20.10"); "Pazar Araştırması" gibi ders adları gün sayılmaz.
        var m = Regex.Match(text.Trim().ToLower(Turkish), @"^([\p{L}]+)\.?(?:[\s,]+[\d./\s-]*)?$");
        return m.Success && Days.TryGetValue(m.Groups[1].Value, out var day) ? day : null;
    }
    // Hücre bir saat ya da saat aralığı mı? (başlangıç, bitiş?) dakika olarak.
    public static (int Start, int? End)? TimeOf(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        static int? M(string h, string m) => int.Parse(h) is var hh and <= 24 && int.Parse(m) is var mm and < 60 ? (hh % 24) * 60 + mm : null;
        if (Range.Match(text) is { Success: true } r && M(r.Groups[1].Value, r.Groups[2].Value) is { } s && M(r.Groups[3].Value, r.Groups[4].Value) is { } e) return (s, e == 0 ? 1440 : e);
        if (Single.Match(text) is { Success: true } one && M(one.Groups[1].Value, one.Groups[2].Value) is { } only) return (only, null);
        if (HourRange.Match(text) is { Success: true } h && int.Parse(h.Groups[1].Value) is var a and < 24 && int.Parse(h.Groups[2].Value) is var b and > 0 and <= 24 && b > a) return (a * 60, b * 60);
        return null;
    }
    private static bool Empty(string cell) => string.IsNullOrWhiteSpace(cell) || cell.Trim() is "-" or "–" or "—" or "x" or "X" or "boş" or "Boş" or "BOŞ" or "/";
    private static string Clean(string text) { var t = Regex.Replace(text, @"\s+", " ").Trim(); return t.Length > 200 ? t[..200] : t; }

    public static ScheduleParse Parse(IEnumerable<ScheduleTable> tables)
    {
        var entries = new List<ScheduleEntry>(); var notes = new List<string>();
        foreach (var table in tables) {
            var rows = table.Rows.Where(r => r.Any(c => !string.IsNullOrWhiteSpace(c))).ToList();
            var found = Grid(rows) ?? Transposed(rows) ?? List(rows);
            entries.AddRange(found);
        }
        var merged = Merge(entries);
        if (merged.Count == 0) notes.Add("Dosyada gün ve saat içeren bir program bulunamadı. Satırları elle ekleyebilirsin.");
        if (merged.Any(e => e.End <= e.Start)) notes.Add("Bazı satırların bitiş saati yok ya da başlangıçtan önce; kontrol et.");
        return new(merged, notes);
    }

    // 1) Günler sütun başlığında.
    private static List<ScheduleEntry>? Grid(List<List<string>> rows)
    {
        var header = rows.FindIndex(r => r.Count(c => DayOf(c) != null) >= 3);
        if (header < 0) return null;
        var columns = rows[header].Select((c, i) => (Day: DayOf(c), i)).Where(x => x.Day != null).ToDictionary(x => x.i, x => x.Day!.Value);
        var slots = new List<(int Start, int? End, List<string> Row)>();
        foreach (var row in rows.Skip(header + 1)) {
            var time = row.Select((c, i) => (T: columns.ContainsKey(i) ? null : TimeOf(c), i)).FirstOrDefault(x => x.T != null).T;
            if (time is { } t) slots.Add((t.Start, t.End, row));
        }
        return Cells(slots, (row, add) => { foreach (var (i, day) in columns) if (i < row.Count && !Empty(row[i]) && TimeOf(row[i]) == null) add(day, row[i]); });
    }
    // 2) Saatler sütun başlığında, günler satır başında.
    private static List<ScheduleEntry>? Transposed(List<List<string>> rows)
    {
        var header = rows.FindIndex(r => r.Count(c => TimeOf(c) != null) >= 3);
        if (header < 0) return null;
        var times = rows[header].Select((c, i) => (T: TimeOf(c), i)).Where(x => x.T != null).Select(x => (x.i, x.T!.Value)).ToList();
        var result = new List<ScheduleEntry>();
        foreach (var row in rows.Skip(header + 1)) {
            if (row.Select(DayOf).FirstOrDefault(d => d != null) is not { } day) continue;
            var slots = times.Select((t, n) => (t.Value.Start, End: t.Value.End ?? (n + 1 < times.Count ? times[n + 1].Value.Start : (int?)null), Text: t.i < row.Count ? row[t.i] : "")).ToList();
            foreach (var s in slots) if (!Empty(s.Text) && DayOf(s.Text) == null) result.Add(new(day, s.Start, s.End ?? s.Start + Typical(times.Select(t => t.Value)), Clean(s.Text)));
        }
        return result.Count > 0 ? result : null;
    }
    // 3) Satır satır: gün + saat (+ bitiş) + ad.
    private static List<ScheduleEntry> List(List<List<string>> rows)
    {
        var result = new List<ScheduleEntry>();
        foreach (var row in rows) {
            var dayIndex = row.FindIndex(c => DayOf(c) != null);
            if (dayIndex < 0) continue;
            var times = row.Select((c, i) => (T: i == dayIndex ? null : TimeOf(c), i)).Where(x => x.T != null).ToList();
            if (times.Count == 0) continue;
            var start = times[0].T!.Value.Start; var end = times[0].T!.Value.End ?? (times.Count > 1 ? times[1].T!.Value.Start : start + 60);
            var used = times.Select(t => t.i).Append(dayIndex).ToHashSet();
            var title = string.Join(" · ", row.Where((c, i) => !used.Contains(i) && !Empty(c) && DayOf(c) == null && TimeOf(c) == null).Select(Clean));
            result.Add(new(DayOf(row[dayIndex])!.Value, start, end, title.Length > 0 ? title : "Program"));
        }
        return result;
    }
    // Izgara satırlarından kayıtlar: bitiş saati yoksa bir sonraki satırın başlangıcıdır.
    private static List<ScheduleEntry> Cells(List<(int Start, int? End, List<string> Row)> slots, Action<List<string>, Action<DayOfWeek, string>> each)
    {
        var result = new List<ScheduleEntry>(); var typical = Typical(slots.Select(s => (s.Start, s.End)));
        for (var n = 0; n < slots.Count; n++) {
            var (start, end, row) = slots[n];
            var finish = end ?? (n + 1 < slots.Count && slots[n + 1].Start > start ? slots[n + 1].Start : start + typical);
            each(row, (day, text) => result.Add(new(day, start, finish, Clean(text))));
        }
        return result;
    }
    // Bitişi bilinen satırların süresinden tahmin (yoksa 50 dk, okullardaki ders süresi).
    private static int Typical(IEnumerable<(int Start, int? End)> slots)
    {
        var lengths = slots.Where(s => s.End > s.Start).Select(s => s.End!.Value - s.Start).OrderBy(x => x).ToList();
        return lengths.Count > 0 ? lengths[lengths.Count / 2] : 50;
    }
    // Aynı gün, aynı ad, arka arkaya (en fazla 15 dk teneffüsle) → tek kayıt.
    private static List<ScheduleEntry> Merge(List<ScheduleEntry> entries)
    {
        var result = new List<ScheduleEntry>();
        foreach (var e in entries.Distinct().OrderBy(e => ((int)e.Day + 6) % 7).ThenBy(e => e.Start).ThenBy(e => e.Title)) {
            var i = result.FindLastIndex(r => r.Day == e.Day && string.Equals(r.Title, e.Title, StringComparison.CurrentCultureIgnoreCase));
            if (i >= 0 && e.Start >= result[i].Start && e.Start - result[i].End is >= 0 and <= 15) result[i] = result[i] with { End = Math.Max(result[i].End, e.End) };
            else if (i >= 0 && e.Start >= result[i].Start && e.Start < result[i].End) result[i] = result[i] with { End = Math.Max(result[i].End, e.End) };
            else result.Add(e);
        }
        return result;
    }
}
