using System.Text.RegularExpressions;
namespace KisiselAsistan;

public static class SpeechVocabulary
{
    public static string BuildPrompt(string language, IEnumerable<string>? names = null) {
        // Whisper's initial prompt is transcript context, not an instruction to an LLM.
        var prefix = language == "tr"
            ? "Steam'de Hades ara. Spotify'dan Tame Impala çal. Hollow Knight, Counter-Strike 2. Hatırlatıcı, saniye, dakika, saat, duraklat. "
            : "Steam search Hades. Spotify play Tame Impala. Hollow Knight, Counter-Strike 2. Reminder, seconds, minutes, hours, pause. ";
        var selected = new List<string>(); var length = prefix.Length;
        foreach (var name in (names ?? []).Take(100)) {
            var clean = Regex.Replace(name ?? "", @"[^\p{L}\p{N}\s'’:&.\-]", " "); clean = Regex.Replace(clean, @"\s+", " ").Trim();
            if (clean.Length < 2 || clean.Length > 70 || selected.Contains(clean, StringComparer.OrdinalIgnoreCase)) continue;
            if (length + clean.Length + 2 > 480) continue;
            selected.Add(clean); length += clean.Length + 2; if (selected.Count == 12) break;
        }
        return prefix + string.Join(", ", selected);
    }
    internal static void Verify() {
        var prompt = BuildPrompt("tr", ["Red Dead Redemption 2", "Tame Impala", "Red Dead Redemption 2", "Baldur's Gate 3"]);
        if (!prompt.Contains("Red Dead Redemption 2") || !prompt.Contains("Baldur's Gate 3") || prompt.Split("Red Dead Redemption 2").Length != 2) throw new Exception("İngilizce ad bağlamı korunmadı.");
        if (BuildPrompt("tr", Enumerable.Range(0, 1000).Select(i => "Game Title " + i)).Length > 480) throw new Exception("Ses bağlamı gereksiz büyüdü.");
        if (!BuildPrompt("en").Contains("Steam search")) throw new Exception("İngilizce bağlam bozuldu.");
    }
}
