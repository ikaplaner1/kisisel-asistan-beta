import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const arch=process.argv.includes('--x64')?'x64':'arm64';
const root=path.resolve('distribution',arch);
const report=path.resolve('verification',arch);
fs.mkdirSync(report,{recursive:true});
function run(cmd,args,env={}){
 const r=spawnSync(cmd,args,{encoding:'utf8',timeout:90000,env:{...process.env,...env}});
 process.stdout.write(r.stdout||'');process.stderr.write(r.stderr||'');
 if(r.error)throw r.error;
 if(r.status!==0)throw new Error(`${cmd} failed: ${r.status}`);
 return r.stdout;
}
const packages=fs.readdirSync(root).filter(n=>/\.(zip|dmg)$/.test(n));
if(packages.length!==2)throw new Error('Expected one DMG and one ZIP');
for(const name of packages){
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'assistant-package-'));
 const mount=path.join(temp,'mounted');
 const dest=path.join(temp,'extracted');fs.mkdirSync(dest);
 const isDmg=name.endsWith('.dmg');
 try{
  if(isDmg){fs.mkdirSync(mount);run('/usr/bin/hdiutil',['attach',path.join(root,name),'-readonly','-nobrowse','-mountpoint',mount]);}
  else run('/usr/bin/ditto',['-x','-k',path.join(root,name),dest]);
  if(isDmg){const bundle=fs.readdirSync(mount).find(n=>n.endsWith('.app'));if(!bundle)throw new Error('DMG has no app');run('/usr/bin/ditto',[path.join(mount,bundle),path.join(dest,bundle)]);}
  const bundle=fs.readdirSync(dest).find(n=>n.endsWith('.app'));if(!bundle)throw new Error('Archive has no app');
  const app=path.join(dest,bundle);
  run('/usr/bin/codesign',['--verify','--deep','--strict','--verbose=2',app]);
  run('/usr/bin/codesign',['--verify','--strict','--verbose=2',path.join(app,'Contents/Resources/host/Assistant.Host')]);
  const executable=path.join(app,'Contents/MacOS/Kişisel Asistan Beta');
  const result=path.join(report,name+'.json');
  // Hosted Intel Mac runners have no usable GPU. Keep this switch in the test
  // command only; normal launches continue to use hardware acceleration.
  run(executable,['--smoke-test','--disable-gpu'],{CI:'true',ASSISTANT_SMOKE_RESULT:result});
  const data=JSON.parse(fs.readFileSync(result,'utf8'));
  if(data.arch!==arch||data.version!==JSON.parse(fs.readFileSync('package.json','utf8')).version||!data.ui||!data.host)throw new Error('Unexpected startup result');
  console.log('VERIFIED '+name);
 }finally{if(isDmg && fs.existsSync(mount))run('/usr/bin/hdiutil',['detach',mount]);}
}
