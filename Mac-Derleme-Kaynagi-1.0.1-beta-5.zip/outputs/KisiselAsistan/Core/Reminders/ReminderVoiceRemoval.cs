using System.Text.RegularExpressions;
namespace KisiselAsistan;

internal static class ReminderVoiceRemoval
{
    internal static string Fold(string text) => Regex.Replace(text.ToLowerInvariant().Replace('ı','i').Replace('İ','i').Replace('ş','s').Replace('ç','c').Replace('ğ','g').Replace('ö','o').Replace('ü','u'), @"[^a-z0-9 ]", " ").Trim();
    internal static string? Parse(string text)
    {
        var value = Regex.Replace(Fold(text), @"\s+", " ");
        if (Regex.IsMatch(value, @"\b(?:silme|kaldirma|iptal etme|vazgec|dont|do not)\b")) return null;
        value = Regex.Replace(value, @"^(?:(?:lutfen|bana|benim icin)\s+)+|\s+lutfen$", "");
        value = Regex.Replace(value, @"\b(?:siler|silebilir|kaldirir|kaldirabilir) misin$", m => m.Value.StartsWith("sil") ? "sil" : "kaldir");
        value = Regex.Replace(value, @"\b(?:silsene|silsana)$", "sil");
        var match = Regex.Match(value, @"^(.*?)\s*\b(?:sil|kaldir|iptal et)$");
        if (!match.Success) match = Regex.Match(value, @"^(?:sil|kaldir|iptal et)\s+(.+)$");
        if (!match.Success) return null;
        var target = match.Groups[1].Value.Trim();
        if (!Regex.IsMatch(target, @"\b(?:hatirlatici\w*|hatirlatma\w*|plan\w*)\b")) return null;
        target = Regex.Replace(target, @"\b(?:hatirlatici\w*|hatirlatma\w*|plan(?:i|ini|imi|im|larimi|lari)?)\b", "");
        target = Regex.Replace(target, @"\b(?:adli|isimli|olan|numarali|numara)\b", "");
        return Regex.Replace(target, @"\s+", " ").Trim();
    }
    private static string NameKey(string text) => Regex.Replace(Fold(text), @"(me|ma)(?:yi|mi|ni)$", "$1");
    internal static string Execute(string target, IReminderService service, IReadOnlyList<Reminder> visible, Guid? selected)
        => Apply(target, service, visible, selected, r => { service.Remove(r.Id); return "Silindi: " + r.Text; });
    internal static string Apply(string target, IReminderService service, IReadOnlyList<Reminder> visible, Guid? selected, Func<Reminder, string> action)
    {
        var (found, error) = Resolve(target, service.Items, visible, selected, DateTime.Now);
        return found is null ? error! : action(found);
    }
    // Söylenen hedefi tek bir hatırlatıcıya çözer: "seçili", sıra numarası ("ikinci", "2"), tarih/saat ("15 ekim saat 7deki") ya da ad.
    // Tekrarlı bir serinin günleri aynı adı taşır; ada göre aramada her seriden yalnızca sıradaki gün aday olur.
    internal static (Reminder? Found, string? Error) Resolve(string target, IReadOnlyList<Reminder> all, IReadOnlyList<Reminder> visible, Guid? selected, DateTime now)
    {
        target = Fold(target);
        if (target is "hepsini" or "tum" or "butun" or "tumunu") return (null, "Toplu işlem uygulanmadı. Planın adını veya listedeki numarasını söyle.");
        if (target is "secili" or "secileni" or "bu" or "bunu") {
            var chosen = all.FirstOrDefault(r => r.Id == selected);
            return chosen is null ? (null, "Seçili bir hatırlatıcı yok. Planın adını veya listedeki numarasını söyle.") : (chosen, null);
        }
        var number = target switch { "ilk" or "birinci" => "1", "ikinci" => "2", "ucuncu" => "3", "dorduncu" => "4", "besinci" => "5", "uc" => "3", "dort" => "4", "bes" => "5", "alti" => "6", _ => target };
        if (CommandParser.Number(number) is var index && index > 0) {
            if (index > visible.Count) return (null, "Bu numarada görünür bir hatırlatıcı yok. Hatırlatıcıları göster deyip listedeki numarayı söyle.");
            var listed = all.FirstOrDefault(r => r.Id == visible[index - 1].Id);
            return listed is null ? (null, "Hatırlatıcı artık mevcut değil. Listeyi tekrar kontrol et.") : (listed, null);
        }
        var byTime = ReminderTimeTarget.TryFind(target, all, now, out var matches, out var timeError);
        if (timeError is not null) return (null, timeError);
        if (!byTime) {
            matches = target.Length == 0 ? all.ToArray() : all.Where(r => NameKey(r.Text) == NameKey(target)).ToArray();
            if (matches.Length == 0 && target.Length > 0) matches = all.Where(r => (" " + NameKey(r.Text) + " ").Contains(" " + NameKey(target) + " ", StringComparison.Ordinal)).ToArray();
            if (target.Length > 0) matches = matches.GroupBy(r => r.Plan?.Weekly?.SeriesId is { } series && series != Guid.Empty ? series : r.Id)
                .Select(g => g.Where(r => !r.Done).OrderBy(r => r.Due).FirstOrDefault() ?? g.OrderBy(r => r.Due).First()).ToArray();
        }
        if (matches.Length > 1) return (null, "Birden fazla hatırlatıcı eşleşti: " + string.Join("; ", matches.Take(4).Select(r => r.Text + " (" + r.Due.LocalDateTime.ToString("dd.MM HH:mm") + ")")) + ". Hatırlatıcıları göster deyip listedeki numarasını söyle.");
        if (matches.Length == 0) return (null, byTime ? "Bu tarih ve saatte hatırlatıcı bulamadım. Tarihi ve saati kontrol et." : "Bu isimde bir hatırlatıcı bulamadım. Planın adını veya listedeki numarasını söyle.");
        return (matches[0], null);
    }
}
