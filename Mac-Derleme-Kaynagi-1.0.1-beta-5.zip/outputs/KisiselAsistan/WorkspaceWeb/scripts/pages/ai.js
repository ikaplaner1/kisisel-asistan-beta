"use strict";
// AI sohbetleri: üç sitenin yerel tarayıcıları bu sayfadaki yuvalara (.ai-slot) yerleşir (scheduleSlots).
// Başlık yok; ortak soru ve düğmeler tek ince şeritte, sohbet pencereleri sayfanın geri kalanını kaplar.

function AiPage() {
  const single = compact() || state.aiSingle;
  return html`
    <div class="ai-bar">
      <div class="ai-targets" role="group" aria-label="Kimlere sorulsun">${names.map((n, i) => html`<label key=${n}><input type="checkbox" data-ai-target=${i} checked=${state.targets[i]} />${n}</label>`)}</div>
      <textarea id="ai-question" rows="1" aria-label="Ortak AI sorusu" placeholder="Seçtiklerine birden sor… (Enter gönderir, Tab yeni satır)" value=${state.aiQuestion}></textarea>
      <div class="ai-actions">
        ${single && html`<div class="date-nav"><${Button} action="ai-prev" icon="left" cls="arrow" aria-label="Önceki AI" /><span class="date">${names[state.aiProvider]}</span><${Button} action="ai-next" icon="right" cls="arrow" aria-label="Sonraki AI" /></div>`}
        ${compact() && html`<${Button} action="ai-external" icon="external" cls="icon-button" data-index=${state.aiProvider} aria-label="Tarayıcıda aç" />`}
        <${Button} action="ai-new" icon="plus" cls="icon-button" aria-label="Yeni sohbet başlat" title="Yeni sohbet" />
        <${Button} action="ai-refresh" icon="refresh" cls="icon-button" aria-label="Tümünü yenile" title="Tümünü yenile" />
        ${!compact() && html`<${Button} action="ai-view" cls="ghost">${state.aiSingle ? "Üçlü görünüm" : "Tekli görünüm"}<//>`}
      </div>
    </div>
    <div class=${"ai-grid" + (single ? " single" : "")}>${names.map((n, i) => html`<section class="card ai-card" key=${n} hidden=${single && i !== state.aiProvider}>
      <header class="ai-card-head"><span>${n}</span>
        <${Button} action="ai-one-reload" icon="refresh" cls="icon-button" data-index=${i} aria-label=${n + " yenile"} />
        <${Button} action="ai-external" icon="external" cls="icon-button" data-index=${i} aria-label=${n + " tarayıcıda aç"} />
      </header>
      <div class="ai-slot" data-provider=${i}>Sohbet hazırlanıyor…</div>
    </section>`)}</div>`;
}
pageComponents.ai = AiPage;
