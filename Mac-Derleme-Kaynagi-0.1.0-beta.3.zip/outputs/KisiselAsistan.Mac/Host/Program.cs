using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using KisiselAsistan;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { Converters = { new JsonStringEnumConverter() } };
if (args.Contains("--self-test")) {
    var path = Path.Combine(Environment.CurrentDirectory, "work", "assistant-mac-test-" + Guid.NewGuid().ToString("N"));
    Directory.CreateDirectory(path);
    var test = new ReminderService(new ReminderStore(Path.Combine(path, "reminders.json"), false));
    test.Add("Test", DateTimeOffset.Now.AddMinutes(5), plan: new(DurationMinutes: 45));
    if (test.Items.Count != 1 || test.Items[0].Plan?.DurationMinutes != 45) throw new Exception("Ortak hatırlatıcı servisi çalışmadı.");
    test.RequestCompletion(test.Items[0].Id);
    if (!test.Items[0].Done) throw new Exception("Tamamlama kaydedilmedi.");
    var registry = new OperationRegistry(); _ = new OperationReminderService(test, registry);
    if ((await registry.ExecuteAsync("unknown", JsonSerializer.SerializeToElement(new { }))).Success) throw new Exception("Bilinmeyen işlem kabul edildi.");
    if (ChatSendScript.Build("gemini", "test").Length < 100) throw new Exception("Ortak sohbet gönderimi eksik.");
    var oldKey = Environment.GetEnvironmentVariable("ASSISTANT_ACCOUNT_KEY");
    try {
        Environment.SetEnvironmentVariable("ASSISTANT_ACCOUNT_KEY", Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(32)));
        var plain = System.Text.Encoding.UTF8.GetBytes("fixture-account");
        var encrypted = WindowsSecret.PortableTransform(plain, true);
        if (!WindowsSecret.PortableTransform(encrypted, false).SequenceEqual(plain)) throw new Exception("Mac hesap koruması çözülemedi.");
        encrypted[^1] ^= 1;
        try { WindowsSecret.PortableTransform(encrypted, false); throw new Exception("Değiştirilmiş hesap dosyası kabul edildi."); } catch (System.Security.Cryptography.CryptographicException) { }
    } finally { Environment.SetEnvironmentVariable("ASSISTANT_ACCOUNT_KEY", oldKey); }
    Console.WriteLine("Mac host: ortak kayıt, hatırlatıcı, işlem sınırı ve sohbet betiği kontrolleri geçti."); return;
}
var home = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KisiselAsistan");
Directory.CreateDirectory(home);
var defaults = new ReminderDefaults();
var reminders = new ReminderService(new ReminderStore(Path.Combine(home, "reminders.json")), defaultOptions: () => defaults.Options);
var operations = new OperationRegistry(); _ = new OperationReminderService(reminders, operations);
using var catalog = new SteamClient(); var steam = new SteamService(catalog, new SteamWatchStore(Path.Combine(home, "steam-watches.json"))); steam.Register(operations);
using var spotifyAccount = new SpotifyAccount();
using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(90) };
var spotify = new SpotifyService(new SpotifyController(new MacSpotifyTransport()), new SpotifyPlayback(spotifyAccount, http)); spotify.Register(operations);
using var google = new GoogleCalendarConnection(reminders);
var github = new GithubBetaAccount();
var ollamaStore = new JsonListStore<OllamaSettings>(Path.Combine(home, "ollama-settings.json"));
OllamaSettings OllamaSettings() => ollamaStore.Read().FirstOrDefault() ?? new();
var ollama = new OllamaInterpreter(http, operations, OllamaSettings);
var core = new AssistantCore(); core.Register(new ReminderCapability(reminders)); core.Register(new SpotifyCapability(new(new MacSpotifyTransport()), operations));
var promptIds = new Dictionary<string, ReminderPrompt>();
var notices = new Queue<string>(); steam.Released += notices.Enqueue; steam.Updated += notices.Enqueue;
var nextSteam = DateTimeOffset.MinValue;
async Task<object?> Command(JsonElement p, CancellationToken token) {
    var raw = p.GetProperty("text").GetString() ?? ""; var context = p.TryGetProperty("context", out var c) ? c.GetString() ?? "" : "";
    var normalized = NaturalCommands.Normalize(raw, context);
    var match = Regex.Match(normalized, @"^steam\s+(ara|takip et)\s+(.+)$", RegexOptions.IgnoreCase);
    if (match.Success) return await operations.ExecuteAsync(match.Groups[1].Value == "ara" ? "steam.search" : "steam.trackNamed", JsonSerializer.SerializeToElement(new { query = match.Groups[2].Value }), token);
    match = Regex.Match(normalized, SpotifyPlayback.SongCommandPattern, RegexOptions.IgnoreCase);
    if (match.Success) return await operations.ExecuteAsync("spotify.searchAndPlay", JsonSerializer.SerializeToElement(new { query = match.Groups[1].Value }), token);
    var result = core.Execute(normalized); if (result.Success || !OllamaSettings().Enabled) return result;
    var proposal = await ollama.ProposeAsync(raw, context, JsonSerializer.Serialize(new { reminders = reminders.Items, steam = steam.Items }), token);
    if (proposal.Operation is "reminder.remove" or "reminder.clearCompleted" or "steam.unwatch") return new CommandResult(false, "Silme işlemini ilgili bölümde kendin onayla.");
    return await ollama.ExecuteAsync(proposal, token);
}
async Task<object?> Dispatch(string method, JsonElement p, CancellationToken token) {
    switch (method) {
        case "github.connect": {
            var settings = new BetaReleaseSettings(p.GetProperty("repositoryUrl").GetString()!, p.GetProperty("githubClientId").GetString()!); settings.Save();
            await github.ConnectAsync(settings.GithubClientId, code => Console.WriteLine(JsonSerializer.Serialize(new { @event = "github.code", code })), token); return github.Session!.Login;
        }
        case "github.settings": return BetaReleaseSettings.Load();
        case "github.token": { var settings = BetaReleaseSettings.Load(); if (!github.Connected(settings.GithubClientId)) throw new InvalidOperationException("Önce GitHub hesabını bağla."); return new { token = github.Session!.AccessToken, settings.RepositoryUrl }; }
        case "github.disconnect": github.Disconnect(); return true;
        case "state": return new { reminders = reminders.Items, steam = steam.Items, defaults = defaults.Options, preferences = PlanningPreferenceStore.Load(), spotify = new { spotifyAccount.Connected, spotifyAccount.ClientId }, google = new { google.Account.Connected, google.Account.Configured, google.Status }, ollama = OllamaSettings() };
        case "operation": return await operations.ExecuteAsync(p.GetProperty("name").GetString()!, p.GetProperty("parameters"), token);
        case "command": return await Command(p, token);
        case "tick": {
            foreach (var prompt in reminders.Poll()) promptIds[Guid.NewGuid().ToString("N")] = prompt;
            foreach (var key in promptIds.Where(x => !reminders.IsCurrent(x.Value)).Select(x => x.Key).ToArray()) promptIds.Remove(key);
            await google.TickAsync();
            if (DateTimeOffset.Now >= nextSteam) { nextSteam = DateTimeOffset.Now.AddMinutes(30); await steam.CheckAsync(token); }
            var events = notices.ToArray(); notices.Clear();
            return new { prompts = promptIds.Select(x => new { id = x.Key, prompt = x.Value }).ToArray(), notices = events };
        }
        case "reminder.respond": {
            var id = p.GetProperty("id").GetString()!;
            if (!promptIds.Remove(id, out var prompt)) return null;
            var next = reminders.Respond(prompt, Enum.Parse<ReminderResponse>(p.GetProperty("response").GetString()!), p.TryGetProperty("minutes", out var minutes) ? minutes.GetInt32() : 5);
            if (next is not null) { var key = Guid.NewGuid().ToString("N"); promptIds[key] = next; return new { id = key, prompt = next }; } return null;
        }
        case "reminder.complete": {
            var prompt = reminders.RequestCompletion(p.GetProperty("id").GetGuid());
            if (prompt is null) return null; var key = Guid.NewGuid().ToString("N"); promptIds[key] = prompt; return new { id = key, prompt };
        }
        case "defaults": defaults.Set(p.Deserialize<ReminderOptions>(json)!); return true;
        case "preferences": PlanningPreferenceStore.Save(p.Deserialize<PlanningPreferences>(json)!); return true;
        case "spotify.connect": await spotifyAccount.ConnectAsync(p.GetProperty("clientId").GetString()!, token); return true;
        case "spotify.disconnect": await spotifyAccount.DisconnectAsync(token); return true;
        case "google.import": google.ImportCredentials(p.GetProperty("json").GetString()!); return true;
        case "google.connect": await google.ConnectAsync(token); return google.Status;
        case "google.sync": return await google.SyncNowAsync(token);
        case "google.disconnect": await google.DisconnectAsync(token); return true;
        case "ollama.models": return await ollama.ModelsAsync(token);
        case "ollama.save": { var setting = p.Deserialize<OllamaSettings>(json)!; if (setting.Enabled && !OllamaInterpreter.IsLocalModel(setting.Model)) throw new ArgumentException("Yerel model seç."); ollamaStore.Modify(_ => [setting]); return true; }
        case "speech": {
            var samples = p.GetProperty("samples").Deserialize<float[]>()!;
            if (samples.Length is < 4000 or > 16000 * 60 || samples.Any(x => !float.IsFinite(x))) throw new ArgumentException("Ses kaydı 0,25–60 saniye olmalı.");
            var whisper = new WhisperSpeechToText(Path.Combine(home, "Models", "ggml-small-q5_1.bin"));
            return await whisper.TranscribeAsync(new(samples), new(p.GetProperty("language").GetString()!), token);
        }
        case "chat.script": return ChatSendScript.Build(p.GetProperty("provider").GetString()!, p.GetProperty("text").GetString()!, p.GetProperty("mode").GetString()!);
        default: throw new ArgumentException("Desteklenmeyen işlem.");
    }
}
// Only the parent desktop process has this stdin/stdout pipe; no localhost API is exposed.
while (await Console.In.ReadLineAsync() is { } line) {
    string? id = null;
    try {
        using var request = JsonDocument.Parse(line); id = request.RootElement.GetProperty("id").GetString();
        using var timeout = new CancellationTokenSource(TimeSpan.FromMinutes(4));
        var result = await Dispatch(request.RootElement.GetProperty("method").GetString()!, request.RootElement.GetProperty("params"), timeout.Token);
        Console.WriteLine(JsonSerializer.Serialize(new { id, success = true, result }, json));
    } catch (Exception e) { Console.WriteLine(JsonSerializer.Serialize(new { id, success = false, error = e is OperationCanceledException ? "İşlem zaman aşımına uğradı." : e.Message }, json)); }
}

sealed class MacSpotifyTransport : ISpotifyTransport
{
    public SpotifyState Inspect() { var installed = Directory.Exists("/Applications/Spotify.app") || Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Applications/Spotify.app")); return new(Process.GetProcessesByName("Spotify").Length > 0, installed, null, "Spotify masaüstü"); }
    public void OpenUri(string uri) { if (!uri.StartsWith("spotify:", StringComparison.Ordinal)) throw new ArgumentException("Geçersiz Spotify adresi."); using var process = Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true }); }
    public void SendMediaCommand(int command) {
        var action = command switch { 14 => "playpause", 11 => "next track", 12 => "previous track", 47 => "pause", 46 => "play", _ => throw new ArgumentException("Geçersiz oynatma işlemi.") };
        var start = new ProcessStartInfo("/usr/bin/osascript") { UseShellExecute = false, RedirectStandardError = true };
        start.ArgumentList.Add("-e"); start.ArgumentList.Add("tell application \"Spotify\" to " + action);
        using var process = Process.Start(start)!; if (!process.WaitForExit(5000)) throw new InvalidOperationException("Spotify yanıt vermedi.");
        if (process.ExitCode != 0) throw new InvalidOperationException("Sistem Ayarları → Gizlilik ve Güvenlik → Otomasyon bölümünden Spotify kontrol iznini ver.");
    }
}
