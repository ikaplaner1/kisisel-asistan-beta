using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using UglyToad.PdfPig;

namespace KisiselAsistan;

// Ders programı / iş saati dosyasını satır-sütun tablolarına çevirir (Excel .xlsx, .csv, metin içeren PDF).
// Tabloyu anlamlandırmak ScheduleParser'ın işidir; bu sınıf yalnızca hücreleri çıkarır.
public sealed record ScheduleTable(string Source, List<List<string>> Rows);

public static class ScheduleReader
{
    public const int MaxBytes = 20 * 1024 * 1024;
    public static readonly string[] Extensions = [".xlsx", ".csv", ".pdf"];

    public static List<ScheduleTable> Read(string fileName, byte[] data)
    {
        if (data.Length == 0) throw new ArgumentException("Dosya boş.");
        if (data.Length > MaxBytes) throw new ArgumentException("Dosya çok büyük (en fazla 20 MB).");
        return Path.GetExtension(fileName).ToLowerInvariant() switch {
            ".xlsx" => Xlsx(data),
            ".csv" or ".txt" => [Csv(data)],
            ".pdf" => Pdf(data),
            ".xls" => throw new ArgumentException("Eski Excel biçimi (.xls) okunamıyor. Excel'de \"Farklı kaydet → Excel Çalışma Kitabı (.xlsx)\" ile kaydedip tekrar dene."),
            _ => throw new ArgumentException("Bu dosya türü desteklenmiyor. Excel (.xlsx), CSV ya da PDF seç.")
        };
    }

    // ---------------------------------------------------------------- Excel (.xlsx = XML dosyalarından oluşan ZIP)
    private static List<ScheduleTable> Xlsx(byte[] data)
    {
        try {
            using var zip = new ZipArchive(new MemoryStream(data), ZipArchiveMode.Read);
            XDocument? Load(string path) { var entry = zip.GetEntry(path); if (entry is null) return null; using var s = entry.Open(); return XDocument.Load(s); }
            static IEnumerable<XElement> All(XContainer? x, string name) => x?.Descendants().Where(e => e.Name.LocalName == name) ?? [];
            var shared = All(Load("xl/sharedStrings.xml"), "si").Select(si => string.Concat(All(si, "t").Select(t => t.Value))).ToList();
            var relations = All(Load("xl/_rels/workbook.xml.rels"), "Relationship").ToDictionary(r => (string)r.Attribute("Id")!, r => (string)r.Attribute("Target")!);
            var tables = new List<ScheduleTable>();
            foreach (var sheet in All(Load("xl/workbook.xml"), "sheet")) {
                var id = sheet.Attributes().FirstOrDefault(a => a.Name.LocalName == "id")?.Value;
                if (id is null || !relations.TryGetValue(id, out var target)) continue;
                var path = target.StartsWith('/') ? target.TrimStart('/') : "xl/" + target;
                var doc = Load(path); if (doc is null) continue;
                var cells = new Dictionary<(int Row, int Col), string>();
                foreach (var c in All(doc, "c")) {
                    if ((string?)c.Attribute("r") is not { } reference || Position(reference) is not { } pos) continue;
                    var type = (string?)c.Attribute("t"); var v = All(c, "v").FirstOrDefault()?.Value;
                    var text = type switch {
                        "s" when int.TryParse(v, out var i) && i < shared.Count => shared[i],
                        "inlineStr" => string.Concat(All(c, "t").Select(t => t.Value)),
                        "str" or "b" or "e" => v ?? "",
                        _ => Number(v)
                    };
                    if (!string.IsNullOrWhiteSpace(text)) cells[pos] = text.Trim();
                }
                // Birleştirilmiş hücreler (ör. iki saate yayılan ders): değer kapladığı her hücreye yazılır.
                foreach (var merge in All(doc, "mergeCell")) {
                    var parts = ((string?)merge.Attribute("ref") ?? "").Split(':');
                    if (parts.Length != 2 || Position(parts[0]) is not { } a || Position(parts[1]) is not { } b || !cells.TryGetValue(a, out var value)) continue;
                    if ((b.Row - a.Row + 1) * (b.Col - a.Col + 1) > 5000) continue;
                    for (var r = a.Row; r <= b.Row; r++) for (var col = a.Col; col <= b.Col; col++) cells.TryAdd((r, col), value);
                }
                if (cells.Count == 0) continue;
                int maxRow = cells.Keys.Max(k => k.Row), maxCol = Math.Min(cells.Keys.Max(k => k.Col), 60);
                var rows = new List<List<string>>();
                for (var r = 0; r <= Math.Min(maxRow, 2000); r++) rows.Add(Enumerable.Range(0, maxCol + 1).Select(col => cells.GetValueOrDefault((r, col), "")).ToList());
                tables.Add(new("Sayfa " + (string?)sheet.Attribute("name"), rows));
            }
            return tables;
        } catch (InvalidDataException) { throw new ArgumentException("Excel dosyası açılamadı; dosya bozuk ya da şifreli olabilir."); }
    }
    // "B12" → (11, 1)
    private static (int Row, int Col)? Position(string reference)
    {
        var m = Regex.Match(reference, @"^([A-Z]{1,3})(\d{1,7})$");
        if (!m.Success) return null;
        var col = m.Groups[1].Value.Aggregate(0, (n, ch) => n * 26 + (ch - 'A' + 1)) - 1;
        return (int.Parse(m.Groups[2].Value) - 1, col);
    }
    // Excel saati gün kesri olarak tutar (0,375 = 09:00); tarihleri 1900'den beri gün sayısı olarak.
    private static string Number(string? value)
    {
        if (!double.TryParse(value, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var n)) return value ?? "";
        if (n is > 0 and < 1) { var minutes = (int)Math.Round(n * 1440) % 1440; return $"{minutes / 60:00}:{minutes % 60:00}"; }
        if (n is >= 30000 and < 60000 && Math.Abs(n - Math.Round(n)) < 1e-9) return DateTime.FromOADate(n).ToString("dd.MM.yyyy");
        return value!;
    }

    // ---------------------------------------------------------------- CSV
    private static ScheduleTable Csv(byte[] data)
    {
        string text;
        try { text = new UTF8Encoding(false, true).GetString(data); }
        catch (DecoderFallbackException) {
            // Türkçe Windows'ta Excel'in kaydettiği CSV çoğunlukla Windows-1254'tür.
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            text = Encoding.GetEncoding(1254).GetString(data);
        }
        text = text.TrimStart('﻿');
        var first = text.Split('\n')[0];
        var separator = new[] { ';', '\t', ',' }.OrderByDescending(c => first.Count(x => x == c)).First();
        var rows = new List<List<string>>(); var row = new List<string>(); var cell = new StringBuilder(); var quoted = false;
        for (var i = 0; i < text.Length; i++) {
            var ch = text[i];
            if (quoted) {
                if (ch == '"' && i + 1 < text.Length && text[i + 1] == '"') { cell.Append('"'); i++; }
                else if (ch == '"') quoted = false;
                else cell.Append(ch);
            } else if (ch == '"') quoted = true;
            else if (ch == separator) { row.Add(cell.ToString().Trim()); cell.Clear(); }
            else if (ch == '\n') { row.Add(cell.ToString().Trim()); cell.Clear(); rows.Add(row); row = []; }
            else if (ch != '\r') cell.Append(ch);
        }
        if (cell.Length > 0 || row.Count > 0) { row.Add(cell.ToString().Trim()); rows.Add(row); }
        return new("CSV", rows);
    }

    // ---------------------------------------------------------------- PDF (yalnız metin içeren PDF; taranmış görüntü okunamaz)
    private sealed record Chunk(double Left, double Right, string Text) { public double Center => (Left + Right) / 2; }
    private static List<ScheduleTable> Pdf(byte[] data)
    {
        var tables = new List<ScheduleTable>(); var anyText = false;
        try {
            using var document = PdfDocument.Open(data);
            foreach (var page in document.GetPages()) {
                var words = page.GetWords().Where(w => !string.IsNullOrWhiteSpace(w.Text)).ToList();
                if (words.Count == 0) continue;
                anyText = true;
                // Aynı yükseklikteki kelimeler bir satır; satır içinde büyük boşluk yeni hücre.
                var lines = new List<List<UglyToad.PdfPig.Content.Word>>();
                foreach (var word in words.OrderByDescending(w => w.BoundingBox.Bottom)) {
                    var line = lines.LastOrDefault();
                    var height = Math.Max(1, word.BoundingBox.Height);
                    if (line != null && Math.Abs(line[0].BoundingBox.Bottom - word.BoundingBox.Bottom) < height * 0.5) line.Add(word); else lines.Add([word]);
                }
                var chunked = lines.Select(line => {
                    var ordered = line.OrderBy(w => w.BoundingBox.Left).ToList(); var chunks = new List<Chunk>();
                    foreach (var w in ordered) {
                        var last = chunks.LastOrDefault();
                        var gap = last is null ? double.MaxValue : w.BoundingBox.Left - last.Right;
                        if (last != null && gap < Math.Max(2, w.BoundingBox.Height * 0.9)) chunks[^1] = last with { Right = w.BoundingBox.Right, Text = last.Text + " " + w.Text };
                        else chunks.Add(new(w.BoundingBox.Left, w.BoundingBox.Right, w.Text));
                    }
                    return chunks;
                }).ToList();
                tables.Add(new("Sayfa " + page.Number, Align(chunked)));
            }
        } catch (Exception ex) when (ex is not ArgumentException) { throw new ArgumentException("PDF açılamadı; dosya bozuk ya da şifreli olabilir."); }
        if (!anyText) throw new ArgumentException("Bu PDF'te okunabilir metin yok; büyük olasılıkla taranmış bir görüntü. Programı Excel olarak bulabilirsen onu seç ya da derslerini elle ekle.");
        return tables;
    }
    // Başlık satırı (en az 3 gün adı ya da 3 saat) bulunursa sütunlar onun konumlarına hizalanır; altındaki satırlar
    // en yakın başlık sütununa yerleşir. Satır etiketi olmayan satırlar (hücrede ikinci satır, ör. derslik) üstteki satıra eklenir.
    private static List<List<string>> Align(List<List<Chunk>> lines)
    {
        var header = lines.FindIndex(l => l.Count(c => ScheduleParser.DayOf(c.Text) != null) >= 3 || l.Count(c => ScheduleParser.TimeOf(c.Text) != null) >= 3);
        if (header < 0) return lines.Select(l => l.Select(c => c.Text).ToList()).ToList();
        var anchors = lines[header].Where(c => ScheduleParser.DayOf(c.Text) != null || ScheduleParser.TimeOf(c.Text) != null).ToList();
        var firstAnchor = anchors.Min(a => a.Left);
        var rows = lines.Take(header).Select(l => l.Select(c => c.Text).ToList()).ToList();
        rows.Add(["", .. anchors.Select(a => a.Text)]);
        List<string>? previous = null;
        foreach (var line in lines.Skip(header + 1)) {
            var row = Enumerable.Repeat("", anchors.Count + 1).ToList();
            foreach (var chunk in line) {
                var index = chunk.Right < firstAnchor - 2 ? 0 : 1 + anchors.Select((a, i) => (Distance: Math.Abs(a.Center - chunk.Center), i)).MinBy(x => x.Distance).i;
                row[index] = (row[index] + " " + chunk.Text).Trim();
            }
            if (row[0].Length == 0 && previous != null) {
                for (var i = 1; i < row.Count; i++) if (row[i].Length > 0) previous[i] = (previous[i] + " " + row[i]).Trim();
                continue;
            }
            rows.Add(row); previous = row;
        }
        return rows;
    }
}
