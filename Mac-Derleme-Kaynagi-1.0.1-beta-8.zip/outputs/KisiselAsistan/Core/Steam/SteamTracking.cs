using System.Text.Json;
using System.Text.RegularExpressions;

namespace KisiselAsistan;

// Fiyat kuruş cinsinden (Steam Türkiye fiyatları USD). Initial > Final ise indirim var; ikisi de 0 ise ücretsiz.
public record SteamPrice(string Currency, int Initial, int Final)
{
    public int Discount => Initial > Final && Initial > 0 ? (int)Math.Round(100.0 * (Initial - Final) / Initial) : 0;
    public bool Free => Initial == 0 && Final == 0;
}
public record SteamGame(int Id, string Name, bool ComingSoon, string ReleaseDate, bool EarlyAccess, string? CoverUrl = null, SteamPrice? Price = null);
public record SteamWatch(int Id, string Name, bool ComingSoon, string ReleaseDate, bool EarlyAccess,
    DateTimeOffset? CheckedAt, string? Error = null, string? CoverUrl = null, string[]? SeenUpdates = null, string? LatestUpdate = null, SteamPrice? Price = null, string[]? SeenMajorUpdates = null, SteamPricePoint[]? PriceHistory = null, int? TargetPrice = null)
{
    // Uygulamanın gördüğü en düşük fiyat (kontroller 30 dakikada bir; Steam'in tüm geçmişi değil).
    public int? LowestPrice => PriceHistory is { Length: > 0 } h ? h.Min(p => p.Final) : null;
    // Hedef fiyat (kuruş, oyunun para biriminde): fiyat buna ya da altına inince bildirilir. Yoksa null.
    public bool AtTarget => TargetPrice is { } target && Price is { Free: false } p && p.Final <= target;
}
// Fiyat geçmişinin bir noktası: yalnız fiyat değiştiğinde eklenir (en fazla 200 nokta).
public record SteamPricePoint(DateOnly Day, int Final);
// SeenUpdates: eski (21 Ekim 2026 öncesi) bütün duyuruların kimlikleri; artık kullanılmaz, eski kayıt okunabilsin diye durur.
// SeenMajorUpdates: görülen büyük güncellemeler (Steam etkinlik kimliği). Boşsa ilk kontrol yalnız başlangıç kaydeder, bildirim vermez.
public record SteamUpdate(string Id, string Title);
public record SteamSearchItem(int Id, string Name, bool Approximate = false, string? CoverUrl = null, SteamPrice? Price = null)
{
    public override string ToString() => Approximate ? Name + " · Yakın eşleşme" : Name;
}
public interface ISteamCatalog
{
    Task<List<SteamSearchItem>> SearchAsync(string query, CancellationToken token, Action<List<SteamSearchItem>>? preview = null);
    Task<SteamGame> GetAsync(int id, CancellationToken token);
    Task<List<SteamUpdate>> UpdatesAsync(int id, CancellationToken token);
    // Herkese açık Steam profilinin istek listesi (oyun numaraları, Steam'deki sırayla). Sahte kataloglarda yok.
    Task<List<int>> WishlistAsync(string profile, CancellationToken token) => throw new NotSupportedException();
}
public sealed class SteamClient : ISteamCatalog, IDisposable
{
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(15) };
    private readonly Dictionary<int, SteamSearchItem> candidates = new();
    public async Task<List<SteamSearchItem>> SearchAsync(string query, CancellationToken token, Action<List<SteamSearchItem>>? preview = null)
    {
        var idMatch = Regex.Match(query.Trim(), @"^(?:https://store\.steampowered\.com/app/)?(\d+)(?:/[^\s]*)?$", RegexOptions.IgnoreCase);
        if (idMatch.Success && int.TryParse(idMatch.Groups[1].Value, out var id) && id > 0)
        {
            var game = await GetAsync(id, token);
            return [new(game.Id, game.Name, CoverUrl: game.CoverUrl, Price: game.Price)];
        }
        if (query.Trim().Length > 150) throw new InvalidOperationException("Daha kısa bir oyun adı yaz.");
        var direct = await SearchStoreAsync(query, token);
        token.ThrowIfCancellationRequested();
        Remember(direct);
        var rankedDirect = Rank(query, direct, direct.Select(x => x.Id).ToHashSet());
        if (query.Trim().Length < 4 || direct.Any(x => GameNameMatcher.Score(query, x.Name) >= 0.95)) return rankedDirect;
        if (rankedDirect.Count > 0) preview?.Invoke(rankedDirect);
        using var budget = CancellationTokenSource.CreateLinkedTokenSource(token);
        budget.CancelAfter(TimeSpan.FromSeconds(25));
        foreach (var term in GameNameMatcher.FallbackQueries(query)) {
            try { Remember(await SearchStoreAsync(term, budget.Token)); }
            catch (OperationCanceledException) when (!token.IsCancellationRequested) { break; }
            catch (HttpRequestException) { break; }
            if (candidates.Values.Any(x => GameNameMatcher.Score(query, x.Name) >= 0.85)) break;
        }
        token.ThrowIfCancellationRequested();
        return Rank(query, candidates.Values.Concat(direct), direct.Select(x => x.Id).ToHashSet());
    }
    private void Remember(IEnumerable<SteamSearchItem> items)
    {
        foreach (var item in items) candidates[item.Id] = item;
        while (candidates.Count > 2000) candidates.Remove(candidates.Keys.First());
    }
    public static List<SteamSearchItem> Rank(string query, IEnumerable<SteamSearchItem> items, HashSet<int> directIds)
    {
        return items.DistinctBy(x => x.Id).Select(x => (Item: x, Score: GameNameMatcher.Score(query, x.Name)))
            .Where(x => x.Score >= 0.65 || directIds.Contains(x.Item.Id))
            .OrderByDescending(x => x.Score).ThenBy(x => x.Item.Name)
            .Take(25).Select(x => x.Item with { Approximate = x.Score >= 0.65 && x.Score < 0.95 }).ToList();
    }
    private async Task<List<SteamSearchItem>> SearchStoreAsync(string query, CancellationToken token)
    {
        var json = await http.GetStringAsync("https://store.steampowered.com/api/storesearch/?l=turkish&cc=tr&term=" + Uri.EscapeDataString(query.Trim()), token);
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement.GetProperty("items").EnumerateArray()
            .Where(x => x.TryGetProperty("id", out var value) && value.TryGetInt32(out _))
            .Select(x => new SteamSearchItem(x.GetProperty("id").GetInt32(), x.GetProperty("name").GetString()!, CoverUrl: x.TryGetProperty("tiny_image", out var image) ? image.GetString() : null, Price: ReadPrice(x, "price"))).Take(25).ToList();
    }
    public async Task<SteamGame> GetAsync(int id, CancellationToken token)
    {
        var json = await http.GetStringAsync($"https://store.steampowered.com/api/appdetails?appids={id}&l=turkish&cc=tr", token);
        return ParseGame(json, id);
    }
    public static SteamGame ParseGame(string json, int id)
    {
        using var doc = JsonDocument.Parse(json);
        var entry = doc.RootElement.GetProperty(id.ToString());
        if (!entry.GetProperty("success").GetBoolean()) throw new InvalidDataException("Oyun bilgisi alınamadı; mağazada erişilebilir olmayabilir.");
        var data = entry.GetProperty("data");
        if (data.GetProperty("type").GetString() != "game") throw new InvalidDataException("Bu kayıt oyun değil. Bir oyun seç.");
        var release = data.GetProperty("release_date");
        var early = data.TryGetProperty("genres", out var genres) && genres.EnumerateArray().Any(c => c.GetProperty("id").ToString() == "70");
        return new(id, data.GetProperty("name").GetString()!, release.GetProperty("coming_soon").GetBoolean(), release.GetProperty("date").GetString() ?? "Belirtilmedi", early, data.TryGetProperty("header_image", out var header) ? header.GetString() : null,
            data.TryGetProperty("is_free", out var free) && free.ValueKind == JsonValueKind.True ? new("", 0, 0) : ReadPrice(data, "price_overview"));
    }
    // Arama ("price") ve oyun ayrıntısı ("price_overview") aynı alanları taşır: currency, initial, final. Fiyatı olmayan oyunda null.
    public static SteamPrice? ReadPrice(JsonElement item, string property)
        => item.TryGetProperty(property, out var p) && p.ValueKind == JsonValueKind.Object && p.TryGetProperty("currency", out var c) && p.TryGetProperty("initial", out var i) && p.TryGetProperty("final", out var f)
            ? new(c.GetString() ?? "", i.GetInt32(), f.GetInt32()) : null;
    public void Dispose() => http.Dispose();
    // Profil: 17 haneli SteamID, profil bağlantısı (/profiles/<id> ya da /id/<ad>) ya da özel profil adı.
    // Özel ad, profilin herkese açık XML sayfasından SteamID'ye çevrilir (anahtar gerekmez).
    public async Task<List<int>> WishlistAsync(string profile, CancellationToken token)
    {
        var steamId = await ResolveProfileAsync(profile, token);
        var json = await http.GetStringAsync($"https://api.steampowered.com/IWishlistService/GetWishlist/v1/?steamid={steamId}", token);
        return ParseWishlist(json);
    }
    public static List<int> ParseWishlist(string json)
    {
        using var doc = JsonDocument.Parse(json);
        if (!doc.RootElement.GetProperty("response").TryGetProperty("items", out var items)) return [];
        return items.EnumerateArray().OrderBy(i => i.TryGetProperty("priority", out var p) ? p.GetInt32() : int.MaxValue)
            .Select(i => i.GetProperty("appid").GetInt32()).Distinct().ToList();
    }
    public static string? ProfileId(string profile)
    {
        var text = profile.Trim().TrimEnd('/');
        var id = Regex.Match(text, @"(?:^|/profiles/)(7656\d{13})$");
        return id.Success ? id.Groups[1].Value : null;
    }
    public static string? ProfileName(string profile)
    {
        var text = profile.Trim().TrimEnd('/');
        var named = Regex.Match(text, @"(?:steamcommunity\.com/id/)?([A-Za-z0-9_-]{2,64})$");
        return ProfileId(text) == null && named.Success && !text.Contains("/profiles/") ? named.Groups[1].Value : null;
    }
    private async Task<string> ResolveProfileAsync(string profile, CancellationToken token)
    {
        if (ProfileId(profile) is { } id) return id;
        var name = ProfileName(profile) ?? throw new ArgumentException("Steam profil bağlantını ya da profil adını yaz.");
        var xml = await http.GetStringAsync($"https://steamcommunity.com/id/{Uri.EscapeDataString(name)}/?xml=1", token);
        var match = Regex.Match(xml, @"<steamID64>(\d{17})</steamID64>");
        return match.Success ? match.Groups[1].Value : throw new InvalidOperationException("Bu adla bir Steam profili bulunamadı.");
    }
    public async Task<List<SteamUpdate>> UpdatesAsync(int id, CancellationToken token)
    {
        var json = await http.GetStringAsync($"https://store.steampowered.com/events/ajaxgetadjacentpartnerevents/?appid={id}&count_before=0&count_after=50&lang_list=0_25&event_type_filter=13,14", token);
        return ParseUpdates(json);
    }
    // Yalnız görselli büyük duyurular: Steam etkinlik türü 13 (güncelleme) ve 14 (büyük güncelleme).
    // 12 (küçük güncelleme/yama notları), haberler (28) ve indirim duyuruları alınmaz. Steam bu süzgeci
    // kendisi de uygular; burada yine denetlenir. En yeni önce.
    public static List<SteamUpdate> ParseUpdates(string json)
    {
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement.GetProperty("events").EnumerateArray()
            .Where(e => e.GetProperty("event_type").GetInt32() is MajorUpdate or RegularUpdate)
            .OrderByDescending(e => e.GetProperty("rtime32_start_time").GetInt64())
            .Select(e => new SteamUpdate(e.GetProperty("gid").GetString()!, e.GetProperty("event_name").GetString()!)).ToList();
    }
    private const int RegularUpdate = 13, MajorUpdate = 14;
}
public sealed class SteamWatchStore
{
    private readonly JsonListStore<SteamWatch> data;
    public List<SteamWatch> Items => data.Read();
    public SteamWatchStore(string path)
    {
        data = new(path);
        _ = Items;
    }
    public void Add(SteamGame game)
    {
        data.Modify(items => {
            if (items.Any(w => w.Id == game.Id)) throw new InvalidOperationException("Bu oyun zaten takip listesinde.");
            if (items.Count >= 50) throw new InvalidOperationException("İlk sürüm en fazla 50 oyunu takip ediyor.");
            return [.. items, new(game.Id, game.Name, game.ComingSoon, game.ReleaseDate, game.EarlyAccess, DateTimeOffset.Now, CoverUrl: game.CoverUrl, Price: game.Price, PriceHistory: SteamSale.Record(null, game.Price, DateOnly.FromDateTime(DateTime.Now)))];
        });
    }
    public bool Update(SteamGame game) => Update(game, out _);
    // sale: indirim bildirimi metni (yeni başlayan %20 ve üzeri indirim ya da daha önce görülmemiş en düşük fiyat); yoksa null.
    public bool Update(SteamGame game, out string? sale)
    {
        var released = false; string? notice = null;
        data.Modify(items => {
            var before = items.FirstOrDefault(w => w.Id == game.Id);
            if (before is null) return items;
            released = before.ComingSoon && !game.ComingSoon;
            notice = SteamSale.Notice(game.Name, before, game.Price);
            var history = SteamSale.Record(before.PriceHistory, game.Price, DateOnly.FromDateTime(DateTime.Now));
            return items.Select(w => w.Id == game.Id ? w with { Name = game.Name, ComingSoon = game.ComingSoon, ReleaseDate = game.ReleaseDate, EarlyAccess = game.EarlyAccess, CheckedAt = DateTimeOffset.Now, Error = null, CoverUrl = game.CoverUrl ?? w.CoverUrl, Price = game.Price, PriceHistory = history } : w).ToList();
        });
        sale = notice;
        return released;
    }
    public void SetTarget(int id, int? cents) => data.Modify(items => items.Select(w => w.Id == id ? w with { TargetPrice = cents } : w).ToList());
    public void Failure(int id, string message) => data.Modify(items => items.Select(w => w.Id == id ? w with { Error = message } : w).ToList());
    public void Remove(int id) => data.Modify(items => items.Where(w => w.Id != id).ToList());
    public List<SteamUpdate> UpdateNews(int id, List<SteamUpdate> news)
    {
        List<SteamUpdate> fresh = [];
        data.Modify(items => items.Select(w => {
            if (w.Id != id) return w;
            if (w.SeenMajorUpdates is not null) fresh = news.Where(n => !w.SeenMajorUpdates.Contains(n.Id)).ToList();
            // Son duyuru yalnız büyük güncellemelerden gelir; hiç yoksa eski küçük yama başlığı silinir.
            return w with { SeenMajorUpdates = news.Select(n => n.Id).Concat(w.SeenMajorUpdates ?? []).Distinct().Take(500).ToArray(), LatestUpdate = news.FirstOrDefault()?.Title };
        }).ToList());
        return fresh;
    }
}

// İndirim bildirimi kuralları. Steam her indirimde bildirir; burada yalnız anlamlı olanlar:
// %20 ve üzeri indirim yeni başladıysa ya da (yine %20+ indirimde) fiyat şimdiye kadar görülen en düşüğün altına indiyse.
// Kullanıcının koyduğu hedef fiyata inmek her zaman bildirilir (bir kez; fiyat hedefin üstüne çıkıp tekrar inerse yine).
// İlk fiyat kaydı (geçmiş boş) yalnız başlangıçtır, bildirim vermez. Ücretsiz oyunlar bildirilmez.
public static class SteamSale
{
    public const int MinimumDiscount = 20;
    public static string? Notice(string name, SteamWatch before, SteamPrice? price)
    {
        // Hedef fiyat: önceki kontrolde hedefin üstündeyken (ya da fiyat bilinmezken) hedefe ya da altına indiyse.
        if (price is { Free: false } && before.TargetPrice is { } target && price.Final <= target && (before.Price is null || before.Price.Final > target))
            return $"{name} hedef fiyatına indi: {Money(price.Final, price.Currency)} (hedefin {Money(target, price.Currency)}" + (price.Discount > 0 ? $", %{price.Discount} indirim)" : ")");
        if (price is null || price.Free || before.LowestPrice is not { } lowest) return null;
        var newSale = price.Discount >= MinimumDiscount && (before.Price?.Discount ?? 0) < MinimumDiscount;
        var newLow = price.Final < lowest && price.Discount >= MinimumDiscount;
        if (!newSale && !newLow) return null;
        return $"{name} %{price.Discount} indirimde: {Money(price.Final, price.Currency)} (normalde {Money(price.Initial, price.Currency)})" + (price.Final <= lowest ? " · şimdiye kadarki en düşük fiyat" : "");
    }
    public static SteamPricePoint[]? Record(SteamPricePoint[]? history, SteamPrice? price, DateOnly day)
    {
        if (price is null || price.Free) return history;
        if (history is { Length: > 0 } && history[^1].Final == price.Final) return history;
        return [.. (history ?? []).TakeLast(199), new(day, price.Final)];
    }
    public static string Money(int cents, string currency)
    {
        var amount = (cents / 100m).ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("tr-TR"));
        return currency switch { "USD" => "$" + amount, "EUR" => "€" + amount, "TRY" => amount + " TL", _ => amount + " " + currency };
    }
}
