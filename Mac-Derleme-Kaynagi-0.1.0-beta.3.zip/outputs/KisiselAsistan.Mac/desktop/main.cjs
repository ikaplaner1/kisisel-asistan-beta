const {app, BrowserWindow, WebContentsView, ipcMain, shell, dialog, safeStorage, session} = require('electron');
const {spawn} = require('node:child_process');
const {createInterface} = require('node:readline');
const fs = require('node:fs'); const fsp = fs.promises;
const path = require('node:path'); const crypto = require('node:crypto');
const {pathToFileURL} = require('node:url');
const {providers, externalUrl, trustedUi, releaseAsset} = require('./policy.cjs');
require('electron').nativeTheme.themeSource='dark';
let window, host, seq=0, compact=false, exiting=false, tickBusy=false, chatBounds=null, activeChat=null;
const views = new Map(), pending = new Map(), notices = new Map();
const noticeWindows = new Map();
const smoke = process.argv.includes('--smoke-test') && process.env.CI === 'true';
if(smoke){app.setPath('userData',path.join(require('node:os').tmpdir(),'assistant-smoke-'+process.pid));setTimeout(()=>{console.error('SMOKE_TIMEOUT');host?.kill();app.exit(1);},45000).unref();}
const entry = pathToFileURL(path.join(__dirname,'../ui/index.html')).href;
const noticeEntry = pathToFileURL(path.join(__dirname,'../ui/notice.html')).href;
const allowed = new Set(['state','operation','command','reminder.respond','reminder.complete','defaults','preferences','spotify.connect','spotify.disconnect','google.connect','google.sync','google.disconnect','ollama.models','ollama.save','speech','github.connect','github.settings','github.disconnect']);
function emit(event) { if (window && !window.isDestroyed()) window.webContents.send('assistant:event',event); }
function rpc(method, params={}) { return new Promise((resolve,reject) => { const id=String(++seq); const timer=setTimeout(()=>{pending.delete(id);reject(new Error('İşlem zaman aşımına uğradı.'));},250000); pending.set(id,{resolve,reject,timer}); host.stdin.write(JSON.stringify({id,method,params})+'\n'); }); }
function assertSender(event) { if (event.sender !== window.webContents || !trustedUi(event.senderFrame.url,entry)) throw new Error('Bu işlem yalnız asistan ekranında kullanılabilir.'); }
function layoutChats() {
  for (const [name,view] of views) {
    view.setVisible(Boolean(chatBounds) && (!activeChat || activeChat===name));
    if (!chatBounds) continue;
    const names=[...views.keys()], i=names.indexOf(name), width=Math.floor(chatBounds.width/3);
    view.setBounds(activeChat ? chatBounds : {x:chatBounds.x+i*width,y:chatBounds.y,width:i===2?chatBounds.width-2*width:width,height:chatBounds.height});
  }
}
function createChats() {
  if (views.size) return;
  for (const [name,url] of Object.entries(providers)) {
    const view=new WebContentsView({webPreferences:{partition:`persist:ai-${name}`,nodeIntegration:false,contextIsolation:true,sandbox:true}});
    view.webContents.session.setPermissionRequestHandler((_,__,callback)=>callback(false));
    view.webContents.session.setPermissionCheckHandler(()=>false);
    window.contentView.addChildView(view); views.set(name,view); view.setVisible(false);
    view.webContents.setWindowOpenHandler(({url})=>{if(externalUrl(url)) shell.openExternal(url); return {action:'deny'};});
    view.webContents.on('will-navigate',(event,target)=>{if(!externalUrl(target)) event.preventDefault();});
    view.webContents.on('context-menu',(_,params)=>{const {Menu}=require('electron'); const items=[{role:'copy'},{label:'Bu paneli büyüt',click:()=>{activeChat=name;layoutChats();}},{label:'Üç paneli göster',click:()=>{activeChat=null;layoutChats();}}]; if(params.selectionText)items.push({label:'Seçili metni üçüne sor',click:()=>{emit({type:'selection',text:params.selectionText});}}); Menu.buildFromTemplate(items).popup();});
    view.webContents.on('focus',()=>{if(!activeChat){activeChat=name;layoutChats();emit({type:'chat.focus',name});}});
    view.webContents.loadURL(url).catch(()=>emit({type:'status',text:`${name}: bağlantı kurulamadı.`}));
  }
}
async function sendChats(text) {
  if(typeof text!=='string'||!text.trim()||text.length>20000)throw new Error('Soru 1–20000 karakter olmalı.');
  createChats(); const result={};
  // Each renderer is isolated. Use the same provider-specific selectors as Windows.
  for(const [name,view] of views) {
    try {
      const script=await rpc('chat.script',{provider:name,text,mode:'prepare'});
      const ready=await view.webContents.executeJavaScript(script,true);
      if(ready!=='hazır'){result[name]=ready;continue;}
      await view.webContents.insertText(text);
      result[name]=await view.webContents.executeJavaScript(await rpc('chat.script',{provider:name,text,mode:'submit'}),true);
    } catch {result[name]='Panel hazır değil; girişini ve bağlantını kontrol et.';}
  }
  return result;
}
function toast(item) {
  if(notices.has(item.id))return;
  notices.set(item.id,item);
  const area=require('electron').screen.getDisplayMatching(window.getBounds()).workArea;
  const adhd=item.prompt.reminder.settings.level==='Adhd', center=adhd&&item.prompt.reminder.pressure>=4;
  const popup=new BrowserWindow({width:400,height:260,x:center?Math.round(area.x+(area.width-400)/2):area.x+area.width-420,y:center?Math.round(area.y+(area.height-260)/2):area.y+area.height-280,frame:false,resizable:false,show:false,alwaysOnTop:true,backgroundColor:'#213731',skipTaskbar:true,webPreferences:{preload:path.join(__dirname,'notice-preload.cjs'),sandbox:true,contextIsolation:true,nodeIntegration:false}});
  const popupId=popup.webContents.id;noticeWindows.set(popupId,{popup,item});
  popup.webContents.setWindowOpenHandler(()=>({action:'deny'}));popup.webContents.on('will-navigate',event=>event.preventDefault());
  popup.once('ready-to-show',()=>popup.showInactive());
  popup.on('closed',()=>noticeWindows.delete(popupId));
  popup.loadURL(noticeEntry).catch(()=>popup.close());
  if(!adhd)setTimeout(()=>{if(!popup.isDestroyed())popup.close();},14000);
}
async function tick() {
  if(tickBusy||!host)return;tickBusy=true;
  try {const data=await rpc('tick');const active=new Set(data.prompts.map(item=>item.id));for(const id of notices.keys())if(!active.has(id)){notices.delete(id);for(const owner of noticeWindows.values())if(owner.item.id===id)owner.popup.close();}for(const item of data.prompts)toast(item); for(const text of data.notices)emit({type:'steam.notice',text});}
  catch {emit({type:'status',text:'Arka plan kontrolü tamamlanamadı; tekrar denenecek.'});}
  finally{tickBusy=false;}
}
async function updateDownload() {
  const auth=await rpc('github.token'); const repo=new URL(auth.repositoryUrl).pathname;
  const headers={Authorization:`Bearer ${auth.token}`,Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'};
  const response=await fetch(`https://api.github.com/repos${repo}/releases`,{headers});
  if(!response.ok)throw new Error('Test deposuna erişilemedi. GitHub davetini ve girişini kontrol et.');
  const releases=await response.json(); const release=releases.find(r=>!r.draft&&releaseAsset(r.assets,process.arch));
  if(!release)throw new Error('Bu Mac için yayımlanmış paket bulunamadı.');
  const asset=releaseAsset(release.assets,process.arch);
  const selected=await dialog.showSaveDialog(window,{title:'Mac güncellemesini indir',defaultPath:path.join(app.getPath('downloads'),asset.name),filters:[{name:'Mac kurulumu',extensions:['dmg']}]});
  if(selected.canceled)return 'İndirme iptal edildi.';
  const downloaded=await fetch(asset.url,{headers:{...headers,Accept:'application/octet-stream'}});
  if(!downloaded.ok)throw new Error('Güncelleme indirilemedi.');
  const temporary=selected.filePath+'.'+crypto.randomUUID()+'.partial';
  const {Readable,Transform}=require('node:stream'), {pipeline}=require('node:stream/promises');
  const hash=crypto.createHash('sha256');let bytes=0;
  try {
    await pipeline(Readable.fromWeb(downloaded.body),new Transform({transform(chunk,_,cb){bytes+=chunk.length;hash.update(chunk);emit({type:'status',text:`Mac paketi indiriliyor: ${Math.floor(bytes/1048576)} MB`});cb(null,chunk);}}),fs.createWriteStream(temporary,{flags:'wx'}));
    if(bytes!==asset.size)throw new Error('İndirilen paket eksik.');
    const digest=hash.digest('hex');
    if(!asset.digest||asset.digest!==`sha256:${digest}`)throw new Error('Güncellemenin doğrulama bilgisi eşleşmedi.');
    await fsp.rename(temporary,selected.filePath);shell.showItemInFolder(selected.filePath);
    return 'Mac paketi indirildi. Kurulumu Finder üzerinden tamamla; mevcut sürüm otomatik değiştirilmedi.';
  }catch(error){await fsp.rm(temporary,{force:true});throw error;}
}
app.whenReady().then(async()=>{
  if(!app.requestSingleInstanceLock()){app.quit();return;}
  session.defaultSession.setPermissionRequestHandler((contents,permission,callback,details)=>callback(contents===window?.webContents&&permission==='media'&&details.mediaTypes?.every(t=>t==='audio')));
  session.defaultSession.setPermissionCheckHandler((contents,permission)=>contents===window?.webContents&&permission==='media');
  if(!safeStorage.isEncryptionAvailable())throw new Error('Sistem güvenli hesap deposuna erişilemiyor.');
  const keyPath=path.join(app.getPath('userData'),'account-key.bin');
  const key=fs.existsSync(keyPath)?safeStorage.decryptString(fs.readFileSync(keyPath)):crypto.randomBytes(32).toString('base64');
  if(!fs.existsSync(keyPath)){fs.mkdirSync(path.dirname(keyPath),{recursive:true});fs.writeFileSync(keyPath,safeStorage.encryptString(key),{mode:0o600});}
  const hostPath=app.isPackaged?path.join(process.resourcesPath,'host','Assistant.Host'):path.join(__dirname,'../host-publish',process.platform==='win32'?'Assistant.Host.exe':'Assistant.Host');
  host=spawn(hostPath,[],{env:{...process.env,ASSISTANT_ACCOUNT_KEY:key},stdio:['pipe','pipe','pipe'],windowsHide:true});
  host.stderr.on('data',()=>{});
  host.on('error',()=>emit({type:'status',text:'Asistan servisleri başlatılamadı.'}));
  createInterface({input:host.stdout}).on('line',line=>{try{const response=JSON.parse(line);if(response.event){emit({type:response.event,...response});return;}const request=pending.get(response.id);if(!request)return;clearTimeout(request.timer);pending.delete(response.id);response.success?request.resolve(response.result):request.reject(new Error(response.error));}catch{}});
  host.on('exit',()=>{for(const request of pending.values()){clearTimeout(request.timer);request.reject(new Error('Asistan servisleri kapandı.'));}pending.clear();if(!exiting)emit({type:'status',text:'Servis bağlantısı kesildi. Uygulamayı yeniden aç.'});});
  window=new BrowserWindow({width:1400,height:900,minWidth:420,minHeight:560,backgroundColor:'#10151d',title:'Kişisel Asistan',titleBarStyle:'hiddenInset',webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
  window.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  window.webContents.on('will-navigate',(event,url)=>{if(url!==entry)event.preventDefault();});
  window.on('close',event=>{if(!exiting){event.preventDefault();window.hide();}});
  ipcMain.handle('assistant:call',async(event,method,params)=>{assertSender(event);if(!allowed.has(method))throw new Error('Bu işlem arayüze açık değil.');const result=await rpc(method,params);if(method==='reminder.respond')notices.delete(params.id);return result;});
  ipcMain.handle('notice:get',event=>{const owner=noticeWindows.get(event.sender.id);if(!owner||event.senderFrame.url!==noticeEntry)throw new Error('Bildirim bulunamadı.');return owner.item;});
  ipcMain.handle('notice:respond',async(event,response,minutes)=>{
    const owner=noticeWindows.get(event.sender.id);if(!owner||event.senderFrame.url!==noticeEntry)throw new Error('Bildirim bulunamadı.');
    if(!['Done','Confirmed','NotDone','Snooze','Acknowledge'].includes(response)||![5,15].includes(minutes))throw new Error('Geçersiz bildirim yanıtı.');
    const next=await rpc('reminder.respond',{id:owner.item.id,response,minutes});notices.delete(owner.item.id);owner.popup.close();if(next)toast(next);emit({type:'refresh'});return true;
  });
  ipcMain.handle('assistant:action',async(event,name,p)=>{
    assertSender(event);
    switch(name){
      case 'compact': compact=!compact;chatBounds=null;layoutChats();window.setSize(compact?440:1400,compact?670:900);if(compact){const area=require('electron').screen.getDisplayMatching(window.getBounds()).workArea;window.setPosition(area.x+area.width-460,area.y+area.height-690);}return compact;
      case 'minimize':window.minimize();return true;
      case 'reload':chatBounds=null;layoutChats();window.reload();return true;
      case 'quit':exiting=true;app.quit();return true;
      case 'google.import':{const file=await dialog.showOpenDialog(window,{filters:[{name:'Google bağlantı dosyası',extensions:['json']}],properties:['openFile']});if(file.canceled)return false;return rpc('google.import',{json:await fsp.readFile(file.filePaths[0],'utf8')});}
      case 'speech.import':{const file=await dialog.showOpenDialog(window,{filters:[{name:'Whisper ses modeli',extensions:['bin']}],properties:['openFile']});if(file.canceled)return false;const directory=path.join(app.getPath('appData'),'KisiselAsistan','Models');await fsp.mkdir(directory,{recursive:true});await fsp.copyFile(file.filePaths[0],path.join(directory,'ggml-small-q5_1.bin'));return 'Ses modeli eklendi.';}
      case 'ollama.open':await shell.openExternal('https://ollama.com/download/mac');return 'Ollama kurulduktan sonra modeli indir seçeneğini kullan.';
      case 'ollama.pull':{if(!['qwen3:4b','qwen3:8b'].includes(p.model))throw new Error('Model seç.');const response=await fetch('http://127.0.0.1:11434/api/pull',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:p.model,stream:true}),signal:AbortSignal.timeout(3600000)});if(!response.ok)throw new Error('Ollama açık değil. Kurup açtıktan sonra tekrar dene.');let remainder='',success=false;for await(const chunk of response.body){remainder+=Buffer.from(chunk).toString();let pos;while((pos=remainder.indexOf('\n'))>=0){const value=JSON.parse(remainder.slice(0,pos));remainder=remainder.slice(pos+1);if(value.error)throw new Error('Model indirilemedi.');if(value.status==='success')success=true;if(value.total&&value.completed)emit({type:'status',text:`Model indiriliyor: %${Math.floor(value.completed*100/value.total)}`});}}if(!success)throw new Error('Model indirme tamamlanmadı.');return 'Model indirildi. Yerel modelleri yenileyip Kaydet ile etkinleştir.';}
      case 'chat.layout':{if(p.visible){createChats();const b=p.bounds;const [w,h]=window.getContentSize();chatBounds={x:Math.max(0,Math.round(b.x)),y:Math.max(0,Math.round(b.y)),width:Math.max(0,Math.min(w,Math.round(b.width))),height:Math.max(0,Math.min(h,Math.round(b.height)))};}else chatBounds=null;layoutChats();return true;}
      case 'chat.focus':activeChat=providers[p.name]?p.name:null;layoutChats();return true;
      case 'chat.reload':if(views.has(p.name))views.get(p.name).webContents.reload();return true;
      case 'chat.send':return sendChats(p.text);
      case 'update.download':return updateDownload();
      default:throw new Error('Desteklenmeyen işlem.');
    }
  });
  await window.loadURL(entry);
  if(smoke){
    const data=await rpc('state');
    if(!data || typeof data!=='object')throw new Error('Smoke: host returned no state');
    const body=await window.webContents.executeJavaScript('document.body.innerText');
    if(!body.includes('Planlarım') || !body.includes('Spotify'))throw new Error('Smoke: interface did not load');
    const output=process.env.ASSISTANT_SMOKE_RESULT;
    if(!output)throw new Error('Smoke output path is required');
    let screenshot=false;
    try{
      const frame=await window.webContents.capturePage();
      if(!frame.isEmpty()){fs.writeFileSync(output+'.png',frame.toPNG());screenshot=true;}
    }catch(error){console.warn('SMOKE_SCREENSHOT_UNAVAILABLE',error.message);}
    fs.writeFileSync(output,JSON.stringify({version:app.getVersion(),arch:process.arch,ui:true,host:true,screenshot}));
    exiting=true;host.kill();app.exit(0);return;
  }
  setInterval(tick,10000);tick();
}).catch(error=>{if(smoke){console.error(error);host?.kill();app.exit(1);return;}dialog.showErrorBox('Asistan başlatılamadı',error.message);app.quit();});
app.on('activate',()=>window?.show());app.on('second-instance',()=>{window?.show();window?.focus();});
app.on('before-quit',()=>{exiting=true;host?.stdin.end();host?.kill();});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});

