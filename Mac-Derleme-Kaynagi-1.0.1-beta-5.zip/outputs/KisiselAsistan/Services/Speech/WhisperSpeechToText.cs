using Whisper.net;
namespace KisiselAsistan;
public sealed class WhisperSpeechToText : ISpeechToText
{
    private readonly string modelPath;
    private readonly Lazy<WhisperFactory> factory;
    public WhisperSpeechToText(string modelPath) { this.modelPath = modelPath; factory = new(() => WhisperFactory.FromPath(modelPath)); }
    public Task WarmUpAsync(CancellationToken cancellationToken = default) => Task.Run(() => { cancellationToken.ThrowIfCancellationRequested(); RequireModel(); _ = factory.Value; }, cancellationToken);
    public async Task<string> TranscribeAsync(SpeechAudio audio, SpeechRecognitionOptions options, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (audio.SampleRate != 16000) throw new ArgumentException("Konuşma sesi 16000 Hz olmalı.");
        RequireModel();
        var language = options.Language;
        if (language is not ("tr" or "en")) throw new ArgumentException("Desteklenmeyen konuşma dili.");
        using var processor = factory.Value.CreateBuilder().WithLanguage(language)
            .WithPrompt(SpeechVocabulary.BuildPrompt(language, options.Vocabulary))
            .WithTemperature(0).WithTemperatureInc(0)
            .WithThreads(Math.Clamp(Environment.ProcessorCount / 2, 1, 6)).Build();
        var segments = new List<string>();
        await foreach (var segment in processor.ProcessAsync(audio.Samples, cancellationToken)) if (!string.IsNullOrWhiteSpace(segment.Text)) segments.Add(segment.Text.Trim());
        return System.Text.RegularExpressions.Regex.Replace(string.Join(" ", segments).Trim().TrimEnd('.', '!', '?', '…'), @"\s+", " ");
    }
    private void RequireModel()
    {
        if (!File.Exists(modelPath)) throw new InvalidOperationException("Ses modeli bulunamadı. Kapalı testin isteğe bağlı Ses Paketi içindeki SesModeliniKur.ps1 dosyasını çalıştırıp asistanı yenile.");
    }
}
