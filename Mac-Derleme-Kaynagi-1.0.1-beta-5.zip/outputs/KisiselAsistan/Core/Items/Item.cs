using System.Security.Cryptography;
using System.Text;

namespace KisiselAsistan;

// Uygulamanın tek iş modeli. Eskiden ayrı olan "görev" ve "hatırlatıcı" aynı kayıttır:
// - Günü olabilir (Day) ya da olmayabilir ("bir ara").
// - Saati olabilir: tek seferlikse At (tam an), tekrarlıysa Repeat.TimeMinutes. Saati olan işe bildirim gelir.
// - Tekrarı tek bir kuraldır (Repeat); tekrarlar dosyaya tek tek yazılmaz, gerektiğinde hesaplanır.
//   Bir tekrarın tamamlanma/erteleme/bildirim durumu yalnızca o gün için Occurrences'ta tutulur.
// Bütün alanlar isteğe bağlıdır; yeni bir özellik eklemek buraya bir alan eklemektir.
public sealed record Item(
    Guid Id,
    string Title,
    DateOnly? Day = null,
    DateTimeOffset? At = null,
    ItemRepeat? Repeat = null,
    // Ayrıntılar (her işte aynı)
    string List = "Görevler",
    List<RoutineTaskStep>? Steps = null,
    int Priority = 2,
    PlanCategory Category = PlanCategory.Personal,
    int DurationMinutes = 30,
    bool Flexible = false,
    DateOnly? Deadline = null,
    // Bildirim (yalnızca saati olan işlerde kullanılır)
    ReminderOptions? Notify = null,
    bool RemindDayBefore = false,
    // Tek seferlik işin durumu
    bool Done = false,
    OccurrenceState? State = null,
    // Tekrarlı işin gün gün durumu ("yyyy-MM-dd" → durum)
    Dictionary<string, OccurrenceState>? Occurrences = null,
    // Aynı serinin parçaları (bir tekrar "bu ve sonrakiler" diye düzenlenince seri ikiye bölünür)
    Guid? SeriesId = null,
    DateTimeOffset? Created = null,
    int Revision = 0)
{
    internal bool Timed => At != null || Repeat?.TimeMinutes != null;
    internal bool Repeating => Repeat != null;
    internal bool Important => Priority >= 3;
    internal OccurrenceState StateOn(DateOnly day) => Occurrences != null && Occurrences.TryGetValue(Key(day), out var state) ? state : new();
    internal Item WithState(DateOnly day, OccurrenceState state)
    {
        var next = new Dictionary<string, OccurrenceState>(Occurrences ?? []) { [Key(day)] = state };
        return this with { Occurrences = next };
    }
    internal static string Key(DateOnly day) => day.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
    internal static DateOnly ParseKey(string key) => DateOnly.ParseExact(key, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
    // Tekrarlı işin bir gününe ait kalıcı, tahmin edilebilir kimlik (eski "her tekrar ayrı kayıt" kimliklerinin yerini alır).
    internal static Guid OccurrenceId(Guid item, DateOnly day) => new(SHA256.HashData(Encoding.UTF8.GetBytes(item.ToString("N") + ":" + Key(day))).AsSpan(0, 16));
}

// Tekrar kuralı. DaysMask: haftanın günleri (bit 0 = pazar … bit 6 = cumartesi; 127 = her gün).
// TimeMinutes: gün içindeki saat (dakika); yoksa tekrar saatsizdir (alışkanlık gibi).
public sealed record ItemRepeat(int DaysMask, DateOnly Start, DateOnly? Until = null, int? TimeMinutes = null)
{
    internal const int EveryDay = 127;
    internal bool Includes(DateOnly day) => day >= Start && (Until == null || day <= Until) && (DaysMask & (1 << (int)day.DayOfWeek)) != 0;
    internal IEnumerable<DateOnly> Days(DateOnly from, DateOnly to)
    {
        for (var day = from < Start ? Start : from; day <= to && (Until == null || day <= Until); day = day.AddDays(1))
            if (Includes(day)) yield return day;
    }
    // Yerel saatle o günün tekrar anı. Yaz saati geçişinde var olmayan saat atlanır (null).
    internal DateTimeOffset? At(DateOnly day)
    {
        if (TimeMinutes is not int minutes) return null;
        var local = DateTime.SpecifyKind(day.ToDateTime(TimeOnly.MinValue).AddMinutes(minutes), DateTimeKind.Unspecified);
        if (TimeZoneInfo.Local.IsInvalidTime(local)) return null;
        return new DateTimeOffset(local, TimeZoneInfo.Local.GetUtcOffset(local));
    }
    internal void Validate()
    {
        if (DaysMask is < 1 or > 127 || TimeMinutes is < 0 or > 1439 || Until < Start) throw new ArgumentException("Tekrar için en az bir gün seç.");
    }
}

// Tek seferlik işin ya da tekrarın bir gününün durumu: tamamlanma, atlanma, erteleme ve bildirim ilerlemesi.
public sealed record OccurrenceState(
    bool Done = false,
    bool Skipped = false,
    DateTimeOffset? MovedTo = null,
    int SentCount = 0,
    DateTimeOffset? NextNotice = null,
    int Revision = 0,
    int Pressure = 0,
    DateTimeOffset? AdvanceSentForDue = null)
{
    internal bool Active => !Done && (SentCount > 0 || NextNotice != null || MovedTo != null);
}
