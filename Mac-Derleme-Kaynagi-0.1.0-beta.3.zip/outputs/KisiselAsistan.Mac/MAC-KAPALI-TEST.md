# Mac kapalı test

Bu arayüz Windows Forms kopyası değildir: Electron masaüstü kabuğu, mevcut .NET hatırlatıcı/Steam/Spotify/Google Calendar/komut servislerini kaynak bağlantısıyla kullanır. Windows arayüzü değiştirilmez. Kaynak kodun derlenmesi, Mac'te açıldığı anlamına gelmez.

## Paket üretme

Apple Silicon için `node build.mjs --arm64`, Intel için `node build.mjs --x64`. Node 24+, .NET 10 SDK ve `npm ci` gerekir. Mac'te DMG ve ZIP üretilir. Windows'ta yalnız servis çekirdeğini çapraz derlemek için `--host-only` kullanılır; `.app`/DMG üretimi, macOS izinleri ve gerçek uygulama açılışı macOS gerektirir. Paketleyici Windows'tan Mac uygulaması üretimini reddeder.

GitHub özel deposunda aynı klasör düzenini koruyarak yalnız seçilmiş kaynakları yükle. `mac-beta.yml` dosyasını `.github/workflows/mac-beta.yml` konumuna koy. Actions → Mac kapalı test paketleri → Run workflow iki mimariyi Mac derleme makinelerinde üretir. Bu iş akışı otomatik yayın veya davet yapmaz. Başarılı çıktılarını Windows kurulumu ile aynı taslak GitHub Release'e ekle. `ASSISTANT_GITHUB_CLIENT_ID` yayıncıya ait gizli olmayan GitHub App kimliğidir; erişim tokenı paketlenmez.

## Apple imzası ve güncelleme sınırı

Ücretli Apple Developer hesabı olmadığı için Developer ID imzası/noter onayı yoktur. Test Mac'inde Gatekeeper kurulumu engelleyebilir. Güvenlik korumalarını devre dışı bırakmayın; kurulum için macOS'un sunduğu kullanıcı onayı akışını kullanın. Sorunsuz dağıtım ve otomatik uygulama değiştirme için Developer ID imzası ve noter onayı sonraki ayrı adımdır.

İlk Mac sürümünde GitHub hesabıyla paket indirme vardır, sessiz/otomatik kurulum yoktur. Mac güncelleme düğmesi doğru mimarinin DMG'sini doğrulayarak indirir; Finder'dan kurulum tamamlanır. GitHub App ve repo erişimi Windows ile aynı şekilde yapılandırılır.

## İşlevler ve cihazda yapılacak kontrol

- Ay/hafta/gün/liste plan görünümü, sağ tıkla değiştir/sil, esnek saat önerileri, Normal/ADHD varsayılanı, bildirimde tamamla/ertele; ADHD tamamlaması ikinci onay ister.
- Steam canlı arama, çift tıkla takip, çıkış/güncelleme kontrolü.
- Spotify PKCE ile kendi hesabına giriş, canlı arama, çift tıkla çalma; yerel oynatma için macOS Otomasyon izni gerekir.
- Google bağlantı JSON'unu seç, hesabına giriş yap ve takvim eşitlemesini dene. Kimlik bilgileri kullanıcıya özeldir.
- AI panellerinde üç hesabına ayrı giriş yap. Ortak soru gönderimini üç hizmette de dene; web arayüzleri değişebilir. Google'ın gömülü tarayıcı girişine izin verip vermediği ayrıca denenmelidir. Üç panel / tek panel geçişi vardır.
- Ses Paketi ZIP'indeki `ggml-small-q5_1.bin` dosyasını Ses tanıma ayarından seç. Windows .cmd/.ps1 dosyalarını Mac'te çalıştırma. Mikrofon iznini ver. Türkçe ve İngilizce Whisper, sesli komutun otomatik çalışması cihazda doğrulanmalıdır.
- Mac Ollama kurulumu resmî indirme sayfasından yapılır; ardından model uygulama içinden indirilir. Windows'taki taşınabilir otomatik runtime kurulumu Mac'te henüz uygulanmaz.
- Küçük/büyük görünüm tek penceredir. Küçült sistem küçültmesidir. Pencereyi kapatma arka planda çalışmayı sürdürür; Çıkış uygulamayı bitirir.

Hesap verilerinin anahtarı Electron safeStorage üzerinden macOS Anahtar Zinciri ile korunur. .NET host'a yalnız çocuk süreç ortamında geçer; renderer'a veya pakete verilmez. AI sayfalarında Node/preload yoktur. Ortak servis stdin/stdout borusu kullanır; ağdan erişilen kontrol sunucusu açılmaz.

İlk dağıtımdan önce Apple Silicon ve Intel Mac'te: açılış, mikrofon, ses modeli, Spotify Otomasyon, Google dönüş bağlantısı, üç AI hesabı, bildirim yanıtları, pencere/arka plan davranışı ve ikinci sürüm indirme testi tamamlanmalıdır. Bu kontroller tamamlanana kadar Windows ve Mac'i birlikte yayımlamayın.

## Bu bilgisayarda doğrulananlar

Ortak .NET servis çekirdeği Apple Silicon ve Intel hedefleri için çapraz derlendi. Kayıt/tamamlama, bilinmeyen işlem reddi, Mac hesap şifreleme ve değiştirilmiş dosya reddi kontrolleri geçti. Beş JavaScript testi yerel arayüzün IPC sınırlarını, güncelleme mimarisini, yeni planda varsayılan modu ve küçük görünüm sekme davranışını doğruladı. Windows temel, Google Calendar hata ve beta dağıtım testleri geçti. Yerel NuGet güvenlik veri sorgusu erişim uyarısı verdi; güvenlik taramasının tamamlandığı iddia edilmez. Mac paketleyicisi Windows'ta `.app` üretimini reddetti; şu an hazır bir Mac kurulum dosyası yoktur.
