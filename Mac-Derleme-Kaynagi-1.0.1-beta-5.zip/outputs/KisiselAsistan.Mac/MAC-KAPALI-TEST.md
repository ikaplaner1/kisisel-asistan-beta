# Mac kapalı test

## Ortak arayüz yolu (19 Ekim 2026)

Mac sürümü artık Windows'taki ekranın **aynısını** kullanır; ayrı bir Mac arayüzü yoktur.

- **Ekran:** `../KisiselAsistan/WorkspaceWeb` (Windows'ta WebView2, Mac'te Electron içinde açılır). Electron onu `assistant://workspace/index.html` adresinden yükler; pakete `resources/workspace` olarak girer. Arayüz `window.chrome.webview` yoksa `window.assistantBridge` köprüsünü kullanır (`desktop/preload.cjs`); ikisi de aynı biçimde konuşur.
- **Servis:** `Host/` (.NET 10) Windows projesindeki `Core`'u referans alır. Arayüzün veri istekleri paylaşılan `WorkspaceApi`'ye, sesli/yazılı komutlar paylaşılan `CommandRunner`'a gider; Windows ile aynı kod çalışır. Mac'e özgü olanlar `Host/MacHost.cs` içindedir: tema kaydı, uygulama listesi (`/Applications`), kısayolları `open` ile açma, Spotify'ı AppleScript ile denetleme, Whisper ile ses çözümleme, Google/Ollama/Spotify hesap işlemleri.
- **Kabuk:** `desktop/main.cjs` pencere (çerçevesiz, küçük/büyük görünüm), AI panelleri (`persist:ai-*` oturumları), dosya seçimi, Steam/Spotify kapak yönlendirmesi (yalnız izinli kapak sunucuları), hatırlatıcı bildirim pencereleri (`ui/notice.*`) ve mikrofon kaydını karşılar. Geri kalan her şey servise gider.
- Eski ayrı Mac arayüzü (`ui/index.html`, `renderer.js`, `style.css`) kaldırıldı; yedek `work/yedek-ortak-arayuz-oncesi-*` altında.

Windows arayüzünde yapılan her değişiklik Mac'e kendiliğinden gelir. Yeni bir köprü işlemi eklenirse: veri işi ise `Core/Workspace/WorkspaceApi.cs`, yalnız pencereyle ilgiliyse hem `Shell/AssistantWindow.Web.cs` (Windows) hem `desktop/main.cjs` veya `Host/MacHost.cs` (Mac).

## Windows'ta deneme

`WindowsDaDene.cmd` Mac servisini Windows için derler ve Electron'u ayrı deneme verisiyle (`work/deneme-verisi`) açar; gerçek verine dokunmaz. Gerekenler: .NET 10 SDK ve `node_modules/electron` (Electron 44.7.0). Duman testi:

```
node_modules\electron\dist\electron.exe . --smoke-test --data work\smoke\data
```

Arayüzün açıldığını, köprüden görev kaydını, komut yolundan hatırlatıcı eklemeyi ve bölüm geçiş olayını dener; `SMOKE_OK` yazar.

## Paket üretme

Apple Silicon için `node build.mjs --arm64`, Intel için `node build.mjs --x64`. Node 24+, .NET 10 SDK ve `npm ci` gerekir; `KisiselAsistan` klasörü yanında durmalıdır (ortak arayüz ve Core oradan alınır). Mac'te DMG ve ZIP üretilir. Windows'ta yalnız servis çekirdeğini çapraz derlemek için `--host-only` kullanılır; paketleyici Windows'tan Mac uygulaması üretimini reddeder.

GitHub özel deposunda aynı klasör düzenini koruyarak yalnız seçilmiş kaynakları yükle. `mac-beta.yml` dosyasını `.github/workflows/mac-beta.yml` konumuna koy. Actions → Mac kapalı test paketleri → Run workflow iki mimariyi Mac derleme makinelerinde üretir. Bu iş akışı otomatik yayın veya davet yapmaz. `ASSISTANT_GITHUB_CLIENT_ID` yayıncıya ait gizli olmayan GitHub App kimliğidir; erişim tokenı paketlenmez.

## Apple imzası ve güncelleme sınırı

Ücretli Apple Developer hesabı olmadığı için Developer ID imzası/noter onayı yoktur. Test Mac'inde Gatekeeper kurulumu engelleyebilir. Güvenlik korumalarını devre dışı bırakmayın; macOS'un sunduğu kullanıcı onayı akışını kullanın.

Mac'te sessiz/otomatik kurulum yoktur; arayüzdeki güncelleme düğmesi Windows'a özgüdür (Mac'te gizli). Mac paketi kapalı test deposundan DMG olarak indirilir ve Finder'dan kurulur.

## Mac'te elle denenmesi gerekenler

Bu kontroller yalnız gerçek bir Mac'te yapılabilir:

- Açılış, çerçevesiz pencerenin marka alanından sürüklenmesi, küçük/büyük görünüm, kapatınca arka planda kalma (Dock'tan geri açılır), Cmd+Q ile çıkış.
- Mikrofon izni; ses modelini (`ggml-small-q5_1.bin`) hata mesajındaki `Models` klasörüne koyup Türkçe sesli komut.
- Spotify: hesap bağlama (PKCE), arama, tek tıkla çalma; yerel oynatma için Otomasyon izni.
- Google Calendar bağlantı JSON'u, giriş ve eşitleme.
- AI sayfasında üç hesaba giriş, ortak soru gönderimi; Google'ın gömülü tarayıcı girişine izin verip vermediği.
- Kısayollarda `/Applications` uygulama seçimi ve çalıştırma; web adımı.
- Hatırlatıcı bildirim pencereleri, ADHD tamamlama onayı.
- Ollama: ollama.com/download/mac adresinden kurulum, sonra model seçimi (Windows'taki taşınabilir kurulum Mac'te yok).

Hesap verilerinin anahtarı Electron safeStorage üzerinden macOS Anahtar Zinciri ile korunur; .NET servisine yalnız çocuk süreç ortamında geçer. AI sayfalarında Node/preload yoktur. Ortak servis stdin/stdout borusu kullanır; ağdan erişilen kontrol sunucusu açılmaz.

## Bu bilgisayarda doğrulananlar (Windows, 19 Ekim 2026)

Mac servisi Core üzerine yeniden kuruldu ve derlendi; öz testi (ortak arayüz anlık görüntüsü, form kaydı, komut yolu, hesap şifreleme) geçti. Altı JavaScript testi (köprü, arayüz dosya sınırı, kapak yönlendirme sınırı, güncelleme mimarisi) geçti. Electron 44.7.0 Windows'ta ortak arayüzü açtı ve duman testi geçti. Gerçek Mac'te açılış, izinler ve DMG henüz denenmedi; şu an hazır bir Mac kurulum dosyası yoktur.
