using System.Text.Json;

namespace KisiselAsistan;

internal static class ChatSendScript
{
    #if WINDOWS
    internal static async Task<string> ExecuteAsync(Microsoft.Web.WebView2.Core.CoreWebView2 core, string provider, string text)
    {
        var prepared = await EvaluateAsync(core, Build(provider, text, "prepare"));
        if (prepared != "hazır") return prepared;
        // Feed Chromium's editing pipeline so rich editors receive native input
        // events instead of only a manually changed DOM and synthetic events.
        try { await core.CallDevToolsProtocolMethodAsync("Input.insertText", JsonSerializer.Serialize(new { text })); }
        catch { return "metni kutuya yerleştiremedim"; }
        return await EvaluateAsync(core, Build(provider, text, "submit"));
    }
    internal static Task<string> ProbeAsync(Microsoft.Web.WebView2.Core.CoreWebView2 core, string provider)
        => EvaluateAsync(core, Build(provider, "", "probe"));
    private static async Task<string> EvaluateAsync(Microsoft.Web.WebView2.Core.CoreWebView2 core, string script)
    {
        var key = "__assistantSend_" + Guid.NewGuid().ToString("N");
        var quoted = JsonSerializer.Serialize(key);
        await core.ExecuteScriptAsync("window[" + quoted + "] = null; " + script + ".then(r => window[" + quoted + "] = r).catch(() => window[" + quoted + "] = 'gönderilemedi, paneli kontrol et'); void 0;");
        try {
            for (var i = 0; i < 40; i++) {
                await Task.Delay(200);
                var result = await core.ExecuteScriptAsync("window[" + quoted + "] ?? null");
                if (result != "null") return JsonSerializer.Deserialize<string>(result) ?? "gönderilemedi";
            }
            return "sonuç doğrulanamadı, paneli kontrol et";
        } finally { try { await core.ExecuteScriptAsync("delete window[" + quoted + "]"); } catch { } }
    }
    #endif
    internal static string Build(string provider, string text, string mode = "submit") => "(async () => { const provider = " + JsonSerializer.Serialize(provider) + "; const text = " + JsonSerializer.Serialize(text) + "; const mode = " + JsonSerializer.Serialize(mode) + ";" + Body + "})()";
    internal const string Body = """
        const hosts = {chatgpt: 'chatgpt.com', gemini: 'gemini.google.com', claude: 'claude.ai'};
        if (location.hostname !== hosts[provider]) return 'ana sohbet sayfasını aç';
        const visible = e => {
          if (!e || !e.getClientRects().length || e.closest('[aria-hidden="true"],[inert],[hidden]')) return false;
          const r = e.getBoundingClientRect(), style = getComputedStyle(e);
          return r.width > 2 && r.height > 2 && style.visibility !== 'hidden' && style.display !== 'none';
        };
        const first = selectors => selectors.flatMap(s => [...document.querySelectorAll(s)]).find(visible);
        const config = {
          chatgpt: {editor:['#prompt-textarea','[contenteditable="true"][data-testid="prompt-textarea"]','form [contenteditable="true"][role="textbox"]'], send:['button[data-testid="send-button"]','button[data-testid="composer-send-button"]','button[aria-label="Send prompt" i]','button[aria-label="Send message" i]','button[aria-label="İstem gönder" i]','button[aria-label="Mesaj gönder" i]'], stop:['button[data-testid="stop-button"]']},
          gemini: {editor:['input-area-v2 rich-textarea [contenteditable="true"]','input-area rich-textarea [contenteditable="true"]','.input-area-container rich-textarea [contenteditable="true"]','main rich-textarea [contenteditable="true"]','rich-textarea [contenteditable="true"]','.ql-editor[contenteditable="true"]','[contenteditable="true"][role="textbox"][aria-multiline="true"]'], send:['button.send-button','button[aria-label="Send message" i]','button[aria-label="Send prompt" i]','button[aria-label="Gönder" i]','button[aria-label="Mesaj gönder" i]','button[aria-label="İstem gönder" i]'], stop:['button[aria-label="Stop response" i]','button[aria-label="Yanıtı durdur" i]']},
          claude: {editor:['div.ProseMirror[contenteditable="true"]','[contenteditable="true"][data-testid="chat-input"]'], send:['button[aria-label="Send message" i]','button[aria-label="Mesaj gönder" i]','button[data-testid="send-button"]'], stop:['button[aria-label="Stop response" i]']}
        }[provider];
        if (!config) return 'desteklenmeyen hizmet';
        const responding = () => { const stop = first(config.stop); return stop && !stop.disabled && stop.getAttribute('aria-disabled') !== 'true'; };
        if (responding()) return 'yanıt sürüyor, bitmesini bekle';
        // Prefer the service's primary composer. An unrelated editable field
        // must not make an otherwise unambiguous main chat box fail.
        let candidates = [];
        for (const selector of config.editor) {
          const matches = [...document.querySelectorAll(selector)].filter(visible);
          candidates = matches.filter(e => !matches.some(other => other !== e && e.contains(other)));
          if (candidates.length) break;
        }
        if (!candidates.length && provider === 'chatgpt') {
          for (const selector of ['main form [contenteditable="true"]','main textarea[placeholder]','main [contenteditable="plaintext-only"][role="textbox"]']) {
            candidates = [...document.querySelectorAll(selector)].filter(visible);
            if (candidates.length) break;
          }
        }
        if (candidates.length > 1) return 'birden fazla mesaj kutusu var, panelden gönder';
        const editor = candidates[0];
        if (!editor) return 'giriş yap veya sohbet ekranını aç';
        const read = () => ('value' in editor ? editor.value : editor.innerText).trim();
        if (editor.disabled || editor.readOnly || editor.getAttribute('aria-disabled') === 'true') return 'mesaj kutusu hazır değil';
        const pause = ms => new Promise(r => setTimeout(r, ms));
        if (mode === 'probe') return 'hazır';
        if (mode === 'prepare') {
          if (read()) return 'paneldeki taslağı önce temizle';
          editor.focus();
          if ('value' in editor) editor.setSelectionRange(editor.value.length, editor.value.length);
          else {
            const range = document.createRange(); range.selectNodeContents(editor); range.collapse(false);
            const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range);
          }
          return document.activeElement === editor || editor.contains(document.activeElement) ? 'hazır' : 'mesaj kutusu odaklanamadı';
        }
        const findSend = () => {
          const configured = first(config.send);
          if (configured) return configured;
          // Restrict the fallback to the editor's own form. Never submit a login
          // or unrelated form elsewhere on the same host.
          const form = editor.closest('form');
          return form && [...form.querySelectorAll('button[type="submit"]')].filter(visible).length === 1
            ? [...form.querySelectorAll('button[type="submit"]')].find(visible) : null;
        };
        let button;
        for (let i=0;i<20;i++) {
          if (read().replace(/\s+/g,' ') !== text.trim().replace(/\s+/g,' ')) return 'metni panelde kontrol et';
          button = findSend();
          if (button && !button.disabled && button.getAttribute('aria-disabled') !== 'true') break;
          button = null; await pause(100);
        }
        if (!button) return 'metin hazır, panelden gönder';
        button.click();
        for (let i=0;i<20;i++) { await pause(100); if (!read() || responding()) return 'gönderildi'; }
        return 'gönderme denendi, paneli kontrol et';
    """;
}

