using System.Text.RegularExpressions;

namespace KisiselAsistan;

// Bu bilgisayarda Steam'e giriş yapmış hesabı bulur (istek listesini profil bağlantısı sormadan almak için).
// Steam hesapları kendi klasöründeki config\loginusers.vdf dosyasında tutar: SteamID, görünen ad, "MostRecent".
// Şifre ya da oturum bilgisi okunmaz; dosyada yalnız bunlar aranır. Windows'ta Steam'in açık hesabı (kayıt defterindeki
// ActiveUser) önceliklidir; yoksa en son giriş yapılan, o da yoksa ilk hesap seçilir.
public sealed record SteamAccount(string SteamId, string Name);
public static class SteamLocalAccount
{
    private const ulong IndividualBase = 76561197960265728;
    private static readonly Regex Block = new(@"""(7656\d{13})""\s*\{([^{}]*)\}", RegexOptions.Singleline);
    private static string? Value(string body, string key) => Regex.Match(body, $@"""{key}""\s*""([^""]*)""", RegexOptions.IgnoreCase) is { Success: true } m ? m.Groups[1].Value : null;

    public static List<(SteamAccount Account, bool MostRecent)> Parse(string vdf)
        => Block.Matches(vdf ?? "").Select(m => (new SteamAccount(m.Groups[1].Value, Value(m.Groups[2].Value, "PersonaName") ?? Value(m.Groups[2].Value, "AccountName") ?? "Steam hesabı"), Value(m.Groups[2].Value, "MostRecent") == "1")).ToList();

    // activeAccountId: Steam'in 32 bit hesap numarası (Windows kayıt defteri ActiveUser; 0 = kimse açık değil).
    public static SteamAccount? Find(IEnumerable<string> loginUsersFiles, uint activeAccountId = 0)
    {
        foreach (var file in loginUsersFiles.Distinct(StringComparer.OrdinalIgnoreCase)) {
            string text;
            try { if (!File.Exists(file)) continue; text = File.ReadAllText(file); }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { continue; }
            var accounts = Parse(text);
            if (accounts.Count == 0) continue;
            var active = activeAccountId == 0 ? null : (IndividualBase + activeAccountId).ToString();
            return accounts.FirstOrDefault(a => a.Account.SteamId == active).Account
                ?? accounts.FirstOrDefault(a => a.MostRecent).Account
                ?? accounts[0].Account;
        }
        return null;
    }
    // Steam'in olağan kurulum yerleri (Windows kayıt defterindeki klasör ayrıca eklenir).
    public static IEnumerable<string> DefaultFiles(string? steamFolder = null)
    {
        if (!string.IsNullOrWhiteSpace(steamFolder)) yield return Path.Combine(steamFolder, "config", "loginusers.vdf");
        if (OperatingSystem.IsWindows()) {
            foreach (var root in new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) })
                if (!string.IsNullOrEmpty(root)) yield return Path.Combine(root, "Steam", "config", "loginusers.vdf");
        } else {
            var home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            yield return Path.Combine(home, "Library", "Application Support", "Steam", "config", "loginusers.vdf");
            yield return Path.Combine(home, ".steam", "steam", "config", "loginusers.vdf");
        }
    }
}
