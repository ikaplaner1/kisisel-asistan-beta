const providers = Object.freeze({chatgpt:'https://chatgpt.com/',gemini:'https://gemini.google.com/',claude:'https://claude.ai/'});
function externalUrl(value) { try { const url = new URL(value); return ['https:','http:'].includes(url.protocol) && !url.username && !url.password; } catch { return false; } }
function trustedUi(url, entry) { return url === entry; }
function releaseAsset(assets, arch) { return assets.find(a => a.name.endsWith(`-mac-${arch}.dmg`) && /^https:\/\/api\.github\.com\/repos\/[^/]+\/[^/]+\/releases\/assets\/\d+$/.test(a.url)); }
module.exports = {providers, externalUrl, trustedUi, releaseAsset};
