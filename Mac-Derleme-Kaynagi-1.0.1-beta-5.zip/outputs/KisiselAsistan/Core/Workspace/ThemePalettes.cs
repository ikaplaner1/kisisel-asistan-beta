namespace KisiselAsistan;

// Temaların renkleri (platformdan bağımsız, onaltılık). Windows (Shell/Look/ThemeSettings) ve Mac aynı paleti kullanır.
// Renk uyumu: zemin nötre yakın (60), kart ve yazı (30), vurgu (10). Her temada ana vurgunun yanında renk çarkında
// karşısındaki (tamamlayıcı) ya da yanındaki (komşu) ikinci bir renk vardır; saatlerde, ilerleme çubuğunda ve
// "şimdi" çizgisinde kullanılır ("numbers" rolü). Sıra: zemin, kart, seçili, yazı, soluk yazı, vurgu, çizgi,
// ikinci renk, başlık (yazıyla aynı). Açık temalarda ikinci renk küçük yazıda okunacak kadar koyudur.
public static class ThemePalettes
{
    public static readonly string[] Names = ["Adaçayı", "Kum", "Açık", "Gece mavisi", "Koyu", "Orman", "Alacakaranlık", "Okyanus"];
    public const string Default = "Koyu";
    public static string[] Hex(string name)
    {
        string[] values = name switch {
            "Adaçayı" => ["#F3F4F0", "#FFFFFF", "#E4EADF", "#1F2A24", "#6B756E", "#2F6B4F", "#E1E4DC", "#B35A31"],
            "Kum" => ["#F6F1E9", "#FFFCF7", "#EDE2D0", "#2F271D", "#7A6B58", "#B4552C", "#E6DCCB", "#2C7C78"],
            "Açık" => ["#F4F5F8", "#FFFFFF", "#E3E8F4", "#1C2230", "#667085", "#3B5BDB", "#E1E4EA", "#C2621F"],
            "Gece mavisi" => ["#0F1424", "#171E33", "#26304D", "#E8ECF8", "#99A3BF", "#8E9CFF", "#252E48", "#F2B66D"],
            "Orman" => ["#111A16", "#18241F", "#253830", "#E7F0EA", "#9BB0A3", "#7FD49A", "#24332C", "#E3C16A"],
            "Alacakaranlık" => ["#1A1724", "#231F31", "#342E47", "#F1ECFA", "#ABA2BF", "#C49BFF", "#2F2A40", "#FF9DB4"],
            "Okyanus" => ["#0F1E24", "#162A31", "#21404A", "#E6F4F7", "#93AEB6", "#5CCFE3", "#22383F", "#FF8F6B"],
            _ => ["#121417", "#1B1E23", "#2A2F36", "#ECEEF1", "#9AA1AB", "#4FD1A5", "#272B31", "#F07A6A"]
        };
        return [.. values, values[3]];
    }
    // Zeminin parlaklığına göre koyu tema mı (arayüzde renk şeması için).
    public static bool IsDark(string backgroundHex)
    {
        var value = Convert.ToInt32(backgroundHex.TrimStart('#'), 16);
        return ((value >> 16) * 0.299 + ((value >> 8) & 255) * 0.587 + (value & 255) * 0.114) < 128;
    }
    public static bool Valid(string name, IReadOnlyList<string> colors) =>
        Names.Contains(name) && colors.Count == 9 && colors.All(c => System.Text.RegularExpressions.Regex.IsMatch(c, "^#[0-9a-fA-F]{6}$"));
}
