using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text.Json;

namespace KisiselAsistan;

// Telefona bildirim ve telefondan ekleme: ntfy (ntfy.sh ya da kendi sunucun). Hesap ve anahtar gerekmez.
// - Telefona: hatırlatmanın ilk bildirimi ve sabah özeti ntfy konusuna gönderilir (ShowDetails kapalıysa yalnız "bir hatırlatman var").
// - Telefondan: aynı konuya yazılan mesajlar okunur ve YALNIZ hızlı eklemeden geçer (görev/hatırlatıcı/bir ara); başka komut çalışmaz.
// GÜVENLİK: konu adı şifre gibidir — bilen herkes bildirimleri okuyabilir ve konuya yazabilir. Bu yüzden rastgele üretilir,
// kullanıcı hesabına bağlı şifreyle (Windows: WindowsSecret) saklanır ve yalnız istenince gösterilir. ntfy.sh sunucusu mesaj metnini görür.
public sealed record PhoneSettings(bool Enabled = true, bool ShowDetails = true, string Server = "https://ntfy.sh")
{
    public void Validate()
    {
        if (!Uri.TryCreate(Server, UriKind.Absolute, out var uri) || uri.Scheme != "https" || !string.IsNullOrEmpty(uri.UserInfo)) throw new ArgumentException("Sunucu adresi https:// ile başlamalı.");
    }
}

public sealed class PhoneLink(HttpClient http, string folder, Func<byte[], byte[]> protect, Func<byte[], byte[]> unprotect, Func<DateTimeOffset>? clock = null)
{
    public const string OwnTag = "kisisel-asistan";   // bizim gönderdiklerimiz; gelen kutusunda atlanır
    public const int MaxInbound = 10, MaxText = 500;
    private sealed record State(string? LastId, long LinkedAt);
    private readonly JsonListStore<PhoneSettings> settings = new(Path.Combine(folder, "phone-settings.json"));
    private readonly JsonListStore<State> state = new(Path.Combine(folder, "phone-state.json"));
    private readonly string topicPath = Path.Combine(folder, "phone-topic.bin");
    private DateTimeOffset Now => clock?.Invoke() ?? DateTimeOffset.Now;
    private string? cachedTopic; private bool topicRead;

    public PhoneSettings Settings => settings.Read().FirstOrDefault() ?? new();
    public void Save(PhoneSettings value) { value.Validate(); settings.Modify(_ => [value]); }
    public string? Topic
    {
        get {
            if (topicRead) return cachedTopic;
            topicRead = true;
            try { cachedTopic = File.Exists(topicPath) ? System.Text.Encoding.UTF8.GetString(unprotect(File.ReadAllBytes(topicPath))) : null; }
            catch (Exception ex) when (ex is CryptographicException or IOException) { cachedTopic = null; }
            return cachedTopic;
        }
    }
    public bool Linked => Topic != null;
    public bool Active => Linked && Settings.Enabled;
    public object Status() => new { linked = Linked, enabled = Settings.Enabled, showDetails = Settings.ShowDetails, server = Settings.Server };

    // Yeni, tahmin edilemez konu: "asistan-" + 26 rastgele harf/rakam (~130 bit).
    public string Link()
    {
        const string alphabet = "abcdefghijkmnpqrstuvwxyz23456789";
        var topic = "asistan-" + new string(RandomNumberGenerator.GetBytes(26).Select(b => alphabet[b % alphabet.Length]).ToArray());
        Directory.CreateDirectory(folder);
        File.WriteAllBytes(topicPath, protect(System.Text.Encoding.UTF8.GetBytes(topic)));
        cachedTopic = topic; topicRead = true;
        state.Modify(_ => [new State(null, Now.ToUnixTimeSeconds())]);
        if (!settings.Read().Any()) Save(new());
        return topic;
    }
    public void Unlink()
    {
        try { File.Delete(topicPath); } catch (IOException) { }
        cachedTopic = null; topicRead = true;
        state.Modify(_ => []);
    }

    // Telefona gönder. Ağ hatası işi bozmaz (false döner); hatırlatma bilgisayarda yine gösterilir.
    public async Task<bool> SendAsync(string title, string message, CancellationToken token = default, bool force = false)
    {
        if (Topic is not { } topic || (!force && !Settings.Enabled)) return false;
        var s = Settings;
        var body = new { topic, title = s.ShowDetails || force ? title : "Kişisel Asistan", message = s.ShowDetails || force ? message : "Bir hatırlatman var (ayrıntılar bilgisayarda).", tags = new[] { OwnTag } };
        try {
            using var response = await http.PostAsJsonAsync(s.Server.TrimEnd('/'), body, token);
            return response.IsSuccessStatusCode;
        } catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException) { return false; }
    }

    // Telefondan gelen yeni mesajlar (bizim gönderdiklerimiz hariç). İlk okumada yalnız bağlandıktan sonrakiler.
    public async Task<IReadOnlyList<string>> ReceiveAsync(CancellationToken token = default)
    {
        if (!Active || Topic is not { } topic) return [];
        var current = state.Read().FirstOrDefault() ?? new State(null, Now.ToUnixTimeSeconds());
        var since = current.LastId ?? current.LinkedAt.ToString();
        string text;
        try { text = await http.GetStringAsync($"{Settings.Server.TrimEnd('/')}/{Uri.EscapeDataString(topic)}/json?poll=1&since={Uri.EscapeDataString(since)}", token); }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException) { return []; }
        var result = new List<string>(); var last = current.LastId;
        foreach (var line in text.Split('\n', StringSplitOptions.RemoveEmptyEntries)) {
            try {
                using var doc = JsonDocument.Parse(line); var root = doc.RootElement;
                if (root.TryGetProperty("id", out var id)) last = id.GetString() ?? last;
                if (root.GetProperty("event").GetString() != "message") continue;
                if (root.TryGetProperty("tags", out var tags) && tags.EnumerateArray().Any(t => t.GetString() == OwnTag)) continue;
                var message = root.TryGetProperty("message", out var m) ? m.GetString()?.Trim() ?? "" : "";
                if (message.Length is > 0 and <= MaxText && result.Count < MaxInbound) result.Add(message);
            } catch (Exception ex) when (ex is JsonException or KeyNotFoundException or InvalidOperationException) { }
        }
        if (last != current.LastId) state.Modify(_ => [current with { LastId = last }]);
        return result;
    }
}

// Telefondan gelen metni hızlı eklemeden geçirir: saat varsa hatırlatıcı, "bir ara …" tarihsiz görev, gerisi bugünün görevi.
public static class QuickAdd
{
    public static string Save(ItemEditor editor, ReminderDefaults defaults, string text, DateTimeOffset now)
    {
        var when = WhenParser.Parse(text, now);
        var title = when.Text.Trim();
        if (title.Length == 0) throw new ArgumentException("Ne ekleneceği anlaşılmadı.");
        if (when.Due is { } due) {
            var local = due.LocalDateTime;
            if (due <= now) throw new ArgumentException("Geçmiş bir saat: " + local.ToString("dd.MM HH:mm"));
            editor.Save(new ItemForm(null, title, DateOnly.FromDateTime(local), local.Hour * 60 + local.Minute, Notify: defaults.Options));
            return $"Hatırlatıcı eklendi: {title} · {local:dd.MM HH:mm}";
        }
        if (when.Someday) { editor.Save(new ItemForm(null, title)); return "Bir ara listesine eklendi: " + title; }
        var day = when.Day ?? DateOnly.FromDateTime(now.LocalDateTime);
        editor.Save(new ItemForm(null, title, day));
        return $"Görev eklendi: {title}" + (day == DateOnly.FromDateTime(now.LocalDateTime) ? " · bugün" : $" · {day:dd.MM}");
    }
}
