"use strict";
// Ayarlar: üst çubukta, alt şeritte ve ayrı pencerelerde dağınık duran ayarlar tek sayfada.
// Her satır mevcut ayar penceresini açar (dialogs.js); işlem adları data-action ile aynıdır.

function SettingsPage() {
  const live = state.data.live || {},
    defaults = state.data.defaults || {};
  const row = (title, note, action, label, icon = "") =>
    html`<div class="settings-row"><div class="item-copy"><strong>${title}</strong><small>${note}</small></div><${Button} action=${action} icon=${icon} cls="ghost">${label}<//></div>`;
  const sections = [
    ["Görünüm", [
      row("Tema", live.theme || "", "theme", "Değiştir", "palette"),
      row("Pencere", live.compact ? "Küçük görünüm" : "Büyük görünüm", "view", live.compact ? "Büyüt" : "Küçült", "expand"),
      html`<label class="settings-row"><div class="item-copy"><strong>Arayüz sesleri</strong><small>Tamamlayınca, gün bitince ve ekleyince kısa bir ses</small></div><input type="checkbox" class="switch" id="ui-sounds" checked=${soundsOn()} onChange=${(e) => { setSoundsOn(e.target.checked); if (e.target.checked) playSound("done", true); }} /></label>`,
    ]],
    ["Hatırlatma", [
      row("Varsayılan hatırlatma", defaults.name ? `${defaults.name}${defaults.level === "Adhd" ? " · yapana kadar ısrar eder" : ""}` : "", "defaults", "Değiştir", "clock"),
      row("Plan tercihleri", "Boş saatlerin, uyku, mola ve günlük yük; öneri ve “Günü planla” bunlara göre", "preferences", "Değiştir", "calendar"),
      state.data.reminders.some((r) => r.done) && row("Tamamlananları temizle", "Tamamlanan tek seferlik hatırlatıcı kayıtlarını siler", "reminder-clear", "Temizle", "trash"),
    ]],
    ["Ses ve komutlar", [
      row("Mikrofon ve dil", "Konuşma dili, mikrofon ve konuşma arası bekleme", "speech-settings", "Değiştir", "mic"),
      row("Komut örnekleri", "Sesli ve yazılı komutlar; her yerden Ctrl+K", "help", "Göster", "help"),
    ]],
    ["Bağlantılar", [
      row("Google Takvim", "Saatli işler telefonundaki takvimde de görünür", "google", "Aç", "calendar"),
      row("Spotify", "Arama, çalma ve ses için hesap bağlantısı", "spotify-settings", "Aç", "music"),
      row("Ollama (yerel model)", "Kalıba uymayan komutları bilgisayarındaki model yorumlar", "ollama", "Aç", "ai"),
    ]],
    ...(live.developer ? [["Geliştirici", [row("Sürüm yayınla", "Windows paketini GitHub'a yükler", "publish", "Aç", "code")]]] : []),
  ];
  return html`<${Heading} title="Ayarlar" sub="Bütün ayarlar tek yerde." />
    <div class="settings-page">${sections.map(([title, rows]) => html`<section class="settings-section"><h2>${title}</h2><div class="settings-rows">${rows}</div></section>`)}</div>`;
}
pageComponents.settings = SettingsPage;
