using System.Diagnostics;
using System.Text.Json;

namespace KisiselAsistan;

// Mac'teki hizmetler (Windows'taki AppServices'in karşılığı) ve Electron ile konuşma.
// İstek: {"id","method","params"}  ·  Yanıt: {"id","success","result"|"error"}  ·  Olay: {"event","data"}
// "workspace" yöntemi arayüzün (WorkspaceWeb) isteklerini taşır: {"method","params"} → WorkspaceApi.
internal sealed class MacHost : IWorkspaceHost, ICommandSurface, IDisposable
{
    private readonly TextWriter output;
    private readonly bool testing;
    private readonly object writeLock = new();
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(90) };
    private readonly ReminderDefaults defaults = new();
    private readonly ItemStore items;
    internal readonly ReminderService Reminders;
    private readonly IReminderService reminderOperations;
    internal readonly TaskRoutineService Tasks;
    private readonly ItemEditor editor;
    private readonly RoutineService routines;
    private readonly RoutineRunner routineRunner;
    private readonly SteamClient steamClient = new();
    internal readonly SteamService Steam;
    private readonly SpotifyAccount spotifyAccount = new();
    private readonly OllamaSettingsStore ollamaSettings = new();
    private readonly OllamaInterpreter ollama;
    private readonly GoogleCalendarConnection? google;
    private readonly GithubBetaAccount github = new();
    internal readonly OperationRegistry Operations = new();
    internal readonly CommandRunner Commands;
    internal readonly WorkspaceApi Workspace;
    private readonly MacThemeStore themes = new();
    private readonly Dictionary<string, ReminderPrompt> prompts = [];
    private readonly Queue<string> notices = new();
    private DateTimeOffset nextSteam = DateTimeOffset.MinValue;
    private CancellationTokenSource? command, googleWork;
    private WhisperSpeechToText? whisper;
    private bool compact, listening;
    private string phase = "Hazır", status = "Hazır.", heard = "", language = "tr";

    internal MacHost(TextWriter output, bool testing = false)
    {
        this.output = output; this.testing = testing;
        items = ItemStore.Open(DeploymentPaths.Data("items.json"), DeploymentPaths.Data("reminders.json"), DeploymentPaths.Data("routine-tasks.json"), DeploymentPaths.Data("yedek"));
        var reminderStore = new ReminderStore(items);
        Reminders = new(reminderStore, defaultOptions: () => defaults.Options);
        reminderOperations = new OperationReminderService(Reminders, Operations);
        Tasks = new(items);
        editor = new(items, reminderStore.Locate);
        routines = new(DeploymentPaths.Data("routines.json"), reminderOperations);
        routineRunner = new(routines, MacApplications.LaunchAsync);
        Steam = new(steamClient, new SteamWatchStore(DeploymentPaths.Data("steam-watches.json")));
        Steam.Register(Operations);
        new SpotifyService(new SpotifyController(new MacSpotifyTransport()), new SpotifyPlayback(spotifyAccount, http)).Register(Operations);
        TaskOperations.Register(Operations, Tasks);
        Operations.Register<RoutineNameRequest, CommandResult>("routine.start", "Kısayolu adıyla başlat", r => routineRunner.StartNamed(r.Name));
        ollama = new(http, Operations, () => ollamaSettings.Current);
        if (!testing) google = new(Reminders);
        Commands = new(Operations, reminderOperations, Tasks, Steam, ollama, () => ollamaSettings.Current.Enabled, this);
        Workspace = new(new(items, Reminders, Tasks, editor, routines, Steam, defaults, Operations, Commands), this);
        Reminders.Changed += () => Emit("refresh");
        defaults.Changed += () => Emit("refresh");
        Steam.Changed += () => Emit("refresh");
        Steam.Released += Notice; Steam.Updated += Notice;
        routineRunner.Changed += () => Emit("state", Live());
        if (google != null) google.StatusChanged += text => { status = text; Emit("google", text); };
    }
    private void Notice(string text) { lock (notices) notices.Enqueue(text); status = text; }

    // ---------------------------------------------------------------- Electron ile konuşma
    internal void Emit(string name, object? data = null)
    {
        var line = JsonSerializer.Serialize(new { @event = name, data }, WorkspaceApi.Json);
        lock (writeLock) { output.WriteLine(line); output.Flush(); }
    }
    internal async Task RunAsync(TextReader input)
    {
        while (await input.ReadLineAsync() is { } line) _ = HandleAsync(line);
    }
    internal async Task HandleAsync(string line)
    {
        string? id = null; string reply;
        try {
            using var request = JsonDocument.Parse(line);
            id = request.RootElement.GetProperty("id").GetString();
            var parameters = request.RootElement.TryGetProperty("params", out var p) ? p.Clone() : JsonSerializer.SerializeToElement(new { });
            var result = await DispatchAsync(request.RootElement.GetProperty("method").GetString()!, parameters);
            reply = JsonSerializer.Serialize(new { id, success = true, result }, WorkspaceApi.Json);
        } catch (Exception e) {
            reply = JsonSerializer.Serialize(new { id, success = false, error = e is OperationCanceledException ? "İşlem zaman aşımına uğradı." : e.Message }, WorkspaceApi.Json);
        }
        lock (writeLock) { output.WriteLine(reply); output.Flush(); }
    }
    internal async Task<object?> DispatchAsync(string method, JsonElement p)
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromMinutes(10));
        var token = timeout.Token;
        switch (method) {
            case "workspace": return await Workspace.DispatchAsync(p.GetProperty("method").GetString()!, p.TryGetProperty("params", out var inner) ? inner : JsonSerializer.SerializeToElement(new { }));
            case "live": return Live();
            case "compact": compact = p.GetProperty("compact").GetBoolean(); return Live();
            case "listening": listening = p.GetProperty("listening").GetBoolean(); phase = p.TryGetProperty("phase", out var ph) ? ph.GetString() ?? phase : phase; return Live();
            // Mikrofon kaydı Electron'da alınır (16 kHz mono); burada yerel Whisper ile metne çevrilir.
            case "speech.transcribe": {
                var samples = p.GetProperty("samples").Deserialize<float[]>()!;
                if (samples.Length is < 4000 or > 16000 * 60 || samples.Any(x => !float.IsFinite(x))) throw new ArgumentException("Ses kaydı 0,25–60 saniye olmalı.");
                var model = DeploymentPaths.SpeechModel;
                if (!File.Exists(model)) throw new InvalidOperationException("Ses modeli yok. Ses Paketi'ndeki ggml-small-q5_1.bin dosyasını şu klasöre koy: " + DeploymentPaths.Data("Models"));
                whisper ??= new WhisperSpeechToText(model);
                var names = Steam.Items.Select(w => w.Name).Concat(routines.Items.Select(r => r.Name)).ToList();
                heard = await whisper.TranscribeAsync(new(samples), new(language, names), token);
                return heard;
            }
            case "tick": {
                foreach (var prompt in Reminders.Poll()) prompts[Guid.NewGuid().ToString("N")] = prompt;
                foreach (var key in prompts.Where(x => !Reminders.IsCurrent(x.Value)).Select(x => x.Key).ToArray()) prompts.Remove(key);
                if (google != null) await google.TickAsync();
                if (DateTimeOffset.Now >= nextSteam && !testing) { nextSteam = DateTimeOffset.Now.AddMinutes(30); try { await Steam.CheckAsync(token); } catch (Exception ex) when (ex is HttpRequestException or InvalidOperationException) { } }
                string[] events; lock (notices) { events = notices.ToArray(); notices.Clear(); }
                return new { prompts = prompts.Select(x => new { id = x.Key, prompt = x.Value }).ToArray(), notices = events };
            }
            case "reminder.respond": {
                var key = p.GetProperty("id").GetString()!;
                if (!prompts.Remove(key, out var prompt)) return null;
                var next = Reminders.Respond(prompt, Enum.Parse<ReminderResponse>(p.GetProperty("response").GetString()!), p.TryGetProperty("minutes", out var minutes) ? minutes.GetInt32() : 5);
                if (next is null) return null;
                var nextKey = Guid.NewGuid().ToString("N"); prompts[nextKey] = next; return new { id = nextKey, prompt = next };
            }
            case "chat.script": return ChatSendScript.Build(p.GetProperty("provider").GetString()!, p.GetProperty("text").GetString()!, p.GetProperty("mode").GetString()!);
            case "github.settings": return BetaReleaseSettings.Load();
            case "github.token": { var settings = BetaReleaseSettings.Load(); if (!github.Connected(settings.GithubClientId)) throw new InvalidOperationException("Önce GitHub hesabını bağla."); return new { token = github.Session!.AccessToken, settings.RepositoryUrl }; }
            case "github.connect": {
                var settings = new BetaReleaseSettings(p.GetProperty("repositoryUrl").GetString()!, p.GetProperty("githubClientId").GetString()!); settings.Save();
                await github.ConnectAsync(settings.GithubClientId, code => Emit("github.code", code), token); return github.Session!.Login;
            }
            case "github.disconnect": github.Disconnect(); return true;
        }
        throw new ArgumentException("Desteklenmeyen işlem.");
    }

    // ---------------------------------------------------------------- IWorkspaceHost
    public bool Testing => testing;
    public object Live()
    {
        var (name, colors) = themes.Load(compact);
        return new {
            compact, colors, dark = ThemePalettes.IsDark(colors[0]), theme = name, phase, status,
            busy = command != null || listening, listening, routineStatus = routineRunner.Running ? routineRunner.State : "",
            update = false, developer = false, platform = "mac"
        };
    }
    public IReadOnlyList<WorkspaceTheme> Themes() => ThemePalettes.Names.Select(n => new WorkspaceTheme(n, ThemePalettes.Hex(n))).ToList();
    public void CompleteReminder(Guid id)
    {
        // ADHD hatırlatmasında "yaptım" ayrıca onaylanır: onay bildirimi Electron'un bildirim penceresinde açılır.
        var prompt = Reminders.RequestCompletion(id);
        if (prompt is null) return;
        var key = Guid.NewGuid().ToString("N"); prompts[key] = prompt;
        Emit("prompt", new { id = key, prompt });
    }
    async Task<object?> IWorkspaceHost.DispatchAsync(string method, JsonElement p)
    {
        string Text(string key) => p.GetProperty(key).GetString() ?? "";
        switch (method) {
            case "section": return true;
            case "theme.apply": {
                var name = Text("name"); var colors = p.GetProperty("colors").Deserialize<string[]>() ?? [];
                if (!ThemePalettes.Valid(name, colors)) throw new ArgumentException("Tema renkleri geçersiz.");
                if (!testing) themes.Save(compact, name, colors);
                Emit("state", Live()); return true;
            }
            case "speech.command": {
                if (command != null) throw new InvalidOperationException("Önceki işlemin tamamlanmasını bekle.");
                command = new();
                try {
                    phase = "Çalıştırıyorum"; status = "Komut işleniyor…"; Emit("state", Live());
                    var outcome = await Commands.RunAsync(Text("text"), Commands.LastApp, command.Token);
                    status = outcome.Message; phase = outcome.Phase;
                } finally { command.Dispose(); command = null; Emit("state", Live()); Emit("refresh"); }
                return true;
            }
            case "speech.cancel": command?.Cancel(); return true;
            case "speech.settings": return new {
                heard = heard.Length == 0 ? "Henüz bir şey duyulmadı." : "Son duyulan: " + heard,
                microphones = new[] { "Sistem mikrofonu" }, microphone = 0, language = language == "tr" ? 1 : 0, wait = 1,
                model = File.Exists(DeploymentPaths.SpeechModel)
            };
            case "speech.configure": language = p.GetProperty("language").GetInt32() == 0 ? "en" : "tr"; return true;
            case "routine.run": if (testing) throw new InvalidOperationException("Testte uygulama başlatılmaz."); routineRunner.Start(p.GetProperty("id").GetGuid()); return true;
            case "routine.stop": routineRunner.Stop(); return true;
            case "apps.list": return MacApplications.List();
            case "google.status": return new { status = google?.Status ?? "Test görünümünde Google bağlantısı kapalı.", available = google != null };
            case "google.import": Google().ImportCredentials(Text("json")); return Google().Status;
            case "google.connect": case "google.sync": case "google.disconnect": {
                var connection = Google(); googleWork?.Cancel(); googleWork = new();
                await (method == "google.connect" ? connection.ConnectAsync(googleWork.Token) : method == "google.sync" ? connection.SyncNowAsync(googleWork.Token) : connection.DisconnectAsync(googleWork.Token));
                return connection.Status;
            }
            case "google.cancel": googleWork?.Cancel(); return true;
            case "ollama.get": return new { enabled = ollamaSettings.Current.Enabled, model = ollamaSettings.Current.Model, packages = Array.Empty<string>(), installing = false, mac = true };
            case "ollama.models": {
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(30));
                try { return await ollama.ModelsAsync(timeout.Token); }
                catch (Exception ex) when (ex is HttpRequestException or OperationCanceledException or JsonException) { throw new InvalidOperationException("Ollama'ya ulaşılamadı. Mac'te ollama.com/download/mac adresinden kurup açtıktan sonra tekrar kontrol et."); }
            }
            case "ollama.install": throw new InvalidOperationException("Mac'te Ollama'yı ollama.com/download/mac adresinden kur; sonra modeli seç.");
            case "ollama.stop": return true;
            case "ollama.save": {
                var enabled = p.GetProperty("enabled").GetBoolean(); var model = Text("model");
                if (enabled && !OllamaInterpreter.IsLocalModel(model)) throw new ArgumentException("Önce yerel bir modeli kontrol edip seç.");
                if (!testing) ollamaSettings.Save(new(enabled, model)); return true;
            }
            case "spotify.account": return new { connected = !testing && spotifyAccount.Connected, clientId = testing ? "" : spotifyAccount.ClientId, redirectUri = SpotifyAccount.RedirectUri };
            case "spotify.connect": await spotifyAccount.ConnectAsync(Text("clientId"), CancellationToken.None); return "Spotify bağlandı. Şarkı arayıp sonuca tıklayabilirsin.";
            case "spotify.disconnect": await spotifyAccount.DisconnectAsync(CancellationToken.None); Commands.ForgetSpotifyResults(); return "Bu Mac'teki Spotify bağlantısı kaldırıldı.";
            case "spotify.inspect": { var state = Operations.Call<NoArguments, SpotifyState>("spotify.status", new()); return state.Message; }
            case "spotify.chooseApp": return "Mac'te Spotify uygulaması Uygulamalar klasöründen bulunur; ayrıca seçmen gerekmez.";
        }
        throw new ArgumentException("Bu işlem Mac'te desteklenmiyor: " + method);
    }
    private GoogleCalendarConnection Google() => google ?? throw new InvalidOperationException("Test görünümünde Google bağlantısı kapalı.");

    // ---------------------------------------------------------------- ICommandSurface
    public void Navigate(string section) => Emit("navigate", section);
    public void ShowResults(string type, object items, string? query) => Emit("results", new { type, items, query });
    // Modelin önerdiği silme Mac'te uygulanmaz; kullanıcı ilgili bölümden kendisi siler.
    public Task<bool> ConfirmAsync(string question) { status = "Silme işlemini ilgili bölümde kendin onayla."; return Task.FromResult(false); }

    public void Dispose() { google?.Dispose(); spotifyAccount.Dispose(); steamClient.Dispose(); http.Dispose(); command?.Dispose(); googleWork?.Dispose(); }
}

// Mac'te tema seçimi (küçük ve büyük görünüm için ayrı), DeploymentPaths altında.
internal sealed class MacThemeStore
{
    private sealed record Saved(string Name, string[] Colors);
    private readonly JsonListStore<Saved> compact = new(DeploymentPaths.Data("mac-theme-compact.json")), detailed = new(DeploymentPaths.Data("mac-theme-detailed.json"));
    internal (string Name, string[] Colors) Load(bool isCompact)
    {
        try {
            if ((isCompact ? compact : detailed).Read().FirstOrDefault() is { } saved && ThemePalettes.Valid(saved.Name, saved.Colors)) return (saved.Name, saved.Colors);
        } catch (Exception ex) when (ex is IOException or JsonException) { }
        var name = isCompact ? "Orman" : ThemePalettes.Default;
        return (name, ThemePalettes.Hex(name));
    }
    internal void Save(bool isCompact, string name, string[] colors) => (isCompact ? compact : detailed).Modify(_ => [new(name, colors)]);
}

// Kısayollara eklenebilecek Mac uygulamaları (Uygulamalar klasörleri).
internal static class MacApplications
{
    internal static IEnumerable<object> List()
    {
        var folders = new[] { "/Applications", "/System/Applications", Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Applications") };
        return folders.Where(Directory.Exists)
            .SelectMany(f => { try { return Directory.EnumerateDirectories(f, "*.app"); } catch (UnauthorizedAccessException) { return []; } })
            .Select(path => new { name = Path.GetFileNameWithoutExtension(path), id = path, icon = (string?)null })
            .DistinctBy(a => a.name).OrderBy(a => a.name, StringComparer.CurrentCultureIgnoreCase).ToList();
    }
    // Kısayol adımlarını macOS'un `open` komutuyla açar: uygulama (.app), dosya ya da web adresi.
    internal static Task LaunchAsync(RoutineStep step)
    {
        var start = new ProcessStartInfo("/usr/bin/open") { UseShellExecute = false };
        if (step.Kind == "web") {
            if (!Uri.TryCreate(step.Target, UriKind.Absolute, out var url) || url.Scheme is not ("http" or "https")) throw new ArgumentException("Web adresi http ya da https ile başlamalı.");
            if (step.Browser != "default") { start.ArgumentList.Add("-a"); start.ArgumentList.Add("Google Chrome"); }
        } else if (!(Directory.Exists(step.Target) || File.Exists(step.Target))) throw new InvalidOperationException("Uygulama bulunamadı: " + (step.Label ?? step.Target));
        start.ArgumentList.Add(step.Target);
        using var process = Process.Start(start) ?? throw new InvalidOperationException("Uygulama açılamadı.");
        return process.WaitForExitAsync();
    }
}

// Spotify masaüstü uygulamasını AppleScript ile denetler (macOS Otomasyon izni gerekir).
internal sealed class MacSpotifyTransport : ISpotifyTransport
{
    public SpotifyState Inspect()
    {
        var installed = Directory.Exists("/Applications/Spotify.app") || Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Applications/Spotify.app"));
        var running = Process.GetProcessesByName("Spotify").Length > 0;
        return new(running, installed, null, running ? "Spotify açık." : installed ? "Spotify kapalı." : "Spotify kurulu değil.");
    }
    public void OpenUri(string uri)
    {
        if (!uri.StartsWith("spotify:", StringComparison.Ordinal)) throw new ArgumentException("Geçersiz Spotify adresi.");
        using var process = Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true });
    }
    public void SendMediaCommand(int command)
    {
        var action = command switch { 14 => "playpause", 11 => "next track", 12 => "previous track", 47 => "pause", 46 => "play", _ => throw new ArgumentException("Geçersiz oynatma işlemi.") };
        var start = new ProcessStartInfo("/usr/bin/osascript") { UseShellExecute = false, RedirectStandardError = true };
        start.ArgumentList.Add("-e"); start.ArgumentList.Add("tell application \"Spotify\" to " + action);
        using var process = Process.Start(start)!;
        if (!process.WaitForExit(5000)) throw new InvalidOperationException("Spotify yanıt vermedi.");
        if (process.ExitCode != 0) throw new InvalidOperationException("Sistem Ayarları → Gizlilik ve Güvenlik → Otomasyon bölümünden Spotify kontrol iznini ver.");
    }
}
