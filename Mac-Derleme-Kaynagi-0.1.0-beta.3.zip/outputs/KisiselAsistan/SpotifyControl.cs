using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace KisiselAsistan;

public record SpotifyState(bool Running, bool Installed, string? WindowTitle, string Message);
public record SpotifyControlRequest(string Action, string? Query = null);
public interface ISpotifyTransport
{
    SpotifyState Inspect();
    void OpenUri(string uri);
    void SendMediaCommand(int command);
}
public sealed class SpotifyController(ISpotifyTransport transport)
{
    public SpotifyState Status() => transport.Inspect();
    public async Task<CommandResult> OpenAsync(CancellationToken token = default)
    {
        token.ThrowIfCancellationRequested();
        var request = Act("open");
        if (!request.Success) return request;
        try {
            for (var attempt = 0; attempt < 40; attempt++) {
                if (transport.Inspect().Running) return new(true, "Spotify açık; uygulama penceresi bulundu.");
                await Task.Delay(250, token);
            }
            return new(false, "Spotify'ı başlatmayı denedim ama penceresi görünmedi. Bağlantı ayarlarından ‘Spotify uygulamasını seç’ ile kurulumunu seçebilirsin.");
        } catch (OperationCanceledException) { throw; }
        catch (Exception ex) { return new(false, "Spotify'ın açıldığı doğrulanamadı: " + ex.Message); }
    }
    public CommandResult Act(string action, string? query = null)
    {
        try {
            if (action == "open") { transport.OpenUri("spotify:"); return new(true, "Spotify'ı açma isteği gönderildi."); }
            if (action == "search") {
                transport.OpenUri(SearchUri(query));
                return new(true, "Arama Spotify uygulamasında açıldı. Arama sonucu otomatik çalınmaz.");
            }
            var media = action switch { "toggle" => 14, "next" => 11, "previous" => 12, "pause" => 47, "play" => 46, _ => throw new ArgumentException("Desteklenen işlemler: open, search, toggle, next, previous, pause, play.") };
            transport.SendMediaCommand(media);
            return new(true, "Komut Spotify'a gönderildi. Oynatmanın değiştiği henüz doğrulanmadı.");
        } catch (Exception ex) { return new(false, ex.Message); }
    }
    public static string SearchUri(string? query)
    {
        if (string.IsNullOrWhiteSpace(query) || query.Length > 200) throw new ArgumentException("Arama 1–200 karakter olmalı.");
        return "spotify:search:" + Uri.EscapeDataString(query.Trim());
    }
}
public sealed class SpotifyCapability(SpotifyController controller, OperationRegistry? operations = null) : ICapability
{
    public string Name => "Spotify";
    public bool CanHandle(string command) => command.Trim().StartsWith("spotify", StringComparison.OrdinalIgnoreCase);
    public CommandResult Execute(string command)
    {
        var normalized = command.Trim().ToLower(new System.Globalization.CultureInfo("tr-TR"));
        var action = normalized switch {
            "spotify aç" => "open", "spotify oynat" or "spotify devam et" => "play", "spotify duraklat" or "spotify durdur" => "pause",
            "spotify oynat duraklat" => "toggle", "spotify sonraki" or "spotify sonraki şarkı" => "next", "spotify önceki" or "spotify önceki şarkı" => "previous", _ => null
        };
        if (action is not null) return Control(action);
        var search = Regex.Match(command.Trim(), @"^spotify\s+ara\s+(.+)$", RegexOptions.IgnoreCase);
        if (search.Success) return Control("search", search.Groups[1].Value);
        return new(false, "Örnekler: Spotify aç / Spotify duraklat / Spotify sonraki / Spotify ara şarkı veya sanatçı adı");
    }
    private CommandResult Control(string action, string? query = null) => operations is null ? controller.Act(action, query) : operations.Call<SpotifyControlRequest, CommandResult>("spotify.control", new(action, query));
}
