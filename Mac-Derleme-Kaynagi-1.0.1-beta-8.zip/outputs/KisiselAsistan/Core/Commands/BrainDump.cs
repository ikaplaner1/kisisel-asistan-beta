using System.Text.RegularExpressions;

namespace KisiselAsistan;

// Sesli beyin boşaltma ("toplu ekle"): uzun bir konuşmayı ayrı işlere böler. Her parçanın tarihi/saati
// yine WhenParser ile çözülür (arayüz "quick.split" ile önizler, kullanıcı onaylayınca eklenir).
// Bölme yerleri: cümle sonu, virgül, "sonra", "bir de", "ayrıca", "ardından" gibi bağlaçlar.
// Tek başına "ve" bölmez ("annemi ve babamı ara" tek iştir).
public static class BrainDump
{
    private static readonly Regex Trigger = new(@"^\s*(?:toplu ekle|toplu not al|beyin boşalt(?:ma)?|aklımdakileri (?:ekle|yaz|not al)|not al)\b[\s:,.]*", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    private static readonly Regex Breaks = new(@"[.!?;\n]+|,\s*|\s+(?:ve\s+)?(?:ondan sonra|sonra da|sonra|bir de|ayrıca|ardından|daha sonra)\s+", RegexOptions.IgnoreCase);
    private static readonly Regex Filler = new(@"^(?:ondan sonra|sonra da|daha sonra|sonra|ardından|ayrıca|bir de|ve|şey|şunları|şunu|tamam|evet|hmm+|ee+|yani)\b[\s,]*", RegexOptions.IgnoreCase);

    // Komut "toplu ekle …" ile başlıyorsa geri kalan metni (boş olabilir) döndürür; değilse null.
    public static string? Rest(string command)
    {
        var match = Trigger.Match(command ?? "");
        return match.Success ? command![match.Length..].Trim() : null;
    }

    public static List<string> Split(string text)
    {
        var parts = new List<string>();
        foreach (var raw in Breaks.Split(text ?? "")) {
            var part = raw.Trim();
            for (var before = ""; before != part;) { before = part; part = Filler.Replace(part, "").Trim(); }
            if (part.Length < 3) continue;
            parts.Add(char.ToUpper(part[0], new System.Globalization.CultureInfo("tr-TR")) + part[1..]);
        }
        return parts.Distinct(StringComparer.CurrentCultureIgnoreCase).Take(30).ToList();
    }
}
