const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('notice',{get:()=>ipcRenderer.invoke('notice:get'),respond:(response,minutes=5)=>ipcRenderer.invoke('notice:respond',response,minutes)});
