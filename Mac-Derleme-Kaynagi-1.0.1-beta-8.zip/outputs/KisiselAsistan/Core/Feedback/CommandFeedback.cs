using System.Security.Cryptography;

namespace KisiselAsistan;

// Komut geri bildirimi: anlaşılmayan, eksik bilgi sorulan, hata veren ya da modele giden komutlar kaydedilir ve
// (ayar açıksa) geliştiricinin Google Formu'na gönderilir. Kural yolunun anladığı komutlar kaydedilmez.
// Kayıt önce bu bilgisayardadır (feedback-log.json); gönderilemeyen satırlar sonra yeniden denenir.
// Kim olduğu gönderilmez; her kurulumun rastgele kısa bir numarası vardır (aynı kişinin cümlelerini gruplamak için).
public sealed record FeedbackSettings(bool Share = true, bool NoticeShown = false, string InstallId = "");
public sealed record CommandRecord(string Text, string Cleaned, string Path, string? Operation, string Phase, string Reply);
public sealed record FeedbackEntry(Guid Id, DateTimeOffset At, string Text, string Cleaned, string Path, string? Operation, string Phase, string Reply, string Version, bool Share, bool Sent);

public interface IFeedbackSender
{
    bool Ready { get; }
    Task SendAsync(FeedbackEntry entry, string installId, CancellationToken token);
}

public sealed class CommandFeedback(string folder, IFeedbackSender? sender, string version, Func<DateTimeOffset>? clock = null)
{
    public const int MaxEntries = 300, MaxText = 300, BatchSize = 20;
    private readonly JsonListStore<FeedbackSettings> settings = new(Path.Combine(folder, "feedback-settings.json"));
    private readonly JsonListStore<FeedbackEntry> log = new(Path.Combine(folder, "feedback-log.json"));
    private readonly SemaphoreSlim sending = new(1, 1);
    private DateTimeOffset Now => clock?.Invoke() ?? DateTimeOffset.Now;
    // Gönderim adresi tanımlıysa (FeedbackForm) true; değilse kayıt yalnız bu bilgisayarda kalır.
    public bool Available => sender?.Ready == true;

    public FeedbackSettings Settings
    {
        get {
            var current = settings.Read().FirstOrDefault() ?? new();
            if (current.InstallId.Length > 0) return current;
            current = current with { InstallId = Convert.ToHexString(RandomNumberGenerator.GetBytes(3)).ToLowerInvariant() };
            settings.Modify(_ => [current]);
            return current;
        }
    }
    // Kapatınca henüz gitmemiş satırlar da gönderilmez.
    public void SetShare(bool share)
    {
        settings.Modify(_ => [Settings with { Share = share }]);
        if (!share) log.Modify(list => list.Select(e => e.Sent ? e : e with { Share = false }).ToList());
    }
    public void MarkNoticeShown() => settings.Modify(_ => [Settings with { NoticeShown = true }]);
    public void Clear() => log.Modify(_ => []);
    public IReadOnlyList<FeedbackEntry> Recent(int count = 30) => log.Read().TakeLast(count).Reverse().ToList();

    // Kaydedilecek komut mu: kural yolunun anlayıp yaptığı işler kaydedilmez.
    public static bool Worth(CommandRecord r) => r.Path == "model" || r.Phase is "Anlaşılmadı" or "Hata" or "Bir bilgi eksik";

    public void Add(CommandRecord r)
    {
        if (!Worth(r) || string.IsNullOrWhiteSpace(r.Text)) return;
        static string Cut(string s) => s.Length > MaxText ? s[..MaxText] : s;
        var entry = new FeedbackEntry(Guid.NewGuid(), Now, Cut(r.Text.Trim()), Cut(r.Cleaned.Trim()), r.Path, r.Operation, r.Phase, Cut(r.Reply), version,
            Settings.Share && Available, false);
        log.Modify(list => { list.Add(entry); return list.Count > MaxEntries ? list.Skip(list.Count - MaxEntries).ToList() : list; });
        if (entry.Share) _ = SendPendingAsync(CancellationToken.None);
    }

    // Bekleyen satırları gönderir; internet yoksa kalanlar sonraki komutta ya da açılışta yeniden denenir. Gönderilen sayısı döner.
    public async Task<int> SendPendingAsync(CancellationToken token)
    {
        if (!Available || !Settings.Share || !await sending.WaitAsync(0, token)) return 0;
        var sent = 0;
        try {
            var id = Settings.InstallId;
            foreach (var entry in log.Read().Where(e => e.Share && !e.Sent).Take(BatchSize)) {
                try { await sender!.SendAsync(entry, id, token); }
                catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or IOException) { break; }
                log.Modify(list => list.Select(e => e.Id == entry.Id ? e with { Sent = true } : e).ToList());
                sent++;
            }
        } catch (Exception ex) when (ex is IOException or InvalidDataException) { }
        finally { sending.Release(); }
        return sent;
    }
}

// Google Formu'na gönderim: form herkese açık ama yalnız yanıt kabul eder; adresi bilen başkalarının cevaplarını okuyamaz.
// Alanlar "önceden doldurulmuş bağlantı"dan okunur: her soruya kendi anahtar sözcüğü yazılır (kullanici, surum, cumle, temiz, yol, sonuc, cevap).
public sealed class GoogleFormSender : IFeedbackSender
{
    public static readonly string[] Keys = ["kullanici", "surum", "cumle", "temiz", "yol", "sonuc", "cevap"];
    private readonly HttpClient http;
    private readonly Uri? target;
    private readonly Dictionary<string, string> fields = [];
    public GoogleFormSender(HttpClient http, string prefilledLink)
    {
        this.http = http;
        if (Parse(prefilledLink) is { } parsed) (target, fields) = parsed;
    }
    public bool Ready => target != null;

    // "https://docs.google.com/forms/d/e/<kimlik>/viewform?usp=pp_url&entry.111=kullanici&entry.222=cumle…" → gönderim adresi ve alanlar.
    public static (Uri Target, Dictionary<string, string> Fields)? Parse(string link)
    {
        if (!Uri.TryCreate(link?.Trim(), UriKind.Absolute, out var uri) || uri.Scheme != "https" || uri.Host != "docs.google.com") return null;
        var path = uri.AbsolutePath;
        var at = path.LastIndexOf('/');
        if (at < 0 || !path.StartsWith("/forms/d/e/")) return null;
        var found = new Dictionary<string, string>();
        foreach (var part in uri.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries)) {
            var pair = part.Split('=', 2);
            if (pair.Length != 2 || !System.Text.RegularExpressions.Regex.IsMatch(pair[0], @"^entry\.\d+$")) continue;
            var key = Uri.UnescapeDataString(pair[1].Replace('+', ' ')).Trim().ToLowerInvariant();
            if (Keys.Contains(key)) found[key] = pair[0];
        }
        if (!found.ContainsKey("cumle")) return null;
        return (new Uri($"https://docs.google.com{path[..at]}/formResponse"), found);
    }

    public async Task SendAsync(FeedbackEntry entry, string installId, CancellationToken token)
    {
        if (target == null) return;
        var values = new Dictionary<string, string> {
            ["kullanici"] = installId, ["surum"] = entry.Version, ["cumle"] = entry.Text, ["temiz"] = entry.Cleaned,
            ["yol"] = entry.Path, ["sonuc"] = entry.Phase + (entry.Operation is { } op ? " · " + op : ""), ["cevap"] = entry.Reply,
        };
        using var body = new FormUrlEncodedContent(values.Where(v => fields.ContainsKey(v.Key)).Select(v => KeyValuePair.Create(fields[v.Key], v.Value)));
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
        timeout.CancelAfter(TimeSpan.FromSeconds(15));
        using var response = await http.PostAsync(target, body, timeout.Token);
        // Google başarıda 200 (bazen yönlendirme) döner; alan kimliği yanlışsa 400.
        if ((int)response.StatusCode >= 400) throw new HttpRequestException("Form yanıtı reddedildi: " + (int)response.StatusCode);
    }
}

// Geliştiricinin formu. Boşken gönderim kapalıdır, kayıt yalnız bu bilgisayarda tutulur.
public static class FeedbackForm
{
    public const string Link = "";
}
