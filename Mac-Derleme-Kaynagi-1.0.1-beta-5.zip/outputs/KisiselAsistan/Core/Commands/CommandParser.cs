using System.Text.RegularExpressions;

namespace KisiselAsistan;

// Kurallı komut ayrıştırıcısı: Türkçe/İngilizce cümleyi doğrudan bir niyete (Intent) çevirir.
// Ara bir metin dili yoktur; hatırlatıcı, görev, Steam, Spotify ve kısayol komutlarının hepsi buradadır.
// context: kullanıcının son kullandığı bölüm ("steam", "spotify" ya da ""); "duraklat", "ilk oyunu ekle" gibi kısa komutlar ona göre anlaşılır.
// Anlaşılamayan cümle için null döner (Ollama açıksa ona sorulur).
public static class CommandParser
{
    private const RegexOptions Options = RegexOptions.IgnoreCase | RegexOptions.CultureInvariant;
    private static Match Match(string text, string pattern) => Regex.Match(text, pattern, Options);
    private const string SpotifyOpenPattern = @"^(?:spotify(?:\s*['’]?\s*y?[ıi])?(?:\s+uygulamasını)?\s+(?:aç|açsana|açar\s+mısın|açabilir\s+misin)|open\s+spotify|spotify\s+open)$";
    private const string RemindVerb = @"(?:hatırlat|hatırlatsana|anımsat)";
    private const string DefaultReminderText = "Hatırlatma zamanı";

    // Oyun/şarkı adının sonundaki Türkçe eki atar: "Hades'i" → "Hades".
    internal static string Name(string text) => Regex.Replace(text.Trim().Trim('"', '“', '”'), @"['’](?:y?[ıiuü]|[dt][ae]n?|n[ıiuü]n)$", "", Options).Trim();
    // "iki" → 2, "3." → 3; sayı değilse -1.
    internal static int Number(string text)
    {
        var value = text.ToLowerInvariant().TrimEnd('.') switch {
            "bir" or "one" or "ilk" or "birinci" => "1", "iki" or "two" or "ikinci" => "2", "üç" or "three" or "üçüncü" => "3",
            "dört" or "four" or "dördüncü" => "4", "beş" or "five" or "beşinci" => "5", "altı" or "six" => "6",
            "yedi" or "seven" => "7", "sekiz" or "eight" => "8", "dokuz" or "nine" => "9", "on" or "ten" => "10", var other => other
        };
        return int.TryParse(value, out var number) ? number : -1;
    }

    public static Intent? Parse(string text, string context = "", DateTimeOffset? now = null)
    {
        var at = now ?? DateTimeOffset.Now;
        text = Regex.Replace(text.Trim().TrimEnd('.', '!', '?'), @"\s+", " ");
        if (text.Length == 0) return null;
        text = Regex.Replace(text, @"^(?:(?:lütfen|please|bana|benim için)\s+)+", "", Options);
        text = Regex.Replace(text, @"\s+(?:lütfen|please)$", "", Options);
        text = Regex.Replace(text, @"\b(yapar|eder|açar|çalar|ekler|hatırlatır|bulur|yapabilir|edebilir|açabilir|çalabilir|ekleyebilir|hatırlatabilir|bulabilir)\s+m[ıi]s[ıi]n$", m => m.Groups[1].Value.ToLowerInvariant() switch { "yapar" or "yapabilir" => "yap", "eder" or "edebilir" => "et", "açar" or "açabilir" => "aç", "çalar" or "çalabilir" => "çal", "ekler" or "ekleyebilir" => "ekle", "hatırlatır" or "hatırlatabilir" => "hatırlat", _ => "bul" }, Options);
        // Açıkça reddedilen istek olumlu işleme çevrilmez.
        if (Match(text, @"\b(?:etme|ekleme|silme|açma|çalma|oynatma|kurma|hatırlatma|takip etme|erteleme|tamamlama|başlatma|çalıştırma)\s*$|^(?:don't|don’t|do not)\s+(?:play|open|run|start|delete|remove|track|search|find|pause|stop|remind|set)\b").Success) return null;

        if (ReminderVoiceRemoval.Parse(text) is { } removal) return new("reminder.remove", Target: removal);
        if (ReminderAction(text) is { } reminderAction) return reminderAction;
        if (Task(text, at) is { } task) return task;
        var routine = Match(text, @"^(.+?)\s+(?:rutin(?:ini|imi|i|im)?|kısayol(?:unu|umu|u|um)?)\s+(?:başlat|çalıştır|başlatsana|çalıştırsana|başlatır mısın|başlatabilir misin|çalıştırır mısın|çalıştırabilir misin)$");
        if (!routine.Success) routine = Match(text, @"^(?:(?:rutin|kısayol)\s+(?:başlat|çalıştır)|(?:start|run)\s+routine)\s+(.+)$");
        if (routine.Success) return new("routine.start", Name(routine.Groups[1].Value));

        text = Regex.Replace(text, @"^(?:lütfen\s+|please\s+)(?=(?:spotify|steam|hatırlatıcı)\b)", "", Options);
        if (Match(text, SpotifyOpenPattern).Success) return new("spotify.open");
        var spotifySimple = Match(text, @"^spotify\s+(duraklatsana|oynatsana|sonraki\s+şarkıya\s+geç|önceki\s+şarkıya\s+geç)$");
        if (spotifySimple.Success) return Control(spotifySimple.Groups[1].Value.ToLowerInvariant() switch { "duraklatsana" => "pause", "oynatsana" => "play", "sonraki şarkıya geç" => "next", _ => "previous" });

        // Uygulama adı başta ("Steam'de …", "Spotify'dan …"), ortada ("Hades'i Steam'de takip et") ya da İngilizce sonda olabilir.
        var app = Match(text, @"^(steam|spotify)(?:\s*['’]?\s*(?:[dt][ae]n?|y?[ıi]))?\s*[, :]?\s+(.+)$");
        var domain = app.Success ? app.Groups[1].Value.ToLowerInvariant() : "";
        var body = app.Success ? app.Groups[2].Value : text;
        if (!app.Success) {
            var middle = Match(text, @"^(.+?)\s+(steam|spotify)(?:\s*['’]?\s*(?:[dt][ae]n?|y?[ıi]))?\s+(takip et|takibe al|ara|bul|çal|oynat)$");
            if (middle.Success) { domain = middle.Groups[2].Value.ToLowerInvariant(); body = middle.Groups[1].Value + " " + middle.Groups[3].Value; }
            var english = Match(text, @"^(track|find|search|play)\s+(.+?)\s+on\s+(steam|spotify)$");
            if (english.Success) { domain = english.Groups[3].Value.ToLowerInvariant(); body = english.Groups[1].Value + " " + english.Groups[2].Value; }
        }
        var effective = domain.Length > 0 ? domain : context;
        if (Direct(text) is { } direct) return direct;

        if (effective == "steam") {
            if (Match(body, @"^(?:takip et|takibe al|ekle|eklesene|takip etsene)$").Success) return new("steam.trackSelected");
            var ordinal = Match(body, @"^(ilk|birinci|ikinci|üçüncü|dördüncü|beşinci|\d+\.?)(?:yi|yı|yü|y[ıi])?\s+(?:oyunu\s+|sonucu\s+)?(seç|ekle|takip et|takibe al)$");
            if (ordinal.Success) return new(ordinal.Groups[2].Value == "seç" ? "steam.selectResult" : "steam.trackResult", Number: Number(ordinal.Groups[1].Value));
        }
        if (domain == "steam" || domain.Length == 0) {
            var named = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:takip et|takibe al|takip listeme ekle|takip listesine ekle|takibe ekle|takip etsene|takibe alsana|track)$");
            if (!named.Success) named = Match(body, @"^(.+?)\s+(?:oyunu\s+)?(?:çıktığında|çıkınca|yayınlandığında|yayınlanınca)\s+(?:bana\s+)?(?:haber ver|bildir|bildirim gönder)$");
            if (!named.Success) named = Match(body, @"^(?:takip et|takibe al|track)\s+(.+)$");
            if (!named.Success && effective == "steam") named = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:ekle|eklesene)$");
            if (named.Success && !Match(named.Groups[1].Value, @"^(?:seçili|seçili oyunu|şunu|bunu|bu oyunu)$").Success) return new("steam.trackNamed", Name(named.Groups[1].Value));
            var remove = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:takibi bırak|takipten çıkar|takip listemden çıkar|takip listesinden kaldır|takibini bırak)$");
            if (remove.Success) return new("steam.unwatchNamed", Name(remove.Groups[1].Value));
            if (effective == "steam") {
                var search = Match(body, @"^(?:ara|bul|oyun ara|oyun bul|search|find)\s+(.+)$");
                if (!search.Success) search = Match(body, @"^(.+?)\s+(?:oyununu\s+)?(?:ara|bul|arasana|bulsana)$");
                if (search.Success) return new("steam.search", Name(search.Groups[1].Value));
            }
            // "oyun" sözcüğü Steam'i söyler: "Hades oyununu ara", "oyun bul Celeste"
            var game = Match(body, @"^(.+?)\s+(?:oyununu|oyunu|adlı oyunu)\s+(?:ara|bul|arasana|bulsana)$");
            if (!game.Success) game = Match(body, @"^oyun\s+(?:ara|bul)\s+(.+)$");
            if (game.Success) return new("steam.search", Name(game.Groups[1].Value));
        }
        if (domain == "spotify" || domain.Length == 0) {
            if (effective == "spotify") {
                var volume = Match(body, @"^(?:sesi|ses|ses seviyesini)\s+(?:%\s*|yüzde\s*)?(\d{1,3})(?:\s+(?:yap|ayarla|olsun))?$");
                if (volume.Success) return new("spotify.volume", Number: int.Parse(volume.Groups[1].Value));
                var search = Match(body, @"^(?:ara|bul|search|find)\s+(.+)$");
                if (!search.Success) search = Match(body, @"^(.+?)\s+(?:ara|bul|arasana|bulsana)$");
                if (search.Success) return new("spotify.search", Name(search.Groups[1].Value));
                if (Match(body, @"^(?:şarkıyı|müziği)\s+(?:oynat|çal|devam ettir)$").Success) return Control("play");
            }
            // Şarkı: "X çal", "X dinle", "X şarkısını aç", "Tarkan'dan bir şarkı çal"
            var song = Match(body, @"^(?:çal|oynat|play|dinlet)\s+(.+)$");
            if (!song.Success) song = Match(body, @"^(.+?)['’]?(?:dan|den|tan|ten)\s+(?:bir\s+)?(?:şarkı|parça)\s+(?:çal|aç|oynat|dinlet|dinleyelim)$");
            if (!song.Success) song = Match(body, @"^(.+?)\s+(?:şarkısını|şarkısı|parçasını|albümünü)\s+(?:çal|oynat|aç|dinlet|dinle)$");
            if (!song.Success) song = Match(body, @"^(.+?)\s+(?:çal|oynat|çalsana|oynatsana|dinle|dinlet|dinleyelim|dinlemek istiyorum|çalsın|çalalım)$");
            if (!song.Success && domain == "spotify") song = Match(body, @"^(.+?)\s+aç$");
            // "müzik çal", "biraz müzik dinle": belirli bir şarkı değil, kaldığı yerden devam
            if (song.Success && Match(song.Groups[1].Value, @"^(?:müzik|biraz müzik|şarkı|bir şarkı|bir şey|bişey|müziği|şarkıyı)$").Success) return Control("play");
            if (song.Success && !song.Groups[1].Value.Equals("spotify", StringComparison.OrdinalIgnoreCase)) return new("spotify.play", Name(song.Groups[1].Value));
        }
        if (Reminder(text, at) is { } reminder) return reminder;
        if (effective == "steam") {
            if (Match(body, @"^(?:şunu|bunu|bu oyunu|seçili oyunu)\s+(?:ekle|takibe al|takip et)$").Success) return new("steam.trackSelected");
            if (Match(body, @"^(?:takiplerimi|oyunlarımı|takip ettiğim oyunları|takip listemi|oyun listemi)\s+(?:göster|aç)$").Success) return new("steam.list");
            if (Match(body, @"^(?:oyunları\s+)?(?:kontrol et|kontrol etsene|kontrol eder misin|güncelle)$").Success) return new("steam.check");
            var pick = Match(body, @"^(ilk|birinci|ikinci|üçüncü|sonuç\s+\d+)\s+(?:oyunu\s+)?(seç|ekle|takip et|takibe al)$");
            if (pick.Success) {
                var number = Number(Regex.Replace(pick.Groups[1].Value, @"^sonuç\s+", "", Options));
                return new(pick.Groups[2].Value == "seç" ? "steam.selectResult" : "steam.trackResult", Number: number);
            }
        }
        if (effective == "spotify") {
            if (Match(body, @"^(?:duraklat|duraklatsana|müziği durdur|şarkıyı durdur|müziği duraklat|şarkıyı duraklat|pause)$").Success) return Control("pause");
            if (Match(body, @"^(?:devam et|oynat|çal|müziği devam ettir|play|resume)$").Success) return Control("play");
            if (Match(body, @"^(?:sonraki(?: şarkı)?|şarkıyı geç|sonraki şarkıya geç|next)$").Success) return Control("next");
            if (Match(body, @"^(?:önceki(?: şarkı)?|önceki şarkıya geç|bir önceki şarkı|previous)$").Success) return Control("previous");
        }
        if (Match(text, @"^(?:hatırlatıcılarımı|hatırlatmalarımı|hatırlatıcı listesini)\s+(?:göster|aç)$").Success) return new("reminder.list");
        return QuickAdd(text, at);
    }

    // Hiçbir kalıba uymayan cümle, içinde zaman varsa Bugün'deki hızlı ekleme gibi işlenir:
    // "yarın çamaşır yıka" → yarına görev, "akşam 8'de ilaç iç" → hatırlatıcı, "süt al ekle" → bugüne görev.
    // Soru cümleleri ("yarın hava nasıl") iş sayılmaz.
    private static Intent? QuickAdd(string text, DateTimeOffset now)
    {
        if (Match(text, @"\?\s*$|\b(?:mı|mi|mu|mü|mısın|misin|musun|müsün|nasıl|neden|niye|niçin|kaç|hangi|nedir|ne zaman|var mı)\b").Success) return null;
        var generic = Match(text, @"^(.+?)\s+(?:ekle|eklesene|not al|not et|kaydet|listeye ekle|yapılacaklara ekle)$");
        var when = WhenParser.Parse(generic.Success ? generic.Groups[1].Value : text, now);
        if (when.Text.Length == 0 || when.Conflict) return null;
        if (when.Someday) return new("task.add", when.Text, Target: "someday");
        if (when.RelativeSeconds is int after) return new("reminder.add", when.Text, after);
        if (when.Due is { } due) return new("reminder.add", when.Text, Due: due);
        if (when.Day != null || generic.Success) return new("task.add", when.Text, Day: when.Day);
        return null;
    }
    private static Intent Control(string action) => new("spotify.control", action);

    // Yazılı kısa komutlar ve İngilizce kalıplar ("steam sonuç 2 seç", "spotify next", "show reminders" …).
    private static Intent? Direct(string text)
    {
        Match m;
        if ((m = Match(text, @"^spotify (?:sonuç (\S+) çal|play result (\S+))$")).Success) return new("spotify.playResult", Number: Number(m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value));
        if (Match(text, @"^spotify (?:durum|status)$").Success) return new("spotify.status");
        if ((m = Match(text, @"^play on spotify (.+)$")).Success) return new("spotify.play", Name(m.Groups[1].Value));
        if ((m = Match(text, @"^spotify (?:search|ara) (.+)$")).Success) return new("spotify.search", m.Groups[1].Value.Trim());
        var control = text.ToLowerInvariant() switch {
            "spotify play" or "spotify resume" or "spotify oynat" or "spotify devam et" => "play",
            "spotify pause" or "spotify stop" or "spotify duraklat" or "spotify durdur" => "pause",
            "spotify next" or "spotify next track" or "spotify sonraki" or "spotify sonraki şarkı" => "next",
            "spotify previous" or "spotify previous track" or "spotify önceki" or "spotify önceki şarkı" => "previous",
            "spotify oynat duraklat" => "toggle", _ => null
        };
        if (control != null) return Control(control);
        if ((m = Match(text, @"^steam (?:select result (\S+)|sonuç (\S+) seç)$")).Success) return new("steam.selectResult", Number: Number(m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value));
        if ((m = Match(text, @"^steam (?:takip (\S+) seç|select watch (\S+))$")).Success) return new("steam.selectWatch", Number: Number(m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value));
        if ((m = Match(text, @"^steam sonuç-ekle (\d+)$")).Success) return new("steam.trackResult", Number: Number(m.Groups[1].Value));
        if (Match(text, @"^steam (?:takibi bırak|unwatch selected)$").Success) return new("steam.unwatchSelected");
        if (Match(text, @"^steam (?:seçili oyunu takip et|takip et|track selected)$").Success) return new("steam.trackSelected");
        if (Match(text, @"^steam (?:takipleri göster|list|show watches)$").Success) return new("steam.list");
        if (Match(text, @"^steam (?:kontrol et|check)$").Success) return new("steam.check");
        if (Match(text, @"^(?:hatırlatıcıları göster|show reminders)$").Success) return new("reminder.list");
        if ((m = Match(text, @"^(?:hatırlatıcı (\S+) seç|select reminder (\S+))$")).Success) return new("reminder.select", Number: Number(m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value));
        if (Match(text, @"^delete selected reminder$").Success) return new("reminder.remove", Target: "secili");
        // İngilizce zamanlayıcı ve hatırlatıcı: "set a timer for ten seconds", "remind me in 20 minutes to stretch"
        var detailed = Match(text, @"^remind\s+me\s+in\s+(.+?)\s+to\s+(.+)$");
        if (detailed.Success && WhenParser.EnglishDuration(detailed.Groups[1].Value) is int after) return new("reminder.add", WhenParser.Capitalize(detailed.Groups[2].Value.Trim()), after);
        var timer = Match(text, @"^(?:set\s+(?:a\s+)?(?:timer|reminder)\s+for\s+)?([a-z\d -]+?\s+(?:seconds?|minutes?|hours?))(?:\s+(?:timer|reminder))?$");
        if (timer.Success && (text.Contains("timer", StringComparison.OrdinalIgnoreCase) || text.Contains("reminder", StringComparison.OrdinalIgnoreCase)) && WhenParser.EnglishDuration(timer.Groups[1].Value) is int seconds)
            return new("reminder.add", DefaultReminderText, seconds);
        return null;
    }

    // Hatırlatıcı kurma: süreyle ("on dakika sonra su içmeyi hatırlat"), zamanla ("yarın 9'da raporu hatırlat")
    // ya da zamanlayıcı ("10 dakikalık alarm kur", "hatırlatıcı kur on dakika").
    private static Intent? Reminder(string text, DateTimeOffset now)
    {
        var timer = Match(text, @"^(?:hatırlatıcı|zamanlayıcı|alarm)\s+(?:kur|ayarla|oluştur)\s+(.+)$");
        if (!timer.Success) timer = Match(text, @"^(.+?)(?:lik|lık|lük|luk)?\s+(?:alarm|zamanlayıcı|hatırlatıcı)(?:\s+(?:kur|ayarla|oluştur))?$");
        if (timer.Success && SpokenDuration.TryParse(Regex.Replace(timer.Groups[1].Value, @"(?<=(?:saniye|dakika|saat))(?:lik|lık)$", "", Options), out var seconds))
            return new("reminder.add", DefaultReminderText, seconds);
        var remind = Match(text, @"^(.+?)\s+" + RemindVerb + "$");
        // Fiil sonda ("yarın 9'da raporu hatırlat") ya da başta ("hatırlat yarın 9'da rapor") olabilir.
        if (!remind.Success) remind = Match(text, @"^(?:bana\s+)?(?:hatırlat|hatırlatsana|hatırlatma kur|hatırlatıcı kur)\s+(.+)$");
        if (!remind.Success) return null;
        var when = WhenParser.Parse(remind.Groups[1].Value, now);
        if (when.Conflict) return new("clarify", "Tek bir zaman söyle: ya süre (on dakika sonra) ya da gün ve saat (yarın 9'da).");
        var name = when.Text.Length == 0 ? DefaultReminderText : when.Text;
        if (when.RelativeSeconds is int after) return new("reminder.add", name, after);
        if (when.Due is { } due) return new("reminder.add", name, Due: due);
        return new("clarify", "Ne zaman hatırlatayım? Örneğin ‘yarın 9’da " + remind.Groups[1].Value.Trim() + " hatırlat’ ya da ‘on dakika sonra …’.");
    }

    // Hatırlatıcı erteleme ve tamamlama: "su içme hatırlatıcısını beş dakika ertele", "seçili planı yaptım".
    internal static Intent? ReminderAction(string text)
    {
        if (Regex.IsMatch(text, @"-\s*\d|\b(?:erteleme|tamamlama|tamamlamadım|yapmadım)\b", Options)) return null;
        var folded = Regex.Replace(ReminderVoiceRemoval.Fold(text), @"\s+", " ");
        var snooze = Regex.Match(folded, @"^(.*\b(?:hatirlatici\w*|hatirlatma\w*|plan\w*)(?:\s+\d+(?=\s+(?:\d+|[a-z]+)\s+(?:dakika|saat)))?)\s+(.+?)\s+(?:ertele|ertelesene|erteler misin|erteleyebilir misin)$");
        if (snooze.Success && SpokenDuration.TryParse(snooze.Groups[2].Value, out var seconds) && seconds % 60 == 0) {
            var target = ReminderVoiceRemoval.Parse(snooze.Groups[1].Value + " sil");
            if (target is not null) return new("reminder.snooze", Number: seconds / 60, Target: target);
        }
        var complete = Regex.Match(folded, @"^(.+?)\s+(?:tamamla|tamamladim|yaptim|bitti|tamamlandi|tamamlar misin|tamamlayabilir misin)$");
        if (complete.Success) {
            var target = ReminderVoiceRemoval.Parse(complete.Groups[1].Value + " sil");
            if (target is not null) return new("reminder.complete", Target: target);
        }
        return null;
    }

    // Görevler: ekleme ("yarın market alışverişi görevini ekle", "bir ara dolabı düzenle"), tamamlama, bugünü sorma.
    private static Intent? Task(string text, DateTimeOffset now)
    {
        if (Match(text, @"^(?:bugün(?: için)? ne(?:ler)? var|bugün(?:kü)? (?:görevlerimi|işlerimi|planımı) (?:göster|söyle|oku)|görevlerimi (?:göster|söyle|listele)|yapılacakları göster|show (?:my )?tasks|what(?:'s| is) on today)$").Success) return new("task.list");
        var done = Match(text, @"^(.+?)\s+(?:görevini|görevi|işini)\s+(?:tamamla|tamamladım|yaptım|bitirdim|bitti|tamamlandı)$");
        if (done.Success) return new("task.complete", Target: ReminderVoiceRemoval.Fold(Name(done.Groups[1].Value)));
        var add = Match(text, @"^(?:görev ekle|yeni görev|yapılacaklara ekle|add task)\s*[:,]?\s+(.+)$");
        if (!add.Success) add = Match(text, @"^(.+?)\s+(?:görevini|görevi|diye (?:bir )?görev|işini)\s+(?:ekle|oluştur|yaz|kaydet)$");
        if (!add.Success) add = Match(text, @"^(.+?)\s+(?:yapılacaklara|görevlere|görev listeme)\s+ekle$");
        // "bi ara yemek ye", "yemek ye bir ara" (hatırlatma isteği değilse)
        var someday = !add.Success && !Match(text, RemindVerb + "$").Success && WhenParser.Parse(text, now).Someday;
        if (!add.Success && !someday) return null;
        var when = WhenParser.Parse(add.Success ? add.Groups[1].Value : text, now);
        if (when.Text.Length == 0) return new("clarify", "Görevin adını da söyle. Örneğin ‘yarın market alışverişi görevini ekle’.");
        if (when.Someday) return new("task.add", when.Text, Target: "someday");
        // Saat söylenen iş bildirimli olur (hatırlatıcı); saatsiz iş görevdir.
        if (when.Due is { } due && !when.Conflict) return new("reminder.add", when.Text, Due: due);
        return new("task.add", when.Text, Day: when.Day);
    }
}
