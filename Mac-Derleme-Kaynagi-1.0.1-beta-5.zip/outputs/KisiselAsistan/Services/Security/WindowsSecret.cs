using System.Runtime.InteropServices;
using System.Security.Cryptography;
namespace KisiselAsistan;
internal static class WindowsSecret
{
    [StructLayout(LayoutKind.Sequential)] private struct Blob { public int Length; public IntPtr Bytes; }
    [DllImport("crypt32.dll", SetLastError = true)] private static extern bool CryptProtectData(ref Blob input, string? description, IntPtr entropy, IntPtr reserved, IntPtr prompt, uint flags, out Blob output);
    [DllImport("crypt32.dll", SetLastError = true)] private static extern bool CryptUnprotectData(ref Blob input, IntPtr description, IntPtr entropy, IntPtr reserved, IntPtr prompt, uint flags, out Blob output);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
    public static byte[] Encode(byte[] bytes) => Transform(bytes, true);
    public static byte[] Decode(byte[] bytes) => Transform(bytes, false);
    private static byte[] Transform(byte[] bytes, bool protect)
    {
        if (!OperatingSystem.IsWindows()) return PortableTransform(bytes, protect);
        var input = new Blob { Length = bytes.Length, Bytes = Marshal.AllocHGlobal(bytes.Length) }; Blob output = default;
        try {
            Marshal.Copy(bytes, 0, input.Bytes, bytes.Length);
            var ok = protect ? CryptProtectData(ref input, null, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 1, out output) : CryptUnprotectData(ref input, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 1, out output);
            if (!ok) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            var result = new byte[output.Length]; Marshal.Copy(output.Bytes, result, 0, result.Length); return result;
        } finally { Marshal.FreeHGlobal(input.Bytes); if (output.Bytes != IntPtr.Zero) LocalFree(output.Bytes); }
    }
    internal static byte[] PortableTransform(byte[] bytes, bool protect)
    {
        var encoded = Environment.GetEnvironmentVariable("ASSISTANT_ACCOUNT_KEY");
        if (string.IsNullOrEmpty(encoded)) throw new InvalidOperationException("Güvenli hesap deposu hazırlanamadı.");
        var key = Convert.FromBase64String(encoded);
        try {
            using var aes = new AesGcm(key, 16);
            if (protect) {
                var nonce = RandomNumberGenerator.GetBytes(12); var encrypted = new byte[bytes.Length]; var tag = new byte[16];
                aes.Encrypt(nonce, bytes, encrypted, tag); return [..nonce, ..tag, ..encrypted];
            }
            if (bytes.Length < 28) throw new CryptographicException("Hesap dosyası geçersiz.");
            var plain = new byte[bytes.Length - 28];
            aes.Decrypt(bytes.AsSpan(0, 12), bytes.AsSpan(28), bytes.AsSpan(12, 16), plain); return plain;
        } finally { CryptographicOperations.ZeroMemory(key); }
    }
}

