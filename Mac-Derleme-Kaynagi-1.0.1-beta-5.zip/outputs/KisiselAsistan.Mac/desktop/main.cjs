const {app, BrowserWindow, WebContentsView, ipcMain, shell, dialog, safeStorage, session, protocol, net, screen, systemPreferences, Menu} = require('electron');
const {spawn} = require('node:child_process');
const {createInterface} = require('node:readline');
const fs = require('node:fs'); const fsp = fs.promises;
const path = require('node:path'); const crypto = require('node:crypto');
const {pathToFileURL} = require('node:url');
const {providers, externalUrl, trustedUi, releaseAsset, coverTarget, workspaceFile} = require('./policy.cjs');

// Mac kabuğu. Ekran Windows'taki ortak arayüzün (KisiselAsistan/WorkspaceWeb) aynısıdır; assistant://workspace/ adresinden açılır.
// Arayüzün istekleri .NET servisine (Assistant.Host → paylaşılan WorkspaceApi) gider; pencere, AI panelleri, dosya seçimi,
// kapak görselleri ve mikrofon gibi yalnız kabuğun yapabildikleri burada karşılanır.
protocol.registerSchemesAsPrivileged([{scheme: 'assistant', privileges: {standard: true, secure: true}}]);
let window, host, seq = 0, compact = false, exiting = false, tickBusy = false, lastLive = '', slots = [];
const views = new Map(), pending = new Map(), notices = new Map(), noticeWindows = new Map();
const smoke = process.argv.includes('--smoke-test');
const dataArg = process.argv.indexOf('--data'), dataFolder = dataArg > 0 ? process.argv[dataArg + 1] : null;
if (smoke) { app.setPath('userData', path.join(require('node:os').tmpdir(), 'assistant-smoke-' + process.pid)); setTimeout(() => { console.error('SMOKE_TIMEOUT'); host?.kill(); app.exit(1); }, 60000).unref(); }
const workspaceRoot = app.isPackaged ? path.join(process.resourcesPath, 'workspace') : path.join(__dirname, '../../KisiselAsistan/WorkspaceWeb');
const entry = 'assistant://workspace/index.html';
const noticeEntry = pathToFileURL(path.join(__dirname, '../ui/notice.html')).href;
// Ad sırası Windows'taki AiBrowsers ile aynı (arayüzdeki 0, 1, 2).
const chats = [['chatgpt', 'ChatGPT', 'https://chatgpt.com/'], ['gemini', 'Gemini', 'https://gemini.google.com/app'], ['claude', 'Claude', 'https://claude.ai/new']];

function send(message) { if (window && !window.isDestroyed()) window.webContents.send('workspace:message', message); }
function rpc(method, params = {}, timeout = 250000) {
  return new Promise((resolve, reject) => {
    if (!host || host.exitCode !== null) { reject(new Error('Asistan servisleri çalışmıyor. Uygulamayı yeniden aç.')); return; }
    const id = String(++seq);
    const timer = setTimeout(() => { pending.delete(id); reject(new Error('İşlem zaman aşımına uğradı.')); }, timeout);
    pending.set(id, {resolve, reject, timer});
    host.stdin.write(JSON.stringify({id, method, params}) + '\n');
  });
}
const workspace = (method, params = {}) => rpc('workspace', {method, params});
function assertSender(event) { if (event.sender !== window?.webContents || !trustedUi(event.senderFrame.url, entry)) throw new Error('Bu işlem yalnız asistan ekranında kullanılabilir.'); }
async function publishLive() { try { const live = {...await rpc('live'), update: Boolean(updateRelease)}; const text = JSON.stringify(live); if (text !== lastLive) { lastLive = text; send({event: 'state', data: live}); } } catch {} }

// ---------------------------------------------------------------- AI panelleri (girişler persist:ai-* bölümlerinde saklanır)
function chatView(index) {
  const [name, , url] = chats[index];
  if (views.has(name)) return views.get(name);
  const view = new WebContentsView({webPreferences: {partition: `persist:ai-${name}`, nodeIntegration: false, contextIsolation: true, sandbox: true}});
  view.webContents.session.setPermissionRequestHandler((_, __, callback) => callback(false));
  view.webContents.session.setPermissionCheckHandler(() => false);
  window.contentView.addChildView(view); views.set(name, view); view.setVisible(false);
  view.webContents.setWindowOpenHandler(({url}) => { if (externalUrl(url)) shell.openExternal(url); return {action: 'deny'}; });
  view.webContents.on('will-navigate', (event, target) => { if (!externalUrl(target)) event.preventDefault(); });
  view.webContents.on('context-menu', (_, params) => {
    const items = [{role: 'copy'}, {role: 'paste'}];
    if (params.selectionText) items.push({label: 'Seçili metni asistanlara sor', click: () => send({event: 'selection', data: {text: params.selectionText}})});
    Menu.buildFromTemplate(items).popup();
  });
  view.webContents.loadURL(url).catch(() => {});
  return view;
}
function layoutChats(list) {
  slots = Array.isArray(list) ? list : [];
  const [width, height] = window.getContentSize(), visible = new Set();
  for (const slot of slots) {
    if (!Number.isInteger(slot.index) || slot.index < 0 || slot.index >= chats.length || !(slot.width > 0 && slot.height > 0)) continue;
    const view = chatView(slot.index), x = Math.max(0, Math.round(slot.x)), y = Math.max(0, Math.round(slot.y));
    view.setBounds({x, y, width: Math.max(0, Math.min(width - x, Math.round(slot.width))), height: Math.max(0, Math.min(height - y, Math.round(slot.height)))});
    view.setVisible(true); visible.add(chats[slot.index][0]);
  }
  for (const [name, view] of views) if (!visible.has(name)) view.setVisible(false);
  return true;
}
async function sendChats(text, targets) {
  if (typeof text !== 'string' || !text.trim() || text.length > 100000 || !Array.isArray(targets) || !targets.some(Boolean)) throw new Error('Bir soru ve en az bir asistan seç.');
  const results = await Promise.all(chats.map(async ([name, label], index) => {
    if (!targets[index]) return null;
    try {
      const view = chatView(index);
      for (let i = 0; i < 80 && view.webContents.isLoading(); i++) await new Promise(r => setTimeout(r, 250));
      const ready = await view.webContents.executeJavaScript(await rpc('chat.script', {provider: name, text, mode: 'prepare'}), true);
      if (ready !== 'hazır') return `${label}: ${ready === 'ana sohbet sayfasını aç' ? 'Hesabına giriş yap ve sohbet ekranını aç' : ready}`;
      await view.webContents.insertText(text.trim());
      return `${label}: ` + await view.webContents.executeJavaScript(await rpc('chat.script', {provider: name, text, mode: 'submit'}), true);
    } catch { return `${label}: Gönderilemedi, paneli kontrol et`; }
  }));
  return results.filter(Boolean).join('\n');
}
function chatAction(action, index) {
  if (!Number.isInteger(index) || index < -1 || index >= chats.length) throw new Error('Asistan seçimi geçersiz.');
  if (action === 'ai-external') { if (index < 0) throw new Error('Bir asistan seç.'); return shell.openExternal(chats[index][2]); }
  if (!['ai-new', 'ai-refresh', 'ai-one-reload'].includes(action)) throw new Error('İşlem geçersiz.');
  for (const i of index < 0 ? chats.keys() : [index]) {
    const view = chatView(i);
    if (action === 'ai-new') view.webContents.loadURL(chats[i][2]).catch(() => {}); else view.webContents.reload();
  }
  return true;
}

// ---------------------------------------------------------------- Bildirim pencereleri (hatırlatıcılar)
function toast(item) {
  if (notices.has(item.id)) return;
  notices.set(item.id, item);
  const area = screen.getDisplayMatching(window.getBounds()).workArea;
  const adhd = item.prompt.reminder.settings.level === 'Adhd', center = adhd && item.prompt.reminder.pressure >= 4;
  const popup = new BrowserWindow({width: 400, height: 260, x: center ? Math.round(area.x + (area.width - 400) / 2) : area.x + area.width - 420, y: center ? Math.round(area.y + (area.height - 260) / 2) : area.y + area.height - 280, frame: false, resizable: false, show: false, alwaysOnTop: true, backgroundColor: '#213731', skipTaskbar: true, webPreferences: {preload: path.join(__dirname, 'notice-preload.cjs'), sandbox: true, contextIsolation: true, nodeIntegration: false}});
  const popupId = popup.webContents.id; noticeWindows.set(popupId, {popup, item});
  popup.webContents.setWindowOpenHandler(() => ({action: 'deny'})); popup.webContents.on('will-navigate', event => event.preventDefault());
  popup.once('ready-to-show', () => popup.showInactive());
  popup.on('closed', () => noticeWindows.delete(popupId));
  popup.loadURL(noticeEntry).catch(() => popup.close());
  if (!adhd) setTimeout(() => { if (!popup.isDestroyed()) popup.close(); }, 14000);
}
async function tick() {
  if (tickBusy || !host) return; tickBusy = true;
  try {
    const data = await rpc('tick'); const active = new Set(data.prompts.map(item => item.id));
    for (const id of notices.keys()) if (!active.has(id)) { notices.delete(id); for (const owner of noticeWindows.values()) if (owner.item.id === id) owner.popup.close(); }
    for (const item of data.prompts) toast(item);
    if (data.notices.length) send({event: 'refresh'});
  } catch {} finally { tickBusy = false; }
}

// ---------------------------------------------------------------- Güncelleme (beta deposundan bu Mac'in mimarisine uygun DMG'yi indirir)
// Depo herkese açıksa giriş gerekmez; GitHub hesabı bağlıysa onun anahtarı kullanılır.
let updateRelease = null;
const versionParts = text => String(text).replace(/^v/, '').split(/[^0-9]+/).filter(Boolean).map(Number);
function newer(tag, current) {
  const a = versionParts(tag), b = versionParts(current);
  for (let i = 0; i < Math.max(a.length, b.length); i++) if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0);
  return false;
}
async function githubAccess() {
  const base = {Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28'};
  try { const auth = await rpc('github.token'); return {repo: new URL(auth.repositoryUrl).pathname, headers: {...base, Authorization: `Bearer ${auth.token}`}}; }
  catch { const settings = await rpc('github.settings').catch(() => null); return {repo: new URL(settings?.repositoryUrl || 'https://github.com/ikaplaner1/kisisel-asistan-beta').pathname, headers: base}; }
}
async function latestMacRelease() {
  const {repo, headers} = await githubAccess();
  const response = await fetch(`https://api.github.com/repos${repo.replace(/\/$/, '')}/releases`, {headers});
  if (!response.ok) throw new Error('Test deposuna erişilemedi. İnternet bağlantını kontrol et.');
  const release = (await response.json()).find(r => !r.draft && releaseAsset(r.assets, process.arch));
  return {release, headers};
}
// Açılışta ve 6 saatte bir: daha yeni Mac paketi varsa üstteki "Güncelleme hazır" düğmesi görünür.
async function checkUpdate() {
  try { const {release} = await latestMacRelease(); updateRelease = release && newer(release.tag_name, app.getVersion()) ? release : null; lastLive = ''; publishLive(); } catch {}
}
async function updateDownload() {
  const {release, headers} = await latestMacRelease();
  if (!release) throw new Error('Bu Mac için yayımlanmış paket bulunamadı.');
  const asset = releaseAsset(release.assets, process.arch);
  const selected = await dialog.showSaveDialog(window, {title: 'Mac güncellemesini indir', defaultPath: path.join(app.getPath('downloads'), asset.name), filters: [{name: 'Mac kurulumu', extensions: ['dmg']}]});
  if (selected.canceled) return 'İndirme iptal edildi.';
  const downloaded = await fetch(asset.url, {headers: {...headers, Accept: 'application/octet-stream'}});
  if (!downloaded.ok) throw new Error('Güncelleme indirilemedi.');
  const temporary = selected.filePath + '.' + crypto.randomUUID() + '.partial';
  const {Readable, Transform} = require('node:stream'), {pipeline} = require('node:stream/promises');
  const hash = crypto.createHash('sha256'); let bytes = 0;
  try {
    await pipeline(Readable.fromWeb(downloaded.body), new Transform({transform(chunk, _, cb) { bytes += chunk.length; hash.update(chunk); cb(null, chunk); }}), fs.createWriteStream(temporary, {flags: 'wx'}));
    if (bytes !== asset.size) throw new Error('İndirilen paket eksik.');
    if (!asset.digest || asset.digest !== `sha256:${hash.digest('hex')}`) throw new Error('Güncellemenin doğrulama bilgisi eşleşmedi.');
    await fsp.rename(temporary, selected.filePath); shell.showItemInFolder(selected.filePath);
    return 'Mac paketi indirildi. Kurulumu Finder üzerinden tamamla; mevcut sürüm otomatik değiştirilmedi.';
  } catch (error) { await fsp.rm(temporary, {force: true}); throw error; }
}

// ---------------------------------------------------------------- Arayüz istekleri
function setCompact(value) {
  compact = value;
  const area = screen.getDisplayMatching(window.getBounds()).workArea;
  if (compact) window.setBounds({width: 440, height: 680, x: area.x + area.width - 460, y: area.y + area.height - 700});
  else { window.setSize(1400, 900); window.center(); }
  return rpc('compact', {compact});
}
async function handle(method, p) {
  switch (method) {
    case 'window.view': await setCompact(!compact); await publishLive(); return true;
    case 'window.action':
      if (p.action === 'minimize') window.minimize();
      else if (p.action === 'maximize') { if (compact) { await setCompact(false); await publishLive(); } else if (window.isMaximized()) window.unmaximize(); else window.maximize(); }
      else if (p.action === 'close') { if (process.platform === 'darwin') window.hide(); else { exiting = true; app.quit(); } }
      else throw new Error('Pencere işlemi geçersiz.');
      return true;
    case 'window.drag': return true; // sürükleme CSS ile (-webkit-app-region)
    case 'ai.layout': return layoutChats(p.slots);
    case 'ai.send': { const result = await sendChats(p.text, p.targets); return result; }
    case 'ai.action': return chatAction(p.action, p.index);
    case 'google.setup': await shell.openExternal('https://console.cloud.google.com/apis/library/calendar-json.googleapis.com'); return true;
    case 'routine.pickFile': {
      const file = await dialog.showOpenDialog(window, {title: 'Uygulamayı seç', defaultPath: '/Applications', filters: [{name: 'Uygulama', extensions: ['app']}], properties: ['openFile', 'treatPackageAsDirectory']});
      if (file.canceled || !file.filePaths[0]) return null;
      return {kind: 'app', target: file.filePaths[0], browser: 'default', label: path.basename(file.filePaths[0], '.app'), minutes: 1};
    }
    case 'dialog.refresh': return updateDownload();
    case 'dialog.publish': throw new Error('Yayınlama Mac sürümünde yok.');
  }
  return workspace(method, p);
}
async function speech(stage, samples) {
  if (stage === 'start') {
    if (process.platform === 'darwin' && !(await systemPreferences.askForMediaAccess('microphone'))) throw new Error('Mikrofon izni yok. Sistem Ayarları → Gizlilik ve Güvenlik → Mikrofon bölümünden izin ver.');
    await rpc('listening', {listening: true, phase: 'Dinliyorum'}); await publishLive(); return true;
  }
  try {
    if (stage !== 'samples') return true;
    await rpc('listening', {listening: false, phase: 'Çözümlüyorum'}); await publishLive();
    const text = await rpc('speech.transcribe', {samples: Array.from(samples ?? [])});
    if (!text?.trim()) return true;
    await workspace('speech.command', {text});
    return true;
  } finally { await rpc('listening', {listening: false, phase: 'Hazır'}).catch(() => {}); await publishLive(); }
}

app.whenReady().then(async () => {
  if (!smoke && !app.requestSingleInstanceLock()) { app.quit(); return; }
  protocol.handle('assistant', request => {
    const file = workspaceFile(workspaceRoot, request.url);
    return file ? net.fetch(pathToFileURL(file).href) : new Response('', {status: 404});
  });
  // Steam/Spotify kapakları: Windows'taki covers.assistant.local istekleri yalnız izinli kapak sunucularına yönlenir.
  session.defaultSession.webRequest.onBeforeRequest({urls: ['https://covers.assistant.local/*']}, (details, callback) => {
    const target = coverTarget(details.url);
    callback(target ? {redirectURL: target} : {cancel: true});
  });
  session.defaultSession.setPermissionRequestHandler((contents, permission, callback, details) => callback(contents === window?.webContents && permission === 'media' && (details.mediaTypes ?? []).every(t => t === 'audio')));
  session.defaultSession.setPermissionCheckHandler((contents, permission) => contents === window?.webContents && permission === 'media');
  if (!safeStorage.isEncryptionAvailable()) throw new Error('Sistem güvenli hesap deposuna erişilemiyor.');
  const keyPath = path.join(app.getPath('userData'), 'account-key.bin');
  const key = fs.existsSync(keyPath) ? safeStorage.decryptString(fs.readFileSync(keyPath)) : crypto.randomBytes(32).toString('base64');
  if (!fs.existsSync(keyPath)) { fs.mkdirSync(path.dirname(keyPath), {recursive: true}); fs.writeFileSync(keyPath, safeStorage.encryptString(key), {mode: 0o600}); }
  const hostPath = app.isPackaged ? path.join(process.resourcesPath, 'host', 'Assistant.Host') : path.join(__dirname, '../host-publish', process.platform === 'win32' ? 'Assistant.Host.exe' : 'Assistant.Host');
  // Duman testi kendi geçici veri klasöründe çalışır; gerçek veriye dokunmaz.
  const data = dataFolder ?? (smoke ? path.join(app.getPath('userData'), 'data') : null);
  const hostArgs = [...(data ? ['--data', data] : []), ...(smoke ? ['--testing'] : [])];
  host = spawn(hostPath, hostArgs, {env: {...process.env, ASSISTANT_ACCOUNT_KEY: key}, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true});
  host.stderr.on('data', data => { if (smoke) process.stderr.write(data); });
  host.on('error', () => send({event: 'state', data: null}));
  createInterface({input: host.stdout}).on('line', line => {
    let message; try { message = JSON.parse(line); } catch { return; }
    if (message.event) {
      if (message.event === 'prompt') toast(message.data);
      else if (message.event === 'state') { const live = {...message.data, update: Boolean(updateRelease)}; lastLive = JSON.stringify(live); send({event: 'state', data: live}); }
      else send(message);
      return;
    }
    const request = pending.get(message.id); if (!request) return;
    clearTimeout(request.timer); pending.delete(message.id);
    message.success ? request.resolve(message.result) : request.reject(new Error(message.error));
  });
  host.on('exit', () => { for (const request of pending.values()) { clearTimeout(request.timer); request.reject(new Error('Asistan servisleri kapandı.')); } pending.clear(); });

  window = new BrowserWindow({width: 1400, height: 900, minWidth: 400, minHeight: 560, frame: false, backgroundColor: '#10151d', title: 'Kişisel Asistan', show: !smoke, webPreferences: {preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: !smoke}});
  window.webContents.setWindowOpenHandler(({url}) => { if (externalUrl(url)) shell.openExternal(url); return {action: 'deny'}; });
  window.webContents.on('will-navigate', (event, url) => { if (url !== entry) event.preventDefault(); });
  window.on('close', event => { if (!exiting) { event.preventDefault(); window.hide(); } });
  window.on('resize', () => layoutChats(slots));
  ipcMain.handle('workspace:call', async (event, method, params) => { assertSender(event); if (typeof method !== 'string') throw new Error('Geçersiz istek.'); return handle(method, params && typeof params === 'object' ? params : {}); });
  ipcMain.handle('workspace:speech', async (event, request) => { assertSender(event); return speech(request?.stage, request?.samples); });
  ipcMain.handle('notice:get', event => { const owner = noticeWindows.get(event.sender.id); if (!owner || event.senderFrame.url !== noticeEntry) throw new Error('Bildirim bulunamadı.'); return owner.item; });
  ipcMain.handle('notice:respond', async (event, response, minutes) => {
    const owner = noticeWindows.get(event.sender.id); if (!owner || event.senderFrame.url !== noticeEntry) throw new Error('Bildirim bulunamadı.');
    if (!['Done', 'Confirmed', 'NotDone', 'Snooze', 'Acknowledge'].includes(response) || ![5, 15].includes(minutes)) throw new Error('Geçersiz bildirim yanıtı.');
    const next = await rpc('reminder.respond', {id: owner.item.id, response, minutes}); notices.delete(owner.item.id); owner.popup.close(); if (next) toast(next); send({event: 'refresh'}); return true;
  });
  await window.loadURL(entry);
  if (smoke) {
    // Duman testi: ortak arayüz açılır, servisle konuşur ve Bugün ekranı çizilir.
    const snapshot = await workspace('snapshot', {});
    if (!snapshot?.live) throw new Error('Smoke: host returned no snapshot');
    let body = '';
    for (let i = 0; i < 40 && !body.includes('Bugün'); i++) { await new Promise(r => setTimeout(r, 250)); body = await window.webContents.executeJavaScript('document.querySelector("#page")?.innerText || ""'); }
    if (!body.includes('Bugün')) throw new Error('Smoke: interface did not load');
    // Arayüzün kendi köprüsünden: görev kaydı ve ortak komut yolu.
    const day = new Date().toLocaleDateString('sv-SE');
    await window.webContents.executeJavaScript(`rpc("item.save", {form: {title: "Electron denemesi", day: "${day}"}}).then(() => rpc("speech.command", {text: "yarın 9'da raporu hatırlat"})).then(() => refresh())`);
    // Hatırlatıcı komutu Takvim'e geçirir (navigate olayı); sonra Bugün'e dönülüp kaydedilen görev aranır.
    let page = '';
    for (let i = 0; i < 40 && page !== 'reminders'; i++) { await new Promise(r => setTimeout(r, 250)); page = await window.webContents.executeJavaScript('state.page'); }
    if (page !== 'reminders') throw new Error('Smoke: navigate event did not reach the interface');
    await window.webContents.executeJavaScript('state.page = "today"; render()');
    for (let i = 0; i < 40 && !body.includes('Electron denemesi'); i++) { await new Promise(r => setTimeout(r, 250)); body = await window.webContents.executeJavaScript('document.querySelector("#page")?.innerText || ""'); }
    if (!body.includes('Electron denemesi')) throw new Error('Smoke: task saved through the bridge did not appear');
    const reminders = (await workspace('snapshot', {})).reminders ?? [];
    if (!JSON.stringify(reminders).toLowerCase().includes('rapor')) throw new Error('Smoke: command path did not add the reminder');
    const output = process.env.ASSISTANT_SMOKE_RESULT;
    if (output) {
      let screenshot = false;
      try { const frame = await window.webContents.capturePage(); if (!frame.isEmpty()) { fs.writeFileSync(output + '.png', frame.toPNG()); screenshot = true; } } catch {}
      fs.writeFileSync(output, JSON.stringify({version: app.getVersion(), arch: process.arch, ui: true, host: true, screenshot}));
    }
    console.log('SMOKE_OK');
    exiting = true; host.kill(); app.exit(0); return;
  }
  setInterval(tick, 10000); tick();
  setInterval(publishLive, 1500);
  checkUpdate(); setInterval(checkUpdate, 6 * 3600000);
}).catch(error => { if (smoke) { console.error(error); host?.kill(); app.exit(1); return; } dialog.showErrorBox('Asistan başlatılamadı', error.message); app.quit(); });
app.on('activate', () => window?.show());
app.on('second-instance', () => { window?.show(); window?.focus(); });
app.on('before-quit', () => { exiting = true; host?.stdin.end(); host?.kill(); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
