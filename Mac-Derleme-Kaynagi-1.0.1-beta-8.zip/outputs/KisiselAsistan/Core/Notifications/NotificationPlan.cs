namespace KisiselAsistan;

// Bildirimleri hafifletme ayarları (Ayarlar → Bildirimler).
// DigestEnabled/DigestMinutes: her sabah tek bildirimle günün özeti (varsayılan 08:00).
// GroupReminders: birkaç saniye içinde düşen sıradan hatırlatmalar tek bildirimde listelenir (Yapana kadar türü ayrı kalır).
// SpeakDigest: özet saatinde günün özetini doğal sesle de oku (sesli cevap açıksa; varsayılan kapalı, oyun/video sırasında rahatsız etmesin).
// ShutdownEnabled/ShutdownMinutes: akşam kapanışı (Sunsama gibi); o saatte tek nazik bildirim "Günü kapat" (varsayılan 21:00).
// QuietEnabled/QuietStart/QuietEnd: rahatsız etme saatleri (gece yarısını geçebilir; varsayılan kapalı, 23:00–08:00).
// QuietFullscreen: tam ekran oyun/video/sunum öndeyken de sessiz kal (varsayılan açık). Ayrıntı QuietHours.
public sealed record NotificationSettings(bool DigestEnabled = true, int DigestMinutes = 480, bool GroupReminders = true, bool SpeakDigest = false, bool ShutdownEnabled = true, int ShutdownMinutes = 1260,
    bool QuietEnabled = false, int QuietStart = 1380, int QuietEnd = 480, bool QuietFullscreen = true)
{
    public void Validate()
    {
        if (DigestMinutes is < 0 or > 1439 || ShutdownMinutes is < 0 or > 1439) throw new ArgumentException("Özet ya da kapanış saati geçersiz.");
        if (QuietStart is < 0 or > 1439 || QuietEnd is < 0 or > 1439) throw new ArgumentException("Sessiz saatler geçersiz.");
        if (QuietEnabled && QuietStart == QuietEnd) throw new ArgumentException("Sessiz saatlerin başlangıcı ve bitişi aynı olamaz.");
    }
}

// Rahatsız etme: sessiz saatlerde ya da tam ekran bir uygulama (oyun, video, sunum) öndeyken bildirimler bekletilir,
// sessizlik bitince birlikte verilir. "Yapana kadar" (ADHD) hatırlatmalar beklemez: ilaç gibi kaçırılmaması gerekenler
// oyun sırasında da gelir. Odak ve kullanıcının o an başlattığı işlerin bildirimleri bu kurala girmez.
public static class QuietHours
{
    public static bool InWindow(NotificationSettings s, DateTimeOffset now)
    {
        if (!s.QuietEnabled || s.QuietStart == s.QuietEnd) return false;
        var minute = now.LocalDateTime.Hour * 60 + now.LocalDateTime.Minute;
        return s.QuietStart < s.QuietEnd ? minute >= s.QuietStart && minute < s.QuietEnd : minute >= s.QuietStart || minute < s.QuietEnd;
    }
    public static bool Active(NotificationSettings s, DateTimeOffset now, bool fullscreen) => InWindow(s, now) || (s.QuietFullscreen && fullscreen);
    public static bool Holds(ReminderPrompt prompt) => prompt.Reminder.Settings.Level != ReminderIntensity.Adhd;
    // Bekleyen diğer bildirimler (Steam, sabah özeti …) en fazla üç taneyse tek tek, fazlaysa tek özetle gösterilir.
    public const int ShowEach = 3;
    public static (string Title, string Message) Summary(IReadOnlyList<(string Source, string Title)> held) =>
        ($"Sessizken {held.Count} bildirim geldi", string.Join("\n", held.Take(8).Select(h => $"{h.Source}: {h.Title}")) + (held.Count > 8 ? $"\n… ve {held.Count - 8} tane daha" : ""));
}

// Uzakta: klavye/fare After kadar kullanılmadı. Tam ekran oyun/video sırasında kullanıcı izliyor sayılır (uzakta değil).
// Uzaktayken hatırlatmaların ilk bildirimi gider (telefon bağlıysa oraya da), tekrarları dönüşe kadar bekler (ReminderStore.TakeDue);
// sabah özeti de ayarlanan saatten sonra kullanıcının ilk etkin olduğu anda gelir.
public static class Presence
{
    public static readonly TimeSpan After = TimeSpan.FromMinutes(5);
    public static bool Away(TimeSpan idle, bool fullscreen) => !fullscreen && idle >= After;
}

public sealed class NotificationSettingsStore(string path)
{
    private readonly JsonListStore<NotificationSettings> store = new(path);
    public event Action? Changed;
    private NotificationSettings? cached;   // pencere saniyede bir sorar; dosya yalnız ilk okumada ve kayıtta açılır
    public NotificationSettings Current { get { try { return cached ??= store.Read().FirstOrDefault() ?? new(); } catch (Exception ex) when (ex is IOException or System.Text.Json.JsonException or InvalidDataException) { return new(); } } }
    public void Save(NotificationSettings settings) { settings.Validate(); store.Modify(_ => [settings]); cached = settings; Changed?.Invoke(); }
}

// Sabah özeti: o günün planları (hatırlatmasızlar dahil), görevleri ve gecikenleri tek metinde.
// Günde bir kez, ayarlanan saatten sonraki 4 saat içinde gösterilir (uygulama geç açılırsa yine gelir; öğleden sonra açılırsa atlanır).
public sealed record DailyDigestNotice(string Title, string Message);
public sealed class DailyDigest(IReminderService reminders, TaskRoutineService tasks, NotificationSettingsStore settings, string statePath, Func<DateTimeOffset>? clock = null)
{
    public static readonly TimeSpan ShowWindow = TimeSpan.FromHours(4);
    private sealed record State(DateOnly Shown);
    private readonly JsonListStore<State> state = new(statePath);
    private DateTimeOffset Now => clock?.Invoke() ?? DateTimeOffset.Now;

    public DailyDigestNotice? Poll()
    {
        var current = settings.Current;
        if (!current.DigestEnabled) return null;
        var now = Now; var today = DateOnly.FromDateTime(now.LocalDateTime);
        var at = new DateTimeOffset(today.ToDateTime(TimeOnly.MinValue), now.Offset).AddMinutes(current.DigestMinutes);
        if (now < at || now >= at + ShowWindow) return null;
        if (state.Read().FirstOrDefault()?.Shown == today) return null;
        state.Modify(_ => [new State(today)]);
        return Build(today, now);
    }
    // "Günaydın", "bugün ne var", "günümü özetle": sesle sorulunca özet sesli okunur.
    public static bool Asks(string text) => System.Text.RegularExpressions.Regex.IsMatch(text.Trim(), @"^(?:günaydın|bugün ne(?:ler)? var|bugün neler yapacağım|günümü özetle|bugünün özeti|günün özeti)[.!?]*$", System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.CultureInvariant);
    // Sesli okunacak hali: saatler "saat 9", "saat 14 30" gibi yazılır (ses motoru "09:00"ı rakam rakam okumasın).
    public string Spoken(DateOnly day, DateTimeOffset now, bool morning = true)
    {
        var items = reminders.Items;
        var plans = items.Where(r => !r.Done && DateOnly.FromDateTime(r.Due.LocalDateTime) == day && r.Due >= now.AddMinutes(-30)).OrderBy(r => r.Due).ToList();
        var todo = tasks.Items.Where(t => TaskRoutineService.IsOnDay(t, day)).ToList();
        string Clock(DateTime t) => t.Minute == 0 ? $"saat {t.Hour}" : $"saat {t.Hour} {t.Minute:00}";
        var sentences = new List<string> { morning ? "Günaydın!" : "Bugün için özet." };
        if (plans.Count == 0 && todo.Count == 0) { sentences.Add("Bugün takvimin boş, sakin bir gün."); return string.Join(" ", sentences); }
        sentences.Add(plans.Count > 0 && todo.Count > 0 ? $"Bugün {plans.Count} planın ve {todo.Count} görevin var." : plans.Count > 0 ? $"Bugün {plans.Count} planın var." : $"Bugün {todo.Count} görevin var.");
        if (plans.Count > 0) sentences.Add(string.Join(", ", plans.Take(4).Select(r => $"{Clock(r.Due.LocalDateTime)} {r.Text}")) + (plans.Count > 4 ? $", ve {plans.Count - 4} plan daha." : "."));
        if (todo.Count > 0) sentences.Add("Görevler: " + string.Join(", ", todo.Take(3).Select(t => t.Title)) + (todo.Count > 3 ? $" ve {todo.Count - 3} tane daha." : "."));
        return string.Join(" ", sentences);
    }
    // Özet metni. Boş günde de kısa bir cümle döner (sabah "bugün boş" bilgisi de işe yarar).
    public DailyDigestNotice Build(DateOnly day, DateTimeOffset now)
    {
        var items = reminders.Items;
        var plans = items.Where(r => !r.Done && DateOnly.FromDateTime(r.Due.LocalDateTime) == day).OrderBy(r => r.Due).ToList();
        var late = items.Count(r => !r.Done && !r.Settings.Silent && r.Due < now && DateOnly.FromDateTime(r.Due.LocalDateTime) < day);
        var allTasks = tasks.Items;
        var todo = allTasks.Where(t => TaskRoutineService.IsOnDay(t, day)).ToList();
        var lateTasks = allTasks.Count(t => TaskRoutineService.IsLate(t, day));
        var parts = new List<string>();
        if (plans.Count > 0) parts.Add($"{plans.Count} plan");
        if (todo.Count > 0) parts.Add($"{todo.Count} görev");
        var title = parts.Count == 0 ? "Günaydın · bugün boş" : "Günaydın · bugün " + string.Join(", ", parts);
        var lines = plans.Take(6).Select(r => $"{r.Due.LocalDateTime:HH:mm}  {r.Text}").ToList();
        if (plans.Count > 6) lines.Add($"… ve {plans.Count - 6} plan daha");
        if (todo.Count > 0) lines.Add("Görevler: " + string.Join(", ", todo.Take(4).Select(t => t.Title)) + (todo.Count > 4 ? $" (+{todo.Count - 4})" : ""));
        if (late + lateTasks > 0) lines.Add($"Geciken {late + lateTasks} iş seni bekliyor.");
        if (lines.Count == 0) lines.Add("Takvimin bugün boş. Sakin bir gün.");
        return new(title, string.Join("\n", lines));
    }
}

// Aynı anda düşen hatırlatmaları biriktirir: ilki geldikten Wait kadar sonra hepsi birlikte verilir.
// Tek kalan ayrı gösterilir. Yalnızca sıradan (Normal) asıl-saat hatırlatmaları birikir; diğerleri hemen geçer.
public sealed class ReminderBatcher(Func<DateTimeOffset>? clock = null)
{
    public static readonly TimeSpan Wait = TimeSpan.FromSeconds(4);
    private readonly List<ReminderPrompt> pending = [];
    private DateTimeOffset? first;
    private DateTimeOffset Now => clock?.Invoke() ?? DateTimeOffset.Now;
    public static bool Groupable(ReminderPrompt prompt) => prompt.Kind == ReminderPromptKind.Due && prompt.Reminder.Settings.Level == ReminderIntensity.Normal;
    // Hemen gösterilecekler döner; birikenler Flush ile gelir.
    public IReadOnlyList<ReminderPrompt> Add(IEnumerable<ReminderPrompt> prompts)
    {
        var now = Now; var immediate = new List<ReminderPrompt>();
        foreach (var p in prompts) {
            if (!Groupable(p)) { immediate.Add(p); continue; }
            pending.Add(p); first ??= now;
        }
        return immediate;
    }
    public IReadOnlyList<ReminderPrompt> Flush()
    {
        if (first is null || Now - first < Wait) return [];
        var batch = pending.ToList(); pending.Clear(); first = null;
        return batch;
    }
}

// Akşam kapanışı: günde bir kez, ayarlanan saatten sonraki 3 saat içinde "Günü kapat" bildirimi.
// O gün hiç iş yoksa gelmez. Bildirime basınca arayüzde kapanış penceresi açılır (bitenler kutlanır,
// kalanlar tek tıkla yarına / bir araya). Durum dosyası: shutdown-state.json.
public sealed record ShutdownNotice(string Title, string Message, int Done, int Left);
public sealed class EveningShutdown(TaskRoutineService tasks, IReminderService reminders, NotificationSettingsStore settings, string statePath, Func<DateTimeOffset>? clock = null)
{
    public static readonly TimeSpan ShowWindow = TimeSpan.FromHours(3);
    private sealed record State(DateOnly Shown);
    private readonly JsonListStore<State> state = new(statePath);
    private DateTimeOffset Now => clock?.Invoke() ?? DateTimeOffset.Now;
    public ShutdownNotice? Poll()
    {
        var current = settings.Current;
        if (!current.ShutdownEnabled) return null;
        var now = Now; var today = DateOnly.FromDateTime(now.LocalDateTime);
        var at = new DateTimeOffset(today.ToDateTime(TimeOnly.MinValue), now.Offset).AddMinutes(current.ShutdownMinutes);
        if (now < at || now >= at + ShowWindow || state.Read().FirstOrDefault()?.Shown == today) return null;
        var notice = Build(today, now);
        state.Modify(_ => [new State(today)]);
        return notice.Done + notice.Left == 0 ? null : notice;
    }
    // Bugünün tek seferlik görevleri (gün içi + gecikenler) ve bugünün hatırlatmalı planları; günlük aktiviteler sayılmaz.
    public ShutdownNotice Build(DateOnly day, DateTimeOffset now)
    {
        var dayTasks = tasks.Items.Where(t => !t.DailyActivity && (t.MyDay == day || t.Due == day || TaskRoutineService.IsLate(t, day))).ToList();
        var plans = reminders.Items.Where(r => !r.Settings.Silent && DateOnly.FromDateTime(r.Due.LocalDateTime) == day).ToList();
        int done = dayTasks.Count(t => t.Done) + plans.Count(r => r.Done), left = dayTasks.Count(t => !t.Done) + plans.Count(r => !r.Done && r.Due < now);
        var message = (done > 0 ? $"Bugün {done} iş bitirdin. " : "") + (left > 0 ? $"{left} iş kaldı; yarına ya da bir araya atıp günü kapatabilirsin." : "Hepsi tamam, günü kapatabilirsin.");
        return new("Günü kapatalım mı?", message, done, left);
    }
}
