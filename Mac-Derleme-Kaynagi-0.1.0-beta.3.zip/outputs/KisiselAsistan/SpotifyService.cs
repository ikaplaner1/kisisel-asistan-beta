namespace KisiselAsistan;

public record SpotifyQueryRequest(string Query);
public record SpotifyPlayRequest(SpotifyTrack Track);
public record SpotifySearchPlayResult(List<SpotifyTrack> Tracks, string Message) : IOperationOutcome { public bool Success => Tracks.Count > 0; }

public interface ISpotifyPlayback
{
    Task<List<SpotifyTrack>> SearchAsync(string query, CancellationToken token);
    Task<string> PlayAsync(SpotifyTrack track, CancellationToken token);
    Task<SpotifyPlaying?> CurrentAsync(CancellationToken token);
}
public sealed class SpotifyService(SpotifyController controller, ISpotifyPlayback playback)
{
    private readonly SemaphoreSlim playbackGate = new(1, 1);
    public void Register(OperationRegistry operations)
    {
        RegisterControls(operations, controller);
        operations.RegisterAsync<SpotifyQueryRequest, List<SpotifyTrack>>("spotify.search", "Spotify şarkılarını ara", (r, t) => playback.SearchAsync(r.Query.Trim(), t), r => ValidateQuery(r.Query));
        operations.RegisterAsync<SpotifyPlayRequest, string>("spotify.playTrack", "Seçilen şarkıyı çal", (r, t) => PlayAsync(r.Track, t), r => ValidateTrack(r.Track));
        operations.RegisterAsync<SpotifyQueryRequest, SpotifySearchPlayResult>("spotify.searchAndPlay", "Şarkıyı bul ve çal", (r, t) => SearchAndPlayAsync(r.Query, t), r => ValidateQuery(r.Query));
        operations.RegisterAsync<NoArguments, SpotifyPlaying?>("spotify.current", "Çalan şarkıyı getir", (_, t) => playback.CurrentAsync(t));
    }
    public static void RegisterControls(OperationRegistry operations, SpotifyController controller)
    {
        operations.RegisterAsync<NoArguments, CommandResult>("spotify.open", "Spotify masaüstü uygulamasını aç", (_, t) => controller.OpenAsync(t));
        operations.Register<SpotifyControlRequest, CommandResult>("spotify.control", "Spotify kontrolü: pause=duraklat/durdur, play=devam et, next=sonraki parça, previous=önceki parçaya dön, toggle=duraklat/oynat, open=uygulamayı göster, search=ara", r => controller.Act(r.Action, r.Query), r => { if (r.Action is not ("open" or "search" or "toggle" or "next" or "previous" or "pause" or "play")) throw new ArgumentException("Geçersiz Spotify kontrolü."); if (r.Action == "search") ValidateQuery(r.Query); });
        operations.Register<NoArguments, SpotifyState>("spotify.status", "Spotify masaüstü durumunu kontrol et", _ => controller.Status());
    }
    private static void ValidateQuery(string? query) { if (string.IsNullOrWhiteSpace(query) || query.Length > 200) throw new ArgumentException("Şarkı ve sanatçı adı 1–200 karakter olmalı."); }
    private static void ValidateTrack(SpotifyTrack track) { if (track == null || !System.Text.RegularExpressions.Regex.IsMatch(track.Uri ?? "", "^spotify:track:[A-Za-z0-9]{22}$")) throw new ArgumentException("Geçersiz şarkı adresi."); }
    private async Task<string> PlayAsync(SpotifyTrack track, CancellationToken token)
    {
        if (!await playbackGate.WaitAsync(0, token)) throw new InvalidOperationException("Şarkı işlemi zaten sürüyor.");
        try { return await playback.PlayAsync(track, token); } finally { playbackGate.Release(); }
    }
    private async Task<SpotifySearchPlayResult> SearchAndPlayAsync(string query, CancellationToken token)
    {
        if (!await playbackGate.WaitAsync(0, token)) throw new InvalidOperationException("Şarkı işlemi zaten sürüyor.");
        try {
            var found = await playback.SearchAsync(query.Trim(), token); token.ThrowIfCancellationRequested();
            if (found.Count == 0) return new(found, "Şarkı bulunamadı. Şarkı ve sanatçı adını birlikte söyle.");
            ValidateTrack(found[0]);
            return new(found, await playback.PlayAsync(found[0], token));
        } finally { playbackGate.Release(); }
    }
}
