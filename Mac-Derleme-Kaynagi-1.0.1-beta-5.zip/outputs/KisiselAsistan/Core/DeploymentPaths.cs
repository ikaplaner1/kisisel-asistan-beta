namespace KisiselAsistan;

internal static class DeploymentPaths
{
    // Bütün kullanıcı verisi buradan çözülür. Testler başlarken UseDataFolder ile kendi klasörlerine
    // yönlendirilir; böylece hiçbir test gerçek görevlere, hesaplara veya ayarlara dokunamaz.
    private static string? dataOverride;
    internal static string UserData => dataOverride ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KisiselAsistan");
    internal static string Data(params string[] parts) => Path.Combine([UserData, .. parts]);
    internal static bool Isolated => dataOverride != null;
    internal static void UseDataFolder(string folder) { dataOverride = Path.GetFullPath(folder); Directory.CreateDirectory(dataOverride); }
    internal static string SpeechModel => ResolveSpeechModel(AppContext.BaseDirectory, UserData);
    internal static string ResolveSpeechModel(string appDirectory, string userDirectory)
    {
        const string name = "ggml-small-q5_1.bin";
        var installed = Path.Combine(userDirectory, "Models", name);
        if (File.Exists(installed)) return installed;
        var bundled = Path.Combine(appDirectory, "models", name);
        if (File.Exists(bundled)) return bundled;
        var developmentRoot = Path.GetFullPath(Path.Combine(appDirectory, "..", "..", ".."));
        if (File.Exists(Path.Combine(developmentRoot, "KisiselAsistan.csproj")))
            return Path.Combine(developmentRoot, "models", name);
        return installed;
    }
    internal static string? PortableOllamaRuntime
    {
        get {
            var installed = Path.Combine(UserData, "Ollama", "runtime", "ollama.exe");
            if (File.Exists(installed)) return installed;
            var developmentRoot = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", ".."));
            if (!File.Exists(Path.Combine(developmentRoot, "KisiselAsistan.csproj"))) return null;
            var development = Path.GetFullPath(Path.Combine(developmentRoot, "..", "Ollama", "runtime", "ollama.exe"));
            return File.Exists(development) ? development : null;
        }
    }
}
