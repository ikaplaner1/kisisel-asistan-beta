namespace KisiselAsistan;

// İşlem sonuçlarının ortak biçimi: başarılı mı, kullanıcıya ne söylenecek.
public interface IOperationOutcome { bool Success { get; } string Message { get; } }
public record CommandResult(bool Success, string Message) : IOperationOutcome;
