"use strict";
// Çekirdek: yardımcılar, simgeler, durum, masaüstü köprüsü ve sayfa çizimi.
// Dosyalar klasik betik olarak sırayla yüklenir; buradaki üst düzey adlar
// diğer dosyalarda ve masaüstü testlerinde (WebWorkspaceTests.cs) kullanılır.

const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );

// ---------------------------------------------------------------- Simgeler
const paths = {
  orbit:
    '<circle cx="12" cy="12" r="3"/><path d="M5 16C1 10 6 2 12 3M19 8c4 6-1 14-7 13"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/>',
  task: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  calendar:
    '<rect x="4" y="5" width="16" height="16" rx="2"/><path d="M8 3v4m8-4v4M4 10h16m-12 4h1m3 0h1m3 0h1m-9 3h1m3 0h1"/>',
  shortcut:
    '<rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="13" width="8" height="8" rx="2"/><path d="M7 11v6h6"/>',
  game: '<path d="M7 7h10c4 0 6 12 2 12l-4-3H9l-4 3C1 19 3 7 7 7Z"/><path d="M6 11h5m-2.5-2.5v5m7-2h.1m2 2h.1"/>',
  music: '<path d="M11 18V3l7 4"/><ellipse cx="7" cy="18" rx="4" ry="3"/>',
  ai: '<path d="m10 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3Zm9-2v6m-3-3h6"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01"/>',
  mic: '<rect x="9" y="2" width="6" height="13" rx="3"/><path d="M6 10v2a6 6 0 0 0 12 0v-2m-6 8v4m-3 0h6"/>',
  settings: '<path d="M3 6h18M3 12h18M3 18h18m-6-15v6M8 9v6m7 0v6"/>',
  refresh: '<path d="M20 7v5h-5M4 17v-5h5M5 8a8 8 0 0 1 13-4l2 3M4 17l2 3a8 8 0 0 0 13-4"/>',
  palette:
    '<path d="M12 3a9 9 0 1 0 0 18h2c3 0 2-3 1-4-1-2 0-3 2-3h2c4 0 2-11-7-11Z"/><path d="M7 9h.1M10 6h.1M15 6h.1M18 10h.1"/>',
  expand: '<path d="M4 9V4h5m11 11v5h-5M4 4l6 6m10 10-6-6"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 0 1 6 0c0 2-3 2-3 5m0 3h.1"/>',
  code: '<path d="m8 6-6 6 6 6m8-12 6 6-6 6m-3-15-2 18"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  left: '<path d="m14 6-6 6 6 6"/>',
  right: '<path d="m10 6 6 6-6 6"/>',
  star: '<path d="m12 2 3 6 7 1-5 5 1 8-6-4-6 4 1-8-5-5 7-1Z"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2Z"/><path d="M4 21V5M8 7h7"/>',
  more: '<circle cx="5" cy="12" r=".7"/><circle cx="12" cy="12" r=".7"/><circle cx="19" cy="12" r=".7"/>',
  external: '<path d="M14 3h7v7m0-7L10 14M10 3H4v17h16v-6"/>',
  search: '<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
  play: '<path d="m8 4 12 8-12 8Z"/>',
  pause: '<path d="M8 4v16M16 4v16"/>',
  queue: '<path d="M4 6h12M4 12h12M4 18h7m7-4v8m-4-4h8"/>',
  shuffle: '<path d="M3 7h3c4 0 6 10 10 10h5m0 0-3-3m3 3-3 3M3 17h3c1.5 0 2.7-1.4 3.8-3.2M21 7h-5c-1.5 0-2.7 1.4-3.8 3.2M21 7l-3-3m3 3-3 3"/>',
  repeat: '<path d="M17 2l3 3-3 3M4 11V9a4 4 0 0 1 4-4h12M7 22l-3-3 3-3m13-3v2a4 4 0 0 1-4 4H4"/>',
  "repeat-one": '<path d="M17 2l3 3-3 3M4 11V9a4 4 0 0 1 4-4h12M7 22l-3-3 3-3m13-3v2a4 4 0 0 1-4 4H4"/><path d="M11 10.5l1.5-1V15"/>',
  previous: '<path d="M5 4v16m14-16L7 12l12 8Z"/>',
  next: '<path d="M19 4v16M5 4l12 8-12 8Z"/>',
  volume: '<path d="M3 9h4l5-5v16l-5-5H3Zm13-2a7 7 0 0 1 0 10m3-13a11 11 0 0 1 0 16"/>',
  "volume-off": '<path d="M3 9h4l5-5v16l-5-5H3Zm13 0 6 6m0-6-6 6"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  folder: '<path d="M3 7V4h7l3 3h8v13H3Z"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16Z"/><path d="m13 7 4 4"/>',
  trash: '<path d="M4 7h16M10 11v6m4-6v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
  // Kategori simgeleri (zaman akışındaki renkli kabarcıklar): Kişisel, İş, Sağlık, Boş vakit.
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  briefcase: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18"/>',
  heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z"/>',
  coffee: '<path d="M4 9h13v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V9Zm13 1h1.5a2.5 2.5 0 0 1 0 5H17M8 3v3m4-3v3"/>',
  grip: '<circle cx="9" cy="6" r="1"/><circle cx="15" cy="6" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="18" r="1"/>',
  minus: '<path d="M6 12h12"/>',
  box: '<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5v-9Z"/><path d="m3 7.5 9 4.5 9-4.5M12 12v9"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  up: '<path d="m6 15 6-6 6 6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
};
const I = (n) => `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[n] || paths.task}</svg>`;
const B = (text, action, icon = "", cls = "", data = "") =>
  `<button type="button" data-action="${action}" class="${cls}" ${data}>${icon ? I(icon) : ""}${text}</button>`;

// ---------------------------------------------------------------- Bileşenler (Preact + htm, vendor/)
// html`…` şablonu JSX'in derleme gerektirmeyen karşılığıdır: html`<${Icon} n="search" />`.
// Olaylar eski sayfalardaki gibi data-action ile belge düzeyinde yakalanır (actions.js); bileşen yalnızca çizer.
// Bir sayfa bileşene çevrilince pageComponents'e kaydedilir: pageComponents.steam = SteamPage.
const html = htmPreact.html;
const pageComponents = {};
const Icon = ({ n }) => html`<svg viewBox="0 0 24 24" aria-hidden="true" dangerouslySetInnerHTML=${{ __html: paths[n] || paths.task }}></svg>`;
const Button = ({ action, icon, cls = "", children, ...rest }) =>
  html`<button type="button" data-action=${action} class=${cls} ...${rest}>${icon && html`<${Icon} n=${icon} />`}${children}</button>`;
// Sayfa başlığı: başlık ve ana işlem tek satırda; açıklama araç ipucunda.
const Heading = ({ title, sub, children }) =>
  html`<div class="page-heading"><div class="page-title"><h1>${title}</h1>${sub && html`<p class="page-sub">${sub}</p>`}</div><div class="heading-actions">${children}</div></div>`;
const Empty = ({ text }) => html`<div class="empty"><p>${text}</p></div>`;
const Chip = ({ tone = "", children }) => html`<span class=${"chip " + tone}>${children}</span>`;

// Spotify kapakları uygulama üzerinden, diske önbelleğe alınarak gelir (Shell/CoverCache.cs).
const spotifyCover = (url) => `https://covers.assistant.local/spotify?u=${encodeURIComponent(url)}`;

// ---------------------------------------------------------------- Tarih
const dayKey = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const parseDay = (s) => new Date(s + "T12:00:00");
const today = () => dayKey(new Date());
// Geciken görev: son tarihi ya da planlandığı gün geçmiş, bitmemiş tek seferlik iş. Planlandığı gün geçen iş
// yalnız son tarihe bakılsaydı Bugün'den sessizce kaybolurdu (C# karşılığı TaskRoutineService.IsLate).
const taskLate = (t, key = today()) => !t.dailyActivity && !t.done && ((t.due && t.due < key) || (t.myDay && t.myDay < key));
const clock = (d) => new Date(d).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
function relativeDay(d) {
  const key = dayKey(new Date(d)),
    diff = Math.round((parseDay(key) - parseDay(today())) / 86400000);
  if (diff === 0) return "bugün";
  if (diff === 1) return "yarın";
  if (diff === -1) return "dün";
  return new Date(d).toLocaleDateString("tr-TR", { day: "numeric", month: "long" });
}

// ---------------------------------------------------------------- Durum
const state = {
  page: "today",
  day: today(),
  filter: "Gün",
  lane: "daily",
  // "Bir ara" listesinde bu oturumda tamamlanan görevler (geri al düğmesi için; en son tamamlanan sonda).
  somedayDone: [],
  calendar: "Ay",
  data: null,
  steamResults: [],
  spotifyResults: [],
  playing: null,
  aiProvider: 0,
  aiSingle: false,
  aiQuestion: "",
  targets: [true, true, true],
  completed: false,
  // Ana ekran: asistan kutusundaki metin ve önizleme, boş bir anında listesinin açık olması, boş vakit önerisinin sırası.
  askText: "",
  askHint: "",
  freeExpanded: false,
  suggestAt: 0,
  query: { steam: "", spotify: "" },
  modal: null,
};
// Bölüm kimlikleri masaüstü tarafıyla eşleşir ("today" masaüstünde Görevler sekmesine düşer);
// burada yalnızca görsel sıra, dar menüdeki kısa ad, simge ve araç ipucu var.
const sections = [
  // "Ana": ana ekran (asistan, şimdi, boş bir anında yapılacaklar); kimlik "today" kalır (kayıtlı sekmeler, komutlar, testler).
  ["today", "Ana", "orbit", "Ana ekran (Esc): asistan, şimdi ve boş bir anında yapılacaklar"],
  ["reminders", "Takvim", "calendar", "Takvim"],
  ["steam", "Oyunlar", "game", "Steam oyun takibi"],
  ["stock", "Stok", "box", "Stok takibi: ürün bağlantıları"],
  ["shortcuts", "Kısayol", "shortcut", "Kısayollar"],
  ["ai", "AI", "chat", "AI sohbetleri"],
  // Büyük görünümde sol menünün en altında durur (CSS); küçük görünümde şeridin sonunda.
  ["settings", "Ayarlar", "settings", "Bütün ayarlar"],
];
// Kaldırılan bölümler (Görevler, Müzik) Bugün'e düşer; eski sesli komutlar ve kayıtlı sekmeler bozulmaz.
const sectionOf = (page) => (sections.some((s) => s[0] === page) ? page : "today");
const names = ["ChatGPT", "Gemini", "Claude"];

// ---------------------------------------------------------------- Masaüstü köprüsü
// Windows'ta WebView2 (window.chrome.webview), Mac'te Electron ön yükleyicisi (window.assistantBridge) aynı biçimde konuşur.
const bridge = window.chrome?.webview ?? window.assistantBridge;
let sequence = 0;
const pending = new Map();
let toastTimer, searchTimer, slotTimer, statusTimer;
// timeout: tarayıcıda izin beklemek veya büyük indirme gibi uzun işlemler için uzatılabilir.
function rpc(method, params = {}, timeout = 180000) {
  return new Promise((resolve, reject) => {
    const id = ++sequence;
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error("İşlem zaman aşımına uğradı. Tekrar deneyebilirsin."));
    }, timeout);
    pending.set(id, { resolve, reject, timer });
    if (bridge) bridge.postMessage({ id, method, params });
    else {
      clearTimeout(timer);
      pending.delete(id);
      reject(new Error("Masaüstü bağlantısı hazır değil."));
    }
  });
}
function receive(message) {
  if (message.id) {
    const p = pending.get(message.id);
    if (!p) return;
    clearTimeout(p.timer);
    pending.delete(message.id);
    message.ok ? p.resolve(message.data) : p.reject(new Error(message.error || "İşlem tamamlanamadı."));
    return;
  }
  if (message.event === "state") applyLive(message.data);
  if (message.event === "refresh") run(refresh);
  if (message.event === "selection") {
    state.page = "ai";
    state.aiQuestion = message.data.text;
    render();
  }
  // Açık ayar penceresine canlı ilerleme yazıları.
  if (message.event === "google" && $("#google-status")) $("#google-status").textContent = message.data;
  if (message.event === "ollama" && $("#ollama-status")) $("#ollama-status").textContent = message.data;
  if (message.event === "voice" && $("#voice-status")) $("#voice-status").textContent = message.data;
  // Sesli komutla yapılan Steam/Spotify aramalarının sonuçları.
  if (message.event === "results") {
    state[message.data.type === "steam" ? "steamResults" : "spotifyResults"] = message.data.items || [];
    if (message.data.query != null) state.query[message.data.type] = message.data.query;
    if (state.page === message.data.type) render();
  }
  // Asistan sesle bir bilgi sordu: cevap için mikrofon, düğmeye basılmış gibi açılır (6 sn ses gelmezse kapanır).
  if (message.event === "ask" && !state.data?.live?.listening) run(() => action("microphone-answer"));
  // "toplu ekle": sesle ya da komutla gelen metin önizleme penceresinde açılır; metin yoksa pencere dinlemeye başlar.
  if (message.event === "dump") run(() => dumpDialog(message.data || "", { listen: !message.data && !$("#dump-form") }));
  // Akşam kapanışı bildirimine basıldı.
  if (message.event === "shutdown") shutdownDialog();
  // Odak aşaması bitti: çalışma bitince kutlama, mola bitince yumuşak ses.
  // Tur bitişi sesli; mola bitişi sessiz (bildirimde "Yeni tur?" sorulur).
  if (message.event === "focus" && message.data.ended === "Work") playSound("allDone");
  if (message.event === "navigate") {
    state.page = sectionOf(message.data);
    render();
  }
}
bridge?.addEventListener("message", (e) => receive(e.data));

function toast(text) {
  $("#toast").textContent = text;
  $("#toast").hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($("#toast").hidden = true), 4500);
}
async function run(fn) {
  try {
    return await fn();
  } catch (e) {
    toast(e.message);
    const error = $(".inline-error");
    if (!error) return;
    error.textContent = e.message;
    // Pencerenin sonundaki hata yeri yapışkan Kaydet satırının altında kalır; görünsün diye o satırın başına alınır.
    const actions = error.parentElement?.querySelector(":scope > form .dialog-actions, :scope > .dialog-actions");
    if (actions && !actions.contains(error)) actions.prepend(error);
  }
}
// ---------------------------------------------------------------- Veri deposu
// C# her veri parçasına (tasks, reminders, routines, steam, defaults, themes) bir sürüm verir.
// refresh() bildiğimiz sürümleri gönderir; yalnızca değişen parçalar gelir ve yalnızca o zaman yeniden çizilir.
// Hatırlatıcılarda tekrarlar seçili günün çevresindeki tarih aralığı kadar gelir; aralık dışına çıkınca yeniden istenir.
const loaded = { versions: {}, from: null, to: null, changed: [] };
const addDays = (key, n) => {
  const d = parseDay(key);
  d.setDate(d.getDate() + n);
  return dayKey(d);
};
function wantedRange() {
  const base = today(),
    day = state.day;
  return { from: [addDays(base, -62), addDays(day, -45)].sort()[0], to: [addDays(base, 190), addDays(day, 45)].sort()[1] };
}
const outsideRange = () => loaded.from && (addDays(state.day, -40) < loaded.from || addDays(state.day, 40) > loaded.to);
let refreshPromise = null,
  refreshAgain = false;
function refresh() {
  if (refreshPromise) {
    refreshAgain = true;
    return refreshPromise;
  }
  refreshPromise = (async () => {
    do {
      refreshAgain = false;
      const range = wantedRange();
      const reply = await rpc("snapshot", { known: loaded.versions, ...range });
      const changed = Object.keys(reply).filter((k) => k !== "versions" && k !== "live");
      state.data = { ...state.data, ...Object.fromEntries(changed.map((k) => [k, reply[k]])) };
      Object.assign(loaded, { versions: reply.versions, changed }, range);
      applyLive(reply.live);
      if (changed.length) render();
    } while (refreshAgain);
  })().finally(() => (refreshPromise = null));
  return refreshPromise;
}

// ---------------------------------------------------------------- Tema ve canlı durum
const roles = ["bg", "surface", "selected", "text", "muted", "accent", "border", "numbers", "title"];
function themeVars(element, colors) {
  colors.forEach((c, i) => element.style.setProperty("--" + roles[i], c));
  const n = parseInt(colors[5].slice(1), 16);
  element.style.setProperty(
    "--on-accent",
    (n >> 16) * 0.299 + ((n >> 8) & 255) * 0.587 + (n & 255) * 0.114 > 150 ? "#111827" : "#ffffff",
  );
}
// Masaüstündeki durum yazısı kalıcıdır; burada yalnızca yeni bir mesaj geldiğinde
// birkaç saniye gösterilir, sonra sesli asistanın durumuna geri dönülür.
let lastStatus = null,
  phaseText = "Hazır";
function showPhase() {
  $("#phase").textContent = phaseText;
  $("#phase").classList.remove("is-message");
  // Ana ekrandaki asistan kutusunda "Hazır" gizlenir (yalnız dinlerken, çalışırken ya da mesajda görünür).
  $("#phase").classList.toggle("is-idle", phaseText === "Hazır");
}
// Sesli komut sesleri: mikrofon açılınca "listen"; sesle verilen komut bitince "understood" ya da "missed".
// Yalnız sesli akışta çalar (yazılı komutlar sessiz); Ses ayarlarındaki "Arayüz sesleri" ile kapanır.
let wasListening = false,
  voiceUntil = 0,
  lastPhase = "";
function voiceEarcons(live) {
  const listening = !!live.listening,
    phase = live.phase || "";
  if (listening && !wasListening) playSound("listen");
  if (!listening && wasListening) voiceUntil = Date.now() + 60000;
  if (phase !== lastPhase && Date.now() < voiceUntil) {
    if (phase === "Bitti") playSound("understood");
    if (phase === "Anlaşılmadı") playSound("missed");
    if (phase === "Bitti" || phase === "Anlaşılmadı") voiceUntil = 0;
  }
  wasListening = listening;
  lastPhase = phase;
}
function applyLive(live) {
  if (!live) return;
  if (!commandBar.isConnected) placeCommandBar();
  const previousCompact = document.body.classList.contains("compact");
  document.body.classList.toggle("compact", live.compact);
  $("#view-label").textContent = live.compact ? "Genişlet" : "Küçült";
  themeVars(document.documentElement, live.colors);
  document.documentElement.style.colorScheme = live.dark ? "dark" : "light";
  phaseText = live.phase.replace(/^●\s*/, "") || "Hazır";
  const message = live.status || "";
  if (lastStatus === null) lastStatus = message;
  else if (message !== lastStatus) {
    lastStatus = message;
    if (message) {
      $("#status").textContent = message;
      $("#phase").textContent = message;
      $("#phase").classList.add("is-message");
      $("#phase").classList.remove("is-idle");
      clearTimeout(statusTimer);
      statusTimer = setTimeout(showPhase, 5000);
    }
  }
  if (!$("#phase").classList.contains("is-message") || live.busy) showPhase();
  voiceEarcons(live);
  document.body.classList.toggle("listening", !!live.listening);
  $("#cancel-command").hidden = !live.busy;
  $(".microphone").classList.toggle("listening", live.listening);
  $(".microphone").disabled = live.busy && !live.listening;
  // Mikrofon açıkken de yazılabilir: yazılan komut dinlemeyi bırakır (soruya yazarak cevap vermek için).
  $("#command").disabled = live.busy && !live.listening;
  // Asistan bir bilgi sorduysa (ör. "Ne zaman hatırlatayım?") cevap kutuya yazılır; önceki cümleyle birleştirilir.
  $("#command").placeholder = live.question ? "Cevabını yaz… (vazgeçmek için “vazgeç”)" : "Bir komut yaz veya söyle…";
  $("#command").classList.toggle("awaiting-answer", !!live.question);
  $("#publish").hidden = !live.developer;
  $("#update-button").hidden = !live.update;
  const routineChanged = state.data && (state.data.live?.routineStatus || "") !== (live.routineStatus || "");
  // Odak başlayınca, aşama değişince ya da bitince Bugün yeniden çizilir (kalan süreyi bileşen kendisi sayar).
  const focusKey = (f) => (f ? `${f.phase}|${f.endsAt}|${f.todayCount}|${f.task}` : "");
  const focusChanged = state.data && focusKey(state.data.live?.focus) !== focusKey(live.focus);
  if (state.data) state.data.live = live;
  if (focusChanged) {
    ambientSync();
    focusHistory.at = 0; // biten tur geçmişe yazıldı; Odak widget'ı yeniden alsın
  }
  if (focusChanged && state.page === "today" && !state.modal) render();
  // Kısayol çalışmaya başlayınca ya da bitince "Durdur" şeridi görünür/kaybolur.
  if (routineChanged && state.page === "shortcuts" && !state.modal) render();
  if ($("#routine-status")) $("#routine-status").textContent = live.routineStatus || "";
  if (previousCompact !== live.compact && state.data) render();
  scheduleSlots();
}
const compact = () => document.body.classList.contains("compact");

// ---------------------------------------------------------------- Ortak parçalar
// Sayfa başlığı: başlık ve ana işlem tek satırda. Açıklama yalnızca araç ipucu olarak kalır.
function header(title, sub, action = "") {
  return `<div class="page-heading"><h1 title="${esc(sub)}">${title}</h1><div class="heading-actions">${action}</div></div>`;
}
function dateToolbar(extra = "") {
  const label = parseDay(state.day).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" });
  return `<div class="toolbar"><div class="date-nav">${B("", "day-prev", "left", "arrow", 'aria-label="Önceki"')}<span class="date">${label}</span>${B("", "day-next", "right", "arrow", 'aria-label="Sonraki"')}</div>${state.day === today() ? "" : B("Bugün", "today", "", "ghost")}${extra}</div>`;
}
const overdueCount = () => state.data.reminders.filter((r) => !r.done && new Date(r.due) < new Date()).length;
const empty = (text, extra = "") => `<div class="empty"><p>${text}</p>${extra}</div>`;

// ---------------------------------------------------------------- Çizim
// Küçük görünümde şerit kaydırılmışsa yeniden çizimde yerinde kalır; etkin sekmeye yalnız sekme değişince kayılır.
// (Önceden her yenilemede — birkaç saniyede bir — etkin sekmeye dönülüyordu; tekerlekle kaydırılan şerit geri sıçrıyordu.)
let navPageShown = null;
function renderNavigation() {
  const nav = $("#navigation"),
    left = nav.scrollLeft;
  nav.innerHTML = sections
    .map(([id, title, icon, tip]) =>
      B(
        `<span>${esc(title)}</span>${id === "today" && overdueCount() ? `<b class="nav-badge">${overdueCount()}</b>` : ""}`,
        "navigate",
        icon,
        state.page === id ? "active" : "",
        `data-page="${id}" aria-current="${state.page === id ? "page" : "false"}" title="${esc(tip)}"`,
      ),
    )
    .join("");
  $("#settings-nav").classList.toggle("active", state.page === "settings");
  nav.scrollLeft = left;
  const changed = navPageShown !== state.page + (compact() ? ":c" : "");
  navPageShown = state.page + (compact() ? ":c" : "");
  if (compact() && changed) $("#navigation .active")?.scrollIntoView({ block: "nearest", inline: "nearest" });
}
function render() {
  if (!state.data) return;
  closeMenu();
  if (outsideRange()) run(refresh);
  if (state.page !== "today") state.freeKeep = null;
  const page = $("#page");
  page.className = "page-" + state.page;
  document.body.dataset.section = state.page;
  renderNavigation();
  // Sabit parçalardaki (üst çubuk, menü altı, komut şeridi) simgeler.
  $$("[data-icon]:empty").forEach((el) => (el.innerHTML = I(el.dataset.icon)));
  // Bütün sayfalar bileşendir (Preact): yalnızca değişen kısım güncellenir, odak ve kaydırma korunur.
  if (page.dataset.mode !== "component") {
    page.textContent = "";
    page.dataset.mode = "component";
  }
  htmPreact.render(html`<${pageComponents[state.page] || pageComponents.today} />`, page);
  // Şerit önce yerine konur: ana ekrandan çıkarken yuvayla birlikte belgeden düşmüş olabilir (#bar-player da içinde).
  placeCommandBar();
  htmPreact.render(html`<${BarPlayer} />`, $("#bar-player", commandBar));
  afterRender();
  scheduleSlots();
  // İlk açılış tanıtımı (tour.js): koşullar uygunsa bir kez başlar.
  if (typeof tourAutoStart === "function") tourAutoStart();
  if (typeof feedbackNoticeAutoStart === "function") feedbackNoticeAutoStart();
}
// Ana ekranda asistan kutusu (komut şeridinin kendisi) ortadaki yuvaya (#ask-slot) taşınır, başka bölümde alta döner.
// Tek öğe: yazılan yarım metin, dinleme durumu ve olaylar korunur. Preact yuvanın içine dokunmaz (kendi çizmediği düğüm);
// yuva silinince şerit onunla birlikte belgeden çıkar ve burada yeniden yerine konur.
const commandBar = $(".command-bar");
function placeCommandBar() {
  const target = $("#ask-slot") || $(".workspace");
  document.body.classList.toggle("ask-home", target.id === "ask-slot");
  if (commandBar.parentElement === target) return;
  const focused = document.activeElement === $("#command", commandBar);
  target.append(commandBar);
  if (focused) $("#command", commandBar).focus();
}
function afterRender() {
  // Hafta görünümünü sabah saatlerine ya da ilk plana kaydır.
  const body = $(".week-body");
  if (body && !body.dataset.scrolled) {
    const first = $$(".week-event", body).map((e) => e.offsetTop);
    body.scrollTop = Math.max(0, (first.length ? Math.min(...first) : (8 - firstHour) * hourHeight) - 24);
    body.dataset.scrolled = "1";
  }
}

// AI siteleri ayrı yerel tarayıcılarda açılır; HTML yalnızca yerlerini bildirir.
function scheduleSlots() {
  clearTimeout(slotTimer);
  slotTimer = setTimeout(() => {
    if (!bridge) return;
    const slots =
      state.page === "ai" && !state.modal
        ? $$(".ai-card:not([hidden]) .ai-slot").map((el) => {
            const r = el.getBoundingClientRect(),
              p = $("#page").getBoundingClientRect();
            return {
              index: +el.dataset.provider,
              x: r.x,
              y: Math.max(r.y, p.y),
              width: r.width,
              height: Math.max(0, Math.min(r.bottom, p.bottom) - Math.max(r.y, p.y)),
            };
          })
        : [];
    rpc("ai.layout", { slots, viewportWidth: innerWidth, viewportHeight: innerHeight }).catch(() => {});
  }, 45);
}
