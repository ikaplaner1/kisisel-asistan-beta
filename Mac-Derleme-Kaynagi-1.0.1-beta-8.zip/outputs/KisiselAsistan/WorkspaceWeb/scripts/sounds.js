"use strict";
// Arayüz sesleri: dosya yok, Web Audio ile anında üretilir. Kısa ve yumuşak tutulur;
// her tıklamaya değil, yalnızca bir şey başarıldığında ya da eklendiğinde çalar.

let audio = null;
function soundsOn() {
  try {
    return localStorage.getItem("ui-sounds") !== "off";
  } catch {
    return true;
  }
}
function setSoundsOn(on) {
  try {
    localStorage.setItem("ui-sounds", on ? "on" : "off");
  } catch {}
}
// Tek bir nota: hızlı yükselir, zil gibi söner.
function tone(freq, start, { length = 0.35, volume = 0.14, type = "sine", slide = 0 } = {}) {
  const t = audio.currentTime + start,
    osc = audio.createOscillator(),
    gain = audio.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (slide) osc.frequency.exponentialRampToValueAtTime(freq * slide, t + length);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(volume, t + 0.006);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + length);
  osc.connect(gain).connect(audio.destination);
  osc.start(t);
  osc.stop(t + length + 0.02);
}
const sounds = {
  // Görev tamamlandı: iki notalı marimba. Her notada kısa bir tokmak vuruşu ve alttan sıcak bir gövde var.
  done() {
    for (const [freq, start] of [[880, 0], [1318.5, 0.08]]) {
      tone(freq, start, { length: 0.32, volume: 0.17 });
      tone(freq * 4, start, { length: 0.06, volume: 0.05 });
      tone(freq / 2, start, { length: 0.18, volume: 0.07, type: "triangle" });
    }
  },
  // Günün her şeyi bitti: hızla tırmanan ince bir ışıltı, tebrik eder gibi. Günde en fazla bir kez çalar.
  allDone() {
    [2093, 2349, 2637, 3136, 3520, 4186].forEach((f, i) => tone(f, i * 0.045, { length: 0.5 + i * 0.06, volume: 0.042 }));
    tone(1046.5, 0, { length: 0.6, volume: 0.036, type: "triangle" });
  },
  // Alt adım işaretlendi: küçük, kuru bir tık.
  step() {
    tone(2200, 0, { length: 0.06, volume: 0.08, type: "triangle", slide: 0.7 });
  },
  // Kayıt eklendi: yumuşak bir "pop".
  add() {
    tone(520, 0, { length: 0.12, volume: 0.12, slide: 1.9 });
  },
  // Tamamlama geri alındı: hafifçe inen ton, ödül gibi değil.
  undo() {
    tone(660, 0, { length: 0.16, volume: 0.06, slide: 0.6 });
  },
  // Sesli komut sesleri (az ve tutarlı: üç ses, üç anlam). Dinleme başladı: yükselen iki nota.
  listen() {
    tone(659, 0, { length: 0.1, volume: 0.07 });
    tone(988, 0.07, { length: 0.14, volume: 0.07 });
  },
  // Anlaşıldı ve yapıldı: aynı iki nota, inerek.
  understood() {
    tone(988, 0, { length: 0.1, volume: 0.07 });
    tone(659, 0.07, { length: 0.16, volume: 0.07 });
  },
  // Geçiş uyarısı (sıradaki işe 5 dk): yumuşak, alçalan üç notalı rüzgâr çanı; dikkati çeker ama irkiltmez.
  transition() {
    [[784, 0], [659, 0.16], [523, 0.32]].forEach(([f, s]) => {
      tone(f, s, { length: 0.9, volume: 0.06 });
      tone(f * 2, s, { length: 0.3, volume: 0.015 });
    });
  },
  // Anlaşılmadı: alçak, kuru iki vuruş; uyarı gibi ama ürkütmeden.
  missed() {
    tone(330, 0, { length: 0.09, volume: 0.09, type: "triangle" });
    tone(294, 0.12, { length: 0.12, volume: 0.09, type: "triangle" });
  },
};
function playSound(name, preview = false) {
  if ((!preview && !soundsOn()) || !sounds[name]) return;
  try {
    audio ??= new AudioContext();
    if (audio.state === "suspended") audio.resume();
    sounds[name]();
  } catch {}
}

// ---------------------------------------------------------------- Odak ortam sesi (Forest gibi)
// Dosya yok; gürültü uygulama içinde üretilir. Yalnız odak çalışma turu sürerken çalar (ambientSync).
// Tercih bu bilgisayarda: localStorage "focus-ambient" = { kind: "off" | "rain" | "hum" | "waves", volume: 0–100 }.
const AMBIENT_KINDS = { off: "Kapalı", rain: "Yağmur", hum: "Uğultu", waves: "Dalga" };
function ambientPrefs() {
  try {
    const v = JSON.parse(localStorage.getItem("focus-ambient") || "null");
    if (v && AMBIENT_KINDS[v.kind]) return { kind: v.kind, volume: Math.min(100, Math.max(0, +v.volume || 40)) };
  } catch {}
  return { kind: "off", volume: 40 };
}
function setAmbientPrefs(prefs) {
  try {
    localStorage.setItem("focus-ambient", JSON.stringify(prefs));
  } catch {}
  ambientSync(true);
}
let ambient = null; // { kind, nodes: [], gain }
function noiseBuffer(brown) {
  const length = audio.sampleRate * 4,
    buffer = audio.createBuffer(1, length, audio.sampleRate),
    data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < length; i++) {
    const white = Math.random() * 2 - 1;
    if (brown) {
      last = (last + 0.02 * white) / 1.02;
      data[i] = last * 3.5;
    } else data[i] = white;
  }
  return buffer;
}
function startAmbient(kind, volume) {
  audio ??= new AudioContext();
  if (audio.state === "suspended") audio.resume();
  const source = audio.createBufferSource();
  source.buffer = noiseBuffer(kind !== "rain");
  source.loop = true;
  const gain = audio.createGain();
  gain.gain.setValueAtTime(0.0001, audio.currentTime);
  gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, (volume / 100) * 0.35), audio.currentTime + 2);
  const nodes = [source];
  let tail = source;
  const add = (node) => {
    tail.connect(node);
    tail = node;
    nodes.push(node);
  };
  if (kind === "rain") {
    const hp = audio.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 400;
    const lp = audio.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 5000;
    add(hp);
    add(lp);
  } else {
    const lp = audio.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = kind === "hum" ? 420 : 900;
    add(lp);
  }
  if (kind === "waves") {
    // Dalga: ses ~9 saniyede bir kabarıp çekilir.
    const swell = audio.createGain(),
      lfo = audio.createOscillator(),
      depth = audio.createGain();
    swell.gain.value = 0.6;
    lfo.frequency.value = 0.11;
    depth.gain.value = 0.4;
    lfo.connect(depth).connect(swell.gain);
    lfo.start();
    add(swell);
    nodes.push(lfo, depth);
  }
  tail.connect(gain).connect(audio.destination);
  source.start();
  return { kind, volume, nodes, gain };
}
function stopAmbient() {
  if (!ambient) return;
  const { nodes, gain } = ambient;
  ambient = null;
  try {
    gain.gain.setValueAtTime(gain.gain.value, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + 1.2);
    setTimeout(() => nodes.forEach((n) => { try { n.stop?.(); n.disconnect(); } catch {} }), 1400);
  } catch {}
}
// Odak durumu ya da tercih değişince çağrılır: çalışma turu sürüyorsa seçili ses çalar, değilse susar.
function ambientSync(changed = false) {
  const prefs = ambientPrefs(),
    working = state.data?.live?.focus?.phase === "Work";
  const want = working && prefs.kind !== "off" ? prefs : null;
  if (ambient && (!want || changed || ambient.kind !== want.kind)) stopAmbient();
  if (want && !ambient) {
    try {
      ambient = startAmbient(want.kind, want.volume);
    } catch {}
  }
}
