using System.Net.Http.Headers;
using System.Text.Json;
namespace KisiselAsistan;

internal sealed record GithubBetaSession(string ClientId, string Login, string AccessToken, DateTimeOffset? ExpiresAt);
internal sealed class GithubBetaAccount
{
    private readonly string path;
    private readonly HttpMessageHandler? transport;
    private readonly Action<string> openBrowser;
    private readonly Func<TimeSpan, CancellationToken, Task> delay;
    internal GithubBetaSession? Session { get; private set; }
    internal GithubBetaAccount(string? storagePath = null, HttpMessageHandler? transport = null, Action<string>? browserLauncher = null, Func<TimeSpan, CancellationToken, Task>? delay = null)
    {
        path = storagePath ?? Path.Combine(DeploymentPaths.UserData, "github-beta-account.bin");
        this.transport = transport;
        openBrowser = browserLauncher ?? (url => { using var browser = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true }); });
        this.delay = delay ?? Task.Delay;
        if (File.Exists(path)) {
            try { Session = JsonSerializer.Deserialize<GithubBetaSession>(WindowsSecret.Decode(File.ReadAllBytes(path))); }
            catch (Exception e) when (e is JsonException or System.ComponentModel.Win32Exception or IOException or System.Security.Cryptography.CryptographicException) { }
        }
    }
    internal bool Connected(string clientId) => Session is { } session && session.ClientId == clientId &&
        (session.ExpiresAt is null || session.ExpiresAt > DateTimeOffset.UtcNow.AddMinutes(1));
    internal void Disconnect() { if (File.Exists(path)) File.Delete(path); Session = null; }
    internal async Task ConnectAsync(string clientId, Action<string> showCode, CancellationToken token)
    {
        BetaReleaseSettings.ValidateClientId(clientId);
        using var http = new HttpClient(transport ?? new HttpClientHandler { UseProxy = false, AllowAutoRedirect = false }) { Timeout = TimeSpan.FromSeconds(20) };
        http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        http.DefaultRequestHeaders.UserAgent.ParseAdd("KisiselAsistan-Beta/0.1");
        using var device = await PostAsync(http, "https://github.com/login/device/code", new() { ["client_id"] = clientId }, token);
        var root = device.RootElement;
        if (!root.TryGetProperty("device_code", out var code) || !root.TryGetProperty("user_code", out var userCode))
            throw new InvalidOperationException("GitHub bağlantısı başlatılamadı. GitHub App ayarında Device Flow etkin olmalı.");
        var verification = root.GetProperty("verification_uri").GetString();
        if (verification != "https://github.com/login/device") throw new InvalidOperationException("GitHub doğrulama adresi geçerli değil.");
        var expires = Math.Clamp(root.GetProperty("expires_in").GetInt32(), 1, 1800);
        var interval = root.TryGetProperty("interval", out var step) ? Math.Clamp(step.GetInt32(), 1, 60) : 5;
        using var stop = CancellationTokenSource.CreateLinkedTokenSource(token); stop.CancelAfter(TimeSpan.FromSeconds(expires));
        showCode(userCode.GetString()!);
        openBrowser(verification);
        try {
            while (true) {
                await delay(TimeSpan.FromSeconds(interval), stop.Token);
                using var answer = await PostAsync(http, "https://github.com/login/oauth/access_token", new() {
                    ["client_id"] = clientId, ["device_code"] = code.GetString()!, ["grant_type"] = "urn:ietf:params:oauth:grant-type:device_code"
                }, stop.Token);
                var data = answer.RootElement;
                if (data.TryGetProperty("access_token", out var access)) {
                    var accessToken = access.GetString() ?? "";
                    if (accessToken.Length < 10) throw new InvalidOperationException("GitHub geçerli bir oturum döndürmedi.");
                    using var request = new HttpRequestMessage(HttpMethod.Get, "https://api.github.com/user");
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                    using var response = await http.SendAsync(request, stop.Token);
                    if (!response.IsSuccessStatusCode) throw new InvalidOperationException("GitHub hesabı doğrulanamadı. Tekrar bağlan.");
                    using var identity = JsonDocument.Parse(await response.Content.ReadAsStringAsync(stop.Token));
                    var login = identity.RootElement.GetProperty("login").GetString() ?? "";
                    var expiry = data.TryGetProperty("expires_in", out var ttl) ? DateTimeOffset.UtcNow.AddSeconds(ttl.GetInt32()) : (DateTimeOffset?)null;
                    var session = new GithubBetaSession(clientId, login, accessToken, expiry);
                    Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                    File.WriteAllBytes(path, WindowsSecret.Encode(JsonSerializer.SerializeToUtf8Bytes(session)));
                    Session = session; return;
                }
                var error = data.TryGetProperty("error", out var failure) ? failure.GetString() : "";
                if (error == "authorization_pending") continue;
                if (error == "slow_down") { interval = Math.Min(interval + 5, 120); continue; }
                throw new InvalidOperationException(error == "access_denied" ? "GitHub izni verilmedi." : "GitHub bağlantısı tamamlanamadı. Yeniden bağlan.");
            }
        } catch (OperationCanceledException) when (!token.IsCancellationRequested) { throw new InvalidOperationException("GitHub bağlantısının süresi doldu. Yeniden bağlan."); }
    }
    private static async Task<JsonDocument> PostAsync(HttpClient http, string url, Dictionary<string, string> fields, CancellationToken token)
    {
        using var response = await http.PostAsync(url, new FormUrlEncodedContent(fields), token);
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException("GitHub bağlantı isteğini kabul etmedi. Biraz sonra tekrar dene.");
        return JsonDocument.Parse(await response.Content.ReadAsStringAsync(token));
    }
}
