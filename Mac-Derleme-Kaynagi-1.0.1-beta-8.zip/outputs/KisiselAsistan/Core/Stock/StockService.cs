using System.Net;
using System.Text;

namespace KisiselAsistan;

public sealed record StockPage(Uri Url, int Status, string Html, bool ViaBrowser = false);
// Sayfayı getiren: düz HTTP (Core) ya da görünmez tarayıcı (Windows kabuğu, Shell/StockBrowser.cs).
public interface IStockFetcher
{
    Task<StockPage> GetAsync(Uri url, CancellationToken token);
}

// Tarayıcı gibi görünen düz istek: Türkçe dil, sıkıştırma, çerez (bazı siteler ilk istekte çerez verip yönlendiriyor).
// En fazla 5 MB okunur.
public sealed class HttpStockFetcher : IStockFetcher, IDisposable
{
    private const int Limit = 5 * 1024 * 1024;
    private readonly HttpClient http = new(new SocketsHttpHandler {
        AutomaticDecompression = DecompressionMethods.All, AllowAutoRedirect = true, MaxAutomaticRedirections = 8,
        UseCookies = true, CookieContainer = new CookieContainer(), ConnectTimeout = TimeSpan.FromSeconds(10), PooledConnectionIdleTimeout = TimeSpan.FromMinutes(5),
    }) { Timeout = TimeSpan.FromSeconds(25) };
    public HttpStockFetcher()
    {
        var h = http.DefaultRequestHeaders;
        h.TryAddWithoutValidation("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36");
        h.TryAddWithoutValidation("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.7");
        h.TryAddWithoutValidation("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.7,en;q=0.6");
        h.TryAddWithoutValidation("Upgrade-Insecure-Requests", "1");
    }
    public async Task<StockPage> GetAsync(Uri url, CancellationToken token)
    {
        using var response = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, token);
        await using var stream = await response.Content.ReadAsStreamAsync(token);
        using var buffer = new MemoryStream();
        var chunk = new byte[81920];
        int read;
        while ((read = await stream.ReadAsync(chunk, token)) > 0 && buffer.Length < Limit) buffer.Write(chunk, 0, read);
        Encoding encoding;
        try { encoding = response.Content.Headers.ContentType?.CharSet is { Length: > 0 } cs ? Encoding.GetEncoding(cs.Trim('"')) : Encoding.UTF8; }
        catch (ArgumentException) { encoding = Encoding.UTF8; }
        return new(response.RequestMessage?.RequestUri ?? url, (int)response.StatusCode, encoding.GetString(buffer.GetBuffer(), 0, (int)buffer.Length));
    }
    public void Dispose() => http.Dispose();
}

// Testler ve arayüz testi için internetsiz sayfalar: bağlantıda "tukendi" geçiyorsa stokta yok, "belirsiz" geçiyorsa bilgi yok,
// "engel" geçiyorsa bot koruması, yoksa stokta. Fiyat bağlantıdaki "fiyat-<sayı>" bölümünden.
public sealed class OfflineStockFetcher : IStockFetcher
{
    public Func<Uri, StockPage>? Override { get; set; }
    public Task<StockPage> GetAsync(Uri url, CancellationToken token)
    {
        if (Override != null) return Task.FromResult(Override(url));
        var text = url.ToString().ToLowerInvariant();
        if (text.Contains("engel")) return Task.FromResult(new StockPage(url, 403, "<html><head><title>Just a moment...</title></head><body>cf-browser-verification</body></html>"));
        var name = Uri.UnescapeDataString(url.Segments.LastOrDefault()?.Trim('/') ?? "Ürün").Replace('-', ' ');
        var price = System.Text.RegularExpressions.Regex.Match(text, @"fiyat-(\d+)") is { Success: true } m ? m.Groups[1].Value : "1499.90";
        var availability = text.Contains("tukendi") ? "OutOfStock" : "InStock";
        var html = text.Contains("belirsiz") ? $"<html><head><title>{name}</title></head><body><p>{name}</p></body></html>"
            : $$$"""<html><head><title>{{{name}}}</title><script type="application/ld+json">{"@type":"Product","name":"{{{name}}}","offers":{"@type":"Offer","price":"{{{price}}}","priceCurrency":"TRY","availability":"https://schema.org/{{{availability}}}"}}</script></head><body><h1>{{{name}}}</h1></body></html>""";
        return Task.FromResult(new StockPage(url, 200, html));
    }
}

public sealed class StockStore(string path)
{
    private readonly JsonListStore<StockWatch> data = new(path);
    public List<StockWatch> Items => data.Read();
    public void Modify(Func<List<StockWatch>, List<StockWatch>> edit) => data.Modify(edit);
}

// Stok takibinin kararları. Kontroller sırayla (aynı anda tek sayfa) yapılır; aynı siteye art arda gidilmez.
// Bildirimler: stok geldi (yoktu/bilinmiyordu → stokta), ön siparişe açıldı, hedef fiyata indi, fiyat düştü,
// isteğe bağlı stok bitti, üst üste 3 hatada bir kez "kontrol edilemiyor". İlk okuma yalnız başlangıçtır, bildirim vermez.
public sealed class StockService(StockStore store, IStockFetcher http, IStockFetcher? browser = null, Func<DateTimeOffset>? clock = null)
{
    public const int Limit = 100;
    private readonly SemaphoreSlim gate = new(1, 1);
    private readonly Dictionary<string, DateTimeOffset> lastVisit = new(StringComparer.OrdinalIgnoreCase);
    private DateTimeOffset Now => clock?.Invoke() ?? DateTimeOffset.Now;
    public IReadOnlyList<StockWatch> Items => store.Items;
    public bool BrowserAvailable => browser != null;
    public event Action? Changed;
    // Arayüze giden parçanın sürümü (her değişiklikte artar; bütün listeyi her yenilemede özetlemek gerekmez).
    public int Version { get; private set; }
    private void Touch() { Version++; Changed?.Invoke(); }
    public event Action<StockNotice>? Notice;

    // Bağlantıyı okur, kaydetmez (ekleme penceresindeki önizleme).
    public async Task<StockReading> PreviewAsync(StockDraft draft, CancellationToken token)
    {
        var url = draft.Validate();
        await gate.WaitAsync(token);
        try { return await ReadAsync(url, draft.Mode, false, draft.Variant, draft.Rule, token); }
        finally { gate.Release(); }
    }
    // check=false: toplu eklemede hemen okunmaz, zamanlayıcı sırayla okur (aynı siteye art arda gitmemek için).
    public async Task<StockWatch> AddAsync(StockDraft draft, CancellationToken token, bool check = true)
    {
        var url = draft.Validate();
        StockWatch watch = draft.ApplyTo(new StockWatch { AddedAt = Now, BrowserNeeded = draft.Mode == StockFetchMode.Browser }, url);
        store.Modify(items => {
            if (items.Count >= Limit) throw new InvalidOperationException($"En fazla {Limit} bağlantı takip edilebilir.");
            if (items.Any(w => SameUrl(w.Url, url))) throw new InvalidOperationException("Bu bağlantı zaten takipte.");
            return [.. items, watch];
        });
        Touch();
        return check ? await CheckAsync(watch.Id, token) : watch;
    }
    // Birden çok bağlantı (satır satır ya da boşlukla ayrılmış); ayarlar her birine aynı uygulanır.
    public async Task<(int Added, List<string> Failed)> AddManyAsync(IEnumerable<string> urls, StockDraft defaults, CancellationToken token)
    {
        var added = 0; List<string> failed = [];
        foreach (var url in urls.Select(u => u.Trim()).Where(u => u.Length > 0).Distinct()) {
            try { await AddAsync(defaults with { Url = url, Title = null }, token, check: false); added++; }
            catch (Exception ex) when (ex is ArgumentException or InvalidOperationException) { failed.Add($"{url}: {ex.Message}"); }
        }
        return (added, failed);
    }
    public StockWatch Edit(Guid id, StockDraft draft)
    {
        var url = draft.Validate();
        if (Items.Any(w => w.Id != id && SameUrl(w.Url, url))) throw new InvalidOperationException("Bu bağlantı zaten takipte.");
        StockWatch? saved = null;
        store.Modify(items => items.Select(w => {
            if (w.Id != id) return w;
            var next = draft.ApplyTo(w, url);
            // Neye bakılacağı değiştiyse hemen yeniden kontrol edilir; yeni durum yine başlangıç sayılmaz (geçmiş korunur).
            if (next.Url != w.Url || next.Rule != w.Rule || next.Variant != w.Variant || next.Mode != w.Mode)
                next = next with { AttemptedAt = null, CheckedAt = null, BrowserNeeded = next.Mode == StockFetchMode.Browser || (next.Url == w.Url && w.BrowserNeeded), Failures = 0, ErrorNotified = false };
            return saved = next;
        }).ToList());
        Touch();
        return saved ?? throw new ArgumentException("Takip edilen bağlantı bulunamadı.");
    }
    public void Remove(Guid id) { Find(id); store.Modify(items => items.Where(w => w.Id != id).ToList()); Touch(); }
    public void SetPaused(Guid id, bool paused) { Find(id); store.Modify(items => items.Select(w => w.Id == id ? w with { Paused = paused } : w).ToList()); Touch(); }
    private StockWatch Find(Guid id) => Items.FirstOrDefault(w => w.Id == id) ?? throw new ArgumentException("Takip edilen bağlantı bulunamadı.");

    public async Task<StockWatch> CheckAsync(Guid id, CancellationToken token)
    {
        await gate.WaitAsync(token);
        try { await CheckOneAsync(Find(id), token); }
        finally { gate.Release(); }
        return Find(id);
    }
    // Zamanı gelenler (zamanlayıcı dakikada bir çağırır). Başka kontrol sürüyorsa beklemez.
    public async Task<int> CheckDueAsync(CancellationToken token)
    {
        if (!await gate.WaitAsync(0, token)) return 0;
        var count = 0;
        try {
            foreach (var watch in Items.Where(w => !w.Paused && w.NextCheck <= Now).OrderBy(w => w.NextCheck).Take(10).ToList()) {
                token.ThrowIfCancellationRequested();
                await CheckOneAsync(watch, token, spaced: true); count++;
            }
        } finally { gate.Release(); }
        return count;
    }
    public async Task<StockCheckSummary> CheckAllAsync(CancellationToken token)
    {
        await gate.WaitAsync(token);
        try {
            foreach (var watch in Items.Where(w => !w.Paused).ToList()) { token.ThrowIfCancellationRequested(); await CheckOneAsync(watch, token, spaced: true); }
        } finally { gate.Release(); }
        var active = Items.Where(w => !w.Paused).ToList();
        return new(active.Count, active.Count(w => w.Error != null), active.Count(w => w.State == StockState.InStock));
    }

    // spaced: arka plandaki sıralı kontroller aynı siteye en az 15 sn arayla gider (birden çok ürün aynı mağazadaysa); elle kontrol beklemez.
    private async Task CheckOneAsync(StockWatch watch, CancellationToken token, bool spaced = false)
    {
        var url = new Uri(watch.Url);
        if (spaced && clock == null && lastVisit.TryGetValue(url.Host, out var last) && Now - last < TimeSpan.FromSeconds(15))
            await Task.Delay(TimeSpan.FromSeconds(15) - (Now - last), token);
        StockReading? reading = null; string? error = null;
        try { reading = await ReadAsync(url, watch.Mode, watch.BrowserNeeded, watch.Variant, watch.Rule, token); }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { throw; }
        catch (Exception ex) when (ex is HttpRequestException or IOException or InvalidOperationException or OperationCanceledException or UriFormatException or TimeoutException) { error = Friendly(ex); }
        finally { lastVisit[url.Host] = Now; }
        List<StockNotice> notices = [];
        store.Modify(items => items.Select(w => w.Id != watch.Id ? w : Apply(w, reading, error, Now, notices)).ToList());
        Touch();
        foreach (var n in notices) Notice?.Invoke(n);
    }

    private async Task<StockReading> ReadAsync(Uri url, StockFetchMode mode, bool browserNeeded, string? variant, StockRule? rule, CancellationToken token)
    {
        var useBrowser = browser != null && (mode == StockFetchMode.Browser || mode == StockFetchMode.Auto && browserNeeded);
        if (mode == StockFetchMode.Browser && browser == null) throw new InvalidOperationException("Tarayıcıyla okuma bu sürümde yok.");
        var reading = await ReadWithAsync(useBrowser ? browser! : http, url, variant, rule, token);
        // Düz istek yetmediyse (bot koruması ya da JavaScript ile çizilen boş sayfa) tarayıcıyla bir kez daha.
        if (!useBrowser && mode == StockFetchMode.Auto && browser != null && (reading.State == StockState.Blocked || reading.State == StockState.Unknown && reading.Price == null)) {
            try {
                var second = await ReadWithAsync(browser, url, variant, rule, token);
                if (second.State != StockState.Blocked && (second.State != StockState.Unknown || reading.State == StockState.Blocked || second.Price != null)) {
                    return second with { Signals = [.. second.Signals, "Düz istek yetmedi; sayfa tarayıcıyla okundu."] };
                }
            } catch (Exception ex) when (ex is InvalidOperationException or TimeoutException or IOException) { }
        }
        return reading;
    }
    private static async Task<StockReading> ReadWithAsync(IStockFetcher fetcher, Uri url, string? variant, StockRule? rule, CancellationToken token)
    {
        var page = await fetcher.GetAsync(url, token);
        var reading = StockDetector.Read(page.Html, page.Status, variant, rule) with { ViaBrowser = page.ViaBrowser, FinalUrl = page.Url.ToString() };
        if (rule == null && reading.State != StockState.Blocked && StockDetector.IsShopify(page.Html, page.Url)) {
            try {
                var json = await fetcher.GetAsync(StockDetector.ShopifyJson(page.Url), token);
                if (json.Status == 200 && StockDetector.ReadShopify(StripPre(json.Html), reading, variant) is { } shopify) reading = shopify;
            } catch (HttpRequestException) { }
        }
        return reading;
    }
    // Tarayıcıda açılan JSON <pre> içinde gelir.
    private static string StripPre(string text)
    {
        var start = text.IndexOf('{');
        var end = text.LastIndexOf('}');
        return start >= 0 && end > start ? System.Net.WebUtility.HtmlDecode(text[start..(end + 1)]) : text;
    }

    // Okumayı kayda işler ve bildirim kararlarını verir (zamanlayıcıdan bağımsız, test edilebilir).
    public static StockWatch Apply(StockWatch w, StockReading? reading, string? error, DateTimeOffset now, List<StockNotice> notices)
    {
        if (reading == null || reading.State == StockState.Blocked) {
            var failures = w.Failures + 1;
            var message = error ?? reading?.Evidence ?? "Okunamadı.";
            var next = w with { AttemptedAt = now, Failures = failures, Error = message };
            if (failures >= 3 && !w.ErrorNotified) {
                notices.Add(new(w.Id, "error", "Stok kontrol edilemiyor", $"{w.Name} ({w.Site}) üst üste {failures} kez okunamadı: {message}", w.Url, false));
                next = next with { ErrorNotified = true };
            }
            return next;
        }
        var state = reading.State;
        var first = w.Checks == 0;
        var before = w.State;
        var evidence = reading.Evidence;
        // Bir kontrolde durum okunamadıysa son bilinen durum korunur; yoksa sayfa ara ara boş gelince sahte "Stok geldi" çıkardı.
        if (state == StockState.Unknown && !first && before is StockState.InStock or StockState.OutOfStock or StockState.PreOrder) {
            state = before;
            evidence = "Bu kontrolde stok okunamadı; son bilinen durum: " + StockDetector.Describe(before) + ". (" + reading.Evidence + ")";
        }
        var price = reading.Price;
        var name = w.CustomTitle ?? reading.Title ?? w.Name;
        string Money(decimal value) => StockText.Money(value, reading.Currency ?? w.Currency);
        if (!first) {
            if (state == StockState.InStock && before != StockState.InStock)
                notices.Add(new(w.Id, "stock", "Stok geldi", $"{name} stokta" + (price is { } p ? $" · {Money(p)}" : "") + (w.Variant != null ? $" ({w.Variant})" : "") + $" · {w.Site}", w.Url, w.Phone));
            else if (state == StockState.PreOrder && before is StockState.OutOfStock or StockState.Unknown)
                notices.Add(new(w.Id, "preorder", "Ön siparişe açıldı", $"{name} ön siparişte · {w.Site}", w.Url, w.Phone));
            else if (state == StockState.OutOfStock && before == StockState.InStock && w.NotifyOutOfStock)
                notices.Add(new(w.Id, "out", "Stok bitti", $"{name} yine tükendi · {w.Site}", w.Url, false));
            if (price is { } now2 && state != StockState.OutOfStock) {
                if (w.TargetPrice is { } target && now2 <= target && (w.Price is null || w.Price > target))
                    notices.Add(new(w.Id, "target", "Hedef fiyata indi", $"{name}: {Money(now2)} (hedefin {Money(target)}) · {w.Site}", w.Url, w.Phone));
                else if (w.NotifyPriceDrop && w.Price is { } old && now2 < old && (old - now2) / old >= 0.01m)
                    notices.Add(new(w.Id, "price", "Fiyat düştü", $"{name}: {Money(old)} → {Money(now2)} (%{Math.Round((old - now2) / old * 100)}) · {w.Site}", w.Url, w.Phone));
            }
        }
        var history = w.PriceHistory;
        if (price is { } np && (history.Length == 0 || history[^1].Price != np)) history = [.. history.TakeLast(199), new(now, np)];
        var events = w.Events;
        if (state != before || first) events = [.. events.TakeLast(49), new(now, state, price)];
        return w with {
            Title = reading.Title ?? w.Title, ImageUrl = reading.ImageUrl ?? w.ImageUrl, State = state, Evidence = evidence,
            Price = price ?? w.Price, Currency = reading.Currency ?? w.Currency, CheckedAt = now, AttemptedAt = now, Error = null, Failures = 0, ErrorNotified = false,
            Checks = w.Checks + 1, PriceHistory = history, Events = events,
            InStockSince = state == StockState.InStock ? (before == StockState.InStock && !first ? w.InStockSince ?? now : now) : null,
            BrowserNeeded = w.Mode == StockFetchMode.Auto ? reading.ViaBrowser : w.BrowserNeeded,
        };
    }
    private static bool SameUrl(string a, Uri b) => Uri.TryCreate(a, UriKind.Absolute, out var u) && Uri.Compare(u, b, UriComponents.HttpRequestUrl, UriFormat.Unescaped, StringComparison.OrdinalIgnoreCase) == 0;
    private static string Friendly(Exception ex) => ex switch {
        TaskCanceledException or OperationCanceledException or TimeoutException => "Site zamanında cevap vermedi.",
        HttpRequestException { InnerException: System.Net.Sockets.SocketException } => "Siteye bağlanılamadı (internet ya da adres).",
        HttpRequestException h when h.Message.Contains("SSL", StringComparison.OrdinalIgnoreCase) => "Güvenli bağlantı kurulamadı.",
        _ => ex.Message,
    };
}

public static class StockText
{
    public static string Money(decimal value, string? currency)
    {
        var amount = value.ToString(value % 1 == 0 ? "#,0" : "#,0.00", System.Globalization.CultureInfo.GetCultureInfo("tr-TR"));
        return (currency ?? "").ToUpperInvariant() switch { "USD" => "$" + amount, "EUR" => "€" + amount, "GBP" => "£" + amount, "TRY" or "" => amount + " TL", var c => amount + " " + c };
    }
}
