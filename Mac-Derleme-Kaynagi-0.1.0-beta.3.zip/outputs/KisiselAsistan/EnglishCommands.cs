using System.Text.RegularExpressions;

namespace KisiselAsistan;

public static class EnglishCommands
{
    public const string SpotifyOpenPattern = @"^(?:spotify(?:\s*['’]?\s*y?[ıi])?(?:\s+uygulamasını)?\s+(?:aç|açsana|açar\s+mısın|açabilir\s+misin)|open\s+spotify|spotify\s+open)$";
    public static string Conversational(string text)
    {
        text = text.Trim().TrimEnd('.', '!', '?');
        // Only remove polite prefixes around recognized command families; keep song/game titles intact.
        text = Regex.Replace(text, @"^(?:lütfen\s+|please\s+)(?=(?:spotify|steam|hatırlatıcı)\b)", "", RegexOptions.IgnoreCase);
        if (Regex.IsMatch(text, SpotifyOpenPattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)) return "Spotify aç";
        var simple = Regex.Match(text, @"^spotify\s+(duraklatsana|oynatsana|sonraki\s+şarkıya\s+geç|önceki\s+şarkıya\s+geç)$", RegexOptions.IgnoreCase);
        if (simple.Success) return simple.Groups[1].Value.ToLowerInvariant() switch { "duraklatsana" => "Spotify duraklat", "oynatsana" => "Spotify oynat", "sonraki şarkıya geç" => "Spotify sonraki", _ => "Spotify önceki" };
        return text;
    }
    public static string Normalize(string text)
    {
        text = Conversational(text);
        if (Regex.IsMatch(text, SpotifyOpenPattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)) return "Spotify aç";
        var naturalSpotify = Regex.Match(text, @"^spotify(?:\s*['’]?\s*(?:dan|den|da|de))?\s*[, :]?\s+(.+?)\s+(?:aç|çal|oynat)$", RegexOptions.IgnoreCase);
        if (naturalSpotify.Success) {
            var query = naturalSpotify.Groups[1].Value.Trim().Trim('"', '“', '”', '\'').Trim();
            if (query.Length > 0) return "Spotify ara " + query;
        }
        var simple = Regex.Match(text, @"^(?:set\s+(?:a\s+)?(?:timer|reminder)\s+for\s+)?([a-z\d -]+?)\s+(seconds?|minutes?|hours?)(?:\s+(?:timer|reminder))?$", RegexOptions.IgnoreCase);
        var detailed = Regex.Match(text, @"^remind\s+me\s+in\s+([a-z\d -]+?)\s+(seconds?|minutes?|hours?)\s+to\s+(.+)$", RegexOptions.IgnoreCase);
        var match = detailed.Success ? detailed : simple;
        if (match.Success && TryNumber(match.Groups[1].Value, out var amount)) {
            var unit = match.Groups[2].Value.ToLowerInvariant() switch { "second" or "seconds" => "saniye", "minute" or "minutes" => "dakika", _ => "saat" };
            var message = detailed.Success ? detailed.Groups[3].Value : "Reminder time";
            return $"{amount} {unit} sonra {message} hatırlat";
        }
        var spotify = text.ToLowerInvariant() switch {
            "open spotify" or "spotify open" => "Spotify aç",
            "spotify play" or "spotify resume" => "Spotify oynat",
            "spotify pause" or "spotify stop" => "Spotify duraklat",
            "spotify next" or "spotify next track" => "Spotify sonraki",
            "spotify previous" or "spotify previous track" => "Spotify önceki", _ => null
        };
        if (spotify is not null) return spotify;
        var search = Regex.Match(text, @"^spotify\s+search\s+(.+)$", RegexOptions.IgnoreCase);
        return search.Success ? "Spotify ara " + search.Groups[1].Value : text;
    }
    private static bool TryNumber(string text, out int number)
    {
        if (int.TryParse(text, out number)) return number > 0 && number <= 100000;
        var words = new Dictionary<string, int> { ["one"] = 1, ["two"] = 2, ["three"] = 3, ["four"] = 4, ["five"] = 5, ["six"] = 6, ["seven"] = 7, ["eight"] = 8, ["nine"] = 9, ["ten"] = 10, ["eleven"] = 11, ["twelve"] = 12, ["thirteen"] = 13, ["fourteen"] = 14, ["fifteen"] = 15, ["sixteen"] = 16, ["seventeen"] = 17, ["eighteen"] = 18, ["nineteen"] = 19, ["twenty"] = 20, ["thirty"] = 30, ["forty"] = 40, ["fifty"] = 50, ["sixty"] = 60, ["seventy"] = 70, ["eighty"] = 80, ["ninety"] = 90 };
        var tokens = text.ToLowerInvariant().Replace('-', ' ').Split(' ', StringSplitOptions.RemoveEmptyEntries);
        number = 0;
        if (tokens.Length is < 1 or > 2 || tokens.Any(t => !words.ContainsKey(t))) return false;
        if (tokens.Length == 2 && (words[tokens[0]] < 20 || words[tokens[1]] > 9)) return false;
        number = tokens.Sum(t => words[t]); return true;
    }
    public static void Verify()
    {
        if (Normalize("Lütfen Spotify'ı açsana.") != "Spotify aç" || Normalize("Spotify duraklatsana") != "Spotify duraklat" || Conversational("Lütfen Steam ara Hades") != "Steam ara Hades" || Conversational("Spotify Please Please Me çal") != "Spotify Please Please Me çal") throw new Exception("Esnek komut veya şarkı adı koruma testi başarısız.");
        if (Normalize("Set a timer for ten seconds.") != "10 saniye sonra Reminder time hatırlat") throw new Exception("English timer failed.");
        if (Normalize("remind me in twenty-five minutes to drink water") != "25 dakika sonra drink water hatırlat") throw new Exception("English reminder failed.");
        if (Normalize("Spotify next") != "Spotify sonraki" || Normalize("open Spotify") != "Spotify aç") throw new Exception("English Spotify failed.");
        if (Normalize("Spotify search Hello Adele") != "Spotify ara Hello Adele") throw new Exception("English search failed.");
        if (Normalize("Spotify'dan, \"Tame Impala\" aç") != "Spotify ara Tame Impala" || Normalize("Spotify’dan Tame Impala çal.") != "Spotify ara Tame Impala" || Normalize("Spotify Tame Impala oynat") != "Spotify ara Tame Impala") throw new Exception("Doğal Spotify komutu başarısız.");
        if (Normalize("zero seconds timer") != "zero seconds timer" || Normalize("eleven ten seconds timer") != "eleven ten seconds timer") throw new Exception("Invalid duration accepted.");
    }
}
