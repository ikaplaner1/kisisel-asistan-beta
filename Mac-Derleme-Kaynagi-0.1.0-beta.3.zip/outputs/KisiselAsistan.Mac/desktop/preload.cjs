const {contextBridge, ipcRenderer} = require('electron');
contextBridge.exposeInMainWorld('assistant', {
  call: (method, params={}) => ipcRenderer.invoke('assistant:call', method, params),
  action: (name, params={}) => ipcRenderer.invoke('assistant:action', name, params),
  onEvent: callback => { const handler = (_, event) => callback(event); ipcRenderer.on('assistant:event', handler); return () => ipcRenderer.removeListener('assistant:event', handler); }
});
