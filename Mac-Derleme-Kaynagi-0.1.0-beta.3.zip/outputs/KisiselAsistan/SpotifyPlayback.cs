using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace KisiselAsistan;

public sealed class SpotifyPlayback(ISpotifySession session, HttpClient http) : ISpotifyPlayback
{
    internal const string SongCommandPattern = @"^spotify(?:\s*['’]?\s*(?:dan|den|da|de))?\s*[, :]?\s+(.+?)\s+(?:aç|çal|oynat)$";
    public async Task<List<SpotifyTrack>> SearchAsync(string query, CancellationToken token)
    {
        if (string.IsNullOrWhiteSpace(query) || query.Length > 200) throw new ArgumentException("Şarkı ve sanatçı adı gir (en fazla 200 karakter).");
        using var json = await RequestAsync(HttpMethod.Get, "search?type=track&limit=10&q=" + Uri.EscapeDataString(query.Trim()), null, token);
        return json!.RootElement.GetProperty("tracks").GetProperty("items").EnumerateArray()
            .Where(x => !x.TryGetProperty("is_playable", out var playable) || playable.ValueKind != JsonValueKind.False)
            .Select(ParseTrack).ToList();
    }
    private static SpotifyTrack ParseTrack(JsonElement item) => new(item.GetProperty("uri").GetString()!, item.GetProperty("name").GetString()!,
        string.Join(", ", item.GetProperty("artists").EnumerateArray().Select(a => a.GetProperty("name").GetString())),
        item.TryGetProperty("album", out var album) && album.TryGetProperty("images", out var images) && images.GetArrayLength() > 0 ? images[images.GetArrayLength() > 1 ? 1 : 0].GetProperty("url").GetString() : null);
    public async Task<SpotifyPlaying?> CurrentAsync(CancellationToken token)
    {
        using var json = await RequestAsync(HttpMethod.Get, "me/player", null, token);
        return json is null ? null : ParsePlaying(json.RootElement);
    }
    internal static SpotifyPlaying? ParsePlaying(JsonElement root)
    {
        if (!root.TryGetProperty("item", out var item) || item.ValueKind != JsonValueKind.Object || !item.TryGetProperty("artists", out _)) return null;
        return new(ParseTrack(item), root.TryGetProperty("progress_ms", out var progress) && progress.ValueKind == JsonValueKind.Number && progress.TryGetInt32(out var position) ? Math.Max(0, position) : 0,
            item.TryGetProperty("duration_ms", out var duration) && duration.TryGetInt32(out var milliseconds) ? Math.Max(0, milliseconds) : 0,
            root.TryGetProperty("is_playing", out var playing) && playing.ValueKind == JsonValueKind.True,
            root.TryGetProperty("device", out var device) && device.TryGetProperty("name", out var name) ? name.GetString() ?? "Spotify" : "Spotify");
    }
    public async Task<string> PlayAsync(SpotifyTrack track, CancellationToken token)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(track.Uri, "^spotify:track:[A-Za-z0-9]{22}$")) throw new ArgumentException("Geçersiz şarkı adresi.");
        using var devices = await RequestAsync(HttpMethod.Get, "me/player/devices", null, token);
        var computers = devices!.RootElement.GetProperty("devices").EnumerateArray()
            .Where(x => x.GetProperty("type").GetString() == "Computer" && !x.GetProperty("is_restricted").GetBoolean() && x.GetProperty("id").ValueKind == JsonValueKind.String).ToList();
        var machine = computers.Where(x => string.Equals(x.GetProperty("name").GetString(), Environment.MachineName, StringComparison.OrdinalIgnoreCase)).ToList();
        var candidates = machine.Count > 0 ? machine : computers;
        if (candidates.Count == 0) throw new InvalidOperationException("Spotify masaüstü uygulamasını açıp hesabına giriş yap, sonra tekrar dene. Kullanılabilir bilgisayar bulunamadı.");
        if (candidates.Count > 1) throw new InvalidOperationException("Birden fazla Spotify bilgisayarı açık. Diğer bilgisayarlarda Spotify'ı kapatıp tekrar dene.");
        var deviceId = candidates[0].GetProperty("id").GetString()!;
        using var sent = await RequestAsync(HttpMethod.Put, "me/player/play?device_id=" + Uri.EscapeDataString(deviceId), JsonSerializer.Serialize(new { uris = new[] { track.Uri }, position_ms = 0 }), token);
        for (var attempt = 0; attempt < 3; attempt++) {
            await Task.Delay(600, token);
            using var state = await RequestAsync(HttpMethod.Get, "me/player", null, token);
            if (state is not null && state.RootElement.TryGetProperty("is_playing", out var playing) && playing.GetBoolean() &&
                state.RootElement.TryGetProperty("item", out var item) && item.ValueKind == JsonValueKind.Object &&
                item.GetProperty("uri").GetString() == track.Uri && state.RootElement.GetProperty("device").GetProperty("id").GetString() == deviceId)
                return "Çalıyor: " + track;
        }
        return "Çalma isteği gönderildi: " + track + ". Spotify oynatma durumu henüz doğrulanmadı.";
    }
    private async Task<JsonDocument?> RequestAsync(HttpMethod method, string endpoint, string? body, CancellationToken token)
    {
        using var request = new HttpRequestMessage(method, "https://api.spotify.com/v1/" + endpoint);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", await session.AccessAsync(token));
        if (body is not null) request.Content = new StringContent(body, Encoding.UTF8, "application/json");
        using var response = await http.SendAsync(request, token);
        if (!response.IsSuccessStatusCode) {
            var message = response.StatusCode switch {
                HttpStatusCode.Unauthorized => "Spotify bağlantısı geçersiz. Hesabını yeniden bağla.",
                HttpStatusCode.Forbidden => "Spotify oynatma izni vermedi. Premium hesabını ve Developer uygulamasının kullanıcı erişimini kontrol et.",
                HttpStatusCode.NotFound => "Spotify cihazı hazır değil. Masaüstü Spotify'ı açıp tekrar dene.",
                HttpStatusCode.TooManyRequests => "Spotify istek sınırına ulaşıldı. Biraz bekleyip tekrar dene.",
                _ => $"Spotify işlemi tamamlanamadı (HTTP {(int)response.StatusCode})." };
            throw new InvalidOperationException(message);
        }
        if (response.StatusCode == HttpStatusCode.NoContent) return null;
        var text = await response.Content.ReadAsStringAsync(token);
        return string.IsNullOrWhiteSpace(text) ? null : JsonDocument.Parse(text);
    }
}
