"use strict";
// Ders programı / iş saati içe aktarma (Takvim → "İçe aktar").
// Dosya kabukta seçilip okunur (rpc "schedule.pick": Windows'un dosya penceresi, Mac'te Electron); C# tabloyu programa çevirir
// (Core/Import). Burada önizleme düzenlenir, sonra "schedule.import" ile haftalık tekrarlı kayıtlar oluşur. Kayıtlar normal
// planlardır: takvimden tek tek düzenlenir; program adıyla tek seferde kaldırılır.

const IMPORT_DAYS = [["Pzt", "Monday"], ["Sal", "Tuesday"], ["Çar", "Wednesday"], ["Per", "Thursday"], ["Cum", "Friday"], ["Cmt", "Saturday"], ["Paz", "Sunday"]];
const dayIndex = (d) => IMPORT_DAYS.findIndex(([, v]) => v === d);

function ScheduleImportView() {
  const [step, setStep] = htmPreact.useState("pick");
  const [programs, setPrograms] = htmPreact.useState(null);
  const [rows, setRows] = htmPreact.useState([]);
  const [notes, setNotes] = htmPreact.useState([]);
  const [meta, setMeta] = htmPreact.useState({ name: "", start: today(), until: "", category: "Personal", remind: false });
  const [busy, setBusy] = htmPreact.useState("");
  const [error, setError] = htmPreact.useState("");
  const [confirmRemove, setConfirmRemove] = htmPreact.useState("");
  const loadPrograms = () => rpc("schedule.programs").then(setPrograms, () => setPrograms([]));
  htmPreact.useEffect(() => { loadPrograms(); }, []);

  const attempt = async (label, fn) => {
    setBusy(label); setError("");
    try { await fn(); } catch (e) { setError(e.message); } finally { setBusy(""); }
  };
  const pick = () =>
    attempt("Dosya okunuyor…", async () => {
      const result = await rpc("schedule.pick", {}, 600000);
      if (!result) return; // pencere kapatıldı
      setRows(result.entries.map((e, i) => ({ ...e, key: i })));
      setNotes(result.notes || []);
      setMeta((m) => ({ ...m, name: m.name || result.file.replace(/\.[^.]+$/, "") }));
      setStep("preview");
    });
  const blank = () => {
    setRows([{ key: 0, day: "Monday", start: 540, end: 590, title: "" }]);
    setNotes([]);
    setStep("preview");
  };
  const edit = (key, patch) => setRows((list) => list.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  const save = () =>
    attempt("Takvime ekleniyor…", async () => {
      const entries = rows.filter((r) => r.title.trim());
      if (!entries.length) throw new Error("En az bir satıra ad yaz.");
      const count = await rpc("schedule.import", {
        request: { name: meta.name, start: meta.start, until: meta.until || null, category: meta.category, remind: meta.remind, entries: entries.map(({ day, start, end, title }) => ({ day, start, end, title: title.trim() })) },
      });
      closeDialog();
      toast(`${count} kayıt takvime eklendi: ${meta.name}`);
      playSound("add");
      await refresh();
    });
  const removeProgram = (name) =>
    attempt("Kaldırılıyor…", async () => {
      const n = await rpc("schedule.remove", { name });
      setConfirmRemove("");
      toast(`${name} kaldırıldı (${n} kayıt).`);
      await loadPrograms();
      await refresh();
    });
  const timeInput = (r, field) =>
    html`<input type="time" required value=${minutesText(r[field])} aria-label=${field === "start" ? "Başlangıç" : "Bitiş"} onChange=${(e) => { const m = textMinutes(e.target.value); if (m != null) edit(r.key, { [field]: m }); }} />`;

  if (step === "pick")
    return html`<div class="import-pick">
      <p class="muted">Ders programını ya da iş saatlerini içeren <strong>Excel (.xlsx)</strong>, <strong>CSV</strong> ya da <strong>PDF</strong> dosyasını seç. Uygulama günleri, saatleri ve adları bulur; kaydetmeden önce hepsini görüp düzeltebilirsin.</p>
      <div class="toolbar"><${Button} cls="primary" icon="folder" onClick=${pick} disabled=${!!busy}>Dosya seç<//><${Button} cls="ghost" icon="plus" onClick=${blank}>Elle gir<//></div>
      <p class="muted small">Taranmış (fotoğraf) PDF'ler okunamaz. Eski Excel (.xls) dosyasını önce .xlsx olarak kaydet.</p>
      ${busy && html`<p class="muted">${busy}</p>`}${error && html`<p class="inline-error">${error}</p>`}
      ${programs?.length > 0 && html`<div class="form-block"><span class="form-label">İçe aktarılmış programlar</span>
        <div class="rows">${programs.map((p) => html`<div class="item-row" key=${p.name}><div class="item-copy"><strong>${p.name}</strong><small>${p.count} kayıt${p.until ? " · " + parseDay(p.until).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" }) + " tarihine kadar" : ""}</small></div>
          ${confirmRemove === p.name
            ? html`<${Button} cls="danger-fill" icon="trash" onClick=${() => removeProgram(p.name)}>Hepsini sil<//><${Button} cls="ghost" onClick=${() => setConfirmRemove("")}>Vazgeç<//>`
            : html`<${Button} cls="ghost" icon="trash" onClick=${() => setConfirmRemove(p.name)}>Kaldır<//>`}</div>`)}</div></div>`}
    </div>`;

  return html`<div class="import-preview">
    ${notes.map((n) => html`<p class="import-note" key=${n}>${n}</p>`)}
    <div class="import-meta">
      <label class="field"><span>Program adı</span><input value=${meta.name} maxlength="100" required placeholder="Güz dönemi dersleri" onInput=${(e) => setMeta({ ...meta, name: e.target.value })} /></label>
      <label class="field"><span>Başlangıç</span><input type="date" value=${meta.start} onChange=${(e) => setMeta({ ...meta, start: e.target.value || today() })} /></label>
      <label class="field"><span>Bitiş (isteğe bağlı)</span><input type="date" value=${meta.until} min=${meta.start} onChange=${(e) => setMeta({ ...meta, until: e.target.value })} /></label>
    </div>
    <div class="form-block"><span class="form-label">Kategori</span><${ChipRow} name="import-category" small items=${Object.entries(CATEGORY_NAMES).map(([k, n]) => [n, k])} value=${(v) => v === meta.category} onPick=${(v) => setMeta({ ...meta, category: v })} /></div>
    <${Toggle} label="Hatırlat" hint=${meta.remind ? "Her kaydın saatinde bir kez bildirim gelir." : "Kapalı: takvimde ve Bugün'de görünür, bildirim gelmez."} on=${meta.remind} onChange=${(v) => setMeta({ ...meta, remind: v })} name="import-remind" />
    <div class="import-table" role="table" aria-label="Önizleme">
      <div class="import-row head" role="row"><span>Gün</span><span>Başlangıç</span><span>Bitiş</span><span>Ad</span><span></span></div>
      ${rows.map((r) => html`<div class=${"import-row" + (r.end <= r.start ? " invalid" : "")} role="row" key=${r.key}>
        <select aria-label="Gün" value=${r.day} onChange=${(e) => edit(r.key, { day: e.target.value })}>${IMPORT_DAYS.map(([n, v]) => html`<option value=${v}>${n}</option>`)}</select>
        ${timeInput(r, "start")}${timeInput(r, "end")}
        <input value=${r.title} maxlength="200" placeholder="Ders / iş adı" aria-label="Ad" onInput=${(e) => edit(r.key, { title: e.target.value })} />
        <${Button} cls="icon-button" icon="close" aria-label="Satırı sil" onClick=${() => setRows(rows.filter((x) => x.key !== r.key))} />
      </div>`)}
    </div>
    <div class="toolbar"><${Button} cls="ghost" icon="plus" onClick=${() => { const last = rows[rows.length - 1]; setRows([...rows, { key: Date.now(), day: last?.day || "Monday", start: last?.end || 540, end: (last?.end || 540) + 50, title: "" }]); }}>Satır ekle<//></div>
    ${busy && html`<p class="muted">${busy}</p>`}${error && html`<p class="inline-error">${error}</p>`}
    <div class="dialog-actions"><${Button} cls="ghost" onClick=${() => { setStep("pick"); setError(""); }}>Geri<//><${Button} cls="primary" icon="check" onClick=${save} disabled=${!!busy || !rows.length}>Takvime ekle (${rows.filter((r) => r.title.trim()).length})<//></div>
  </div>`;
}
function scheduleImportDialog() {
  openDialog("Program içe aktar", '<div id="schedule-import-root"></div>', { wide: true });
  htmPreact.render(html`<${ScheduleImportView} />`, $("#schedule-import-root"));
}
