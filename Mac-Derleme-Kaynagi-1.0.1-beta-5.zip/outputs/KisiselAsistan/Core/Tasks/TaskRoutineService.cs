namespace KisiselAsistan;

public record RoutineTaskStep(string Text, bool Done = false);
// Görev görünümü: saati olmayan işler (Item). Tekrarlı iş "Her gün yap" (DailyActivity) olarak görünür;
// RepeatDays haftanın hangi günleri olduğunu söyler (127 = her gün).
public record RoutineTask(Guid Id, string Title, string List, List<RoutineTaskStep> Steps,
    bool Important = false, DateOnly? Due = null, DateOnly? MyDay = null, string Repeat = "none", bool Done = false, bool DailyActivity = false, DateOnly? StartsOn = null, List<DateOnly>? CompletedDays = null, Guid? PreviousOccurrence = null, int? RepeatDays = null);

public sealed class TaskRoutineService
{
    private readonly ItemStore store;
    private long generation = -1;
    private List<RoutineTask> view = [];
    public TaskRoutineService(string path) : this(new ItemStore(path)) { }
    public TaskRoutineService(ItemStore store) => this.store = store;

    public List<RoutineTask> Items
    {
        get {
            var items = store.Read();
            if (generation != store.Generation) { view = items.Where(i => !i.Timed).Select(ToTask).ToList(); generation = store.Generation; }
            return view.Select(t => t with { Steps = [.. t.Steps], CompletedDays = t.CompletedDays is null ? null : [.. t.CompletedDays] }).ToList();
        }
    }
    private static RoutineTask ToTask(Item item) => item.Repeat is { } repeat
        ? new(item.Id, item.Title, item.List, [.. item.Steps ?? []], item.Important, item.Deadline, null, repeat.DaysMask == ItemRepeat.EveryDay ? "daily" : "weekly", false, true, repeat.Start,
            (item.Occurrences ?? []).Where(o => o.Value.Done).Select(o => Item.ParseKey(o.Key)).Order().ToList(), RepeatDays: repeat.DaysMask)
        : new(item.Id, item.Title, item.List, [.. item.Steps ?? []], item.Important, item.Deadline, item.Day, "none", item.Done);

    public void Save(RoutineTask task)
    {
        if (string.IsNullOrWhiteSpace(task.Title) || task.Title.Length > 500 || string.IsNullOrWhiteSpace(task.List)) throw new ArgumentException("Görev ve liste adı yaz.");
        if (task.Repeat is not ("none" or "daily" or "weekly")) throw new ArgumentException("Tekrar seçimi geçersiz.");
        if (task.RepeatDays is < 1 or > 127) throw new ArgumentException("Tekrar için en az bir gün seç.");
        task = task with { Title = task.Title.Trim(), List = task.List.Trim(), Steps = task.Steps.Where(s => !string.IsNullOrWhiteSpace(s.Text)).Select(s => s with { Text = s.Text.Trim() }).ToList() };
        store.Modify(items => {
            var i = items.FindIndex(t => t.Id == task.Id);
            var next = ToItem(task, i < 0 ? null : items[i]);
            if (i < 0) items.Add(next); else items[i] = next;
            return items;
        });
    }
    // Görev alanları işe yazılır; işin görevde görünmeyen alanları (süre, kategori, bildirim …) korunur.
    private static Item ToItem(RoutineTask task, Item? existing)
    {
        var item = (existing ?? new Item(task.Id, task.Title, Created: DateTimeOffset.Now)) with {
            Title = task.Title, List = task.List, Steps = task.Steps, Priority = task.Important ? 3 : existing?.Priority is int p && p != 3 ? p : 2, Deadline = task.Due, At = null
        };
        if (!task.DailyActivity && task.Repeat == "none")
            return item with { Repeat = null, Occurrences = null, Day = task.MyDay, Done = task.Done };
        var start = task.StartsOn ?? existing?.Repeat?.Start ?? task.Due ?? task.MyDay ?? DateOnly.FromDateTime(DateTime.Today);
        // Formda "Tekrar" değiştiyse eski gün maskesi geçersizdir (her gün ⇔ 127).
        var given = task.RepeatDays is int days && (days == ItemRepeat.EveryDay) == (task.Repeat != "weekly") ? days : (int?)null;
        var mask = given ?? (task.Repeat == "weekly" ? existing?.Repeat is { DaysMask: not ItemRepeat.EveryDay } old ? old.DaysMask : 1 << (int)start.DayOfWeek : ItemRepeat.EveryDay);
        var states = new Dictionary<string, OccurrenceState>((existing?.Occurrences ?? []).Where(o => !o.Value.Done));
        foreach (var day in task.CompletedDays ?? []) states[Item.Key(day)] = (existing?.StateOn(day) ?? new()) with { Done = true };
        return item with { Day = null, Done = false, State = null, Repeat = new(mask, start, existing?.Repeat?.Until), Occurrences = states.Count == 0 ? null : states };
    }
    public static bool IsOnDay(RoutineTask task, DateOnly day) => task.DailyActivity
        ? day >= (task.StartsOn ?? DateOnly.MinValue) && ((task.RepeatDays ?? ItemRepeat.EveryDay) & (1 << (int)day.DayOfWeek)) != 0 && !(task.CompletedDays?.Contains(day) ?? false)
        : !task.Done && (task.MyDay == day || task.Due == day);
    public static List<Reminder> Extras(IEnumerable<Reminder> reminders, DateOnly day) => reminders.Where(r => !r.Done && DateOnly.FromDateTime(r.Due.LocalDateTime) == day).OrderBy(r => r.Due).ToList();
    private void Edit(Guid id, Func<Item, Item> change) => store.Modify(items => items.Select(i => i.Id == id && !i.Timed ? change(i) : i).ToList());
    public void CompleteDay(Guid id, DateOnly day) => Edit(id, i => i.Repeat is null ? i : i.WithState(day, i.StateOn(day) with { Done = true }));
    public void Restore(Guid id, DateOnly day) => Edit(id, i => i.Repeat is null ? i with { Done = false } : i.WithState(day, i.StateOn(day) with { Done = false }));
    public void Remove(Guid id) => store.Modify(items => items.Where(t => t.Id != id).ToList());
    // Sürükle-bırak: verilen görevler, kendi kapladıkları yerlerde yeni sıraya dizilir; diğerleri yerinde kalır.
    // Ekranda yalnızca bir kısmı görünen (süzülmüş) liste de böylece öbür görevleri bozmadan sıralanır.
    public void Reorder(IReadOnlyList<Guid> ids) => store.Modify(items => {
        if (ids.Distinct().Count() != ids.Count) throw new ArgumentException("Sıra listesi geçersiz.");
        var slots = items.Select((t, i) => (t, i)).Where(x => ids.Contains(x.t.Id)).Select(x => x.i).ToList();
        if (slots.Count != ids.Count) throw new ArgumentException("Görev bulunamadı.");
        var moved = ids.Select(id => items.First(t => t.Id == id)).ToList();
        for (var k = 0; k < slots.Count; k++) items[slots[k]] = moved[k];
        return items;
    });
    // Tekrarlı iş için "tamamla" o günü tamamlar; tekrar kuralı kendiliğinden sürer, yeni kopya oluşturulmaz.
    public void Complete(Guid id, DateOnly today) => Edit(id, i => i.Repeat is null
        ? i with { Done = true, Steps = (i.Steps ?? []).Select(s => s with { Done = true }).ToList() }
        : i.WithState(today, i.StateOn(today) with { Done = true }));
}
