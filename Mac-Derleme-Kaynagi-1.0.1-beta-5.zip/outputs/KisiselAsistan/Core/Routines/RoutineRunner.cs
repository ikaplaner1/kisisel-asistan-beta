namespace KisiselAsistan;

public record RoutineNameRequest(string Name);

// Kısayolları çalıştırır ve o anki durumu tutar. Aynı anda tek kısayol çalışır.
// Running yalnızca bir kısayol gerçekten sürerken doğrudur; arayüz "Durdur"u buna göre gösterir.
// launch: adımı platforma göre açan işlev (Mac'te `open`); verilmezse RoutineService Windows yolunu kullanır.
internal sealed class RoutineRunner(RoutineService service, Func<RoutineStep, Task>? launch = null)
{
    private CancellationTokenSource? run;
    internal bool Running => run != null;
    internal string State { get; private set; } = "";
    internal event Action? Changed;
    internal void Start(Guid id)
    {
        if (run != null) throw new InvalidOperationException("Bir kısayol zaten çalışıyor.");
        var routine = service.Items.FirstOrDefault(r => r.Id == id) ?? throw new ArgumentException("Kısayol bulunamadı.");
        _ = RunAsync(routine);
    }
    internal CommandResult StartNamed(string target)
    {
        if (run != null) return new(false, "Bir kısayol zaten çalışıyor.");
        var found = RoutineVoice.Find(service.Items, target);
        if (found.Length != 1) return new(false, found.Length == 0 ? "Bu isimde kısayol bulunamadı. Kısayollar bölümünden ekleyebilirsin." : "Birden fazla kısayol eşleşti. Tam adını söyle.");
        _ = RunAsync(found[0]);
        return new(true, "Kısayol başlatıldı: " + found[0].Name);
    }
    internal void Stop() => run?.Cancel();
    private void Set(string text) { State = text; Changed?.Invoke(); }
    private async Task RunAsync(Routine routine)
    {
        run = new();
        try {
            Set(routine.Name + " başlıyor…");
            var errors = await service.RunAsync(routine, run.Token, (i, total) => Set($"{routine.Name} · {i}/{total} · {Describe(routine.Steps[i - 1])}"), launch);
            Set(errors.Count == 0 ? routine.Name + " tamamlandı." : string.Join(" | ", errors));
        } catch (OperationCanceledException) { Set("Kısayol durduruldu. Oluşturulan hatırlatıcılar ve açılan uygulamalar kalır."); }
        catch (Exception ex) { Set(ex.Message); }
        finally { run.Dispose(); run = null; Changed?.Invoke(); }
    }
    internal static string Describe(RoutineStep step) => step.Kind switch {
        "wait" => $"{step.Minutes} dakika bekle",
        "reminder" => $"{step.Minutes} dakika sonra: {step.Target}",
        "web" => step.Target,
        _ => step.Label ?? Path.GetFileNameWithoutExtension(step.Target)
    };
}
