using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace KisiselAsistan;

// İşlerin tek dosyası: { "Version": 2, "Items": [...] }. Atomik yazar, süreçler arası kilit kullanır.
// Eski biçimdeki bir dosya (hatırlatıcı ya da görev dizisi) okunursa bellekte yeni modele çevrilir;
// dosya ancak ilk değişiklikte yeni biçimle yazılır.
public sealed class ItemStore
{
    internal const int Version = 2;
    private sealed record ItemFile(int Version, List<Item> Items);
    private readonly string path, mutexName;
    // Dosya değişmedikçe aynı nesneler döner; görünümler (hatırlatıcı/görev) bu sürüm numarasıyla önbellek tutar.
    private (DateTime Written, long Length) stamp;
    private List<Item>? cached;
    internal long Generation { get; private set; }
    public ItemStore(string path)
    {
        this.path = Path.GetFullPath(path);
        mutexName = (OperatingSystem.IsWindows() ? "Local\\KisiselAsistanData-" : "KisiselAsistanData-") + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(this.path.ToUpperInvariant())));
    }
    internal string FilePath => path;

    public List<Item> Read() => Locked<List<Item>>(() => [.. Load()]);
    public void Modify(Func<List<Item>, List<Item>> edit) => Locked(() => {
        var next = edit([.. Load()]);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temporary = path + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(new ItemFile(Version, next)));
        for (var attempt = 0; ; attempt++) {
            try { File.Move(temporary, path, true); break; }
            catch (UnauthorizedAccessException) when (attempt < 4) { Thread.Sleep(50 * (attempt + 1)); }
            catch (IOException ex) when (attempt < 4 && (ex.HResult & 0xffff) is 32 or 33) { Thread.Sleep(50 * (attempt + 1)); }
        }
        Remember(next);
        return true;
    });

    private List<Item> Load()
    {
        if (!File.Exists(path)) { if (cached is null || stamp != default) { cached = []; stamp = default; Generation++; } return cached; }
        var info = new FileInfo(path);
        if (cached != null && stamp == (info.LastWriteTimeUtc, info.Length)) return cached;
        var text = File.ReadAllText(path);
        cached = Parse(text, DateTimeOffset.Now); stamp = (info.LastWriteTimeUtc, info.Length); Generation++;
        return cached;
    }
    private void Remember(List<Item> items)
    {
        var info = new FileInfo(path);
        cached = items; stamp = (info.LastWriteTimeUtc, info.Length); Generation++;
    }
    internal static List<Item> Parse(string text, DateTimeOffset now)
    {
        if (string.IsNullOrWhiteSpace(text)) return [];
        using var document = JsonDocument.Parse(text);
        var root = document.RootElement;
        if (root.ValueKind == JsonValueKind.Object) return root.Deserialize<ItemFile>()?.Items ?? throw new InvalidDataException("İş dosyası okunamadı.");
        if (root.ValueKind != JsonValueKind.Array) throw new InvalidDataException("İş dosyası okunamadı.");
        // Eski biçim: hatırlatıcı dizisi ("Text") ya da görev dizisi ("Title").
        var first = root.EnumerateArray().FirstOrDefault();
        if (first.ValueKind != JsonValueKind.Object) return [];
        if (first.TryGetProperty("Text", out _)) return LegacyItems.FromReminders(root.Deserialize<List<Reminder>>() ?? [], now);
        if (first.TryGetProperty("Title", out _)) return LegacyItems.FromTasks(root.Deserialize<List<RoutineTask>>() ?? [], DateOnly.FromDateTime(now.LocalDateTime));
        throw new InvalidDataException("İş dosyasının biçimi tanınmadı.");
    }
    private T Locked<T>(Func<T> action)
    {
        using var mutex = new Mutex(false, mutexName);
        var acquired = false;
        try {
            try { acquired = mutex.WaitOne(TimeSpan.FromSeconds(5)); } catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) throw new IOException("Kayıtlar meşgul. Tekrar dene.");
            return action();
        } finally { if (acquired) mutex.ReleaseMutex(); }
    }

    // Uygulamanın asıl deposu. items.json yoksa eski reminders.json ve routine-tasks.json'dan bir kez oluşturulur.
    // Eski dosyalara dokunulmaz; ayrıca yedek klasörüne kopyalanır. Eski sürüme dönülürse eski veri yerinde durur.
    public static ItemStore Open(string itemsPath, string legacyReminders, string legacyTasks, string backupRoot)
    {
        var store = new ItemStore(itemsPath);
        if (File.Exists(itemsPath)) return store;
        var sources = new[] { legacyReminders, legacyTasks }.Where(File.Exists).ToArray();
        if (sources.Length == 0) return store;
        var now = DateTimeOffset.Now;
        var items = new List<Item>();
        if (File.Exists(legacyTasks)) items.AddRange(Parse(File.ReadAllText(legacyTasks), now));
        if (File.Exists(legacyReminders)) items.AddRange(Parse(File.ReadAllText(legacyReminders), now));
        var backup = Path.Combine(backupRoot, "gecis-" + now.ToString("yyyyMMdd-HHmmss"));
        Directory.CreateDirectory(backup);
        foreach (var source in sources) File.Copy(source, Path.Combine(backup, Path.GetFileName(source)), true);
        store.Modify(_ => items);
        return store;
    }
}

// Eski iki kayıt türünü yeni modele çevirir.
internal static class LegacyItems
{
    internal static Item FromReminder(Reminder r) => new(r.Id, r.Text,
        Day: DateOnly.FromDateTime(r.Due.LocalDateTime), At: r.Due,
        Priority: (r.Plan ?? new()).Priority, Category: (r.Plan ?? new()).Category, DurationMinutes: (r.Plan ?? new()).DurationMinutes,
        Flexible: (r.Plan ?? new()).Certainty == PlanCertainty.Flexible, Notify: r.Options?.Normalize(), RemindDayBefore: r.Plan?.RemindDayBefore == true,
        Done: r.Done, State: new(SentCount: r.SentCount, NextNotice: r.NextNotice, Pressure: r.Pressure, AdvanceSentForDue: r.AdvanceSentForDue),
        Revision: r.Revision);

    internal static List<Item> FromReminders(IEnumerable<Reminder> reminders, DateTimeOffset now)
    {
        var result = new List<Item>();
        var all = reminders.ToList();
        foreach (var r in all.Where(r => r.Plan?.Weekly is not { SeriesId: var s } || s == Guid.Empty)) result.Add(FromReminder(r with { Plan = r.Plan is null ? null : r.Plan with { Weekly = null } }));
        foreach (var group in all.Where(r => r.Plan?.Weekly is { SeriesId: var s } && s != Guid.Empty).GroupBy(r => r.Plan!.Weekly!.SeriesId)) {
            // Seri "bu ve sonrakiler" diye düzenlendiyse aynı kimlikte birden çok kural vardır: sırayla parçalara ayrılır.
            string Signature(Reminder r) => JsonSerializer.Serialize(new { r.Text, Options = r.Settings, Plan = r.Plan! with { Weekly = r.Plan.Weekly! with { SeriesId = Guid.Empty } } });
            var segments = new List<List<Reminder>>();
            foreach (var r in group.OrderBy(r => r.Due)) {
                if (segments.Count == 0 || Signature(segments[^1][0]) != Signature(r)) segments.Add([]);
                segments[^1].Add(r);
            }
            for (var i = 0; i < segments.Count; i++) {
                var segment = segments[i]; var first = segment[0]; var rule = first.Plan!.Weekly!;
                var minutes = rule.TimeMinutes >= 0 ? rule.TimeMinutes : first.Due.LocalDateTime.Hour * 60 + first.Due.LocalDateTime.Minute;
                var start = DateOnly.FromDateTime(first.Due.LocalDateTime);
                DateOnly? until = i + 1 < segments.Count ? DateOnly.FromDateTime(segments[i + 1][0].Due.LocalDateTime).AddDays(-1) : null;
                var repeat = new ItemRepeat(rule.DaysMask, start, until is { } u && u < start ? start : until, minutes);
                var plan = first.Plan;
                var item = new Item(i == 0 ? group.Key : Guid.NewGuid(), first.Text, Repeat: repeat,
                    Priority: plan.Priority, Category: plan.Category, DurationMinutes: plan.DurationMinutes, Flexible: plan.Certainty == PlanCertainty.Flexible,
                    Notify: first.Options?.Normalize(), RemindDayBefore: plan.RemindDayBefore, SeriesId: group.Key);
                foreach (var r in segment) {
                    var day = DateOnly.FromDateTime(r.Due.LocalDateTime);
                    // Ertelenmiş (saati kuraldan kaymış) tekrar güvenli olsun diye ayrı, tek seferlik bir iş olur.
                    if (!repeat.Includes(day) || repeat.At(day) != r.Due) {
                        result.Add(FromReminder(r with { Id = Guid.NewGuid(), Plan = r.Plan! with { Weekly = null } }));
                        // Kuralın o günkü kopyası yerini ertelenmiş işe bırakır.
                        if (repeat.Includes(day)) item = item.WithState(day, new(Skipped: true));
                        continue;
                    }
                    var state = new OccurrenceState(r.Done, SentCount: r.SentCount, NextNotice: r.NextNotice, Revision: r.Revision, Pressure: r.Pressure, AdvanceSentForDue: r.AdvanceSentForDue);
                    if (state != new OccurrenceState() && state != new OccurrenceState(AdvanceSentForDue: null)) item = item.WithState(day, state);
                }
                result.Add(item);
            }
        }
        return result;
    }

    internal static List<Item> FromTasks(IEnumerable<RoutineTask> tasks, DateOnly today)
    {
        var list = tasks.ToList();
        var successors = list.Where(t => t.PreviousOccurrence != null).Select(t => t.PreviousOccurrence!.Value).ToHashSet();
        var result = new List<Item>();
        foreach (var t in list) {
            var basics = new Item(t.Id, t.Title, List: t.List, Steps: [.. t.Steps ?? []], Priority: t.Important ? 3 : 2, Deadline: t.Due);
            if (t.DailyActivity) {
                var item = basics with { Repeat = new(ItemRepeat.EveryDay, t.StartsOn ?? today) };
                foreach (var day in t.CompletedDays ?? []) item = item.WithState(day, new(Done: true));
                result.Add(item);
            } else if (t.Repeat is "daily" or "weekly" && !t.Done && !successors.Contains(t.Id)) {
                // Eski "tamamlayınca bir sonraki kopyayı oluştur" tekrarı tek bir kurala dönüşür.
                var start = t.Due ?? t.MyDay ?? t.StartsOn ?? today;
                result.Add(basics with { Deadline = null, Repeat = new(t.Repeat == "daily" ? ItemRepeat.EveryDay : 1 << (int)start.DayOfWeek, start) });
            } else result.Add(basics with { Day = t.MyDay ?? t.Due, Done = t.Done });
        }
        return result;
    }
}
