namespace KisiselAsistan;

// Stok takibi: kullanıcının verdiği ürün bağlantıları belirli aralıklarla okunur, stok/fiyat değişince bildirilir.
// Sayfa okuma StockDetector'da, kontrol ve bildirim kararları StockService'te, kayıt stock-watches.json'da.
public enum StockState { Unknown, InStock, OutOfStock, PreOrder, Blocked }
// Sayfa nasıl alınır: Auto önce düz istek dener, sayfa okunamazsa görünmez tarayıcıya geçer ve bunu öğrenir.
public enum StockFetchMode { Auto, Http, Browser }
// Kullanıcının kuralı: Text sayfada görününce (InStockWhenPresent) ya da kaybolunca stokta sayılır.
public sealed record StockRule(string Text, bool InStockWhenPresent);
public sealed record StockPricePoint(DateTimeOffset At, decimal Price);
public sealed record StockEvent(DateTimeOffset At, StockState State, decimal? Price);

public sealed record StockWatch
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public string Url { get; init; } = "";
    // Sayfadan okunan ad; kullanıcı kendi adını verdiyse CustomTitle önce gelir.
    public string Title { get; init; } = "";
    public string? CustomTitle { get; init; }
    public string? ImageUrl { get; init; }
    public string? Group { get; init; }
    public string? Note { get; init; }
    public StockState State { get; init; } = StockState.Unknown;
    // Kararın kısa gerekçesi ("Ürün verisi: InStock", "Sayfada 'Tükendi' yazıyor" …).
    public string? Evidence { get; init; }
    public decimal? Price { get; init; }
    public string? Currency { get; init; }
    public decimal? TargetPrice { get; init; }
    public bool NotifyPriceDrop { get; init; } = true;
    public bool NotifyOutOfStock { get; init; }
    // Telefon bağlıysa stok/fiyat bildirimi oraya da gider.
    public bool Phone { get; init; } = true;
    public int IntervalMinutes { get; init; } = 15;
    public bool Paused { get; init; }
    public StockFetchMode Mode { get; init; } = StockFetchMode.Auto;
    // Auto kipinde düz istek yetmedi, tarayıcıyla okundu: sonraki kontroller doğrudan tarayıcıyla yapılır.
    public bool BrowserNeeded { get; init; }
    public StockRule? Rule { get; init; }
    // Beden/renk/model: yalnız bu seçenek stoktaysa stokta sayılır (ürün verisi seçenekleri listeliyorsa).
    public string? Variant { get; init; }
    public DateTimeOffset AddedAt { get; init; } = DateTimeOffset.Now;
    // Son başarılı okuma ve son deneme (hata dahil).
    public DateTimeOffset? CheckedAt { get; init; }
    public DateTimeOffset? AttemptedAt { get; init; }
    public DateTimeOffset? InStockSince { get; init; }
    public string? Error { get; init; }
    public int Failures { get; init; }
    public bool ErrorNotified { get; init; }
    public int Checks { get; init; }
    public StockPricePoint[] PriceHistory { get; init; } = [];
    public StockEvent[] Events { get; init; } = [];

    public string Name => string.IsNullOrWhiteSpace(CustomTitle) ? (string.IsNullOrWhiteSpace(Title) ? Site : Title) : CustomTitle!;
    public string Site => Uri.TryCreate(Url, UriKind.Absolute, out var uri) ? (uri.Host.StartsWith("www.", StringComparison.OrdinalIgnoreCase) ? uri.Host[4..] : uri.Host) : Url;
    public decimal? LowestPrice => PriceHistory.Length > 0 ? PriceHistory.Min(p => p.Price) : Price;
    public bool AtTarget => TargetPrice is { } target && Price is { } price && price <= target;
    // Görünmez tarayıcıyla okunan sayfa (6–8 sn gerçek tarayıcı çalıştırır) en sık 30 dakikada bir okunur;
    // düz istekle okunanlar (bir saniyenin altında) seçilen sıklıkta. Kullanıcı daha kısa seçse de bu uygulanır.
    public const int BrowserMinimumMinutes = 30;
    public bool UsesBrowser => BrowserNeeded || Mode == StockFetchMode.Browser;
    public int EffectiveIntervalMinutes => UsesBrowser ? Math.Max(IntervalMinutes, BrowserMinimumMinutes) : IntervalMinutes;
    // Sıradaki kontrol: hata sürdükçe aralık ikiye katlanır (en çok 16 kat, en fazla 6 saat); siteyi yormamak için ±%10 kayma.
    public DateTimeOffset NextCheck
    {
        get {
            var last = AttemptedAt ?? CheckedAt;
            if (last is null) return AddedAt;
            var minutes = (double)EffectiveIntervalMinutes;
            if (Failures > 0) minutes = Math.Min(minutes * Math.Pow(2, Math.Min(Failures - 1, 4)), Math.Max(EffectiveIntervalMinutes, 360));
            var spread = (((Id.GetHashCode() & 0x7fffffff) % 1000 + Checks + Failures) % 21 - 10) / 100.0;
            return last.Value.AddMinutes(minutes * (1 + spread));
        }
    }
}

// Ekleme ve düzenleme formunun alanları.
public sealed record StockDraft
{
    public string Url { get; init; } = "";
    public string? Title { get; init; }
    public string? Group { get; init; }
    public string? Note { get; init; }
    public int IntervalMinutes { get; init; } = 15;
    public StockFetchMode Mode { get; init; } = StockFetchMode.Auto;
    public string? RuleText { get; init; }
    public bool RuleInStockWhenPresent { get; init; }
    public string? Variant { get; init; }
    public decimal? TargetPrice { get; init; }
    public bool NotifyPriceDrop { get; init; } = true;
    public bool NotifyOutOfStock { get; init; }
    public bool Phone { get; init; } = true;

    public static readonly int[] Intervals = [2, 5, 10, 15, 30, 60, 180, 360, 720, 1440];
    public Uri Validate()
    {
        var text = Url.Trim();
        if (!text.Contains("://")) text = "https://" + text;
        if (!Uri.TryCreate(text, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https") || string.IsNullOrEmpty(uri.Host) || !uri.Host.Contains('.'))
            throw new ArgumentException("Geçerli bir ürün bağlantısı yapıştır (https://… ile başlayan).");
        if (text.Length > 2000) throw new ArgumentException("Bağlantı çok uzun.");
        if (!Intervals.Contains(IntervalMinutes)) throw new ArgumentException("Kontrol sıklığı listeden seçilmeli.");
        if ((Title?.Length ?? 0) > 200 || (Group?.Length ?? 0) > 40 || (Note?.Length ?? 0) > 500 || (Variant?.Length ?? 0) > 80 || (RuleText?.Length ?? 0) > 120)
            throw new ArgumentException("Alanlardan biri çok uzun.");
        if (RuleText is { } rule && rule.Trim().Length is > 0 and < 3) throw new ArgumentException("İzlenecek yazı en az 3 harf olmalı.");
        if (TargetPrice is <= 0 or > 100_000_000) throw new ArgumentException("Hedef fiyat geçersiz.");
        return uri;
    }
    public StockRule? Rule => string.IsNullOrWhiteSpace(RuleText) ? null : new(RuleText.Trim(), RuleInStockWhenPresent);
    static string? Clean(string? text) => string.IsNullOrWhiteSpace(text) ? null : text.Trim();
    public StockWatch ApplyTo(StockWatch watch, Uri url) => watch with {
        Url = url.ToString(), CustomTitle = Clean(Title), Group = Clean(Group), Note = Clean(Note), IntervalMinutes = IntervalMinutes, Mode = Mode,
        Rule = Rule, Variant = Clean(Variant), TargetPrice = TargetPrice, NotifyPriceDrop = NotifyPriceDrop, NotifyOutOfStock = NotifyOutOfStock, Phone = Phone,
    };
}

// Bir okumanın sonucu: önizlemede gösterilir, kontrolde kayda işlenir. Signals: neye bakıldığı (önizlemede liste).
public sealed record StockReading(StockState State, string Evidence, string? Title, string? ImageUrl, decimal? Price, string? Currency, IReadOnlyList<string> Signals)
{
    public bool ViaBrowser { get; init; }
    public string? FinalUrl { get; init; }
    // Sayfa geldi ama ürün hakkında hiçbir şey okunamadı (çoğu zaman sayfa JavaScript ile çiziliyor).
    public bool Empty => State == StockState.Unknown && Title is null && Price is null;
}
public sealed record StockNotice(Guid Id, string Kind, string Title, string Message, string Url, bool Phone);
public sealed record StockCheckSummary(int Checked, int Errors, int InStock);
