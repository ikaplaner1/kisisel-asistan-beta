using System.Text.Json;

namespace KisiselAsistan;

// Komutun çözüldüğü anki durum: görünen listeler ve son seçimler ("ikinci hatırlatıcı", "sonuç 2", "seçili oyun").
public sealed record CommandContext(
    IReadOnlyList<Reminder> Reminders,
    IReadOnlyList<RoutineTask> Tasks,
    IReadOnlyList<SteamSearchItem> SteamResults,
    IReadOnlyList<SpotifyTrack> SpotifyResults,
    IReadOnlyList<SteamWatch> Watches,
    string SteamQuery = "",
    Guid? SelectedReminder = null,
    int? SelectedResult = null,
    int? SelectedWatch = null,
    DateTimeOffset? Now = null);

// Niyeti (Intent) tek bir işlem önerisine çevirir: Ollama'nın ürettiğiyle aynı tür (OperationProposal).
// Kayıt hedefleri burada çözülür; hedef belirsizse "none" önerisi ve açıklayıcı bir soru döner.
// "ui." ile başlayan işlemler kayıtta değil, masaüstü kabuğunda yapılır (seçim, tamamlama onayı).
// Message, işlem başarılı olursa gösterilecek cümledir.
public static class CommandResolver
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
    private static OperationProposal Propose(string operation, object parameters, string message = "") => new(operation, JsonSerializer.SerializeToElement(parameters, Json), message);
    private static OperationProposal Ask(string message) => Propose("none", new { }, message);

    public static OperationProposal Resolve(Intent intent, CommandContext c)
    {
        var now = c.Now ?? DateTimeOffset.Now;
        var today = DateOnly.FromDateTime(now.LocalDateTime);
        switch (intent.Kind) {
            case "clarify": return Ask(intent.Text);
            // Hatırlatıcılar
            case "reminder.add": {
                var due = intent.Due ?? now.AddSeconds(intent.Number);
                return Propose("reminder.add", new ReminderAddRequest(intent.Text, due), "Kaydedildi: " + intent.Text + " · " + When(due, now));
            }
            case "reminder.list": return Propose("reminder.list", new NoArguments());
            case "reminder.select": {
                if (intent.Number < 1 || intent.Number > c.Reminders.Count) return Ask("Geçerli bir hatırlatıcı numarası söyle.");
                var picked = c.Reminders[intent.Number - 1];
                return Propose("ui.selectReminder", new { id = picked.Id }, "Seçildi: " + picked.Text);
            }
            case "reminder.remove" or "reminder.snooze" or "reminder.complete": {
                var (found, error) = ReminderVoiceRemoval.Resolve(intent.Target ?? "", c.Reminders, c.Reminders, c.SelectedReminder, now.LocalDateTime);
                if (found is null) return Ask(error!);
                if (intent.Kind == "reminder.remove") return Propose("reminder.remove", new ReminderIdRequest(found.Id), "Silindi: " + found.Text);
                if (intent.Kind == "reminder.complete") return Propose("ui.completeReminder", new { id = found.Id }, found.Text);
                if (found.Settings.Level == ReminderIntensity.Adhd) return Ask("ADHD modunda erteleme kapalı. Tamamladığında ‘planı tamamladım’ diyebilirsin.");
                if (intent.Number is < 1 or > 525600) return Ask("Erteleme süresi geçersiz.");
                return Propose("reminder.snooze", new ReminderSnoozeRequest(found.Id, intent.Number), $"{intent.Number} dakika ertelendi: {found.Text}");
            }
            // Görevler
            case "task.add": {
                var someday = intent.Target == "someday";
                var day = someday ? (DateOnly?)null : intent.Day ?? today;
                var where = someday ? "bir ara listesine" : day == today ? "bugüne" : day == today.AddDays(1) ? "yarına" : day!.Value.ToString("d MMMM dddd", new System.Globalization.CultureInfo("tr-TR")) + " gününe";
                return Propose("task.add", new TaskAddRequest(intent.Text, day), $"Görev {where} eklendi: {intent.Text}");
            }
            case "task.complete": {
                var key = intent.Target ?? "";
                var open = c.Tasks.Where(t => !(t.DailyActivity ? t.CompletedDays?.Contains(today) == true : t.Done)).ToList();
                var matches = open.Where(t => ReminderVoiceRemoval.Fold(t.Title) == key).ToList();
                if (matches.Count == 0) matches = open.Where(t => (" " + ReminderVoiceRemoval.Fold(t.Title) + " ").Contains(" " + key + " ", StringComparison.Ordinal)).ToList();
                // Aynı adı taşıyanlardan bugüne ait olan tercih edilir.
                if (matches.Count > 1 && matches.Count(t => TaskRoutineService.IsOnDay(t, today)) == 1) matches = matches.Where(t => TaskRoutineService.IsOnDay(t, today)).ToList();
                if (key.Length == 0 || matches.Count == 0) return Ask("Bu adla açık bir görev bulamadım. Görevin adını söyle.");
                if (matches.Count > 1) return Ask("Birden fazla görev eşleşti: " + string.Join("; ", matches.Take(4).Select(t => t.Title)) + ". Tam adını söyle.");
                return Propose("task.complete", new TaskIdRequest(matches[0].Id), "Tamamlandı: " + matches[0].Title);
            }
            case "task.list": return Propose("task.list", new NoArguments());
            case "routine.start": return Propose("routine.start", new RoutineNameRequest(intent.Text));
            // Steam
            case "steam.search": return Propose("steam.search", new SteamQueryRequest(intent.Text));
            case "steam.trackNamed": return Propose("steam.trackNamed", new SteamQueryRequest(intent.Text));
            case "steam.unwatchNamed": {
                var matching = c.Watches.Where(w => string.Equals(w.Name, intent.Text, StringComparison.OrdinalIgnoreCase)).ToArray();
                if (matching.Length != 1) return Ask("Takip listesinde bu adla tek bir oyun bulamadım. Oyunu listeden seçerek takibi bırakabilirsin.");
                return Propose("steam.unwatch", new SteamIdRequest(matching[0].Id), matching[0].Name + " takibi bırakıldı.");
            }
            case "steam.trackResult":
                return intent.Number < 1 || intent.Number > c.SteamResults.Count ? Ask("Geçerli bir numara söyle.") : Propose("steam.track", new SteamIdRequest(c.SteamResults[intent.Number - 1].Id));
            case "steam.selectResult":
                return intent.Number < 1 || intent.Number > c.SteamResults.Count ? Ask("Geçerli bir sonuç numarası söyle.")
                    : Propose("ui.selectResult", new { index = intent.Number - 1 }, "Seçildi: " + c.SteamResults[intent.Number - 1].Name);
            case "steam.trackSelected": {
                var selected = c.SelectedResult is int i && i < c.SteamResults.Count ? c.SteamResults[i] : SteamService.SelectNamed(c.SteamQuery, c.SteamResults);
                return selected is null ? Ask("Hangi oyunu ekleyeceğin net değil. Oyun adını söyle veya listeden seç.") : Propose("steam.track", new SteamIdRequest(selected.Id));
            }
            case "steam.list": return Propose("steam.list", new NoArguments());
            case "steam.check": return Propose("steam.check", new NoArguments());
            case "steam.selectWatch":
                return intent.Number < 1 || intent.Number > c.Watches.Count ? Ask("Geçerli bir takip numarası söyle.")
                    : Propose("ui.selectWatch", new { id = c.Watches[intent.Number - 1].Id }, "Seçildi: " + c.Watches[intent.Number - 1].Name);
            case "steam.unwatchSelected": {
                var watch = c.Watches.FirstOrDefault(w => w.Id == c.SelectedWatch);
                return watch is null ? Ask("Önce takip seç: Steam takip 1 seç.") : Propose("steam.unwatch", new SteamIdRequest(watch.Id), watch.Name + " takibi bırakıldı.");
            }
            // Spotify
            case "spotify.open": return Propose("spotify.open", new NoArguments());
            case "spotify.status": return Propose("spotify.status", new NoArguments());
            case "spotify.control": return Propose("spotify.control", new SpotifyControlRequest(intent.Text));
            // Uygulamada arama: Spotify masaüstü uygulamasının arama sayfası (hesap bağlantısı gerekmez).
            case "spotify.search": return Propose("spotify.control", new SpotifyControlRequest("search", intent.Text.Trim('"', '“', '”', '\'').Trim()));
            case "spotify.play": return Propose("spotify.searchAndPlay", new SpotifyQueryRequest(intent.Text.Trim('"', '“', '”', '\'').Trim()));
            case "spotify.playResult":
                return intent.Number < 1 || intent.Number > c.SpotifyResults.Count ? Ask("Geçerli bir şarkı sonucu numarası söyle.") : Propose("spotify.playTrack", new SpotifyPlayRequest(c.SpotifyResults[intent.Number - 1]));
            case "spotify.volume":
                return intent.Number is < 0 or > 100 ? Ask("Ses seviyesi 0 ile 100 arasında olmalı.") : Propose("spotify.setVolume", new SpotifyPercentRequest(intent.Number));
            default: return Ask("Bu komutu çalıştıramadım.");
        }
    }
    // "bugün 14:30", "yarın 09:00", "22.10 18:00"
    internal static string When(DateTimeOffset due, DateTimeOffset now)
    {
        var local = due.LocalDateTime; var today = now.LocalDateTime.Date;
        var day = local.Date == today ? "bugün" : local.Date == today.AddDays(1) ? "yarın" : local.ToString("dd.MM");
        return day + " " + local.ToString("HH:mm");
    }
}
